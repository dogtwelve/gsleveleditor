//  ===================================================================================================================
//
//      PLATFORM (internal, project) - Vox xcode config
//
//  * See the common global xcode config file (in Internal) for a detailled explanation about this system.
//  * See the user debug project xcode config file (in ../voxConfig/xcconfig) for a detailled explanation
//    about user customisable configuration.
//
//  ===================================================================================================================

// Preprocessor Definitions (iPhone)
PLATFORM_GCC_PREPROCESSOR_DEFINITIONS[sdk=iphoneos*] = IPHONEDEVICE

// Preprocessor Definitions (Simulator)
PLATFORM_GCC_PREPROCESSOR_DEFINITIONS[sdk=iphonesimulator*] = IPHONESIMULATOR
