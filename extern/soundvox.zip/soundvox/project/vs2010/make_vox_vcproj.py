import os
import shutil

      
#
# Create the 2010 project from the 2008 project.
#

if os.path.exists('vox.vcproj'):
	os.remove('vox.vcproj')

if os.path.exists('vox.vcxproj'):
	os.remove('vox.vcxproj')
	
if os.path.exists('vox.vcxproj.filters'):
	os.remove('vox.vcxproj.filters')

shutil.copy('../vs9/vox.vcproj', 'vox.vcproj')
os.system('config_visual_studio_2010_express & vcupgrade vox.vcproj')

if os.path.exists('vox.vcproj'):
	os.remove('vox.vcproj')


