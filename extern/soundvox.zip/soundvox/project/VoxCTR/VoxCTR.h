//
// CTR - Library : VoxCTR
//

#ifndef	__VoxCTR_H__
#define	__VoxCTR_H__

//
// global symbol declared.
//
extern int g_VoxCTR;

//
// function prototypes.
//
void	VoxCTR(void);

//
// class definition.
//
class CVoxCTR
{
public:
	CVoxCTR();
};

#endif	// __VoxCTR_H__
