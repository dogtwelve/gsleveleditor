//
// CTR - Library : VoxCTR
//

#include <stdio.h>

#include <nn/os.h>
#include <nn/dbg.h>
#include "VoxCTR.h"

//
// global symbol definition.
//
int g_VoxCTR = 0;

//
// function definition.
//
void	VoxCTR(void)
{

}

//
// class definition.
//

// constructor
CVoxCTR::CVoxCTR()
{

}

