//  ===================================================================================================================
//
//      COMMON (internal, libvox) - Vox xcode config
//
//  * See the common global xcode config file (in Internal) for a detailled explanation about this system.
//  * See the user debug project xcode config file (in ../voxConfig/xcconfig) for a detailled explanation
//    about user customisable configuration.
//
//  ===================================================================================================================

// Target name
PRODUCT_NAME = libvox
MACH_O_TYPE = staticlib
