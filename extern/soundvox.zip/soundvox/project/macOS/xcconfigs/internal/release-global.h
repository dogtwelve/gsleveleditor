//  ===================================================================================================================
//
//      RELEASE (internal, global) - xcode config
//
//  * See the common global xcode config file (in Internal) for a detailled explanation about this system.
//  * See the user debug project xcode config file (in ../voxConfig/xcconfig) for a detailled explanation
//    about user customisable configuration.
//
//  ===================================================================================================================

// Optimization
GCC_OPTIMIZATION_LEVEL = 3

// Preprocessor definition
CONFIG_GCC_PREPROCESSOR_DEFINITIONS = NDEBUG
