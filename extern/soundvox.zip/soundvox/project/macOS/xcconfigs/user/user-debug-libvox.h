//  ===================================================================================================================
//
//      USER DEBUG (project) - Vox XCode Config User Override
//
//  ===================================================================================================================

// NOTE : You can use this file to override debug settings at the project level. You can find settings
//        examples and explanations in section "EXAMPLES AND IMPORTANT NOTES"


// --------------------------------------------------------------------------------------------------------------------
// User section (write your stuff below)
// --------------------------------------------------------------------------------------------------------------------


// --------------------------------------------------------------------------------------------------------------------
// EXAMPLES AND IMPORTANT NOTES
// --------------------------------------------------------------------------------------------------------------------

// --------------------
// Override
// --------------------

//NINJA_POWERS = ALWAYS

// --------------------
// Partial Override
// --------------------

// If you want to add a preprocessor definition, you should not override GCC_PREPROCESSOR_DEFINITIONS
// as you will lose the sєttings done by the project and targets. Instead, use the following user settings:
//
//     USER_COMMON_GCC_PREPROCESSOR_DEFINITIONS							// For common debug or release definitions (project)
//     USER_CONFIG_GCC_PREPROCESSOR_DEFINITIONS							// For debug/release definitions (project)
//     USER_PLATFORM_GCC_PREPROCESSOR_DEFINITIONS						// For platform definitions (project)
//     USER_TARGET_COMMON_GCC_PREPROCESSOR_DEFINITIONS					// For common definitions (target)
//     USER_TARGET_CONFIG_GCC_PREPROCESSOR_DEFINITIONS					// For debug/release definitions (target)
//     USER_TARGET_PLATFORM_GCC_PREPROCESSOR_DEFINITIONS				// For platform definitions (target)
//

// The same applies to HEADER_SEARCH_PATHS (use the following instead)

//     USER_COMMON_HEADER_SEARCH_PATHS									// For common debug or release definitions (project)
//     USER_CONFIG_HEADER_SEARCH_PATHS									// For debug/release definitions (project)
//     USER_PLATFORM_HEADER_SEARCH_PATHS								// For platform definitions (project)
//     USER_TARGET_COMMON_HEADER_SEARCH_PATHS							// For common definitions (target)
//     USER_TARGET_CONFIG_HEADER_SEARCH_PATHS							// For debug/release definitions (target)
//     USER_TARGET_PLATFORM_HEADER_SEARCH_PATHS							// For platform definitions (target)

// NOTE : You are discouraged to use USER_COMMON_* or USER_TARGET_COMMON_* directly in this file, as it won't
// be updated for both debug and release (since this file only affects debug). If you need a common definition,
// you can make your own user common configuration file and include it here, or duplicate the preprocessor
// definition and use USER_CONFIG_* or USER_TARGET_CONFIG_*.

