#pragma once
#ifndef _VOX_DRIVER_DATA_H_
#define _VOX_DRIVER_DATA_H_

#include "vox_default_config.h"

#if VOX_DRIVER_USE_DATA && VOX_DATA_DRIVER_PLATFORM

#if !defined(VOX_THREADING_MODE_NONE)
#error Data driver can only work in non-threaded mode
#endif

#include "vox_driver_callback_template.h"
#include "vox_internal.h"


namespace vox {


class DriverDataSource : public DriverCallbackSourceInterface
{
public:
	DriverDataSource(void * trackParam, void* driverParam, u32 sourceId = 0);
	virtual ~DriverDataSource();

	virtual void PrintDebug();
};

enum DriverDataOutputType
{
	k_nInvalidOutput,
	k_nBuffer,
	k_nFileRAW,
	k_nFileWave,
};

class DriverData : public DriverCallbackInterface
{
public:
	DriverData();
	virtual ~DriverData();

	static DriverData* GetInstance();

	virtual void Init(void* param);
	virtual void Shutdown();

	virtual void Suspend();
	virtual void Resume();

	virtual void PrintDebug();

	virtual DriverSourceInterface* CreateDriverSource(void * trackParam, void* driverParam, s32 priority = 0);
	virtual void DestroyDriverSource(DriverSourceInterface* driverSource);

	s32 UpdateOutput(f32 dt);//second
	bool SetOutputDestination(DriverDataOutputType type, void* param);

	bool OpenOutput();
	bool CloseOutput();
	
private:

	static DriverData* s_instance;
	DriverDataOutputType m_outputType;
	c8* m_callbackBuffer;
	s32 m_callbackBufferSize;
	f32 m_dtError;

	void* m_outputDestination;
	bool m_outputActive;

};

};//namespace vox

#endif //VOX_DRIVER_USE_DATA && VOX_DATA_DRIVER_PLATFORM


#endif //_VOX_DRIVER_DATA_H_
