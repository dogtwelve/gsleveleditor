#pragma once
#ifndef _VOX_DRIVER_ALSA_H_
#define _VOX_DRIVER_ALSA_H_

#include "vox_default_config.h"

#if VOX_DRIVER_USE_ALSA && VOX_ALSA_DRIVER_PLATFORM
#include "vox_driver_callback_template.h"
#include "vox_internal.h"
#include <alsa/asoundlib.h>

namespace vox {

class DriverAlsaSource : public DriverCallbackSourceInterface
{
public:
	DriverAlsaSource(void * trackParam, void* driverParam, u32 sourceId = 0);
	virtual ~DriverAlsaSource();

	virtual void PrintDebug();
};

class DriverAlsa : public DriverCallbackInterface
{
public:
	DriverAlsa();
	virtual ~DriverAlsa();

	virtual void Init(void* param);
	virtual void Shutdown();

	virtual void Suspend();
	virtual void Resume();	

	virtual void PrintDebug();

	virtual DriverSourceInterface* CreateDriverSource(void * trackParam, void* driverParam, s32 priority = 0);
	virtual void DestroyDriverSource(DriverSourceInterface* driverSource);
private:

	void DoCallback();
	void Recover(s32 errorType);

	static void UpdateThreaded(void* caller, void* param);
	static void playbackCallback(snd_async_handler_t *pcm_callback_handler);

	c8* m_outBuffer;
	snd_pcm_t *m_pcm_handle;
	snd_async_handler_t *m_pcm_callback;
	snd_pcm_uframes_t m_buffer_size;
	snd_pcm_uframes_t m_period_size;

	VoxThread* m_updateThread;
};

};//namespace vox

#endif //VOX_DRIVER_USE_ALSA && VOX_ALSA_DRIVER_PLATFORM
#endif //_VOX_DRIVER_ALSA_H_
