#pragma once
#ifndef _VOX_DECODER_NATIVE_H
#define _VOX_DECODER_NATIVE_H

#include "vox_decoder.h"
#include "vox_native_subdecoder.h"
#if !defined(_NN_CTR) && !defined(_PS3)
#include "vox_mswav_subdecoder_msadpcm.h"
#endif
#include "MSHeaders.h"
#include "NativeHeaders.h"
#include "vox_native_playlists.h"
#include "vox_memory.h"
#include VOX_MAP_INCLUDE


namespace vox {

typedef TrackParams DecoderNativeParams;


class DecoderNative : public DecoderInterface
{
 public:
	DecoderNative();
	virtual ~DecoderNative();

	virtual DecoderCursorInterface* CreateNewCursor(StreamCursorInterface* pStreamCursor);
	virtual void DestroyCursor(DecoderCursorInterface* pDecoderCursor);
	virtual s32 GetType(){return k_nDecoderTypeInteractiveMusic;}
	virtual void* GetParam(){return 0;}

	s32 GetFileSize();

	void AddCueToSegment(s32 segmentId);

	// Container creation methods
#if !defined(_NN_CTR) && !defined(_PS3)
	void CreateFmtExtendedInfosContainer(void);
#endif
	void CreatePlaylistsContainer(s32 nbPlaylists);
	void CreateSegmentsInfoContainers(s32 nbSegments, s32 segmentSize);
	void CreateStatesContainer(s32 nbStates);
	void CreateTransitionRulesContainer(s32 nbRules, s32 ruleSize);
	void CreateTransitionsContainer(s32 nbStates);

	// Accessor methods
	AudioSegments								*GetAudioSegments(){return &m_audioSegments;};
	NativeChunks								*GetNativeChunks(){return &m_nativeChunks;}
	STRING_MAP(s32, StringCompare)				*GetStateLabels(){return &m_stateLabels;};
	States										*GetStates(){return &m_states;};
	TransitionRules								*GetTransitionRules(){return &m_transitionRules;};
	NativePlaylistsManager						*GetPlaylistsManager(){return &m_playlists;};
#if !defined(_NN_CTR) && !defined(_PS3)
	FmtExtendedInfos							*GetFmtExtendedInfos(){return m_pFmtExtentedInfos;};
#endif

	DOUBLE_VECTOR(s32)		*GetSegmentsCues(){return &m_segmentsCues;};
	DOUBLE_VECTOR(TransitionParams)	*GetTransitions(){return &m_transitions;};

	// Parsing methods
	bool NeedParsing(){return m_needParsing;}
	void SetParsed(){m_needParsing = false;}
	
 private:
	NativeChunks					m_nativeChunks;
	AudioSegments					m_audioSegments;
	NativePlaylistsManager			m_playlists;
	States							m_states;
	TransitionRules					m_transitionRules;
	DOUBLE_VECTOR(s32)				m_segmentsCues;
	DOUBLE_VECTOR(TransitionParams)	m_transitions;
	STRING_MAP(s32, StringCompare)	m_stateLabels;

#if !defined(_NN_CTR) && !defined(_PS3)
	FmtExtendedInfos				*m_pFmtExtentedInfos;
#endif
	
	bool m_needParsing;
};


DecoderInterface* DecoderNativeFactory(void* params);


class DecoderNativeCursor : public DecoderCursorInterface
{
 protected:
	DecoderNativeCursor(DecoderInterface* pDecoder, StreamCursorInterface* pStreamCursor );

 public:
	virtual ~DecoderNativeCursor();
	virtual s32  Decode(void* outputBuffer, s32 nbSamples);
	virtual s32  Seek(u32 sampleNum);
	virtual bool HasData();
	virtual void SetLoop(bool loop);
	virtual void Reset(void);
#if VOX_NATIVE_REDUCE_LATENCY
	virtual s32	GetRewindLimit(void);	// In bytes
	virtual void Rewind(s32 nbBytes);
#endif

	void SetInteractiveMusicState(const char *stateLabel);
 private:
	NativeChunks								*m_pNativeChunks;	// Chunk information from parsed file.
	AudioSegments								*m_pAudioSegments;	// Description of audio segments as found in native file.
	States										*m_pStates;
	TransitionRules								*m_pTransitionRules;
	DOUBLE_VECTOR(TransitionParams)				*m_pTransitions;
	DOUBLE_VECTOR(s32)							*m_pSegmentsCues;
	STRING_MAP(s32, StringCompare)				*m_pStateLabels;
	NativePlaylistsManager						*m_pPlaylists;

#if !defined(_NN_CTR) && !defined(_PS3)
	FmtExtendedInfos							*m_pFmtExtentedInfos;
#endif

	// State parameters
	SIMPLE_LIST(s32)		m_statesList;			// List of states requested by game

	VoxNativeSubDecoder		*m_pSubDecoder;
	u32						m_decodeCount;

#if VOX_NATIVE_REDUCE_LATENCY
	NativeSubDecoderState	*m_pSubDecoderOldState;			// Snapshot of subdecoder's old state.
	NativeSubDecoderState	*m_pSubDecoderRecentState;		// Most recent snapshot of subdecoder's state.
	s32						m_nbBytesSinceOldSnapshot;		// Nb of bytes decoded since old snapshot.
	s32						m_nbBytesSinceRecentSnapshot;	// Nb of bytes decoded since recent snapshot.
	s32						m_maxRewindBytes;				// Max nb bytes that decoder can rewind.
	s32						m_nbBytesSinceLastTransition;
#endif

	Mutex m_mutex;

	s32 GetStateIndex(void);
	bool ParseFile();
	void SetImplicitSegmentCues(void);

	friend class DecoderNative;
};

}

#endif // _VOX_DECODER_NATIVE_H
