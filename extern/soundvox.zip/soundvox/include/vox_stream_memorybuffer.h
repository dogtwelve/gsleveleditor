#pragma once
#ifndef _VOX_STREAM_MEMORYBUFFER_H_
#define _VOX_STREAM_MEMORYBUFFER_H_

#include "vox_stream.h"

namespace vox {

struct StreamMemoryBufferParams
{
	StreamMemoryBufferParams():buffer(0), size(0), doCopy(false), takeOwnership(false){}
	u8* buffer;
	s32  size;
	bool doCopy;
	bool takeOwnership;
};

class StreamMemoryBuffer : public StreamInterface
{
public:
	StreamMemoryBuffer( StreamMemoryBufferParams* );
	virtual ~StreamMemoryBuffer();
	virtual StreamCursorInterface* CreateNewCursor();
	virtual void DestroyCursor(StreamCursorInterface* pStreamCursor);
	virtual s32 GetType(){return vox::k_nStreamTypeMemoryBuffer;}

	u8* GetBuffer() const { return m_buffer; }

protected:
	u8*		m_buffer;
	bool    m_isBufferOwned;
};

StreamInterface* StreamMemoryBufferFactory(void* params);

class StreamMemoryBufferCursor : public StreamCursorInterface
{
public:
	StreamMemoryBufferCursor(StreamInterface* pStream) : StreamCursorInterface(pStream), m_cursorPosition(0) {}
	
	virtual s32 Seek( s32 pos, s32 origin = ORIGIN_START );
	virtual bool IsSeekable(){return true;}
	virtual s32 Tell(){return m_cursorPosition;}
	virtual s32  Read( u8* buff, s32 len );
	virtual s32  ReadRef( u8* &buff, s32 len );
	virtual bool EndOfStream();

	virtual bool AllowBufferReference(){return true;}

	friend class StreamMemoryBuffer;

protected:
	s32 m_cursorPosition;
};

}

#endif //_VOX_STREAM_MEMORYBUFFER_H_
