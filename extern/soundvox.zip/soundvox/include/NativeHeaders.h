#pragma once
#ifndef _NATIVE_HEADERS_H
#define _NATIVE_HEADERS_H

#include "MSHeaders.h"
#include VOX_STRING_INCLUDE

namespace vox
{

#define NATIVE_CHUNK_HEADER_SIZE	8
#define NATIVE_VERSION_SIZE			8

// Native playback states
#define NATIVE_STATE_FORCED_STOP	0
#define NATIVE_STATE_STOPPED		1
#define NATIVE_STATE_IDLE			2
#define NATIVE_STATE_PLAYING		3
#define NATIVE_STATE_STOPPING		4

// Rule indexes indicating dynamic rule or stop applying rules
#define NATIVE_RULE_NONE	-1

// Segment definitions
#define NATIVE_SEGMENT_NONE		-1

// Define the absence of state
#define NATIVE_STATE_NONE	-1

// Define implicit cues
#define NATIVE_CUE_SEGMENT_START	0
#define NATIVE_CUE_PRE_ENTRY		1
#define NATIVE_CUE_POST_EXIT		2

// Define fade out length of dying segment (in samples)
#define NATIVE_FORCED_FADE_LENGTH	256

// Vector definitions
#ifdef WIN32
	#define SIMPLE_VECTOR(X)	VOX_VECTOR<X, SAllocator<X> >
	#define DOUBLE_VECTOR(X)	VOX_VECTOR<VOX_VECTOR<X, SAllocator<X>>, SAllocator<VOX_VECTOR<X, SAllocator<X>>>>
	#define SIMPLE_LIST(X)		VOX_LIST<X, SAllocator<X>>
	#define STRING_MAP(V,C)		VOX_MAP<VOX_STRING, V, C, SAllocator<std::pair<const VOX_STRING,V>>>
#else
	#define SIMPLE_VECTOR(X)	VOX_VECTOR<X, SAllocator<X> >
	#define DOUBLE_VECTOR(X)	VOX_VECTOR<VOX_VECTOR<X, SAllocator<X> >, SAllocator<VOX_VECTOR<X, SAllocator<X> > > >
	#define SIMPLE_LIST(X)		VOX_LIST<X, SAllocator<X> >
	#define STRING_MAP(V,C)		VOX_MAP<VOX_STRING, V, C, SAllocator<std::pair<const VOX_STRING,V> > >
#endif


// TODO : See where it should be put (or use stringcomp in vox xml file) (Robert)
struct StringCompare
{
  bool operator() (const VOX_STRING& lhs, const VOX_STRING& rhs) const
  {return lhs<rhs;}
};

// Definitions of chunk names
const u32 k_idChunkName = 0x4E786F56;
const u32 k_formatChunkName = 0x746D6641;
const u32 k_dataChunkName = 0x61746144;
const u32 k_segmentsChunkName = 0x6D676553;
const u32 k_cuesChunkName = 0x73657543;
const u32 k_groupsChunkName = 0x73707247;
const u32 k_playlistElementsChunkName = 0x65707247;
const u32 k_playlistsChunkName = 0x74736C50;
const u32 k_rulesChunkName = 0x656C7552;
const u32 k_transitionsChunkName = 0x6E737254;
const u32 k_statesChunkName = 0x74617453;
const u32 k_noChunk = 0x656E6F6E;
const u32 k_msAdpcmExtensionChunkName = 0x6561734D;


enum SegmentLifeState
{
	k_nSegmentNone,
	k_nSegmentCurrent,
	k_nSegmentOld,
	k_nSegmentDying
};


struct NativeChunkHeader
{
	u32 m_id;
	s32	m_size;

	void SwitchEndian()
	{
		char *tmp = (char*)&m_size;
		m_size = tmp[3] + (tmp[2] << 8) + (tmp[1] << 16) + (tmp[0] << 24);
	}
};


struct NativeFileInfos
{
	char	m_version[NATIVE_VERSION_SIZE];	// Native file format version.
	s32		m_fileSize;						// File size in bytes.
	s32		m_dataStart;					// Position of first data byte from start of file (in bytes).

	NativeFileInfos():m_dataStart(0){}
};


struct AudioFormat
{
	s16 m_compressionCode;
	s16 m_nbChannels;
	s32 m_sampleRate;
	s16 m_blockAlign;
	s16 m_bitsPerSample;

	AudioFormat():m_compressionCode(0), m_nbChannels(0), m_sampleRate(0), m_blockAlign(0), m_bitsPerSample(0) {}

	void Reset(void)
	{
		m_compressionCode = 0;
		m_nbChannels = 0;
		m_sampleRate = 0;
		m_blockAlign = 0;
		m_bitsPerSample = 0;
	}
};


struct MsAdpcmFormatExt
{
	s16 m_nbSamplesPerBlock;
	s16 m_nbCoefficients;		// Size of 'couples' array m_pCoefficients (e.g. 'n' means m_pCoefficients[n][2])
	s16 *m_pCoefficients;

	MsAdpcmFormatExt(): m_nbSamplesPerBlock(0), m_nbCoefficients(0), m_pCoefficients(0) {}

	void Reset(void)
	{
		m_nbSamplesPerBlock = 0;
		m_nbCoefficients = 0;
		m_pCoefficients = 0;
	}
};


struct DataBuffer
{
	unsigned int	m_bufferSize;
	char			*m_pBuffer;
	
	DataBuffer():m_bufferSize(0), m_pBuffer(0) {}
};

enum ExitPointType
{
	k_nExitImmediate,
	k_nExitNextGrid,
	k_nExitNextBar,
	k_nExitNextBeat,
	k_nExitNextCue,
	k_nExitCustomCue,
	k_nExitPostExitCue
};


enum EntryPointType
{
	k_nEntryPreEntryCue,
	k_nEntrySameTime
};



struct TransitionRule
{
	s32	m_entryPointType;		// Type of entry point into segment pointed to by this rule.
	s32	m_exitPointType;		// Type of exit point from segment currently playing.
	s32	m_playPreEntry;			// Play the pre-entry section of the segment pointed to by this rule.
	s32	m_playPostExit;			// Play the post-exit section of the segment currently playing.
	f32	m_fadeInLength;			// Fade in time of new segment to play (in seconds).
	f32	m_fadeInOffset;
	f32	m_fadeOutLength;		// Fade out time of segment to stop (in seconds).
	f32	m_fadeOutOffset;
	s32	m_transitionSegment;	// Index transition block between source and destination.

	TransitionRule(): m_entryPointType(k_nEntryPreEntryCue), m_exitPointType(k_nExitPostExitCue),
					  m_playPreEntry(0), m_playPostExit(0), m_fadeInLength(0.0f), m_fadeInOffset(0.0f),
					  m_fadeOutLength(0.0f), m_fadeOutOffset(0.0f), m_transitionSegment(-1) {}

	void Reset(void)
	{
		m_entryPointType = k_nEntryPreEntryCue;
		m_exitPointType = k_nExitPostExitCue;
		m_playPreEntry = 0;
		m_playPostExit = 0;
		m_fadeInLength = 0.0f;
		m_fadeInOffset = 0.0f;
		m_fadeOutLength = 0.0f;
		m_fadeOutOffset = 0.0f;	
		m_transitionSegment = -1;
	}
};


struct TransitionRules
{
	s32				m_nbRules;
	TransitionRule	*m_pBuffer;

	TransitionRules():m_nbRules(0), m_pBuffer(0) {}
};


struct AudioSegment
{
	u32 m_start;		// Offset (in bytes) relative to beginning of data section of 'Data' chunk.
	u32 m_size;			// Size of segment (in bytes)
	u32 m_nbSamples;	// Nb of samples per channel of audio segment
	u32 m_bpm;			// Nb of beats per minute (for music with beats).
	u32 m_beatsPerBar;
	u32 m_barOffset;	// Nb of samples between segment start and bar preceding start.

	AudioSegment():m_start(0), m_size(0), m_nbSamples(0), m_bpm(0), m_beatsPerBar(0), m_barOffset(0) {}

	void Reset(void)
	{
		m_start = 0;
		m_size = 0;
		m_nbSamples = 0;
		m_bpm = 0;
		m_beatsPerBar = 0;
		m_barOffset = 0;
	}
};


struct AudioSegments
{
	s32				m_nbSegments;
	AudioSegment	*m_pBuffer;

	AudioSegments():m_nbSegments(0), m_pBuffer(0){}
};


struct FadeParameters
{
	s32			m_startOffset;			// Nb of samples before fade start (relative to first decode block with fade).
	s32			m_nbSamples;			// Total nb of samples to fade.
	s32			m_nbSamplesRemaining;	// Nb samples remaining to fade.
	fx1715		m_gainChange;			// Multiplier change for fade (negative for fade out).
	fx1715		m_gain;					// Multiplier used for segment fade.

	FadeParameters():m_startOffset(0), m_nbSamples(0), m_nbSamplesRemaining(0),
					 m_gainChange(0), m_gain(0) {}

	void Reset(void)
	{
		m_startOffset = 0;
		m_nbSamples = 0;
		m_nbSamplesRemaining = 0;
		m_gainChange = 0;
		m_gain = 0;
	}
};


struct SegmentState
{
	s32				m_index;				// Index of segment in AudioSegment array.
	s32				m_lifeState;			// Life cycle state of segment.
	u32				m_position;				// Segment position in bytes (relative to segment start).
	u32				m_totalSamplesDecoded;	// Nb of samples decoded since start of segment.
	u32				m_startCue;				// Playback starting point (in samples, relative to start of segment).
	u32				m_endCue;				// Playback end point (in samples, relative to start of segment).
	s32				m_nbLoops;				// Nb of loops to do (-1 to loop indefinitely).
	s32				m_nbLoopsRemaining;		// Nb of loops still remaining.
	s32				m_playPostExit;			// 1 if post-exit should be played.
	s32				m_playbackState;		// TODO : See if values should be from an enum instead of defines
	FadeParameters	m_fadeParameters;
	s32				m_adpcmBufferIndex;		// Index of adpcm decoding buffer.
	bool			m_setAdpcmBufferCursor;	// Set cursor position in adpcm decode buffer.

	SegmentState():m_index(-1), m_lifeState(k_nSegmentNone), m_position(0), m_totalSamplesDecoded(0),
				   m_startCue(0), m_endCue(0), m_nbLoops(1), m_nbLoopsRemaining(1), m_playPostExit(0),
				   m_playbackState(NATIVE_STATE_IDLE), m_adpcmBufferIndex(-1),
				   m_setAdpcmBufferCursor(false) {}

	void Reset(void)
	{
		m_index = -1;
		m_lifeState = k_nSegmentNone;
		m_position = 0;
		m_totalSamplesDecoded = 0;
		m_startCue = 0;
		m_endCue = 0;
		m_nbLoops = 1;
		m_nbLoopsRemaining = 1;
		m_playPostExit = 0;
		m_playbackState = NATIVE_STATE_IDLE;
		m_adpcmBufferIndex = -1;
		m_setAdpcmBufferCursor = false;

		m_fadeParameters.Reset();
	}
};

// Structure used to contain segment cue information on file.
struct SegmentCue
{
	s32 m_cueIndex;			// Index of cue within segment.
	s32 m_segmentIndex;		// Index of segment containing cue.
	u32 m_sampleOffset;		// Cue position in samples (relative to segment start).

	SegmentCue(): m_cueIndex(-1), m_segmentIndex(-1), m_sampleOffset(0) {}

	void Reset(void)
	{
		m_cueIndex = -1;
		m_segmentIndex = -1;
		m_sampleOffset = 0;
	}
};


struct SegmentCues
{
	s32				m_nbCues;
	SegmentCue		*m_pBuffer;

	SegmentCues():m_nbCues(0), m_pBuffer(0) {}
};


enum PlaylistSelectMode
{
	k_nSelectionUnforced,			// Playlist chooses group element based on GroupSwitchMode and GroupElementSelectMode.
	k_nSelectionSamePosition,		// Required playlist element has same position than current playlist element
	k_nSelectionTransitionSegment	// Request for a specific playlist element (no contained in group).
};

enum GroupElementSelectMode
{
	k_nSelectSequential,
	k_nSelectRandom
};

enum GroupSwitchMode
{
	k_nSwitchContinuous,
	k_nSwitchStep
};

enum GroupResetType
{
	k_nGroupFullReset,
	k_nGroupPartialReset
};

struct PlaylistElementInfos
{
	s32 m_playlist;				// Index of playlist containing group element.
	s32 m_index;				// Position of group element in playlist.
	s32	m_groupIndex;			// Index of group containing segment.
	s32	m_segmentIndex;			// Index of segment representing the group element.
	s32 m_playPreEntry;
	s32 m_playPostExit;
	s32 m_nbLoops;				// Nb of loops between pre-entry and post-exit points.
	s32 m_weight;				

	PlaylistElementInfos():m_playlist(-1), m_index(-1), m_groupIndex(-1), m_segmentIndex(-1),
						   m_playPreEntry(0), m_playPostExit(0), m_nbLoops(1), m_weight(1) {}

	void Reset(void)
	{
		m_playlist = -1;
		m_index = -1;
		m_groupIndex = -1;
		m_segmentIndex = -1;
		m_playPreEntry = 0;
		m_playPostExit = 0;
		m_weight = 1;
	}
};


struct PlaylistElements
{
	s32						m_nbElements;
	PlaylistElementInfos	*m_pBuffer;

	PlaylistElements():m_nbElements(0), m_pBuffer(0) {}
};


struct GroupInfos
{
	s32	m_playlist;			// Index of playlist containing group.
	s32	m_playlistPosition;	// Position of group within playlist.
	s32	m_selectMode;		// Segment's selection mode within group (sequential or random)
	s32	m_selectParameter;	// Parameter associated with selection mode.
	s32	m_nbLoops;			// Nb of times a group can loop
	s32	m_playcount;		// Nb of group elements that can play before group is done (-1 = infinite).
	
	GroupInfos(): m_playlist(-1), m_playlistPosition(-1), m_selectMode(k_nSelectSequential), m_selectParameter(0),
				  m_nbLoops(1), m_playcount(-1) {}

	void Reset(void)
	{
		m_playlist = -1;
		m_playlistPosition = -1;
		m_selectMode = k_nSelectSequential;
		m_selectParameter = 0;
		m_nbLoops = 1;
		m_playcount = -1;
	}
};

struct SegmentGroups
{
	s32			m_nbGroups;
	GroupInfos	*m_pBuffer;

	SegmentGroups():m_nbGroups(0), m_pBuffer(0) {}
};


struct PlaylistInfos
{
	s32	m_switchMode;
	s32	m_nbLoops;
	
	PlaylistInfos(): m_switchMode(k_nSwitchContinuous), m_nbLoops(1) {}

	void Reset(void)
	{
		m_switchMode = k_nSwitchContinuous;
		m_nbLoops = 1;
	}
};

struct Playlists
{
	s32				m_nbPlaylists;
	PlaylistInfos	*m_pBuffer;

	Playlists():m_nbPlaylists(0), m_pBuffer(0){}
};


struct StateInfos
{
	s32		m_playlistIndex;
	char	m_label[28];		// String representing state label.

	StateInfos() {Reset();}

	void Reset(void)
	{
		m_playlistIndex = -1;
		m_label[0] = 0;
	}
};


struct States
{
	s32	m_nbStates;
	s32	*m_pPlaylistIndexes;

	States():m_nbStates(0), m_pPlaylistIndexes(0) {}
};


struct StatesInfos
{
	s32			m_nbStates;
	StateInfos	*m_pBuffer;

	StatesInfos():m_nbStates(0), m_pBuffer(0) {}
};


struct TransitionParams
{
	s32		m_ruleIndex;
	s32		m_resetPlaylist;

	TransitionParams():m_ruleIndex(-1), m_resetPlaylist(0) {}

	void Reset(void)
	{
		m_ruleIndex = -1;
		m_resetPlaylist = 0;
	}
};


struct Transition
{
	s32	m_fromState;
	s32	m_toState;
	TransitionParams m_parameters;

	Transition(): m_fromState(0), m_toState(0) {}

	void Reset(void)
	{
		m_fromState = 0;
		m_toState = 0;
		m_parameters.Reset();
	}
};


struct Transitions
{
	s32			m_nbTransitions;
	Transition	*m_pBuffer;

	Transitions():m_nbTransitions(0), m_pBuffer(0) {}
};


// Must be first chunk in file
struct IdChunk
{
	NativeChunkHeader	m_header;
	NativeFileInfos		m_fileInfos;
};


struct FormatChunk
{
	NativeChunkHeader	m_header;
	AudioFormat			m_format;
};


// TODO : See what's really necessary in this
struct NativeChunks
{
	IdChunk				m_idChunk;
	FormatChunk			m_formatChunk;
};



// Big endian conversion methods

// This method assumes that blockSize is a multiple of 4 bytes.
inline void ConvertIntBlockToBE(u32 *pBlock, s32 blockSize)
{
	u32 *pCursor = pBlock;
	s32 nbElementsToConvert = blockSize / sizeof(s32);

	for(s32 i = 0; i < nbElementsToConvert; i++)
	{
		ConvertIntToBE(*pCursor);
		pCursor++;
	}
}


inline void ConvertFileInfosToBE(NativeFileInfos &fileInfos)
{
	ConvertIntToBE((u32 &) fileInfos.m_dataStart);
	ConvertIntToBE((u32 &) fileInfos.m_fileSize);
}


inline void ConvertAudioFormatToBE(AudioFormat &format)
{
	ConvertShortToBE((u16 &) format.m_compressionCode);
	ConvertShortToBE((u16 &) format.m_nbChannels);
	ConvertIntToBE((u32 &) format.m_sampleRate);
	ConvertShortToBE((u16 &) format.m_blockAlign);
	ConvertShortToBE((u16 &) format.m_bitsPerSample);
}

inline void ConvertStateInfosToBE(StateInfos &stateInfos)
{
	ConvertIntToBE((u32 &) stateInfos.m_playlistIndex);
}

inline void ConvertNativeChunkHeaderToBE(NativeChunkHeader &chunk)
{
	ConvertIntToBE(chunk.m_id);
	ConvertIntToBE((u32 &) chunk.m_size);
}

}
#endif // _NATIVE_HEADERS_H
