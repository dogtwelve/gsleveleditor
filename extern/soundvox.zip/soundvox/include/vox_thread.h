#pragma once
#ifndef _VOX_THREAD_H_
#define _VOX_THREAD_H_

#include "vox_default_config.h"
#include "vox_mutex.h"

#if VOX_USE_GLF
#include <glf/core/thread.h>
typedef glf::ThreadT<32 * 1024> voxThreadType;
#elif defined(_PS3)
#include <sys/ppu_thread.h>
typedef sys_ppu_thread_t voxThreadType;
#include <sys/timer.h>
#elif defined(SN_TARGET_PSP2)
#include <kernel.h>
typedef SceUID voxThreadType;
#elif defined(_WIN32)
#if VOX_DEBUG_SERVER_ENABLE
#define _WINSOCKAPI_
#endif
#include <windows.h>
typedef HANDLE voxThreadType;
#elif VOX_USE_PTHREAD
#include <pthread.h>
typedef pthread_t voxThreadType;
#elif defined(_NN_CTR)
#include <nn/os.h>
typedef nn::os::Thread voxThreadType;
#endif

namespace vox
{

typedef void (*ThreadUpdateCallback) (void* caller, void* param);

#if VOX_USE_GLF

struct VoxRunnable : public glf::Runnable
{
	VoxRunnable(c8* name):m_name(name), glf::Runnable(), m_alive(true){}
	virtual ~VoxRunnable(){}
	virtual void Run();

	ThreadUpdateCallback m_callbackMethod;
	void* m_caller;
	void* m_param;

	c8* m_name;

	f64 m_lastUpdate;

	bool m_alive;
};

#endif

class VoxThread
{
public:
	VoxThread(ThreadUpdateCallback callbackMethod, void* caller, void* param, const c8* name=0);
	~VoxThread();

	static void Sleep(u32 sleepTimeMs);

	static u32 GetCurThreadId();

private:

	void Stop();

#if VOX_USE_GLF
	//defines runnable farther
#elif defined(_PS3)
	static void* Update(uint64_t iValue);
#elif  defined(SN_TARGET_PSP2)
	static s32 Update(u32 argsize, void* iValue);
#elif defined(_WIN32)
	static DWORD WINAPI Update(LPVOID iValue);
#elif VOX_USE_PTHREAD
	static void* Update(void* iValue);
#elif defined (_NN_CTR)
	static void Update(void* iValue);
#endif

#if VOX_USE_GLF
	//nothing
#elif defined(_PS3)
	friend void funcUpdate(std::uint64_t arg);
#elif VOX_USE_PTHREAD
	friend void* funcUpdate(void* arg);
#endif
	
	void _Update();

	ThreadUpdateCallback m_updateCallback;
	void* m_caller;
	void* m_param;
	Mutex m_mutex;
	bool m_update;
	bool m_alive;
	f64 m_lastUpdate;
	c8 m_name[64];
	voxThreadType m_internThread;
#if VOX_USE_GLF
	VoxRunnable* m_voxRunnable;
#endif
};

}

#endif
