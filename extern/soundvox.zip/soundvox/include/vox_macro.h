#pragma once
#ifndef _VOX_MACRO_H
#define _VOX_MACRO_H

#include "vox_memory.h"
#include "vox_console.h"
#include "vox_default_config.h"

#if VOX_USE_CONSOLE
#define VOX_CONSOLE_OUT vox::Console::GetInstance()->Print
#define VOX_CONSOLE_FLUSH vox::Console::GetInstance()->Flush()
#else
#ifdef _WIN32
#define VOX_CONSOLE_OUT(level, msg, ...) if(level <= VOX_WARNING_LEVEL) {vox::Console::PrintStatic(level, msg, __VA_ARGS__);}
#else
#ifdef _NN_CTR
#define VOX_CONSOLE_OUT(level, msg, ...) if(level <= VOX_WARNING_LEVEL) {NN_LOG("[VOX W%d] " msg, level, __VA_ARGS__);}
#elif defined(_ANDROID)
#include <android/log.h>
#define  VOX_CONSOLE_OUT(level, msg, ...) if(level <= VOX_WARNING_LEVEL) {__android_log_print(ANDROID_LOG_FATAL-level, "VOX", msg, __VA_ARGS__);}
#else
#include <stdio.h>
#define VOX_CONSOLE_OUT(level, msg, ...) if(level <= VOX_WARNING_LEVEL) {printf("[VOX W%d] " msg, level, __VA_ARGS__);}
#endif
#endif
#define VOX_CONSOLE_FLUSH
#endif

#define VOX_WARNING_LEVEL_1(msg, ...) VOX_CONSOLE_OUT(1, msg "\n", __VA_ARGS__)
#define VOX_WARNING_LEVEL_2(msg, ...) VOX_CONSOLE_OUT(2, msg "\n", __VA_ARGS__)
#define VOX_WARNING_LEVEL_3(msg, ...) VOX_CONSOLE_OUT(3, msg "\n", __VA_ARGS__)
#define VOX_WARNING_LEVEL_4(msg, ...) VOX_CONSOLE_OUT(4, msg "\n", __VA_ARGS__)
#define VOX_WARNING_LEVEL_5(msg, ...) VOX_CONSOLE_OUT(5, msg "\n", __VA_ARGS__)

#if (VOX_WARNING_LEVEL > 0)
#define VOX_ASSERT_MSG(X, msg) if(!(X)) { VOX_WARNING_LEVEL_1("Assertion failed (%s:%d): " msg, __FUNCTION__, __LINE__); VOX_CONSOLE_FLUSH; VOX_ASSERT(X); }
#else
#define VOX_ASSERT_MSG(X, msg) VOX_ASSERT(X)
#endif

#if defined(_PS3) && VOX_DRIVER_USE_PS3_MULTISTREAM
#define CELLMS_ERROR(X) if(X == -1)VOX_WARNING_LEVEL_2("%s:%d => Multistream Error : %d", __FUNCTION__,__LINE__, cellMSSystemGetLastError());
#endif

#if (VOX_THREAD_SAFETY_LEVEL >= 2)
#define VOX_MUTEX_LEVEL_1(X) X
#define VOX_MUTEX_LEVEL_2(X) X
#elif (VOX_THREAD_SAFETY_LEVEL == 1)
#define VOX_MUTEX_LEVEL_1(X) X
#define VOX_MUTEX_LEVEL_2(X)
#else
#define VOX_MUTEX_LEVEL_1(X)
#define VOX_MUTEX_LEVEL_2(X)
#endif

#endif
