#pragma once
#ifndef _VOX_MSWAV_SUBDECODER_H
#define _VOX_MSWAV_SUBDECODER_H

#include "vox_decoder.h"
#include "MSHeaders.h"

namespace vox
{

class VoxMSWavSubDecoder
{
public:
	VoxMSWavSubDecoder(StreamCursorInterface* pStreamCursor, WaveChunk* pWaveChunks)
		:m_pStreamCursor(pStreamCursor),
		 m_pWaveChunks(pWaveChunks),
		 m_currentDataNode(0),
		 m_currentChunkPosition(0),
		 m_decodedSamples(0),
		 m_loop(false) {}
	virtual ~VoxMSWavSubDecoder(){}
	
	TrackParams GetTrackParams(){return m_trackParams;}

	void SetLoop(bool loop){m_loop = loop;}
	
	virtual s32 Decode(void* buf, s32 nbBytes)=0;
	
	virtual s32 Seek(u32 sampleNum )=0;

	virtual bool HasData()=0;
protected:
	StreamCursorInterface* m_pStreamCursor;

	WaveChunk* m_pWaveChunks;
	DataNode* m_currentDataNode;
	TrackParams m_trackParams;
	u32 m_currentChunkPosition;
	u32 m_decodedSamples;
	bool m_loop;

	void GoToNextDataChunk(void);
};

}
#endif
