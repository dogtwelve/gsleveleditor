#ifndef _VOX_DECODER_BCWAV_H_
#define _VOX_DECODER_BCWAV_H_

#include <vox_default_config.h>

#if VOX_CTR_DRIVER_PLATFORM && VOX_DRIVER_USE_CTR_HW

#include <vox_decoder.h>

namespace vox 
{

struct BCWavParam
{
	u8 m_encoding;
	u8 m_numChannel;
	u32 m_sampleRate; 
	u32 m_dataSize;
};

DecoderInterface* DecoderBCWavFactory(void* params);

class DecoderBCWav : public DecoderInterface 
{
public:
	DecoderBCWav():m_bcwavParam(0){}
	virtual ~DecoderBCWav(){if(m_bcwavParam)VOX_DELETE(m_bcwavParam);}
public:
	virtual void Init(){}
	virtual void Shutdown() {}
	virtual DecoderCursorInterface* CreateNewCursor( StreamCursorInterface* pStreamCursor );
	virtual void DestroyCursor(DecoderCursorInterface* pDecoderCursor);
	virtual s32 GetType(){return k_nDecoderTypeBCWav;}
	virtual void* GetParam();

private:
	BCWavParam* m_bcwavParam;
};

class DecoderBCWavCursor : public DecoderCursorInterface
{
protected:
	DecoderBCWavCursor(DecoderInterface* pDecoder, StreamCursorInterface* pStreamCursor );
public:
	virtual ~DecoderBCWavCursor(){}

public:
	virtual void Init();
	virtual void Shutdown() {}
	virtual s32  Decode( void* outputBuffer, s32 nbBytes ){VOX_ASSERT_MSG(false, "DecoderBCWavCursor doesn't support data copy");return 0;}
	virtual s32  DecodeRef( void* &outputBuffer, s32 nbBytes );
	virtual bool HasData(){return !m_hasSentData || m_loop;}
	virtual void Reset(void){Seek(0);}
	virtual s32  Seek(u32 sampleNum ){return (sampleNum == 0 ? 0 : -1); }
	virtual void SetLoop(bool loop){m_loop = loop;}

	virtual StreamCursorInterface* GetStreamCursor(){return m_pStreamCursor;}

	virtual bool AllowBufferReference(){ return true; }

private:
	bool m_hasSentData;

	friend class DecoderBCWav;
};

} //namespace

#endif //VOX_CTR_DRIVER_PLATFORM
#endif //_VOX_DECODER_BCWAV_H_
