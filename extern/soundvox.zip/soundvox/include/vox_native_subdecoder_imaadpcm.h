#pragma once
#ifndef _VOX_NATIVE_SUBDECODER_IMAADPCM_H
#define _VOX_NATIVE_SUBDECODER_IMAADPCM_H

#include "vox_native_subdecoder.h"
#include "AdpcmState.h"

namespace vox
{
#define SAMPLES_PER_CHUNK 8

#if VOX_NATIVE_REDUCE_LATENCY

class NativeSubDecoderIMAADPCMState : public NativeSubDecoderState
{
 public:
	s32	m_decodeBuffersState[3];		// Availability state of decoding buffers

	NativeSubDecoderIMAADPCMState(NativePlaylistsManager *pPlaylists);
	virtual ~NativeSubDecoderIMAADPCMState();
};

#endif // VOX_NATIVE_REDUCE_LATENCY


class VoxNativeSubDecoderIMAADPCM : public VoxNativeSubDecoder
{
 public:
	VoxNativeSubDecoderIMAADPCM(StreamCursorInterface* pStreamCursor, NativeChunks* pNativeChunks, States *pStates,
								AudioSegments *pAudioSegments, DOUBLE_VECTOR(s32) *pSegmentsCues,
								TransitionRules *pTransitionRules, DOUBLE_VECTOR(TransitionParams) *pTransitions,
								STRING_MAP(s32, StringCompare) *pStateLabels,
								NativePlaylistsManager *pPlaylists);
	virtual ~VoxNativeSubDecoderIMAADPCM();
	virtual s32 Seek(u32 sample){return 0;};

#if VOX_NATIVE_REDUCE_LATENCY
	void GetState(NativeSubDecoderIMAADPCMState *pState);
	void SetState(NativeSubDecoderIMAADPCMState *pState);
#endif

 protected:
	u32	m_samplesPerBlock;				// Nb of samples per adpcm encoded block (including the one in preamble)

	// Buffer parameters
	u8	**m_pDecodeBuffers;				// Buffers containing 1 block of decoded samples (one per segment).
	s32 m_samplesInBuffer[3];			// Nb of samples decoded in buffers 'm_decodeBuffers[i]' (i = 0, 1, 2).
	s32 m_samplesInBufferConsumed[3];	// Nb of samples uploaded from buffers 'm_decodeBuffers[i]' (i = 0, 1, 2).
	s32 m_decodeBuffersState[3];		// Availability state of decoding buffers
	u8* m_blockReadBuffer;

	AdpcmState	m_states[8]; //Up to eight channel

	
	virtual s32 DecodeCurrentSegmentWithOffset(void* outputBuffer, s32 nbBytes);
	virtual s32 DecodeSegment(void* outputBuffer, s32 nbBytes, SegmentState *pSegmentState);
	virtual u32 GetBytePositionFromSampleOffset(u32 sampleOffset);
	virtual s32 GetDecodingBuffer(void);	
	virtual void ReleaseDecodingBuffer(s32 bufferIndex);
	virtual void Reset(void);
	virtual s32 Seek(s32 samplePosition, SegmentState *pSegmentState);
	virtual void SetDecodingBufferToSegmentPosition(SegmentState *pSegmentState);

#if VOX_NATIVE_REDUCE_LATENCY
	virtual void EmulateSetDecodingBufferToSegmentPosition(SegmentState *pSegmentState);
	virtual s32 EmulateDecodeCurrentSegmentWithOffset(s32 nbBytes);
	virtual s32 EmulateDecodeSegment(s32 nbBytes, SegmentState *pSegmentState);
#endif

 private:
	s32 DecodeBlock(void* outbuf, SegmentState *pSegmentState);

#if VOX_NATIVE_REDUCE_LATENCY
	s32 EmulateDecodeBlock(SegmentState *pSegmentState);
#endif
};

}

#endif // _VOX_NATIVE_SUBDECODER_IMAADPCM_H
