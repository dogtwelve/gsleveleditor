#pragma once
#ifndef _VOX_DRIVER_NACL_H_
#define _VOX_DRIVER_NACL_H_

#include "vox_default_config.h"

#if VOX_DRIVER_USE_NACL

#include "vox_driver_callback_template.h"
#include "vox_internal.h"
#include "vox_macro.h"

#include "ppapi/cpp/audio.h"
#include "ppapi/cpp/instance.h"
#include "ppapi/cpp/module.h"
#include "ppapi/cpp/var.h"

namespace vox
{

class DriverNaclSource : public DriverCallbackSourceInterface
{
 public:
	DriverNaclSource(void * trackParam, void* driverParam, u32 sourceId = 0);
	virtual ~DriverNaclSource();

	virtual void PrintDebug();
};

class DriverNacl : public DriverCallbackInterface
{
public:
	DriverNacl();
	virtual ~DriverNacl();

	virtual void Init(void* param);
	virtual void Shutdown();

	virtual void Suspend();
	virtual void Resume();	

	virtual void PrintDebug();

	virtual DriverSourceInterface* CreateDriverSource(void * trackParam, void* driverParam, s32 priority = 0);
	virtual void DestroyDriverSource(DriverSourceInterface* driverSource);

	static void playbackCallback(void* samples, uint32_t buffer_size, void* data);

	static pp::Instance* s_ppInstance;
	
private:
	pp::Audio audio_interface;
	
};

};//namespace vox

#endif //VOX_DRIVER_USE_NACL
#endif //_VOX_DRIVER_NACL_H_
