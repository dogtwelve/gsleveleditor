#ifndef _VOX_DRIVER_CTR_H_
#define _VOX_DRIVER_CTR_H_

#include "vox_default_config.h"

#if VOX_DRIVER_USE_CTR && VOX_CTR_DRIVER_PLATFORM

#include "vox_driver_callback_template.h"
#include "vox_internal.h"

#include <nn.h>
#include <nn/os.h>
#include <nn/snd.h>

namespace vox {

const int SOUND_THREAD_PRIORITY = 2;
const int SOUND_THREAD_STACK_SIZE = 4096;

const int nBuffers = 2;
const int nBufferSize = 2048;

const int nMemorySize       = (nBuffers * sizeof(s32) * nBufferSize) + 128;

struct CTRSourceParam : public DriverSourceParam
{
};

class DriverCTRSource : public DriverCallbackSourceInterface
{
 public:
	DriverCTRSource(void * trackParam, void* driverParam, u32 sourceId = 0);
	virtual ~DriverCTRSource();

	virtual void PrintDebug();
};

class DriverCTR : public DriverCallbackInterface
{
public:
	DriverCTR();
	virtual ~DriverCTR();

	virtual void Init(void* param);
	virtual void Shutdown();

	virtual void Suspend();
	virtual void Resume();	

	virtual void PrintDebug();

	virtual DriverSourceInterface* CreateDriverSource(void * trackParam, void* driverParam, s32 priority = 0);
	virtual void DestroyDriverSource(DriverSourceInterface* driverSource);
	
private:
	
	nn::os::Thread		m_threadSound;
	//nn::os::MemoryBlock m_memBlock;
	nn::fnd::ExpHeap	m_expHeap;


	nn::snd::Voice*		m_voice;
    nn::snd::WaveBuffer m_buffer[nBuffers];
    s16*				m_memory[nBuffers];
	s32					m_currentBufferId;

	u8*					m_pcmBuffer;

    static void TreadFunc(void * arg);
    void processCallback(void);
};

}//namespace vox

#endif VOX_DRIVER_USE_CTR && VOX_CTR_DRIVER_PLATFORM
#endif //_VOX_DRIVER_CTR_H_
