#pragma once
#ifndef IO_AUDIO_MSHEADERS
#define IO_AUDIO_MSHEADERS

#include "vox_types.h"
#include "vox_memory.h"

namespace vox
{

enum CompressionCode
{
	k_ccUnknown          = 0x0000,
	k_ccPCM              = 0x0001,
	k_ccMSADPCM          = 0x0002,
	k_ccITUG_711_A_LAW   = 0x0006,
	k_ccITUG_711_AMU_LAW = 0x0007,
	k_ccIMAADPCM         = 0x0011,
	k_ccITUG_723_ADPCM   = 0x0016,
	k_ccGSM_6_10         = 0x0031,
	k_ccITUG_721_ADPCM   = 0x0040,
	k_ccMPEG             = 0x0050,
	k_ccExperimental     = 0xFFFF
};

enum ChunkSize
{
	k_nChunkHeaderSize	= 8,
	k_nRiffChunkSize	= 12,
	k_nFmtChunkSize		= 24,
	k_nFactChunkSize	= 12
};

struct RiffHeader
{
	char               chunkId[4];  // "RIFF"
	unsigned int	   filesize;    // total file size -8 bytes for this header
	char               riffType[4]; // usually "WAVE"
};

struct FormatHeader
{
	char               chunkId[4];          // "fmt "
	unsigned int       chunkDataSize;       // size of this header: 16 + extra format bytes
	unsigned short     compressionCode;     // 0x0001 = PCM, 0x0011 = IMA ADPCM 
	unsigned short     numChannels;
	unsigned int       sampleRate;
	unsigned int       avgBytesPerSample;
	unsigned short     blockAlign;
	unsigned short     significantBitsPerSample;
};

struct FactHeader
{
	char               chunkId[4];     // "fact"
	unsigned int       chunkDataSize;  // for IMA ADPCM this is the # of samples
	unsigned int       factData;
};

struct DataHeader
{
	char               chunkId[4]; // "data"
	unsigned int       chunkSize;  // data size including any padding
};

struct ChunkHeader
{
	char               chunkId[4]; 
	unsigned int       chunkSize;  
};

struct DataNode
{
	DataNode():m_fileOffset(0),m_byteSize(0),m_next(0){}
	DataNode(s32 fileOffset, s32 byteSize):m_fileOffset(fileOffset),m_byteSize(byteSize),m_next(0){}
	s32 m_fileOffset;
	s32 m_byteSize;
	DataNode* m_next;

	void AddNode(s32 fileOffset, s32 byteSize)
	{
		if(m_next)
			m_next->AddNode( fileOffset, byteSize);
		else
			m_next = VOX_NEW DataNode(fileOffset, byteSize);
	}

	void DropNodes()
	{
		if(m_next)
		{
			m_next->DropNodes();
			VOX_DELETE(m_next);
		}
	}
};

struct WaveChunk
{
	WaveChunk():m_dataNodes(0){}
	RiffHeader m_riffHeader;
	FormatHeader m_formatHeader;
	DataHeader m_dataHeader;
	FactHeader m_factHeader;
	vox::DataNode* m_dataNodes;
};

inline void ConvertLongToBE(unsigned long long &value)
{
	value = (value >> 56) | ((value >> 40) & 0x0000FF00) | ((value >> 24) & 0x00FF0000) | ((value >> 8) & 0xFF000000) |
			(value << 56) | ((value & 0x0000FF00) << 40) | ((value & 0x00FF0000) << 24) | ((value & 0xFF000000) << 8);
}

inline void ConvertIntToBE(unsigned int &value)
{
	value = (value >> 24) | ((value >> 8) & 0x0000FF00) | ((value << 8) & 0x00FF0000) | (value << 24);
}

inline void ConvertSignedIntToBE(int &value)
{
	value = (value >> 24) | ((value >> 8) & 0x0000FF00) | ((value << 8) & 0x00FF0000) | (value << 24);
}

inline void ConvertShortToBE(unsigned short &value)
{
	value = (value >> 8) | (value << 8);
}

inline void ConvertRiffHeaderToBE(RiffHeader &riffHeader)
{
	ConvertIntToBE(riffHeader.filesize);
}

inline void ConvertFormatHeaderToBE(FormatHeader &formatHeader)
{
	ConvertIntToBE(formatHeader.avgBytesPerSample);
	ConvertIntToBE(formatHeader.chunkDataSize);
	ConvertIntToBE(formatHeader.sampleRate);
	ConvertShortToBE(formatHeader.blockAlign);
	ConvertShortToBE(formatHeader.compressionCode);
	ConvertShortToBE(formatHeader.numChannels);
	ConvertShortToBE(formatHeader.significantBitsPerSample);
}

inline void ConvertDataHeaderToBE(DataHeader &dataHeader)
{
	ConvertIntToBE(dataHeader.chunkSize);
}

inline void ConvertChunkHeaderToBE(ChunkHeader &chunkHeader)
{
	ConvertIntToBE(chunkHeader.chunkSize);
}

inline void ConvertFactHeaderToBE(FactHeader &factHeader)
{
	ConvertIntToBE(factHeader.chunkDataSize);
	ConvertIntToBE(factHeader.factData);
}

}
#endif /* IO_AUDIO_MSHEADERS */
