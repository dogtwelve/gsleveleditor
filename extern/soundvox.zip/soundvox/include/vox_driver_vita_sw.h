#pragma once
#ifndef _VOX_DRIVER_VITA_SW_H_
#define _VOX_DRIVER_VITA_SW_H_

#include "vox_default_config.h"

#if VOX_DRIVER_USE_VITA_SW && VOX_VITA_SW_DRIVER_PLATFORM

#include "vox_driver_callback_template.h"
#include "vox_internal.h"

namespace vox {

struct FilterHistory
{
	FilterHistory():x(0), y(0){}
	s32 x;
	s32 y;
};

class DriverVitaSWSource : public DriverCallbackSourceInterface
{
 public:
	DriverVitaSWSource(void * trackParam, void* driverParam, u32 sourceId = 0);
	virtual ~DriverVitaSWSource();

	virtual void FillBuffer(s32* buffer, s32 nbSample);

	virtual void PrintDebug();

	static s32* m_filterBuffer;

private:
	//filter param biquad
	FilterHistory m_historyL[2];
	FilterHistory m_historyR[2];
};

class DriverVitaSW : public DriverCallbackInterface
{
public:
	DriverVitaSW();
	virtual ~DriverVitaSW();

	virtual void Init(void* param);
	virtual void Shutdown();

	virtual void Suspend();
	virtual void Resume();	

	virtual void PrintDebug();

	virtual DriverSourceInterface* CreateDriverSource(void * trackParam, void* driverParam, s32 priority = 0);
	virtual void DestroyDriverSource(DriverSourceInterface* driverSource);
	
private:
	static s32 soundThread(u32 args, void *argc );
	void playbackCallback();

	s32 m_portId;
	s32 m_threadId;

	volatile bool m_doUpdate;

	s16* m_outBuffer[2];
	s32  m_currentOutBuffer;
};

};//namespace vox


#endif //VOX_DRIVER_USE_VITA_SW && VOX_VITA_SW_DRIVER_PLATFORM

#endif //_VOX_DRIVER_VITA_SW_H_