#pragma once
#ifndef _VOX_DRIVER_MMSYSTEM_H_
#define _VOX_DRIVER_MMSYSTEM_H_

#include "vox_default_config.h"

#if VOX_DRIVER_USE_MMSYSTEM && VOX_MMSYSTEM_DRIVER_PLATFORM

#include <mmsystem.h>
#include "vox_driver_callback_template.h"

#define VOX_DRIVER_MMSYSTEM_DEFAULT_NB_BUFFERS	5
#define VOX_DRIVER_MMSYSTEM_DEFAULT_NB_SAMPLES	512

namespace vox 
{

class DriverMMSystemSource : public DriverCallbackSourceInterface
{
 public:
	DriverMMSystemSource(void * trackParam, void* driverParam, u32 sourceId = 0);
	virtual ~DriverMMSystemSource();

	virtual void PrintDebug();
};

class DriverMMSystem : public DriverCallbackInterface
{
public:
	DriverMMSystem();
	virtual ~DriverMMSystem();

	virtual void Init(void* param);
	virtual void Shutdown();

	virtual void Suspend();
	virtual void Resume();	

	virtual void PrintDebug(){}

	virtual DriverSourceInterface* CreateDriverSource(void * trackParam, void* driverParam, s32 priority = 0);
	virtual void DestroyDriverSource(DriverSourceInterface* driverSource);
private:
	static void UpdateThreaded(void* caller, void* param);
	void UpdateData(void);

	// Buffer parameters
	u32		m_nbBuffers;
	s32		m_bufferSize;
	s32		m_currentBuffer;
	u8**	m_pOutBuffers;

	// MMSytem parameters
	WAVEFORMATEX	m_waveformat;
	HWAVEOUT		m_waveOut;			// Wave out object.
	WAVEHDR			*m_pWaveBlocks;		// Objects containing buffer address provided (by reference) to mmsystem.

	VoxThread*	m_updateThread;
	bool		m_isThreadRunning;
};

}//namespace vox

#endif // VOX_DRIVER_USE_MMSYSTEM && VOX_MMSYSTEM_DRIVER_PLATFORM
#endif //_VOX_DRIVER_MMSYSTEM_H_
