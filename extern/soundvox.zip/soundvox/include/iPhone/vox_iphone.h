#pragma once
#ifndef _VOX_IPHONE_H_
#define _VOX_IPHONE_H_

#include "vox.h"
#include <string>

typedef void (*iPodPlayerStateChangedCallback) (vox::s32 state);
typedef void (*iPodPlayerNowPlayingChangedCallback) (void);
typedef void (*iPodLibraryChangedCallback) (void);	

namespace vox
{

namespace VoxIpodShuffleMode
{
	enum
	{
		k_nDefault,
		k_nOff,
		k_nSongs,
		k_nAlbums,		
	};
}
	
namespace VoxIpodRepeatMode
{
	enum
	{
		k_nDefault,
		k_nNone,
		k_nOne,
		k_nAll,
	};
}
	
namespace VoxIpodState
{
	enum
	{
		k_nPlaying,
		k_nPaused,
		k_nStopped,
		k_nOther,
		k_nPending,
	};
}

namespace VoxIpodQueryState
{
	enum 
	{
		k_nQuerySuccess = 0,
		k_nQueryError = -1,
		k_nQueryRunning = -2,
		k_nQueryDisabled = -3,
	};
}
	
//! Vox Engine iPhone User Interface
/*!
	This class is the extended version of VoxEngine for iPhone.  By using this 
	class to first instanciate the engine will allow automatic iPhone audio
	interruption handling and usage of the iPod access library API.  Once the
	first instance is created, either class can be used for common method.
	<BR>
	All iPod method are exposed either the API is available or not.  If the
	iPod controller is not available (not supported, low memory, os error ...),
	the playback state will be VoxIpodState::k_nOther.
	<BR>
	<b>To use VoxIphone the SDK must be set to 3.0 or newer. Ipod API is not
	available on the iphone simulator.</b>
	<BR>
	Asynchronous query mode is now mandatory, all documentation consider that
	asynchronous mode is on (see vox_default_config.h).
	<BR>
	<b>Do not call any of the deprecated methods from an iPod controller 
	callback</b>
*/
class VoxIphone : public VoxEngine
{
private:
	VoxIphone();
public:

	virtual ~VoxIphone();

	//! Retrieve current VoxEngine singleton
	/*!
		If VoxIphone and VoxEngine don't exist yet, it's created. 
		\return Reference to current VoxEngine/VoxIphone object.
	*/	
	static VoxIphone& GetVoxEngine();	

	//! VoxIphone singleton destructor
	/*!
		If VoxIphone exist, it's destroyed.
	*/	
	static void DestroyVoxEngine();
	
	//
	// Interruption methods
	//
	
	//! Suspend vox engine
	/*!
	 This method suspends the vox engine. A counter is incremented each time the
	 method is called and decremented each time ResumeEngine() is called. Actual
	 resumption is effective when the counter gets to 0.
	 */	
	virtual void SuspendEngine(void);
	
	//! Resume vox engine
	/*!
	 This method resumes the vox engine. A counter is decremented each time the
	 method is called and incremented each time SuspendEngine() is called. Actual
	 resumption is effective when the counter gets to 0.
	 */	
	virtual void ResumeEngine(void);
	
	//! Get engine suspension state
	/*!
	 This method provides the suspension state resulting from SuspendEngine()
	 and ResumeEngine() calls.
	 \return True if the vox engine is suspended.
	 */	
	virtual bool IsEngineSuspended(void);

	//! Start iPod music playback
	/*!
		If a playlist is currently active in the iPod controller, this method
		start the playback of the playlist is the current state of the iPod is
		stopped (VoxIpodState::k_nStopped).  If the iPod state is paused or
		interrupted (VoxIpodState::k_nPaused), the playback is resume at the
		current position.
	*/	
	
	void iPod_Play();

	//! Pause iPod music playback
	/*!
		If the iPod is currently playing the playback is pause and current
		position is preserved.
	*/
	void iPod_Pause();

	//! Stop iPod music playback
	/*!
		Changes iPod current playback state to stopped.  The position of the
		playback cursor is moved back to the beginning of the playlist.  If the
		application did set any playlist, this reset the current playlist and 
		a new playlist must be set before before calling iPod_Play.
	*/
	void iPod_Stop();

	//! Skip to next item in current iPod playlist
	/*!
		Stop current media item playback and skip to the next one in the list.
		Next media item selection is done according to shuffle mode and repeat
		mode.  If repeat mode is set to none(VoxIpodRepeatMode::k_nNone) and 
		the current item is the last available item, this action has the same
		effect than calling iPod_Stop. If the iPod is not playing, the current
		item is changed, but playback state is not affected.
	*/
	void iPod_Next();

	//! Skip to previous item in current iPod playlist
	/*!
		Stop current media item playback and skip to the previous one in the 
		list. If the iPod is not playing, the current item is changed, but 
		playback state is not affected.
	*/
	void iPod_Previous();
	
	//! Set iPod current shuffle mode
	/*!
		Shuffle mode available are the same than the regular iPod player : 
		<ul>
		<li>k_nDefault => Set to same as user preference in iPod player</li>
		<li>k_nOff => No shuffle, play item in the same order than the list</li>
		<li>k_nSongs => Shuffle all item in the list</li>
		<li>k_nAlbums => No shuffle within an album, shuffle to select next</li>
		</ul>
		Shuffle mode are contained inside VoxIpodShuffleMode namespace.
		\param shuffleMode Shuffle mode to set to the iPod controller
	*/
	void iPod_SetShuffle(s32 shuffleMode);

	//! Set iPod current repeat mode
	/*!
		Repeat mode available are the same than the regular iPod player : 
		<ul>
		<li>k_nDefault => Set to same as user preference in iPod player</li>
		<li>k_nNone => No repeat, once every item is played, playback stop</li>
		<li>k_nOne => Repeat current item</li>
		<li>k_nAll => Once all item were played, start again the whole list</li>
		</ul>
		Repeat mode are contained inside VoxIpodRepeatMode namespace.
		\param repeatMode Repeat mode to set to the iPod controller
	*/
	void iPod_SetRepeat(s32 repeatMode);
	
	//! Asynchronous query to retrieve accessible playlist
	/*!
		\return Return the number of user playlist currently accessible when available, return VoxIpodQueryState until then
	*/
	s32  iPod_GetPlaylistCount();

	//! Get the name of a user playlist
	/*!
		Return the name of the playlist at the specified index.  The string
		is encoded using UTF8.  If the index is invalid, an empty string is
		returned. <b>Need iPod_GetPlaylistCount previously successful for this
		method to work.</b>
		\param playlistIndex Index of the playlist to return the name of
		\return UTF8 string containing the name of the playlist, if it exist
	*/
	std::string iPod_GetPlaylistName(s32 playlistIndex);

	//! Set the current iPod playlist
	/*!
		Set the playlist at the specified index as the current playlist. Using
		a negative index set the entire music library as the current playlist. 
		<b>Need iPod_GetPlaylistCount previously successful for this
		method to work.</b>
		<b>The iPod controller only accept to change the current playlist if
		the current playback is stopped.  Any call to this method while the 
		playback state is not stopped will be ignore by the iPod controller.</b>
	*/
	void iPod_SetPlaylist(s32 playlistIndex);
	
	//! Asynchronous query to retrieve currently accessible artists
	/*!
	 \return Return the number of artists currently accessible when available, return VoxIpodQueryState until then
	 */
	s32	iPod_GetArtistCount();
	
	//! Get the name of an artist
	/*!
	 Return the name of the artist at the specified index.  The string is
	 encoded using UTF8.  If the index is invalid (< 0), an empty string is
	 returned. <b>Need iPod_GetArtistCount previously successful for this
	 method to work.</b>
	 \param artistIndex Index of the artist to return the name of
	 \return UTF8 string containing the name of the artist, if it exist
	*/
	std::string	iPod_GetArtistName(s32 artistIndex);
	
	//! Set the artist songs in the playback queue
	/*!
	 Set all songs from the artist specified by artistIndex in the playback queue.
	 Negative index is not allowed. Use iPod_SetPlaylist(-1) to set the entire music
	 library as the current playlist. 
	 <b>Need iPod_GetArtistCount previously successful for this
	 method to work.</b>
	 <b>The iPod controller only accept to change the playback queue if
	 the current playback is stopped.  Any call to this method while the 
	 playback state is not stopped will be ignore by the iPod controller.</b>
	 */
	void iPod_SetArtist(s32 artistIndex);
	
	//! Asynchronous query to retrieve currently accessible albums
	/*!
	 \return Return the number of albums currently accessible when available, return VoxIpodQueryState until then.
	 */
	s32	iPod_GetAlbumCount();
	
	//! Get the name of an album
	/*!
	 Return the name of the album at the specified index.  The string is
	 encoded using UTF8.  If the index is invalid (< 0), an empty string is
	 returned. <b>Need iPod_GetAlbumCount previously successful for this
	 method to work.</b>
	 \param albumIndex Index of the album to return the name of
	 \return UTF8 string containing the name of the album, if it exist
	 */
	std::string	iPod_GetAlbumName(s32 albumIndex);
	
	//! Set an album songs in the playback queue
	/*!
	 Set all songs from the album specified by albumIndex in the playback queue.
	 Negative index is not allowed. Use iPod_SetPlaylist(-1) to set the entire music
	 library as the current playlist. 
	 <b>Need iPod_GetAlbumCount previously successful for this
	 method to work.</b>
	 <b>The iPod controller only accept to change the playback queue if
	 the current playback is stopped.  Any call to this method while the 
	 playback state is not stopped will be ignore by the iPod controller.</b>
	 */
	void iPod_SetAlbum(s32 albumIndex);
	
	//! Asynchronous query to retrieve currently accessible songs
	/*!
	 \return Return the number of songs currently accessible when available, return VoxIpodQueryState until then
	 */
	s32	iPod_GetSongCount();
	
	//! Get the name of a song
	/*!
	 Return the name of the song at the specified index.  The string is
	 encoded using UTF8.  If the index is invalid (< 0), an empty string is
	 returned. <b>Need iPod_GetSongCount previously successful for this
	 method to work.</b>
	 \param songIndex Index of the song to return the name of
	 \return UTF8 string containing the name of the song, if it exist
	 */
	std::string	iPod_GetSongName(s32 songIndex);
	
	//! Set a song in the playback queue
	/*!
	 Set the song specified by songIndex in the playback queue. Negative
	 index is not allowed. Use iPod_SetPlaylist(-1) to set the entire music
	 library as the current playlist. 
	 <b>Need iPod_GetSongCount previously successful for this
	 method to work.</b>
	 <b>The iPod controller only accept to change the playback queue if
	 the current playback is stopped.  Any call to this method while the 
	 playback state is not stopped will be ignore by the iPod controller.</b>
	 */
	void iPod_SetSong(s32 songIndex);
	
	//! Return the current iPod playback state
	/*! 
		<b>Do not call from an iPod controller callback</b>
		Vox group the different iPod controller state as four state contained
		in VoxIpodState namespace.
		\return Current iPod controller state translated into VoxIpodState
		\deprecated Use iPod_GetPlaybackStateAsync instead
	*/
	s32 iPod_GetPlaybackState();
	
	//! Get the "Now Playing" item title
	/*!
		<b>Do not call from an iPod controller callback</b>
		If available, return the title of the current item set in the iPod
		controller.  If no item is currently set in the iPod controller, an 
		empty string is returned.  The string is encoded using UTF8.  
		\return UTF8 string of the title of the current iPod item
		\deprecated Use iPod_GetNowPlayingItemData instead
	*/
	std::string iPod_GetNowPlayingItemTitle();

	//! Get the "Now Playing" item artist
	/*!
		<b>Do not call from an iPod controller callback</b>
		If available, return the artist of the current item set in the iPod
		controller.  If no item is currently set in the iPod controller, an 
		empty string is returned.  The string is encoded using UTF8.  
		\return UTF8 string of the artist of the current iPod item
		\deprecated Use iPod_GetNowPlayingItemData instead
	*/
	std::string iPod_GetNowPlayingItemArtist();

	//! Get the "Now Playing" item album title
	/*!
		<b>Do not call from an iPod controller callback</b>
		If available, return the album title of the current item set in the 
		iPod controller.  If no item is currently set in the iPod controller, 
		an empty string is returned.  The string is encoded using UTF8.  
		\return UTF8 string of the album title of the current iPod item
		\deprecated  Use iPod_GetNowPlayingItemData instead
	*/
	std::string iPod_GetNowPlayingItemAlbumTitle();

	//! Get the current position of the playback cursor of the iPod controller
	/*!
		<b>Do not call from an iPod controller callback</b>
		/return Current playback position.  If not available, return 0.0f
		\deprecated Use iPod_GetNowPlayingItemData instead
	*/
	f32 iPod_GetNowPlayingCursorPosition();

	//! Get the duration of the "Now Playing" item
	/*!
		<b>Do not call from an iPod controller callback</b>
		\return Duration of the item set in iPod. If not available, return 0.0f
		\deprecated Use iPod_GetNowPlayingItemData instead
	*/
	f32 iPod_GetNowPlayingDuration();		
	
	//! Return if iPod API is available on current device
	/*!
		\return True if iPod controller is available 
	*/
	bool iPod_IsAvailable();		
	
	//! Asynchronous query to get Now Playing Item information
	/*! 
		If a value is unwanted, the method also accept a null pointer.  If no 
		item is currently set in the iPod, this method will return an error
		state.
		\param title Title of the Now Playing Item
		\param artist Artist of the Now Playing Item
		\param album Album title of the Now Playing Item
		\param cursorPosition Current cursor position of the Now Playing Item (in seconds)
		\param playbackDuration Duration of the Now Playing Item (in seconds)
		\return Current iPod controller state translated into VoxIpodState when ready, return VoxIpodQueryState until then
	*/
	s32 iPod_GetNowPlayingItemData(std::string* title, std::string* artist, std::string* album, f32* cursorPosition, f32* playbackDuration);

	//! Asynchronous query to get iPod Player state
	/*! 
		Vox group the different iPod controller state as four state contained
		in VoxIpodState namespace.
		\return VoxIpodQueryState, return state when query is finished (state >= k_nQuerySuccess)
	*/
    s32 iPod_GetPlaybackStateAsync();
	
	//!	Set the callback function to catch iPod state changes
	/*!
		Allow to set a callback function meeting iPodPlayerStateChangedCallback
		requirement.  This function will be call every time the iPod controller
		sends a MPMusicPlayerControllerPlaybackStateDidChangeNotification.  The
		callback will receive the updated state as a parameter.
		\param callback Function to call when the notification is received
	*/
	void SetiPodPlayerStateChangedCallback(iPodPlayerStateChangedCallback callback);

	//!	Set the callback function to catch iPod "Now Playing" item changes
	/*!
		Allow to set a callback function meeting iPodPlayerNowPlayingChangedCallback
		requirement.  This function will be call every time the iPod controller
		sends a MPMusicPlayerControllerNowPlayingItemDidChangeNotification.
		\param callback Function to call when the notification is received
	*/
	void SetiPodPlayerNowPlayingChangedCallback(iPodPlayerNowPlayingChangedCallback callback);

	//!	Set the callback function to catch iPod library changes
	/*!
		Allow to set a callback function meeting iPodLibraryChangedCallback
		requirement.  This function will be call every time the iPod controller
		sends a MPMediaLibraryDidChangeNotification.  <b>After receiving this
		callback, the application needs to update its playlist information.</b>
		<b>There is a known issue that syncing with iTune while an application
		is running will disrupt all iPod controller notifiaction until the 
		application is started again.</b>
		\param callback Function to call when the notification is received
	*/
	void SetiPodLibraryChangedCallback(iPodLibraryChangedCallback callback);
	
	//! Set the emitter group to mute when the iPod player is playing
	/*!
		The group mask set with this method will allow to mute these group when
		the iPod notification is received.  These group will be restore, when a
		notification is received for a stop or a pause event.  Any command on 
		muted emitter will still work.
		\param groupMask Group mask representing all group affected by iPod
	*/
	void SetInterruptableGroup(u32 groupMask);
	
public:
	//! Method to tell VoxIphone that the application became active
	/*!
		This method should be call when the application delegate selector
		applicationDidBecomeActive is called.  Failure to call this method may
		cause problem with iPod controller.
	*/
	void ApplicationDidBecomeActive();

	//! Method to tell VoxIphone that the application will resign active
	/*!
		This method should be call when the application delegate selector
		applicationWillResignActive is called.  Failure to call this method may
		cause problem with iPod controller.
	*/
	void ApplicationWillResignActive();
};

}

#endif
