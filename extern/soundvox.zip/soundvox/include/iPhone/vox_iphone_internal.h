#pragma once
#ifndef _VOX_IPHONE_INTERNAL_H_
#define _VOX_IPHONE_INTERNAL_H_

#include "vox_internal.h"
#import <AudioToolbox/AudioToolbox.h>
//#import "vox_iPod_controller.h"

typedef void (*iPodPlayerStateChangedCallback) (vox::s32 state);
typedef void (*iPodPlayerNowPlayingChangedCallback) (void);
typedef void (*iPodLibraryChangedCallback) (void);	

namespace vox
{
	
class VoxiPodController;	
	
class VoxIphoneInternal : public VoxEngineInternal
{
protected:
	static VoxIphoneInternal* GetVoxEngineInternal();
	virtual ~VoxIphoneInternal();
	
protected:
	VoxIphoneInternal();
	virtual void Initialize();
	virtual void Suspend();
	virtual void Resume();
	virtual bool IsSuspended();
	
protected:
	virtual void UpdateSources();
	virtual void UpdateEmitters(f32 dt);
	void ForceUpdateEmitters(bool stopNonLooping = false);
	//virtual void ReleaseDatasource( const DataHandle &handle );
	virtual void KillEmitter( EmitterObj* emitter );
	virtual void SetGroupGain( u32 groupMask, f32 gain, f32 fadeTime = 0.0f  );
	//virtual void SetMasterGain(float gain, float fadeTime);
	
	void ForceEndAudioInterruption();
	static void interruptionListenerCallback(void *inUserData,UInt32 interruptionState);
	static void propertyListenerCallback(void * inClientData, AudioSessionPropertyID inID, UInt32 inDataSize, const void * inData);
	void beginInterruption();
	void endInterruption();
	
	void ApplicationDidBecomeActive();
	void ApplicationWillResignActive();
	
	static void iPodStateChanged(s32 state);
	static void iPodSongChanged();
	static void iPodLibraryChanged();

	void iPod_Play();
	void iPod_Pause();
	void iPod_Stop();
	void iPod_Next();
	void iPod_Previous();
	
	void iPod_SetRepeat(s32 repeatMode);
	void iPod_SetShuffle(s32 shuffleMode);

	s32			iPod_GetPlaylistCount();
	std::string	iPod_GetPlaylistName(s32 playlistIndex);
	void		iPod_SetPlaylist(s32 playlistIndex);	
	s32			iPod_GetArtistCount();
	std::string	iPod_GetArtistName(s32 artistIndex);
	void		iPod_SetArtist(s32 artistIndex);
	s32			iPod_GetAlbumCount();
	std::string	iPod_GetAlbumName(s32 albumIndex);
	void		iPod_SetAlbum(s32 albumIndex);
	s32			iPod_GetSongCount();
	std::string	iPod_GetSongName(s32 songIndex);
	void		iPod_SetSong(s32 songIndex);
	
	s32 iPod_GetPlaybackState();
	bool iPod_IsAvailable();
	
	std::string iPod_GetNowPlayingItemTitle();
	std::string iPod_GetNowPlayingItemArtist();
	std::string iPod_GetNowPlayingItemAlbumTitle();
	f32 iPod_GetNowPlayingCursorPosition();
	f32 iPod_GetNowPlayingDuration();	
	
	s32 iPod_GetNowPlayingItemData(std::string* title, std::string* artist, std::string* album, f32* cursorPosition, f32* playbackDuration);
    s32 iPod_GetPlaybackStateAsync();
	
	
	void SetiPodPlayerStateChangedCallback(iPodPlayerStateChangedCallback callback);
	void SetiPodPlayerNowPlayingChangedCallback(iPodPlayerNowPlayingChangedCallback callback);
	void SetiPodLibraryChangedCallback(iPodLibraryChangedCallback callback);
		
	void SetInterruptableGroup(u32 groupMask);
	
	void ForceResumeForDelete();
	void ProcessAudioRouteChanged();
	
	static s32 ConvertiPodState(s32 iPodNativeState);
	
	volatile s32 m_interruptionLevel;
	volatile bool m_systemSound;
	f32 m_timeSinceOtherAudioCheck;
	s32 m_checkThreshold;
	Mutex m_audioMutex;
	volatile s32 m_iPodSuspendCount;
	VoxiPodController* m_iPodController;
	bool m_isIpodPlaying;
	bool m_isVolumeDucked;
	u32 m_interruptableGroupMask;
	f32 m_SavedGroupGainModifier[k_nVoxGroupId_max];
	
	iPodPlayerStateChangedCallback m_externaliPodPlayerStateChangedCallback;
	iPodPlayerNowPlayingChangedCallback m_externaliPodPlayerNowPlayingChangedCallback;
	iPodLibraryChangedCallback m_externaliPodLibraryChangedCallback;

	UInt32 m_defaultAudioSessionCategory;
	
	friend class VoxIphone;
	friend class DataHandle;
	friend class EmitterHandle;	
};
	
}

#endif
