#pragma once
/*
 *  vox_ipod_asynchronous_query.h
 *  VoxIphone
 *
 *  Created by alexandre.belanger on 10-06-14.
 *  Copyright 2010 Gameloft. All rights reserved.
 *
 */

#ifndef _VOX_IPOD_ASYNCHRONOUS_QUERY_H_
#define _VOX_IPOD_ASYNCHRONOUS_QUERY_H_

#include <pthread.h>
#include "vox_mutex.h"

@class NSArray;
@class NSAutoreleasePool;

namespace vox
{
	
struct VoxIpodControllerQueryData
{
	VoxIpodControllerQueryData(){}
	VoxIpodControllerQueryData(void* _array, Mutex* pQueryMutex):m_array(_array), m_pQueryMutex(pQueryMutex){}
	void* m_array;
	Mutex* m_pQueryMutex;
};	
	
class VoxiPodAsyncQuery
{
public:
	VoxiPodAsyncQuery(){}
	~VoxiPodAsyncQuery();
	
	//bool GetPlaylists(NSArray** returnArray);
	//bool GetSongs(NSArray** returnArray);
	//bool GetArtists(NSArray** returnArray);
	//bool GetAlbums(NSArray** returnArray);
	
	bool GetPlaylists(VoxIpodControllerQueryData queryData);
	bool GetSongs(VoxIpodControllerQueryData queryData);
	bool GetArtists(VoxIpodControllerQueryData queryData);
	bool GetAlbums(VoxIpodControllerQueryData queryData);
	
	static bool m_isRunning;
	static bool m_dropResult;
	
private:

	bool Cancel();
	
	static void* _QueryPlaylists(void* arg);
	static void* _QuerySongs(void* arg);
	static void* _QueryArtists(void* arg);
	static void* _QueryAlbums(void* arg);
	
	VoxIpodControllerQueryData m_queryData;
	pthread_t m_thread;
};

}
#endif //_VOX_IPOD_ASYNCHRONOUS_QUERY_H_
