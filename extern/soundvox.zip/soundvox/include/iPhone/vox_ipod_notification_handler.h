#pragma once
//
//  vox_ipod_notification_handler.h
//  iSimple
//
//  Created by alexandre.belanger@gameloft.com on 9/25/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "vox.h"

typedef void (*iPodPlayerStateChangedCallback) (vox::s32 state);
typedef void (*iPodPlayerNowPlayingChangedCallback) (void);
typedef void (*iPodLibraryChangedCallback) (void);

@interface VoxiPodNotificationHandler : NSObject 
{
	iPodPlayerStateChangedCallback m_stateCallback;
	iPodPlayerNowPlayingChangedCallback m_songCallback;
	iPodLibraryChangedCallback m_libraryCallback;
}

-(void) initHandler;
-(void) reset;
-(void) setStateCallback:(iPodPlayerStateChangedCallback) stateCallback;
-(void) setSongCallback:(iPodPlayerNowPlayingChangedCallback) songCallback;
-(void) setLibraryCallback:(iPodLibraryChangedCallback) libraryCallback;
-(void) handle_stateChanged:(NSNotification*) aNotification;
-(void) handle_songChanged:(NSNotification*) aNotification;
-(void) handle_libraryChanged:(NSNotification*) aNotification;

@end
