#pragma once
//
//  vox_iPod_controller.h
//  iSimple
//
//  Created by alexandre.belanger@gameloft.com on 9/25/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//
#ifndef _VOX_IPOD_CONTROLLER_H_
#define _VOX_IPOD_CONTROLLER_H_

#include "vox_iphone.h"
#include "vox_memory.h"
#include "vox_thread.h"
#include "vox_mutex.h"
#include "vox_ipod_notification_handler.h"
#include "vox_ipod_asynchronous_query.h"
#import <MediaPlayer/MediaPlayer.h>
#include <string>
#include VOX_LIST_INCLUDE


@interface VoxDummyNSThreadClass : NSObject 
{
}
- (void) dummy;
@end	

namespace vox
{
	
enum VoxIpodControllerCommandType
{
    k_nVoxIpodControllerCommandCancelled,
    k_nVoxIpodControllerCommandPlay,
    k_nVoxIpodControllerCommandPause,
    k_nVoxIpodControllerCommandStop,
    k_nVoxIpodControllerCommandNext,
    k_nVoxIpodControllerCommandPrevious,
    k_nVoxIpodControllerCommandSetShuffleMode,
    k_nVoxIpodControllerCommandSetRepeatMode,
    k_nVoxIpodControllerCommandSetPlaylist,
    k_nVoxIpodControllerCommandSetArtist,
    k_nVoxIpodControllerCommandSetAlbum,
    k_nVoxIpodControllerCommandSetSong,    
	k_nVoxIpodControllerCommandGetNowPlayingItemData,
	k_nVoxIpodControllerCommandGetPlaybackStateAsync,
	k_nVoxIpodControllerCommandPlaylistQuery,
	k_nVoxIpodControllerCommandArtistQuery,
	k_nVoxIpodControllerCommandAlbumQuery,
	k_nVoxIpodControllerCommandSongQuery,
	k_nVoxIpodControllerCommandProcessSongChanged,
	k_nVoxIpodControllerCommandProcessStateChanged,
	k_nVoxIpodControllerCommandProcessLibraryChanged,
	k_nVoxIpodControllerCommandPollIpod,
};

struct VoxIpodControllerCommand
{
    VoxIpodControllerCommand():m_type(k_nVoxIpodControllerCommandCancelled), m_param(0){}
    VoxIpodControllerCommand(VoxIpodControllerCommandType commandType, s32 param):m_type(commandType), m_param(param){}
    VoxIpodControllerCommandType m_type;
    s32 m_param;
};    

class VoxiPodController
{
private:
	VoxiPodController();
public:
	static VoxiPodController* GetiPodController();
	static void DestroyiPodController();
	~VoxiPodController();
	
	void Init(iPodPlayerStateChangedCallback stateCallback = 0, iPodPlayerNowPlayingChangedCallback songCallback=0, iPodLibraryChangedCallback libraryCallback=0);
	bool IsAvailable(){return mpc != 0;} 
    
    //Asynchronous
	
		//Playback control
	void Play();
	void Pause();
	void Stop();
	void Next();
	void Previous();
	
	void SetRepeatMode(s32 repeatMode);
	void SetShuffleMode(s32 shuffleMode);

	s32	GetAlbumCount();	
	s32	GetPlaylistCount();
	s32 GetArtistCount();
    s32	GetSongCount();
	
    void SetPlaylist(s32 playlistIndex);
    void SetArtist(s32 artistIndex);
    void SetAlbum(s32 albumIndex);
    void SetSong(s32 songIndex);
    
    s32 GetNowPlayingItemData(std::string* title, std::string* artist, std::string* album, f32* cursorPosition, f32* playbackDuration);
    s32 GetPlaybackStateAsync();
    
    //Synchronous
    
	std::string	GetPlaylistName(s32 playlistIndex);
	std::string	GetArtistName(s32 artistIndex);
	std::string	GetAlbumName(s32 albumIndex);
	std::string	GetSongName(s32 songIndex);	
	
    void Suspend();
    void Resume();
	
    //Deprecated
	std::string GetNowPlayingItemTitle();
	std::string GetNowPlayingItemArtist();
	std::string GetNowPlayingItemAlbumTitle();
	f32 GetNowPlayingCursorPosition();
	f32 GetNowPlayingDuration();
	
	s32 GetPlaybackState();
	
	void DropQuery();
	
	static void LibraryChangeHandler();
	
private:
    //Playback control
	void _Play();
	void _Pause();
	void _Stop();
	void _Next();
	void _Previous();
	
	void _SetRepeatMode(s32 repeatMode);
	void _SetShuffleMode(s32 shuffleMode);

    void _SetPlaylist(s32 playlistIndex);
    void _SetArtist(s32 artistIndex);
    void _SetAlbum(s32 albumIndex);
    void _SetSong(s32 songIndex);
    
	void _GetNowPlayingItemData();
    void _GetPlaybackStateAsync();

	void _GetPlaylists();
	void _GetArtists();
	void _GetAlbums();
	void _GetSongs();
	
	static void _LibraryChangedHandler();
	static void _SongChangedHandler();
	static void _StateChangedHandler(s32 dummyState);
	
	void _ProcessLibraryChanged();
	void _ProcessStateChanged();
	void _ProcessSongChanged();
	
	void _PollIpod();
	
	static void ThreadRoutine(void* caller, void* param);	
	void ProcessQueue();
    void QueueCommand(VoxIpodControllerCommandType commandType, s32 param = 0, bool isHighPrio = false); 
	
	iPodPlayerStateChangedCallback      m_externalStateCallback;
    iPodPlayerNowPlayingChangedCallback m_externalSongCallback;
    iPodLibraryChangedCallback          m_externalLibraryCallback;
    
    iPodPlayerStateChangedCallback      m_stateCallback;
	iPodPlayerNowPlayingChangedCallback m_songCallback;
	iPodLibraryChangedCallback          m_libraryCallback;
	    
	VoxiPodAsyncQuery m_iPodQuery;
	bool m_isQueryEnabled;
    bool m_isNowPlayingItemValid;
    bool m_isNowPlayingItemUpdating;
    bool m_isStateValid;
    bool m_isStateUpdating;
	bool m_isIpodQueryPending;
    bool m_isPollingIpod;
	bool m_isSuspended;
    
	f64 m_nextPoll;
	
	s32 m_lastPollState;
	MPMediaItem* m_lastPollItem;
	
    VOX_LIST<VoxIpodControllerCommand, SAllocator<VoxIpodControllerCommand> > m_commandQueue;

    Mutex m_commandQueueMutex;
	Mutex m_queryMutex;
	Mutex m_nowPlayingItemMutex;

	VoxThread* m_commandThread;
        
    // Collections
	NSArray *m_playlists;
	NSArray *m_artists;
	NSArray *m_albums;
	NSArray *m_songs;	

	MPMediaItem* m_nowPlayingItem;
	f32 m_nowPlayingItemPosition;
	s32 m_iPodState;
    
    Class mpc;	
};

}
#endif