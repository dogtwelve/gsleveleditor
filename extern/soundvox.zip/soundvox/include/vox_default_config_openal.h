#pragma once
#ifndef _VOX_DEFAULT_CONFIG_OPENAL_H_
#define _VOX_DEFAULT_CONFIG_OPENAL_H_

//
// Do not mofify this file in any game-specific way.
//

#include "vox_default_config.h"

#ifndef VOX_USE_OPENAL_DRIVER
#define VOX_USE_OPENAL_DRIVER 1
#endif

#ifndef VOX_OPENAL_AL_HEADER_LOCATION
#define VOX_OPENAL_AL_HEADER_LOCATION "../Libs/OpenAL/include/al.h"
#endif

#ifndef VOX_OPENAL_ALC_HEADER_LOCATION
#define VOX_OPENAL_ALC_HEADER_LOCATION "../Libs/OpenAL/include/alc.h"
#endif

#ifndef VOX_OPENAL_ALEXT_HEADER_LOCATION
#define VOX_OPENAL_ALEXT_HEADER_LOCATION "../Libs/OpenAL/OpenAL soft/includes/common/al_gext.h"
#endif

#ifndef VOX_OPENAL_SOURCE_NUM_BUFFER
#define VOX_OPENAL_SOURCE_NUM_BUFFER 3
#endif

#ifndef VOX_OPENAL_ENABLE_SOURCE_POOL
#define VOX_OPENAL_ENABLE_SOURCE_POOL 0
#endif

#ifndef VOX_OPENAL_MAX_SOURCE
#define VOX_OPENAL_MAX_SOURCE 10 //Engine will try to allocate, but actual driver can have lower limit
#endif

#endif //_VOX_DEFAULT_CONFIG_OPENAL_H_
