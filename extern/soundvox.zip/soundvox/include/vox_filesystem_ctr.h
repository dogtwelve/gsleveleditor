#pragma once
#ifndef _VOX_FILE_SYSTEM_CTR_H_
#define _VOX_FILE_SYSTEM_CTR_H_

#include "vox_default_config.h"

#if defined(_NN_CTR)

#include "vox_filesystem.h"
#include <nn.h>
#include <nn/fs.h>

namespace vox
{

class FileSystemCTR : public FileSystemInterface
{
public:
	FileSystemCTR();
	virtual ~FileSystemCTR();
};

}

#endif
#endif //_VOX_FILE_SYSTEM_CTR_H_
