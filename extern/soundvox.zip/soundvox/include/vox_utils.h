#pragma once
#ifndef _VOX_UTILS_H_
#define _VOX_UTILS_H_

#include "vox.h"

namespace vox
{

//! Static class with helper method for Vox Engine
/*!
	This class contain static methods that regroup method of VoxEngine to allow easier integration.
*/
class VoxUtils
{
public:
	//! Method to create a data source from a file
	/*!
		This method create a data source with stream already set to "cfile".
		\param fileName Name of the file to use to create de data source
		\param decoderType Decoder type to use with in the data source
		\param groupFlags Default group to set to all emitter created with this data source
		\return Handle to the data source created
		\deprecated Use LoadDataSourceFromFileEx with loading flag instead of this function
	*/
	static DataHandle LoadDataSourceFromFile( const c8* fileName, s32 decoderType, s32 groupFlags = 0 );

	//! Method to create a data source from a file
	/*!
		This method create a data source with stream already set to "cfile".
		The decoder will be choosen according to the file extension.
		<ul>
		<li>.wav ==> k_nDecoderTypeMSWav</li>
		<li>.ogg ==> k_nDecoderTypeStbVorbis</li>
		<li>.mpc ==> k_nDecoderTypeMPC8</li>
		</ul>
		\param fileName Name of the file to use to create de data source
		\param groupFlags Default group to set to all emitter created with this data source
		\return Handle to the data source created
	*/
	static DataHandle LoadDataSourceFromFileAutoDetectDecoder( const c8* fileName, s32 groupFlags = 0);

	//! Extended method to create a data source from a file
	/*!
		This method create a data source according to the loading flags. The effect
		of each flag are :
		<ul>
		<li>k_nNone ==> The stream will be set to cfile and decoder is set according to auto-detection</li>
		<li>k_nLoadToRam ==> The content of the file is transfered to a memory buffer in RAM and the decoder is set according to auto-detection</li>
		<li>k_nLoadToRamAndDecode ==> The stream will be decoded according to the auto-detection to a memory buffer in RAM</li>
		</ul>
		An invalid flag will be process as the k_nNone flag.  Flags are not cumulative.
		The decoder will be choosen according to the file extension.
		<ul>
		<li>.wav ==> k_nDecoderTypeMSWav</li>
		<li>.ogg ==> k_nDecoderTypeStbVorbis</li>
		<li>.mpc ==> k_nDecoderTypeMPC8</li>
		</ul>
		If needed the user data can be directly set to the source.  The object reference by the will be copied in the process, 
		the original object can be released.
		\param fileName Name of the file to use to create de data source
		\param groupFlags Default group to set to all emitter created with this data source
		\param loadingFlags Flag to use to set the behavior of the loading
		\param pDataSourceUserData Pointer to the user data object to set to the newly created data source
		\return Handle to the data source created
	*/
	static DataHandle LoadDataSourceFromFileAutoDetectDecoderEx( const c8* fileName, s32 groupFlags = 0, VoxSourceLoadingFlags loadingFlags = k_nNone, DataHandleUserData* pDataSourceUserData = 0 );

	//! Method to create a static decoded data source from a file
	/*!
		This method create a data source by decoding the file in a memory buffer stream.
		The decoder type of the resulting data source is set to RAW
		\param fileName Name of the file to use to create de data source
		\param decoderType Decoder type to use to decode the file to create the data source
		\param groupFlags Default group to set to all emitter created with this data source
		\return Handle to the data source created
		\deprecated Use LoadDataSourceFromFileEx with loading flag instead of this function
	*/
	static DataHandle LoadDataSourceFromFileAsRAW( const c8* fileName, s32 decoderType, s32 groupFlags = 0 );

	//! Method to create a static data source from a file
	/*!
		This method create a data source by loading the file into a memory buffer.
		\param fileName Name of the file to use to create de data source
		\param decoderType Decoder type to use with in the data source
		\param groupFlags Default group to set to all emitter created with this data source
		\return Handle to the data source created
		\deprecated Use LoadDataSourceFromFileEx with loading flag instead of this function
	*/
	static DataHandle LoadDataSourceFromFileToRAM( const c8* fileName, s32 decoderType, s32 groupFlags = 0 );

	//! Method to create a static data source from a file
	/*!
		This method create a data source by loading the file according to relevant flags.
		\param fileName Name of the file to use to create de data source
		\param decoderType Decoder type to use with in the data source
		\param loadingFlags Loading flags
		\param groupFlags Default group to set to all emitter created with this data source
		\return Handle to the data source created
	*/
	static DataHandle LoadDataSourceFromFileEx( const c8* fileName, s32 decoderType, VoxSourceLoadingFlags loadingFlags, s32 groupFlags = 0);
};

}

#endif
