#pragma once
#ifndef _VOX_DRIVER_ANDROID_H_
#define _VOX_DRIVER_ANDROID_H_

#include "vox_default_config.h"

#if VOX_DRIVER_USE_ANDROID && VOX_ANDROID_DRIVER_PLATFORM
#include "vox_driver_callback_template.h"
#include "vox_internal.h"

#include <android/api-level.h>

#if __ANDROID_API__ < 9
#define VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED
#else
#define VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED
#define VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED
#endif

#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)
#include <jni.h>
#endif

#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_Platform.h>
#endif

#include <pthread.h>

namespace vox {

class DriverAndroidSource : public DriverCallbackSourceInterface
{
public:
	DriverAndroidSource(void * trackParam, void* driverParam, u32 sourceId = 0);
	virtual ~DriverAndroidSource();

	virtual void PrintDebug();
};

class DriverAndroid : public DriverCallbackInterface
{
public:
	DriverAndroid();
	virtual ~DriverAndroid();

	virtual void Init(void* param);
	virtual void Shutdown();

	virtual void Suspend();
	virtual void Resume();	

	virtual void PrintDebug();

	virtual void Update(f32 dt); //not needed is using an intern thread

	virtual DriverSourceInterface* CreateDriverSource(void * trackParam, void* driverParam, s32 priority = 0);
	virtual void DestroyDriverSource(DriverSourceInterface* driverSource);

#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)
	static JavaVM* s_javaVM;
	static f64 m_dataThresholdRatio;
#endif
	static s32 s_androidAPILevel;

private:
	enum AudioAPI
	{
		AA_Invalid,
		AA_AudioTrack,
		AA_OpenSLES
	};

	AudioAPI m_audioAPI;

	//AudioTrack stuff
	void _InitAT(void* param);
	void _ShutdownAT();
	void _SuspendAT();
	void _ResumeAT();	
	void _UpdateAT(f32 dt);

#if defined(VOX_ANDROID_DRIVER_AUDIO_TRACK_SUPPORTED)
	void DoCallbackAT(jarray &buffer);
	static void* UpdateThreadedAT(void* caller); //not needed is using Update()

	s32 m_samplePerBufferAT;
	s32 m_samplePerUpdateAT;
	bool m_suspendedAT;
	jobject m_audioTrack;

	pthread_t m_internThread;
	pthread_mutex_t m_suspendLock;
	pthread_cond_t m_suspendCondition;

	static bool m_running;
	static f64 m_updateTime;
	static f64 m_updateStartTime;
	static f64 m_dataDuration;
	static f64 m_dataThreshold;

	//reference to AudioTrack API
	static jclass cAudioTrack;
	static jmethodID mAudioTrack;
	static jmethodID mGetMinBufferSize;
	static jmethodID mPlay;
	static jmethodID mPause;
	static jmethodID mStop;
	static jmethodID mRelease;
	static jmethodID mWrite;
	static jmethodID mGetPlayState;
#endif


	//OpenSL Stuff
	void _InitOSL(void* param);
	void _ShutdownOSL();
	void _SuspendOSL();
	void _ResumeOSL();	
	void _UpdateOSL(f32 dt);

#if defined(VOX_ANDROID_DRIVER_AUDIO_OPENSLES_SUPPORTED)
	void DoCallbackOSL();
	static void CallbackOSL(SLBufferQueueItf bufferQueue, void *caller); //not needed is using Update()
	
	//Engine
	SLObjectItf m_engineObject;
    SLEngineItf m_engine;
    SLObjectItf m_output;

	//Player
	SLObjectItf m_playerObject;
	SLuint32 m_numBuffers;
    SLPlayItf m_play;
    SLBufferQueueItf m_bufferQueue;

	s16* m_outputBufferOSL;
	s32 m_bufferSizeOSL;
#endif

};

};//namespace vox

#endif //VOX_DRIVER_USE_ANDROID && VOX_ANDROID_DRIVER_PLATFORM
#endif //_VOX_DRIVER_ANDROID_H_
