#pragma once
#ifndef _VOX_DRIVER_MACOSX_AUDIOUNIT_H_
#define _VOX_DRIVER_MACOSX_AUDIOUNIT_H_

#include "vox_default_config.h"

#if VOX_DRIVER_USE_MACOSX_AUDIOUNIT && VOX_MACOSX_AUDIOUNIT_DRIVER_PLATFORM
#include "vox_driver_callback_template.h"
#include "vox_internal.h"
#include <AudioUnit/AudioUnit.h>

namespace vox {

class DriverMacOSXAudioUnitSource : public DriverCallbackSourceInterface
{
 public:
	DriverMacOSXAudioUnitSource(void * trackParam, void* driverParam, u32 sourceId = 0);
	virtual ~DriverMacOSXAudioUnitSource();
	
	virtual void PrintDebug();
};
	
class DriverMacOSXAudioUnit : public DriverCallbackInterface
{
 public:
	DriverMacOSXAudioUnit();
	virtual ~DriverMacOSXAudioUnit();
		
	virtual void Init(void* param);
	virtual void Shutdown();
		
	virtual void Suspend();
	virtual void Resume();	
		
	virtual void RampOut(){m_needRampOut = true;}
	virtual void RampIn(){m_needRampIn = true;}
		
	virtual void PrintDebug();
		
	virtual DriverSourceInterface* CreateDriverSource(void * trackParam, void* driverParam, s32 priority = 0);
	virtual void DestroyDriverSource(DriverSourceInterface* driverSource);
		
	virtual void Update(f32 dt);
	
 private:
		
	virtual void FillBuffer(s16* outBuffer, s32 nbSample);	
		
	void _InitializeAudioUnit();
		
	static OSStatus playbackCallback(void *inRefCon, AudioUnitRenderActionFlags *ioActionFlags, const AudioTimeStamp *inTimeStamp, UInt32 inBusNumber, UInt32 inNumberFrames, AudioBufferList *ioData);

	s16* m_resampleBuffer;
	s32	 m_resampleBufferSize;
	fx1814 m_resamplePos;
	s16  m_prevLeft, m_prevRight;
		
	AudioComponentInstance m_audioUnit;	
	bool m_audioCallbackActive;
	bool m_audioUnitInitialized;
	bool m_driverSuspended;
	int  m_nbAudioUnitReactivationTrials;
	f32  m_reactivationTrialInterval;
	bool m_needRampOut;
	bool m_needRampIn;
};
	
};//namespace vox

#endif //VOX_DRIVER_USE_MACOSX_AUDIOUNIT && VOX_MACOSX_AUDIOUNIT_DRIVER_PLATFORM
#endif //_VOX_DRIVER_MACOSX_AUDIOUNIT_H_