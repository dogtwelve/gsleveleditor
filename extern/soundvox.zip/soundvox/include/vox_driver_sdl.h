#pragma once
#ifndef _VOX_DRIVER_SDL_H_
#define _VOX_DRIVER_SDL_H_

#include "vox_default_config.h"

#if VOX_DRIVER_USE_SDL && VOX_SDL_DRIVER_PLATFORM

#include "vox_driver_callback_template.h"
#include "vox_internal.h"

// TODO : Include if SDL_InitSubSystem() and SDL_QuitSubSystem() are to be used.
//#include "SDL.h"
// End TODO

#include "SDL_audio.h"
#ifdef _WIN32
	#include "SDL_config_win32.h"
#endif

namespace vox {

class DriverSdlSource : public DriverCallbackSourceInterface
{
 public:
	DriverSdlSource(void * trackParam, void* driverParam, u32 sourceId = 0);
	virtual ~DriverSdlSource();

	virtual void PrintDebug();
};

class DriverSdl : public DriverCallbackInterface
{
public:
	DriverSdl();
	virtual ~DriverSdl();

	virtual void Init(void* param);
	virtual void Shutdown();

	virtual void Suspend();
	virtual void Resume();	

	virtual void PrintDebug();

	virtual DriverSourceInterface* CreateDriverSource(void * trackParam, void* driverParam, s32 priority = 0);
	virtual void DestroyDriverSource(DriverSourceInterface* driverSource);
	
private:
	static void playbackCallback(void *userdata, Uint8 *stream, int len);
};

};//namespace vox

#endif //VOX_DRIVER_USE_SDL && VOX_SDL_DRIVER_PLATFORM
#endif //_VOX_DRIVER_SDL_H_
