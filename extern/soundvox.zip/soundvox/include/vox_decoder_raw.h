#pragma once
#ifndef _VOX_DECODER_RAW_H_
#define _VOX_DECODER_RAW_H_

#include "vox_decoder.h"

namespace vox {

typedef TrackParams DecoderRawParams;

class DecoderRaw : public DecoderInterface
{
public:
	DecoderRaw( TrackParams* params );

	virtual DecoderCursorInterface* CreateNewCursor( StreamCursorInterface* pStreamCursor );
	virtual void DestroyCursor(DecoderCursorInterface* pDecoderCursor);
	virtual s32 GetType(){return k_nDecoderTypeRAW;}
	virtual void* GetParam(){return &m_trackParams;}

	const TrackParams& GetTrackParams() const { return m_trackParams; }
protected:
	TrackParams m_trackParams;
};


DecoderInterface* DecoderRawFactory(void* params);


class DecoderRawCursor : public DecoderCursorInterface
{
protected:
	DecoderRawCursor(DecoderInterface* pDecoder, StreamCursorInterface* pStreamCursor );

public:
	virtual ~DecoderRawCursor(){}
	virtual s32  Decode( void* outputBuffer, s32 nbSamples );
	virtual s32  DecodeRef( void* &outputBuffer, s32 nbBytes );
	virtual s32  Seek(u32 sampleNum );
	virtual bool HasData();

	virtual bool AllowBufferReference(){ return m_pStreamCursor ? m_pStreamCursor->AllowBufferReference() : false; }

protected:
	friend class DecoderRaw;
};

}

#endif //_VOX_DECODER_RAW_H_
