#pragma once
#ifndef _VOX_SOUNDPACK_XML_H_
#define _VOX_SOUNDPACK_XML_H_

#include "vox_default_config.h"

#if VOX_USE_SOUNDPACK_XML

#include "vox.h"
#include "vox_memory.h"
#include VOX_LIST_INCLUDE
#include VOX_STRING_INCLUDE
#include VOX_VECTOR_INCLUDE
#include VOX_MAP_INCLUDE

namespace vox
{

struct stringcomp {
  bool operator() (const VOX_STRING& lhs, const VOX_STRING& rhs) const
  {return lhs<rhs;}
};

struct c8stringcomp {
  bool operator() (const c8* lhs, const c8* rhs) const;
};

enum VoxSoundPackEventType
{
	k_nEventTypeInvalid = -1,
	k_nEventTypeRandom  =  0,
	k_nEventTypePlaylist=  1,
	k_nEventTypePlRandom=  2
};

//! 3D positioning type
enum Vox3DSoundType
{
	k_n3DSoundTypeNone,		/*!< Emitter relative to listener, position is set to  {0.0.0} */
	k_n3DSoundTypeAbsolute, /*!< Emitter not relative to listener, position is set to its world position */
	k_n3DSoundTypeRelative /*!< Emitter relative to listener, position is set to its position in the listener world */
};

//! Structure to retrieve information about a bank from an XMLSoundpack object
struct BankInfoXML
{
	BankInfoXML():m_id(0), m_behaviour(k_nDoNothing), m_maxPlayback(2147483647), m_threshold(-(s32)2147483647), m_name(0){}

	s32 m_id; //!< Unique id of the bank
	PriorityBankBehavior m_behaviour;//!< Behaviour of the bank
	s32 m_maxPlayback; //!< Maximum playback allowed by the bank
	s32 m_threshold;//!< Minimum priority threshold
	const c8* m_name;//!< Label of the bank
};

struct BankXMLDef
{
	BankXMLDef():m_id(0), m_behaviour(k_nDoNothing), m_maxPlayback(2147483647), m_threshold(-(s32)2147483647), m_name(""){}
	s32 m_id;
	PriorityBankBehavior m_behaviour;
	s32 m_maxPlayback;
	s32 m_threshold;
	VOX_STRING m_name;
};

//! Structure to retrieve information about a group from an XMLSoundpack object
struct GroupInfoXML
{
	GroupInfoXML(): m_id(0), m_busName(0), m_name(0), m_is3D(k_n3DSoundTypeNone){}
	s32 m_id;//!< Unique id of the group
	const c8* m_busName;//!< Label of the bus to route the member of the group to
	const c8* m_name;//!< Label of the group
	Vox3DSoundType m_is3D;//!< 3D mode of member of the group
};

struct GroupXMLDef
{
	GroupXMLDef(): m_id(0), m_busName(""), m_name(""), m_is3D(k_n3DSoundTypeNone){}
	s32 m_id;
	VOX_STRING m_busName;
	VOX_STRING m_name;
	Vox3DSoundType m_is3D;
};

//! Structure to retrieve information about a data source from an XMLSoundpack object
struct DataSourceInfoXML
{
	DataSourceInfoXML():m_id(0),m_label(0), m_filename(0),m_formatType(k_nDecoderTypeInvalid), m_groupId(0),
						m_bankId(0), m_loadingFlags(k_nNone), m_numCustomSound(0), m_customSoundStr(0) {}

	s32 m_id;//!< Unique id of the sound
	const c8* m_label;//!< Label of the sound
	const c8* m_filename;//!< Name of the file (may include path)
	FormatTypes m_formatType;//!< Id of the decoder to use
	s32 m_groupId;//!< Id of the group to use
	s32 m_bankId;//!< Id of the bank to use
	VoxSourceLoadingFlags m_loadingFlags;//!< Loading flags to use
	s32 m_numCustomSound;//!< Custom parameter count
	c8 const * const * m_customSoundStr;//!< List of custom parameter
};

//! Structure to retrieve information about an emitter from an XMLSoundpack object
struct EmitterInfoXML
{
	EmitterInfoXML():m_id(0),m_label(0),m_priority(0), m_groupId(0),m_isLoop(false),m_is3d(k_n3DSoundTypeNone),
					 m_busName(0), m_referenceDistance(VOX_DEFAULT_3D_EMITTER_REFERENCE_DISTANCE),
					 m_maxDistance(VOX_DEFAULT_3D_EMITTER_MAX_DISTANCE), m_rolloffFactor(VOX_DEFAULT_3D_EMITTER_ROLLOFF_FACTOR),
					 m_baseGain(1.0f), m_minGainMod(1.0f), m_maxGainMod(1.0f), m_isGainRandom(false), m_basePitch(1.0f),
					 m_minPitchMod(1.0f), m_maxPitchMod(1.0f), m_isPitchRandom(false), m_numCustomSound(0), m_customSoundStr(0) {}

	s32 m_id;//!< Unique id of the sound
	const c8* m_label;//!< Label of the sound
	s32 m_priority;//!< Priority of the sound
	s32 m_groupId;//!< Id of the group to use
	bool m_isLoop;//!< Looping mode
	Vox3DSoundType m_is3d;//!< 3D mode
	const c8* m_busName;//!< Name of the bus to route to

	// 3D parameters
	f32 m_referenceDistance;//!< Reference distance used in gain attenuation models based on distance.
	f32 m_maxDistance;//!< Maximum distance used in gain attenuation models based on distance.
	f32	m_rolloffFactor;//!< Rolloff factor used in gain attenuation models based on distance.

	// Gain parameters
	f32 m_baseGain;//!< Base value for emitter's user gain.
	f32 m_minGainMod;//!< Minimum gain multiplier applied on base gain when using random gain modifications.
	f32 m_maxGainMod;//!< Maximum gain multiplier applied on base gain when using random gain modifications.
	bool m_isGainRandom;//!< True if gain requires random modifications.

	// Pitch parameters
	f32 m_basePitch;//!< Base value for emitter's user pitch.
	f32 m_minPitchMod;//!< Minimum pitch multiplier applied on base pitch when using random pitch modifications.
	f32 m_maxPitchMod;//!< Maximum pitch multiplier applied on base pitch when using random pitch modifications.
	bool m_isPitchRandom;//!< True if pitch requires random modifications.

	s32 m_numCustomSound;//!< Custom parameter count
	c8 const * const * m_customSoundStr;//!< List of custom parameter
};

struct SoundXMLDef
{
	SoundXMLDef(): m_id(0), m_priority(0), m_label(0), m_filename(0), m_loadingFlags(k_nNone), 
				   m_format((s16)k_nDecoderTypeInvalid), m_bankId(0), m_groupId(0), m_isLoop(false),
				   m_referenceDistance(VOX_DEFAULT_3D_EMITTER_REFERENCE_DISTANCE), m_maxDistance(VOX_DEFAULT_3D_EMITTER_MAX_DISTANCE),
				   m_rolloffFactor(VOX_DEFAULT_3D_EMITTER_ROLLOFF_FACTOR), m_baseGain(1.0f), m_minGainMod(1.0f),
				   m_maxGainMod(1.0f), m_isGainRandom(false), m_basePitch(1.0f), m_minPitchMod(1.0f),
				   m_maxPitchMod(1.0f), m_isPitchRandom(false), m_numCustomSound(0), m_customSoundStr(0) {}

	~SoundXMLDef()
	{
		if(m_label)
			VOX_FREE(m_label);
		if(m_filename)
			VOX_FREE(m_filename);

		if(m_customSoundStr)
		{
			if(m_customSoundStr[0])
				VOX_FREE(m_customSoundStr[0]);
			VOX_FREE(m_customSoundStr);
		}
	}
	s32 m_id;
	s32 m_priority;
	c8* m_label;
	c8* m_filename;
	VoxSourceLoadingFlags m_loadingFlags;
	/*FormatTypes*/ s8 m_format;
	s8 m_bankId;
	s8 m_groupId;
	bool m_isLoop;
	
	// 3D parameters
	f32 m_referenceDistance;
	f32 m_maxDistance;
	f32	m_rolloffFactor;

	// Gain parameters
	f32 m_baseGain;
	f32 m_minGainMod;		// Minimum gain multiplier applied on base gain when using random gain modifications.
	f32 m_maxGainMod;		// Maximum gain multiplier applied on base gain when using random gain modifications.
	bool m_isGainRandom;	// True if gain can experience random modifications.

	// Pitch parameters
	f32 m_basePitch;
	f32 m_minPitchMod;		// Minimum pitch multiplier applied on base pitch when using random pitch modifications.
	f32 m_maxPitchMod;		// Maximum pitch multiplier applied on base pitch when using random pitch modifications.
	bool m_isPitchRandom;	// True if pitch can experience random modifications.

	// User custom parameters
	s32		m_numCustomSound;
	c8**	m_customSoundStr;
};

//! Structure to retrieve information about an event from an XMLSoundpack object
struct EventInfoXML
{
	EventInfoXML():m_id(0), m_label(0), m_pSoundIds(0), m_eventType(k_nEventTypeInvalid), m_eventParam(0), m_playbackProbability(0), m_numCustomEvent(0), m_customEventStr(0){}

	s32 m_id;//!< Unique id of the event
	const c8* m_label;//!< Label of the event

	VOX_VECTOR<s32, SAllocator<s32> > const* m_pSoundIds;//!< Reference to the list of sound ids member of the event

	VoxSoundPackEventType m_eventType;//!< Event type
	s16 m_eventParam;//!< Parameter of the event
	s16 m_playbackProbability;	//!< Playback probability of the event

	s32 m_numCustomEvent;//!< Custom parameter count
	c8 const * const * m_customEventStr;//!< List of custom parameter
};

//! Structure that retrieve editable parameter of an event from an XMLSoundpacl object
struct EventXmlEditable
{
	EventXmlEditable():m_soundIds(0), m_eventType(0), m_eventParam(0), m_playbackProbability(0){}

	VOX_VECTOR<s32, SAllocator<s32> >* m_soundIds;//!< Vector of the sound uid linked to the event
	s16* m_eventType;//!< Event type
	s16* m_eventParam;//!< Parameter of the event
	s16* m_playbackProbability;//!< Playback probability of the event	
};

struct EventXMLDef
{
	EventXMLDef(): m_id(0), m_label(0), m_eventType((s16)k_nEventTypeInvalid), m_eventParam(0), m_playbackProbability(100), m_currentEvent(-1), m_numCustomEvent(0), m_customEventStr(0){}
	~EventXMLDef()
	{
		if(m_label)
			VOX_FREE(m_label);

		if(m_customEventStr)
		{
			if(m_customEventStr[0])
				VOX_FREE(m_customEventStr[0]);
			VOX_FREE(m_customEventStr);
		}
	}
	
	s32 m_id;
	c8* m_label;	

	VOX_LIST<s32, SAllocator<s32> > m_usedSoundIds;
	VOX_VECTOR<s32, SAllocator<s32> > m_soundIds;

	/*VoxSoundPackEventType*/s16 m_eventType;
	s16 m_eventParam;
	s16 m_playbackProbability;		
	s16 m_currentEvent;
	s32 m_numCustomEvent;
	c8** m_customEventStr;
};

//! XML sound pack descriptor class
/*!
	This class contain all the informations from the sound design document relevant at run-time
*/
class VoxSoundPackXML
{
public:
	//! Default constructor
	/*!
		Create an empty XML sound pack descriptor
	*/
	VoxSoundPackXML(){}

	//! Optional constructor
	/*!
		Create an XML sound pack descriptor based on the file passed as argument
		\param xmlFileName	Absolute path to the xml file containing sound pack information
	*/
	VoxSoundPackXML(const c8* xmlFileName);
	//! Destructor
	~VoxSoundPackXML();

	//! Get sound element count
	/*!
		\return How many sound element are present in descriptor
	*/
	s32 GetSoundCount() const {return m_soundVector.size();}

	//! Get priority bank element count
	/*!
		\return How many priority bank element are present in descriptor
	*/
	s32 GetBankCount() const {return m_bankVector.size();}

	//! Get group element count
	/*!
		\return How many group element are present in descriptor
	*/
	s32 GetGroupCount() const {return m_groupVector.size();}

	//! Get event element count
	/*!
		\return How many event element are present in descriptor
	*/
	s32 GetEventCount() const {return m_eventVector.size();}

	//! Get the numeric unique id of a priority bank
	/*!
		\param	name Name of the priority bank in the sound design document
		\return Unique id of the priority bank
	*/
	s32 GetBankUid(const c8* name) const ;

	//! Get priority bank information
	/*!	
		Get information needed to the configuration of the bank
		\param name Name of the priority bank to get information for
		\param bankId <b>[out]</b>Unique id of the priority bank
		\param threshold <b>[out]</b>Priority threashold of the bank
		\param maxplayback <b>[out]</b>Maximum sound playback of the bank
		\param behaviour <b>[out]</b>Behaviour of the bank when full
		\return True if the bank was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetBankInfo(const c8* name, s32 &bankId, s32 &threshold, s32 &maxplayback, PriorityBankBehavior &behaviour) const ;

	//! Get priority bank information
	/*!	
		Get information needed to the configuration of the bank
		\param bankId Unique id of the priority bank to get information for
		\param threshold <b>[out]</b>Priority threashold of the bank
		\param maxplayback <b>[out]</b>Maximum sound playback of the bank
		\param behaviour <b>[out]</b>Behaviour of the bank when full
		\return True if the bank was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetBankInfo(s32 bankId, s32 &threshold, s32 &maxplayback, PriorityBankBehavior &behaviour) const ;

	//! Get priority bank information
	/*!	
		Get information needed to the configuration of the bank
		\param name Name of the priority bank to get information for
		\param bankInfo <b>[out]</b>Bank info struct to fill with the information
		\return True if the bank was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetBankInfo(const c8* name, BankInfoXML &bankInfo) const ;

	//! Get priority bank information
	/*!	
		Get information needed to the configuration of the bank
		\param bankId Unique id of the priority bank to get information for
		\param bankInfo <b>[out]</b>Bank info struct to fill with the information
		\return True if the bank was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetBankInfo(s32 bankId, BankInfoXML &bankInfo) const ;


	//! Get the numeric unique id of a group
	/*!
		\param	name Name of the group in the sound design document
		\return Unique id of the group
	*/
	s32 GetGroupUid(const c8* name) const ;

	//! Get group information
	/*!	
		Get information related to the group
		\param name Name of the group to get information for
		\param groupId <b>[out]</b>Unique id of the group
		\param busName <b>[out]</b>String id of the bus to use all sound of the group
		\param is3D <b>[out]</b>3D positioning type
		\return True if the group was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetGroupInfo(const c8* name, s32 &groupId, const c8* &busName, Vox3DSoundType &is3D) const ;

	//! Get group information
	/*!	
		Get information related to the group
		\param groupId Unique id of the group
		\param busName <b>[out]</b>String id of the bus to use all sound of the group
		\param is3D <b>[out]</b>3D positioning type
		\return True if the group was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetGroupInfo(s32 groupId, const c8* &busName, Vox3DSoundType &is3D) const ;
	
	//! Get group information
	/*!	
		Get information related to the group
		\param name Name of the group to get information for
		\param groupInfo <b>[out]</b>Group info struct to fill with the information
		\return True if the group was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetGroupInfo(const c8* name, GroupInfoXML &groupInfo) const ;

	//! Get group information
	/*!	
		Get information related to the group
		\param groupId Unique id of the group
		\param groupInfo <b>[out]</b>Group info struct to fill with the information
		\return True if the group was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetGroupInfo(s32 groupId, GroupInfoXML &groupInfo) const ;

	//! Get integer group mask for a group mask identifier
	/*!
		\param groupMaskLabel String identifier of the group mask
		\param groupMask <b>out</b> Integer group mask
		\return True if the group mask was found
	*/
	bool GetGroupMask(const c8* groupMaskLabel, s32 &groupMask) const ;

	//! Get the numeric unique id of a sound
	/*!
		\param	label Label of the sound in the sound design document
		\return Unique id of the sound
	*/
	s32 GetSoundUid(const c8* label) const ;

	//! Get data source information
	/*!	
		Get information needed to create a data source of the sound
		\param label Label of the sound to get information for
		\param soundUid <b>[out]</b>Unique id of the sound
		\param filename <b>[out]</b>Filename of the sound file
		\param decoderType <b>[out]</b>Decoder to use
		\param groupId <b>[out]</b>Group id to use for the sound
		\param bankId <b>[out]</b>Bank id to use for the sound
		\param loadingFlags <b>[out]</b>Loading flag
		\return True if the sound was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetDataSourceInfo(const c8* label, s32 &soundUid, const c8* &filename, FormatTypes &decoderType, s32 &groupId, s32 &bankId, VoxSourceLoadingFlags &loadingFlags) const ;

	//! Get data source information
	/*!	
		Get information needed to create a data source of the sound
		\param soundUid Unique id of the sound
		\param filename <b>[out]</b>Filename of the sound file
		\param decoderType <b>[out]</b>Decoder to use
		\param groupId <b>[out]</b>Group id to use for the sound
		\param bankId <b>[out]</b>Bank id to use for the sound
		\param loadingFlags <b>[out]</b>Loading flag
		\return True if the sound was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetDataSourceInfo(s32 soundUid, const c8* &filename, FormatTypes &decoderType, s32 &groupId, s32 &bankId, VoxSourceLoadingFlags &loadingFlags) const ;

	//! Get data source information
	/*!	
		Get information needed to create a data source of the sound
		\param label Label of the sound to get information for
		\param dataSourceInfo <b>[out]</b>Data source info struct to fill with the information
		\return True if the sound was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetDataSourceInfo(const c8* label, DataSourceInfoXML &dataSourceInfo) const ;

	//! Get data source information
	/*!	
		Get information needed to create a data source of the sound
		\param soundUid Unique id of the sound
		\param dataSourceInfo <b>[out]</b>Data source info struct to fill with the information
		\return True if the sound was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetDataSourceInfo(s32 soundUid, DataSourceInfoXML &dataSourceInfo) const ;

	//! Get emitter information
	/*!
		Get information needed to create an emitter of the sound
		\param label Label of the sound to get information for
		\param soundUid <b>[out]</b>Unique id of the sound
		\param priority <b>[out]</b>Priority of the emitter
		\param groupId <b>[out]</b>Group id to use for the sound
		\param isLoop <b>[out]</b>Looping state of the emitter
		\param is3d <b>[out]</b>3D positioning type
		\param busName <b>[out]</b>String id of the bus to use for the emitter
		\return True if the sound was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetEmitterInfo(const c8* label, s32 &soundUid, s32 &priority, s32 &groupId, bool &isLoop, Vox3DSoundType &is3d, const c8* &busName) const ;

	//! Get emitter information
	/*!	
		Get information needed to create an emitter of the sound
		\param soundUid Unique id of the sound
		\param priority <b>[out]</b>Priority of the emitter
		\param groupId <b>[out]</b>Group id to use for the sound
		\param isLoop <b>[out]</b>Looping state of the emitter
		\param is3d <b>[out]</b>3D positioning type
		\param busName <b>[out]</b>String id of the bus to use for the emitter
		\return True if the sound was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetEmitterInfo(s32 soundUid, s32 &priority, s32 &groupId, bool &isLoop, Vox3DSoundType &is3d, const c8* &busName) const ;

	//! Get emitter information
	/*!
		Get information needed to create an emitter of the sound
		\param label Label of the sound to get information for
		\param emitterInfo <b>[out]</b>Emitter info struct to fill the with the information
		\return True if the sound was found, if false, value of <b>[out]</b> parameters should not be used
	*/

	bool GetEmitterInfo(const c8* label, EmitterInfoXML &emitterInfo) const ;

	//! Get emitter information
	/*!	
		Get information needed to create an emitter of the sound
		\param soundUid Unique id of the sound
		\param emitterInfo <b>[out]</b>Emitter info struct to fill the with the information
		\return True if the sound was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetEmitterInfo(s32 soundUid, EmitterInfoXML &emitterInfo) const ;

	//! Get emitter information from sound or event label
	/*!
		Get information needed to create an emitter of the sound
		\param label Label of the sound (or event) to get information for
		\param emitterInfo <b>[out]</b>Emitter info struct to fill the with the information
		\return True if the sound (or event) was found, if false, value of <b>[out]</b> parameters should not be used
	*/

	bool GetEmitterInfoFromSoundOrEvent(const c8* label, EmitterInfoXML &emitterInfo);

	//! Get the value of a sound custom parameter
	/*!
		\param soundLabel Label of the sound
		\param index Index of the custom parameter
		\param param String that will contain the parameter
		\return True if the parameter returned is valid
	*/
	bool GetSoundCustomParam(const c8* soundLabel, s32 index, const c8* &param);

	//! Get the value of a sound custom parameter
	/*!
		\param soundUid Unique id of the sound
		\param index Index of the custom parameter
		\param param String that will contain the parameter
		\return True if the parameter returned is valid
	*/
	bool GetSoundCustomParam(s32 soundUid, s32 index, const c8* &param);

	//! Get the numeric unique id of an event
	/*!
		\param	eventLabel Label of the event in the sound design document
		\return Unique id of the event
	*/
	s32 GetEventUid(const c8* eventLabel) const;

	//! Get event information
	/*!	
		Get information about an event
		\param label Label of the event in the sound design document
		\param eventInfo <b>[out]</b>Envent info struct to fill the with the information
		\return True if the event was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetEventInfo(const c8* label, EventInfoXML &eventInfo) const ;

	//! Get event information
	/*!	
		Get information about an event
		\param eventUid Unique id of the event
		\param eventInfo <b>[out]</b>Envent info struct to fill the with the information
		\return True if the event was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetEventInfo(s32 eventUid, EventInfoXML &eventInfo) const ;

	//! Get sound id of the event
	/*!	
		Get the id of the sound that should be used according to the rule of the event
		\param eventLabel Label of the event in the sound design document
		\param soundUid <b>[out]</b>Unique id of the sound to use
		\return True if the event was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetEventSoundUid(const c8* eventLabel, s32 &soundUid);

	//! Get sound id of the event
	/*!	
		Get the id of the sound that should be used according to the rule of the event
		\param eventUid Unique id of the event
		\param soundUid <b>[out]</b>Unique id of the sound to use
		\return True if the event was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetEventSoundUid(s32 eventUid, s32 &soundUid);

	//! Reset event parameter to initial value
	/*!
		\param eventLabel Label of the event to reset
		\return True if the event was found
	*/
	bool ResetEvent(const c8* eventLabel);

	//! Reset event parameter to initial value
	/*!
		\param eventUid Unique id of the event to reset
		\return True if the event was found
	*/
	bool ResetEvent(s32 eventUid);

	//! Get count of the sound associated to the event
	/*!
		\param eventLabel Label of the event
		\return Count of the sound associated to the event
	*/
	s32 GetEventSize(const c8* eventLabel);

	//! Get count of the sound associated to the event
	/*!
		\param eventUid Unique id of the event
		\return Count of the sound associated to the event
	*/
	s32 GetEventSize(s32 eventUid);

	//! Get event editable parameter
	/*!	
		Get reference to event editable parameters.  Calling this method will 
		always call ResetEvent internally.  <b>After the parameters are modified,
		the application must call ResetEvent to reset internal state (failure to
		do so may result in crashes).  No other call should done between this
		call and ResetEvent.  After the modification, eventEditableParam should
		be discard.</b>
		\param eventLabel Label of the event
		\param eventEditableParam <b>[out]</b>Event editable struct to fill the with the reference
		\return True if the event was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetEventEditableParam(const vox::c8* eventLabel, vox::EventXmlEditable& eventEditableParam);

	//! Get event editable parameter
	/*!	
		Get reference to event editable parameters.  Calling this method will 
		always call ResetEvent internally.  <b>After the parameters are modified,
		the application must call ResetEvent to reset internal state (failure to
		do so may result in crashes).  No other call should done between this
		call and ResetEvent.  After the modification, eventEditableParam should
		be discard.</b>
		\param eventUid Unique id of the event
		\param eventEditableParam <b>[out]</b>Event editable struct to fill the with the reference
		\return True if the event was found, if false, value of <b>[out]</b> parameters should not be used
	*/
	bool GetEventEditableParam(vox::s32 eventUid, vox::EventXmlEditable& eventEditableParam);

	//! Get the value of an event custom parameter
	/*!
		\param eventLabel Label of the event
		\param index Index of the custom parameter
		\param param String that will contain the parameter
		\return True if the parameter returned is valid
	*/
	bool GetEventCustomParam(const c8* eventLabel, s32 index, const c8* &param);

	//! Get the value of an event custom parameter
	/*!
		\param eventUid Unique id of the event
		\param index Index of the custom parameter
		\param param String that will contain the parameter
		\return True if the parameter returned is valid
	*/
	bool GetEventCustomParam(s32 eventUid, s32 index, const c8* &param);

	//! Load a sound pack descriptor from a XML file
	/*!
		Load a sound pack descriptor from a XML file.
		<br>Note : This method first reset old descriptor.  If loading failed,
		previous information is not accessible.
		\param xmlFileName File to load information from
		\return True if the load was completed with success
	*/
	bool LoadXML(const c8* xmlFileName);

private:

	VOX_VECTOR<SoundXMLDef, SAllocator<SoundXMLDef> >  m_soundVector;
	VOX_VECTOR<GroupXMLDef, SAllocator<GroupXMLDef> >  m_groupVector;
	VOX_VECTOR<BankXMLDef, SAllocator<BankXMLDef> >   m_bankVector;
	VOX_VECTOR<EventXMLDef, SAllocator<EventXMLDef> >  m_eventVector;

#if defined(_NN_CTR)
	VOX_MAP<c8*, s32, c8stringcomp/*, SAllocator<std::pair<const c8*,s32> >*/ > m_soundLabel; //for fast uid search 
	VOX_MAP<VOX_STRING, s32, stringcomp/*, SAllocator<std::pair<VOX_STRING,s32> >*/ > m_groupMask; //for fast uid search 
#else
	//VOX_MAP<VOX_STRING, s32, stringcomp, SAllocator<std::pair<const VOX_STRING,s32> > > m_soundLabel; //for fast uid search 
	VOX_MAP<c8*, s32, c8stringcomp, SAllocator<std::pair<const c8*,s32> > > m_soundLabel; //for fast uid search 
	VOX_MAP<VOX_STRING, s32, stringcomp, SAllocator<std::pair<const VOX_STRING,s32> > > m_groupMask; //for fast uid search 
	//VOX_MAP<c8*, s32, c8stringcomp, SAllocator<std::pair<const c8*,s32> > > m_groupMask; //for fast uid search 
#endif
};

} //namespace vox
#endif //VOX_USE_SOUNDPACK_XML

#endif //_VOX_SOUNDPACK_XML_H_
