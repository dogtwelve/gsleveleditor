#pragma once
#ifndef _VOX_DRIVER_OPENAL_H_
#define _VOX_DRIVER_OPENAL_H_

#include "vox_default_config.h"

#if VOX_USE_OPENAL_DRIVER && VOX_OPENAL_DRIVER_PLATFORM

#include "vox_driver.h"
#include "vox_internal.h"
#include VOX_LIST_INCLUDE
#include VOX_OPENAL_AL_HEADER_LOCATION
#include VOX_OPENAL_ALC_HEADER_LOCATION
#ifdef _PS3
#include VOX_OPENAL_ALEXT_HEADER_LOCATION
#endif

namespace vox {

struct OpenALSourceParam : public DriverSourceParam
{
};

struct OpenALBuffer
{
	ALuint id;
	s32 size;
	bool queued;
};

class DriverOpenALSource : public DriverSourceInterface
{
public:
	DriverOpenALSource(void * trackParam, void* driverParam, ALuint sourceId = 0);
	virtual ~DriverOpenALSource();

	virtual void Play();
	virtual void Stop();
	virtual void Pause();
	virtual void Reset();

	virtual s32 GetState();

	virtual long GetByteOffset();
	virtual void SetByteOffset(s32 offset);

	virtual bool NeedData();
	virtual void UploadData(void* soundData, s32 bufferSize);

	virtual void SetGain(f32 gain);
	virtual void SetPitch(f32 pitch);
	virtual f32 GetGain();
	virtual f32 GetPitch();
	
	virtual void Set3DParameter(s32 paramId, void* param);

	virtual s32 GetBufferCount(){return m_param.numBuffer;}

	virtual void PrintDebug();

	void ReleaseSource();

protected:

	virtual void Init();
	virtual void Cleanup();

private:
	
	OpenALBuffer* GetFreeBuffer();
	OpenALBuffer* GetBuffer(ALuint bufferId);
	void SetFreeBuffer(ALuint bufferId);
	ALenum ConvertParamToALFormat();
	s32 ConvertSourceState(ALint alState);

	ALuint m_sourceId;
	OpenALBuffer* m_buffers;
	OpenALSourceParam m_param;	
	TrackParams m_trackParams;
	s32 m_processedBytes;
	ALenum m_format;
	Mutex m_mutex;
};

#if VOX_OPENAL_ENABLE_SOURCE_POOL
struct OpenALSourcePoolItem
{
	ALuint sourceId;
	s32 priority;
	DriverOpenALSource* driverSource;
};
#endif

class DriverOpenAL : public DriverInterface
{
public:
	DriverOpenAL();
	virtual ~DriverOpenAL();

	virtual void Init(void* param);
	virtual void Shutdown();

	virtual void Suspend();
	virtual void Resume();	

	virtual void Set3DParameter(s32 paramId, void* param);

	virtual void PrintDebug();

	virtual DriverSourceInterface* CreateDriverSource(void * trackParam, void* driverParam, s32 priority = 0);
	virtual void DestroyDriverSource(DriverSourceInterface* driverSource);

//protected:

private:
	ALCdevice* m_device;
	ALCcontext* m_context;

	ALuint GetOpenAL3DModel(s32 vox3DModel);
	void SetDefaultParameter();
	void _Set3DParameter(s32 paramId, void* param);

#if VOX_OPENAL_ENABLE_SOURCE_POOL
	OpenALSourcePoolItem GetSource(s32 priority);
	VOX_LIST<OpenALSourcePoolItem, SAllocator<OpenALSourcePoolItem> > m_sourcePool;
#endif

	Mutex m_mutex;
};

/*class EmitterObjOpenAL : public EmitterObj
{
public:
	EmitterObjOpenAL(HandleId id, int bufferSize, DriverOpenALSource* phwSourceInterface, DecoderCursorInterface* pDecoderCursor, DataObj* pDataSource);

	void Update();
private:
	DriverOpenALSource* m_phwSource; //Only to avoid casting every use of the hwSource
};*/

};//namespace vox

#endif //VOX_USE_OPENAL_DRIVER && VOX_OPENAL_DRIVER_PLATFORM
#endif //_VOX_DRIVER_OPENAL_H_
