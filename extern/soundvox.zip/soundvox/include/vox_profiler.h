#ifndef _VOX_PROFILER_H_
#define _VOX_PROFILER_H_

#include <vox_types.h>
#include <vox_thread.h>

#define VOX_PROFILING_START_FRAME_LAZY VOX_PROFILING_FRAME_START( vox::VoxThread::GetCurThreadId())

#if VOX_ENABLE_CPU_PROFILING
extern "C++" void VoxExternProfilingRegisterThread(const vox::c8* threadName, vox::u32 voxThreadId);
extern "C++" void VoxExternProfilingEventStart(const vox::c8* scopedName, vox::u32 voxThreadId);
extern "C++" void VoxExternProfilingEventStop(const vox::c8* scopedName, vox::u32 voxThreadId);
extern "C++" void VoxExternProfilingEventFrameStart(vox::u32 voxThreadId);

namespace vox
{

struct ScopedProfilingEvent
{
	ScopedProfilingEvent(unsigned int type, const char* scopedName, int voxThreadId):m_type(type), m_scopeName(scopedName),m_threadId(voxThreadId)
	{
		if(m_type & VOX_PROFILER_EVENT_ENABLED) 
			VoxExternProfilingEventStart(m_scopeName, m_threadId);
	}
	~ScopedProfilingEvent()
	{
		if(m_type & VOX_PROFILER_EVENT_ENABLED) 
			VoxExternProfilingEventStop(m_scopeName, m_threadId);
	}

	unsigned int m_type;
	const char* m_scopeName;
	int m_threadId;
};

}

#define VOX_PROFILING_REGISTER_THREAD( NAME, THREAD_ID) VoxExternProfilingRegisterThread(NAME, THREAD_ID);
#define VOX_PROFILING_FRAME_START(THREAD_ID) VoxExternProfilingEventFrameStart(THREAD_ID)

#define VOX_PROFILING_SCOPED_EVENT( VAR, TYPE, NAME, THREAD_ID) vox::ScopedProfilingEvent VAR(TYPE, NAME, THREAD_ID)
#define VOX_PROFILING_START_EVENT(TYPE, NAME, THREAD_ID) if(TYPE & VOX_PROFILER_EVENT_ENABLED) VoxExternProfilingEventStart(NAME, THREAD_ID)
#define VOX_PROFILING_END_EVENT(TYPE, NAME, THREAD_ID) if(TYPE & VOX_PROFILER_EVENT_ENABLED) VoxExternProfilingEventStop(NAME, THREAD_ID)


#else

#define VOX_PROFILING_REGISTER_THREAD( NAME, THREAD_ID)
#define VOX_PROFILING_SCOPED_EVENT( VAR, TYPE, NAME, THREAD_ID)
#define VOX_PROFILING_START_EVENT( TYPE, NAME, THREAD_ID)
#define VOX_PROFILING_END_EVENT( TYPE, NAME, THREAD_ID)
#define VOX_PROFILING_FRAME_START(THREAD_ID)

#endif

#endif
