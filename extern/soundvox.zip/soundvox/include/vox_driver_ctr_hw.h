#pragma once
#ifndef _VOX_DRIVER_CTR_HW_H_
#define _VOX_DRIVER_CTR_HW_H_

#include <vox_default_config.h>

#if VOX_DRIVER_USE_CTR_HW && VOX_CTR_DRIVER_PLATFORM

#include <vox_driver.h>
#include <vox.h>
#include <vox_internal.h>
#include <vox_macro.h>
#include <vox_memory.h>
#include <vox_mutex.h>

#include <nn.h>
#include <nn/os.h>
#include <nn/snd.h>
#include VOX_VECTOR_INCLUDE

namespace vox {

struct CTRVoice
{
	CTRVoice():m_pVoice(0), m_bcwavWaveOffset(0), m_isLooped(false), m_currentBuffer(0)
	{
		for(int i = 0; i < VOX_DRIVER_CTR_SOURCE_BUFFER; ++i)
		{
			m_dataBuffer[i] = 0;
		}
	}

	nn::snd::Voice* m_pVoice;
	nn::snd::WaveBuffer m_waveBuffer[VOX_DRIVER_CTR_SOURCE_BUFFER];
	s16* m_dataBuffer[VOX_DRIVER_CTR_SOURCE_BUFFER];
	nn::snd::Bcwav::DspAdpcmInfo m_adpcmInfo;
	nn::snd::Bcwav::WaveInfo m_waveInfo;
	s32 m_bcwavWaveOffset;
	bool m_isLooped;
	s32 m_currentBuffer;
};

struct CTRBuffer
{
	u8* m_data;
	s32 m_usedSize;
	s32 m_totalSize;
	s32 m_cursorPos; // In bytes
	bool free;
};

struct CTRSourceParam : public DriverSourceParam
{
};

struct CTRListenerParameters
{
	VoxVector3f m_position;
	VoxVector3f m_velocity;
	VoxVector3f m_atOrientation;
	VoxVector3f m_upOrientation;
};

class DriverSourceCTRHW : public DriverSourceInterface
{
public:
	DriverSourceCTRHW(void * trackParam, void* driverParam, s32 sourceId = 0);
	virtual ~DriverSourceCTRHW();

	virtual void Play();
	virtual void Stop();
	virtual void Pause();
	virtual void Reset();

	virtual s32 GetState();

	virtual long GetByteOffset(){return m_byteOffset;}
	virtual void SetByteOffset(s32 offset){m_byteOffset = offset;}

	virtual bool NeedData();
	virtual void UploadData(void* soundData, s32 bufferSize);

	virtual void SetGain(f32 gain);
	virtual void SetPitch(f32 pitch);
	
	virtual f32 GetGain();
	virtual f32 GetPitch();

	virtual void Set3DParameter(s32 paramId, void* param);

	virtual bool AllowBufferReference(){return true;}
	virtual void FreeDisposableData(s32 maxSamplesToFree, s32 &nbBuffersFreed, s32 &nbBytesFreed);

	virtual void PrintDebug(){};

	virtual s32 GetBufferCount();

	void ProcessDSPCallback();

	CTRVoice* GetCTRVoice(){return m_pVoiceData;}
	static void Set3DParameters(CTRListenerParameters listenerParameters, Vox3DGeneralParameters parameters3D);

	static f32 m_lastUpdateDT;

	TrackParams& GetTrackParams(){return m_trackParams;}

protected:

	virtual void Init();
	virtual void Cleanup();

	void _Pause(void);
	void _Play(void);
	void _Stop(void);
	void _Reset(void);

	bool m_isReady;				// True when Init() has completed

	TrackParams m_trackParams;
	s32 m_processedBytes;

	s32 FillBuffer(u8* buffer, s32 size);
	s32 FillBufferBCWav(u8* buffer, s32 size);

	void FreeAllBuffer();
	s32 m_numBuffer;
	s32 m_currentWriteBuffer;
	s32 m_currentReadBuffer;

	VOX_VECTOR<CTRBuffer, SAllocator<CTRBuffer> > m_bufferList;

	bool m_useHWState;
	s32 m_state;
	u32 m_byteOffset;
	CTRVoice* m_pVoiceData;

	f32 m_gain;
	f32 m_oldGain;
	f32 m_deltaGain;
	f32 m_userPitch;
	f32 m_oldPitch;
	f32 m_deltaPitch;

	Mutex m_mutex;

	// 3D and doppler methods
	f32 GetDopplerPitch(void);
	void Get2DSourceProjections(f32 &px, f32 &pz);
	f32 GetDirectionalGain(void);
	f32 GetDistanceGain(void);

	// Listener and general 3D and doppler parameters
	static CTRListenerParameters	s_listenerParameters;
	static u32					s_distanceModel;
	static f32					s_dopplerFactor;			
	static f32					s_alteredSpeedOfSound;		// = speedOfSound / dopplerFactor
	
	s32 m_callbackCount;
	s32 m_bytesPerSample;

	// 3D and doppler parameters (per source)
	VoxVector3f	m_position;
	VoxVector3f	m_velocity;
	VoxVector3f	m_direction;
	s32			m_relativeToListener;
	f32			m_maxDistance;
	f32			m_referenceDistance;
	f32			m_rolloffFactor;
	f32			m_innerConeAngle;
	f32			m_outerConeAngle;
	f32			m_outerConeGain;
	f32			m_cullingDistance;
	f32			m_dopplerPitch;			// To avoid calculating it twice.

	// State parameters
	bool m_isPauseUpdateNeeded;
	bool m_isPlayUpdateNeeded;
	bool m_isStopUpdateNeeded;
	s32 m_stopProcessState;
	bool m_isResetNeeded;
	u32 m_finishedCheckCount;

	bool m_isFirstUploadDone;
	bool m_isFirstPlayDone;
private:
	s32 GetNbAvailableSamples(s32 nbSamplesNeeded);
	s32 RampDownMonoBuffer(u8* buffer, s32 size);
	s32 RampDownStereoBuffer(u8* buffer, s32 size);
};

class DriverCTRHW : public DriverInterface
{
public:
	DriverCTRHW();
	virtual ~DriverCTRHW();

	virtual void Init(void* param);
	virtual void Shutdown();
	
	virtual void Suspend();
	virtual void Resume();
	
	virtual void Set3DParameter(s32 paramId, void* param);

	virtual void PrintDebug(){};

	virtual bool SetOutputMode(VoxOutputMode mode){m_nextOutputMode = mode; return true;}
	virtual VoxOutputMode GetOutputMode(){return m_currentOutputMode;}

	virtual void Update(f32 dt){DriverSourceCTRHW::m_lastUpdateDT = dt;}

	virtual DriverSourceInterface* CreateDriverSource(void * trackParam, void* driverParam, s32 priority = 0);
	virtual void DestroyDriverSource(DriverSourceInterface* driverSource);

protected:

	static void TreadFunc(void * arg);
    void ProcessCallback(void);

	VOX_LIST<DriverSourceCTRHW*, SAllocator<DriverSourceCTRHW*> > m_activeSources;

	nn::fnd::ExpHeap	m_voiceBufferExtHeap;
	u8*					m_voiceBufferHeapMemory;

	nn::os::Thread		m_threadSoundCallback;
	static bool 		m_isCallbackThreadActive;
	static bool 		m_isCallbackThreadNeedUpdate;
	Mutex				m_mutex;

	void SetDefaultParameter();
	void _Set3DParameter(s32 paramId, void* param);
	// Listener and general 3D parameters
	Vox3DGeneralParameters	m_3DGeneralParameters;
	CTRListenerParameters	m_listener;

	VoxOutputMode m_currentOutputMode;
	VoxOutputMode m_nextOutputMode;
};

};//namespace vox

#endif //VOX_DRIVER_USE_CTR_HW && VOX_CTR_DRIVER_PLATFORM
#endif //_VOX_DRIVER_H_
