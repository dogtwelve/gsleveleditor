#pragma once
#ifndef _VOX_DEFAULT_CONFIG_H_
#define _VOX_DEFAULT_CONFIG_H_

//
// Do not mofify this file in any game-specific way.
//

#ifndef GAME_VOX_CONFIG_ALT_FILE
// Default game-specific configuration file.
#include "../../voxConfig/vox_config.h"
#else
// The GAME_VOX_CONFIG_ALT_FILE macro can be used to point to an alternate.
// For example, the following preprocessor definition can be added to the project settings:
// GAME_VOX_CONFIG_ALT_FILE=\"my_vox_config.h\"
#include GAME_VOX_CONFIG_ALT_FILE
#endif

#include "vox_types.h"

//*  BOOKMARKS *//
//
//  You can find setting related to a spefic part of vox by searching a bookmark
//
//   1. GENERAL               [GENERAL]
//   2. MEMORY                [MEMORY]
//   3. DEBUG                 [DEBUG]
//   4. VOX INTERNAL THREAD   [THREAD]
//   5. DATA SOURCES          [DATASOURCE]
//   6. EMITTERS              [EMITTER]
//   7. 3D SOUND              [3DSOUND]
//   8. STB VORBIS            [STBVORBIS]
//   9. OPENAL DRIVER         [OPENAL]
//  10. REMOTEIO DRIVER       [REMOTEIO]
//	11. MACOSX DRIVER         [MACOSX]
//  12. MULTISTREAM DRIVER    [PS3MS]
//  13. SDL DRIVER            [SDL]
//  14. BADA DRIVER           [BADA]
//  15. DATA DRIVER           [DATA]
//  16. PS3                   [PS3]
//  17. DSP                   [DSP]
//  18. NO CATEGORY           [MISC]
//  19. ALSA DRIVER           [ALSA]
//	20.	ZIP                   [ZIP]
//	21. IPOD                  [IPOD]
//  22. IPHONE                [IPHONE]
//  23. CTR                   [CTR]
//  24. PROFILER              [PROFILER]
//	25. VXN DECODER			  [VXN DECODER]
//  26. ANDROID				  [ANDROID]
//  27. VITA				  [VITA]
//  28. GOOGLE CHROME NACL    [NACL]
//  29. QSA	DRIVER		  	  [BLACKBERRYPLAYBOOK]
//  30. MMSYSTEM DRIVER		  [MMSYSTEM]
//
//******************************************************************************
//   1. GENERAL               [GENERAL]
//******************************************************************************

// This define will compile Vox to use glf classes within the generic layer.
#ifndef VOX_USE_GLF
#define VOX_USE_GLF 0
#endif

#ifndef VOX_MAX_STREAM_TYPES
#define VOX_MAX_STREAM_TYPES 32
#endif

#ifndef VOX_MAX_DECODER_TYPES
#define VOX_MAX_DECODER_TYPES 32
#endif

#ifndef VOX_USE_SOUNDPACK_XML
#define VOX_USE_SOUNDPACK_XML 0
#endif

#ifndef VOX_NB_TIMESTAMP_GROUP
#define VOX_NB_TIMESTAMP_GROUP 16
#endif

//******************************************************************************
//   2. MEMORY                [MEMORY]
//******************************************************************************

// When this define is one Vox will use allocator with debug parameters.
#ifndef VOX_DEBUG_MEMORY
#define VOX_DEBUG_MEMORY 0
#endif

// If VOX_CUSTOM_ALLOCATOR is set to 1, the application has to define
// both allocation and free function :
//typedef unsigned int size_t;
//void* VoxAlloc(size_t size, const char* filename, const char* function, int line);
//void* VoxAlloc(size_t size);
//void VoxFree(void* ptr);
#ifndef VOX_CUSTOM_ALLOCATOR
#define VOX_CUSTOM_ALLOCATOR 0
#endif

// AUTORELEASE is now mandatory, these options are no longer user defined
#ifdef VOX_AUTORELEASE_DATA_SOURCE
#undef VOX_AUTORELEASE_DATA_SOURCE
#endif
#define VOX_AUTORELEASE_DATA_SOURCE 1

#ifdef VOX_AUTORELEASE_EMITTER
#undef VOX_AUTORELEASE_EMITTER
#endif
#define VOX_AUTORELEASE_EMITTER 1

//******************************************************************************
//   3. DEBUG                 [DEBUG]
//******************************************************************************

#ifndef VOX_ASSERT
#define VOX_ASSERT(X) // none
#endif

// By setting VOX_WARNING_LEVEL, all warning with level higher than VOX_WARNING_LEVEL wil lget ignore
//
// VOX_WARNING_LEVEL_1 Major error, will most likely be related to an error that make VoxEngine unusable.  Failed assert message also use this level.
// VOX_WARNING_LEVEL_2 Major error that has a major impact on the playback, as an error in a data source
// VOX_WARNING_LEVEL_3 Minor error that should only impact 1 sound playback, as an error in an emmiter
// VOX_WARNING_LEVEL_4 Minor error that should not have any impact, as setting volume higher than maximum value
// VOX_WARNING_LEVEL_5 Mainly information about what happening in Vox
//
#ifndef VOX_WARNING_LEVEL
#define VOX_WARNING_LEVEL 0
#endif

// Vox console is thread safe buffer base console
// This allow to flush all output once a frame and warning level are color coded on platform supporting it
#ifndef VOX_USE_CONSOLE
#define VOX_USE_CONSOLE 0
#endif

#ifndef VOX_MAX_CONSOLE_ENTRY
#define VOX_MAX_CONSOLE_ENTRY 1024
#endif

#ifndef VOX_DEBUG_SERVER_ENABLE
#define VOX_DEBUG_SERVER_ENABLE 0
#else 
#ifndef _WIN32 //Only support on win32 atm
#undef VOX_DEBUG_SERVER_ENABLE
#define VOX_DEBUG_SERVER_ENABLE 0
#endif
#endif

#ifndef VOX_DEBUG_SERVER_REMOTE_ADDRESS
#define VOX_DEBUG_SERVER_REMOTE_ADDRESS {(char)127,(char)0,(char)0,(char)1}
#endif

#ifndef VOX_DEBUG_SERVER_REMOTE_PORT
#define VOX_DEBUG_SERVER_REMOTE_PORT 11000
#endif

#ifndef VOX_DEBUG_SERVER_LISTEN_PORT
#define VOX_DEBUG_SERVER_LISTEN_PORT 11001
#endif

#ifndef VOX_DEBUG_SERVER_UPDATE_RATE
#define VOX_DEBUG_SERVER_UPDATE_RATE 1
#endif

//******************************************************************************
//   4. VOX INTERNAL THREAD   [THREAD]
//******************************************************************************

// VOX_THREAD_SAFETY_LEVEL 0 => No thread safety enabled
// VOX_THREAD_SAFETY_LEVEL 1 => Both UpdateEmitter and UpdateSource are safe to run in their own thread

#ifndef VOX_THREAD_SAFETY_LEVEL
#define VOX_THREAD_SAFETY_LEVEL 0
#endif

// Minimal time between voxthread update loop
#ifndef VOX_THREAD_UPDATE_DT
#define VOX_THREAD_UPDATE_DT 33 //ms
#endif

// This defined the platform offcially supported by Vox Audio Engine that use
// Posix thread.  This define can be enable to activate Posix thread for platform
// that are not officially supported by Vox Audio Engine.  This define is 
// overiden when GLF is used or a platform spefic threading API is available.
#ifndef VOX_USE_PTHREAD
#if defined(_LINUX) || defined(_LIMO) || defined(_IPHONE_OS) || defined(_MAC_OSX_INTEL) || defined(_PALMPRE) || defined(_ANDROID) || defined(__native_client__) || defined(__QNXNTO__)
#define VOX_USE_PTHREAD 1
#else
#define VOX_USE_PTHREAD 0
#endif
#endif

// VOX_THREADING_MODE_NONE          => No intern thread
// VOX_THREADING_MODE_SINGLE_THREAD => 1 thread that do both updates
// VOX_THREADING_MODE_DUAL_THREAD   => Each update has it's own thread
// If multi-threading is enabled, thread safety is forced to 1
#ifdef VOX_THREADING_MODE_NONE
#undef VOX_THREADING_MODE_SINGLE_THREAD
#undef VOX_THREADING_MODE_DUAL_THREAD
#elif defined(VOX_THREADING_MODE_SINGLE_THREAD)
#undef VOX_THREADING_MODE_DUAL_THREAD
#undef VOX_THREAD_SAFETY_LEVEL
#define VOX_THREAD_SAFETY_LEVEL 1
#elif defined(VOX_THREADING_MODE_DUAL_THREAD)
#undef VOX_THREAD_SAFETY_LEVEL
#define VOX_THREAD_SAFETY_LEVEL 1
#else
#define VOX_THREADING_MODE_NONE
#undef VOX_THREAD_SAFETY_LEVEL
#define VOX_THREAD_SAFETY_LEVEL 0
#endif


// This define allow to use user-defined priority for pthread instead of using
// default value.  This will not change the scheduling policy
#ifndef VOX_OVERRIDE_PTHREAD_DEFAULT_PRIORITY
#define VOX_OVERRIDE_PTHREAD_DEFAULT_PRIORITY 0
#endif

// When VOX_OVERRIDE_PTHREAD_DEFAULT_PRIORITY is enabled, this define set the 
// value of the priority to use
#ifndef VOX_PTHREAD_PRIORITY
#define VOX_PTHREAD_PRIORITY 31
#endif

//******************************************************************************
//   5. DATA SOURCES          [DATASOURCE]
//******************************************************************************

//
//	Define the number of priority bank created by default. By defaut only create
//	one.
//
#ifndef VOX_NUM_PRIORITY_BANK
#define VOX_NUM_PRIORITY_BANK 1
#endif

//
// To define your own data source user data, first define VOX_USE_CUSTOM_DATA_SOURCE_USER_DATA
// then define the class DataSourceUserData as you want it.  The class is responsible of its own data.
// The only garantee is that the constructor is called at the construction of a data source and the
// destructor will be call at the destruction of the data source.  The class should handle properly
// copy and assignation. If thread are active, at least copy and assignation should be thread-safe.
//
#ifndef VOX_USE_CUSTOM_DATA_SOURCE_USER_DATA
namespace vox
{
//! User defined data for data source object
/*!
	This class is meant to contain user defined data associated with a data source object.  The default constructor
	should create a state that is easily identified with uninitialized object, since it will get returned on any
	failed getter call and for data source object that no user data was set.  If threading is active, this class should be made
	be thread-safe.  The class define in "vox_default_config.h".  The user can redefined it by first defining
	VOX_USE_CUSTOM_EMITTER_USER_DATA, than creating its own EmitterHandleUserData class in the custom define header.
*/
class DataHandleUserData
{
public:
	DataHandleUserData():m_userId(-1){}
	DataHandleUserData(s32 userId):m_userId(userId){}

	s32 GetUserId() const {return m_userId;}
	void SetUserId(s32 userId){m_userId = userId;}
private:
	s32 m_userId;
};
}
#endif

//******************************************************************************
//   6. EMITTERS              [EMITTER]
//******************************************************************************

//
//  Default fade time for all methods that support fading in seconds
//
#ifndef VOX_DEFAULT_FADE_TIME
#define VOX_DEFAULT_FADE_TIME 0.f
#endif

#ifndef VOX_DRIVER_SOURCE_NUM_BUFFER
#define VOX_DRIVER_SOURCE_NUM_BUFFER 3
#endif

#ifndef VOX_EMITTER_BUFFER_DURATION_MS
#define VOX_EMITTER_BUFFER_DURATION_MS 250 //ms
#endif

#ifndef VOX_BUFFERED_FILE_STREAM
#define VOX_BUFFERED_FILE_STREAM 1
#endif

#ifndef VOX_FILE_STREAM_BUFFER_SIZE
#define VOX_FILE_STREAM_BUFFER_SIZE 128 * 1024
#endif

//
//	If VOX_USE_EMITTER_PREFETCH is enable, the emitter will prefecth data at
//	every update according to update dt.  When disable, the emitter only fetch
//	the data to fill the whole buffer when the driver needs data.  Enabling it
//	may slightly reduce performance, but will allow more consistent update
//	duration.
//
#ifndef VOX_USE_EMITTER_PREFETCH
#define VOX_USE_EMITTER_PREFETCH 0
#endif

#ifndef VOX_ENABLE_EMITTER_STATE_CHANGED_CALLBACK
#define VOX_ENABLE_EMITTER_STATE_CHANGED_CALLBACK 0
#endif

//
//	Vox default sound parameters
//

//
//	Default value for the master gain parameter.  This will be the master gain
//	until set by the application
//
#ifndef VOX_DEFAULT_MASTER_GAIN
#define VOX_DEFAULT_MASTER_GAIN 1.0f
#endif

//
//	Default gain value for all group.  Each group will use this value, unless 
//	set by the application
//
#ifndef VOX_DEFAULT_GROUP_GAIN
#define VOX_DEFAULT_GROUP_GAIN 1.0f
#endif

//
//	Default gain value for all newly created emitter.  There's not fade on the 
//	initial gain value.
//
#ifndef VOX_DEFAULT_EMITTER_GAIN
#define VOX_DEFAULT_EMITTER_GAIN 1.0f
#endif

//
//	Initial pitch value for all newly created emitter.  Unless set by the 
//	application for each emitter, this is the value used.
//
#ifndef VOX_DEFAULT_EMITTER_PITCH
#define VOX_DEFAULT_EMITTER_PITCH 1.0f
#endif

//
// To define your own emitter user data, first define VOX_USE_CUSTOM_EMITTER_USER_DATA
// then define the class EmitterHandleUserData as you want it.  The class is responsible of its own data.
// The only garantee is that the constructor is called at the construction of an emitter and the
// destructor will be call at the destruction of the emitter.  The class should handle properly
// copy and assignation. If thread are active, at least copy and assignation should be thread-safe.
//
#ifndef VOX_USE_CUSTOM_EMITTER_USER_DATA
namespace vox
{
//! User defined data for emitter object
/*!
	This class is meant to contain user defined data associated with an emitter object.  The default constructor
	should create a state that is easily identified with uninitialized object, since it will get returned on any
	failed getter call and for emitter object that no user data was set.  If threading is active, this class should be made
	be thread-safe.  The class define in "vox_default_config.h".  The user can redefined it by first defining
	VOX_USE_CUSTOM_EMITTER_USER_DATA, than creating its own EmitterHandleUserData class in the custom define header.
*/
class EmitterHandleUserData
{
public:
	EmitterHandleUserData():m_userId(-1){}
	EmitterHandleUserData(s32 userId):m_userId(userId){}

	s32 GetUserId() const {return m_userId;}
	void SetUserId(s32 userId){m_userId = userId;}
private:
	s32 m_userId;
};
}
#endif

//******************************************************************************
//   7. 3D SOUND              [3DSOUND]
//******************************************************************************

//
//	Vox default 3d sound parameters
//	Since Vox first hardware driver was OpenAL, most of the 3D sound parameter
//	are based on OpenAL 1.1 specifications.  For more information on a
//	parameter, the specification should be in the OpenAL folder of the library 
//	folder. The specification should also be available from creative labs
//	website.	
//
//	There is not set unit system in Vox.  You are free to use any unit
//	system, as long it's the same for all emitters and listener.  The only
//	exception to this is the constant for the speed of sound that uses meter
//	per second as a unit.  This constant is only used in doppler effect 
//	calculation.
//

//
//	Default Vox 3D model. The model k_nNone implitly disables any 3D sound
//	processing. The model currently avaibable are listed in Vox3DDistanceModel
//	namespace in vox.h.  For more detailed information on each model, you can 
//	refer to either OpenAL 1.1 specification or Vox user documentation.  As of
//	iPhone OS 3.1.2 OpenAL implementation, disabling distance attenuation is 
//	bugged and should be used.
//
#ifndef VOX_DEFAULT_3D_MODEL
#define VOX_DEFAULT_3D_MODEL Vox3DDistanceModel::k_nInverseDistanceClamped
#endif

//
//	Factor to apply to doppler effect calculation.  A value higher than 1.0
//	will exagerate the doppler effect, while a value lower than 1.0 will reduce
//	it.
//
#ifndef VOX_DEFAULT_3D_DOPPLER_FACTOR
#define VOX_DEFAULT_3D_DOPPLER_FACTOR 1.0f
#endif

//
//	This is the default speed of sound to use in doppler effect calculation.
//	This value is in meter per second.  IMPORTANT : If the velocity vector of 
//	emitters and listener do not use this unit, this value need to be set to 
//	the same unit system.  This constant represent the speed of sound in air at
//	sea level.
//
#ifndef VOX_DEFAULT_3D_SPEED_OF_SOUND
#define VOX_DEFAULT_3D_SPEED_OF_SOUND 343.3f
#endif

//
//	This parameter controls the front/back and up/down sound position
//  simulation at run time. Enabling this increases CPU usage for positioned sources.
//
#ifndef VOX_DEFAULT_3D_ENHANCED_3D
#define VOX_DEFAULT_3D_ENHANCED_3D 0
#endif

//
//	Default listener position in the 3D world.
//
#ifndef VOX_DEFAULT_3D_LISTENER_POSITION
#define VOX_DEFAULT_3D_LISTENER_POSITION { 0.0f, 0.0f, 0.0f }
#endif

//
//	Default listener velocity in the 3D world.
//
#ifndef VOX_DEFAULT_3D_LISTENER_VELOCITY
#define VOX_DEFAULT_3D_LISTENER_VELOCITY { 0.0f, 0.0f, 0.0f }
#endif

//
//	Default up vector for the listener.
//
#ifndef VOX_DEFAULT_3D_LISTENER_UP 
#define VOX_DEFAULT_3D_LISTENER_UP { 0.0f, 1.0f, 0.0f }
#endif

//
//	Default "look at" vector for the listener.  The combination of this value
//	and "up" value create the orientation parameter.
//
#ifndef VOX_DEFAULT_3D_LISTENER_LOOKAT
#define VOX_DEFAULT_3D_LISTENER_LOOKAT { 0.0f, 0.0f, -1.0f }
#endif

//
//	This value determine if all vector value of the emitter have their origin
//	at the world origin or at the listener position.  This is the default value
//	for all newly creted emitter.
//
#ifndef VOX_DEFAULT_3D_EMITTER_RELATIVE_TO_LISTENER
#define VOX_DEFAULT_3D_EMITTER_RELATIVE_TO_LISTENER 0
#endif

//
//	Default value for max distance in attenuation calculation.  Depending on
//	the current attenutation model, this value doesn't have the same effect.
//	For more information on attenuation model, you can look at OpenAL
//	specification or Vox user documention. The default value is the maximum
//	value for a single precision floating point variable according to IEEE 
//	standard 754.  If you system uses another standard, this value might not be
//	adequate.
//
#ifndef VOX_DEFAULT_3D_EMITTER_MAX_DISTANCE
#define VOX_DEFAULT_3D_EMITTER_MAX_DISTANCE 3.40282346638528860e+38
#endif 

//
//	Default initial distance for attenuation calculation for clamped model. In
//	clamped model, this is the absolute minimum distance needed before any
//	attenuation is applied to the emitter. This value needs to be equal or 
//	higher than zero.
//
#ifndef VOX_DEFAULT_3D_EMITTER_REFERENCE_DISTANCE
#define VOX_DEFAULT_3D_EMITTER_REFERENCE_DISTANCE 1.0f
#endif

//
//	Default rolloff factor for attenuation calculation.  This value has a
//	effect on the amplitude of the attenuation.  The higher the value, the
//	stronger will be the attenuation. This value needs to equal or higher than
//	zero.
//
#ifndef VOX_DEFAULT_3D_EMITTER_ROLLOFF_FACTOR
#define VOX_DEFAULT_3D_EMITTER_ROLLOFF_FACTOR 1.0f
#endif

//
//	Default angle for the inner cone for directional sound.  The cone is
//	positioned according to the emitter position and direction.  The inner cone
//	is the region where no radial attenuation is applied.  This is the radial
//	equivalent of the reference distance.
//
#ifndef VOX_DEFAULT_3D_EMITTER_INNER_CONE_ANGLE
#define VOX_DEFAULT_3D_EMITTER_INNER_CONE_ANGLE 360.0f
#endif

//
//	Default angle for the outer cone for directionnal sound.  This cone is 
//	positioned according to the emitter position and direction.  The outer cone
//	is the outer limit for attenuation calculation.  For the region between the
//	inner cone and the outer cone, a linear attenuation, based on the angle is 
//	applied. For the region outside the outer cone, a constant value is used.
//	For directionnal sound, this attenuation is multiplied with the distance
//	attenuation facor.
//
#ifndef VOX_DEFAULT_3D_EMITTER_OUTER_CONE_ANGLE
#define VOX_DEFAULT_3D_EMITTER_OUTER_CONE_ANGLE 360.0f
#endif

//
//	Default gain value for the zone outside the outer cone of a directionnal
//	sound.  The distance attenuation is applied to that value.
//
#ifndef VOX_DEFAULT_3D_EMITTER_OUTER_CONE_GAIN
#define VOX_DEFAULT_3D_EMITTER_OUTER_CONE_GAIN 0.0f
#endif

//
//	Default ditance value to exclude an emitter for the 3D sound redering. At
//	the moment no driver support this parameter.
//
#ifndef VOX_DEFAULT_3D_EMITTER_CULLING_DISTANCE
#define VOX_DEFAULT_3D_EMITTER_CULLING_DISTANCE 3.40282346638528860e+38
#endif

//
//	Default position for all newly created emitter. The effect of this value
//	will varie depending if the emitter vector are relative to the origin of
//	the world or the to the position of the emitter.The default value is the 
//	maximum value for a single precision floating point variable according to 
//	IEEE standard 754.  If you system uses another standard, this value might 
//	not be adequate.
//
#ifndef VOX_DEFAULT_3D_EMITTER_POSITION
#define VOX_DEFAULT_3D_EMITTER_POSITION { 0.0f, 0.0f, 0.0f }
#endif

//
//	Default velocity for all newly created emitter. The effect of this value
//	will varie depending if the emitter vector are relative to the origin of
//	the world or the to the position of the emitter.
//
#ifndef VOX_DEFAULT_3D_EMITTER_VELOCITY
#define VOX_DEFAULT_3D_EMITTER_VELOCITY { 0.0f, 0.0f, 0.0f }
#endif

//
//	Default direction for all newly created emitter. The effect of this value
//	will varie depending if the emitter vector are relative to the origin of
//	the world or the to the position of the emitter.  This vector is only used
//	for directionnal emitter (inner cone < 360 degree).
//
#ifndef VOX_DEFAULT_3D_EMITTER_DIRECTION
#define VOX_DEFAULT_3D_EMITTER_DIRECTION { 0.0f, 0.0f, 0.0f }
#endif

//
// Power value in channel located on the same side as source, when source is totally on one side of listener.
// For default value of 1.0, no sound will be heard in left (right) channel if source is totally to the right
// (left). For values smaller than 1.0f, VOX_MAX_STEREO_PANNING_POWER of the power will be in the channel that
// is on the same side as source and 1 - VOX_MAX_STEREO_PANNING_POWER of the power will in the channel opposite
// from source. One must have 0.5 <= VOX_MAX_STEREO_PANNING_POWER <= 1.0f, where 0.5 corresponds to both channels
// having the same power. Realistic values would rather be larger than 0.8f.
//
#ifndef VOX_MAX_STEREO_PANNING_POWER
#define VOX_MAX_STEREO_PANNING_POWER 1.0f
#endif

//******************************************************************************
//   8. STB VORBIS            [STBVORBIS]
//******************************************************************************

//
//	STBVORBIS decoder can use a buffer for all its allocations.  If enabled, one buffer
//	will be allocated per decoder.  If disabled, the decoder will use vox standard 
//	allocator (around 350 allocations per decoder).
//
#ifndef VOX_USE_STBVORBIS_INTERNAL_BUFFER
#define VOX_USE_STBVORBIS_INTERNAL_BUFFER 0
#endif

//
//	If STBVORBIS internal buffer are enabled, the size of the buffer can be change.  According to
//	STBVORBIS documentation, 150k bytes are needed for each decoder instance.  Each emitter using
//	STBVORBIS decoder will have its own decoder instance.  If the buffer size is too small, the intern
//	allocator will override the setting and use Vox allocator to allocate remaining memory needed.
//
#ifndef VOX_STBVORBIS_INTERNAL_BUFFER_SIZE
#define VOX_STBVORBIS_INTERNAL_BUFFER_SIZE (150 << 10) // 150 kbytes
#endif

//
//	Since most of STBVORBIS data is the same for every decoder using the same file and is read-only,
//	some of it can be share by all theses decoders.  When this setting is active, the main
//	decoder data will be store inside the data source, then sent to every new emitter.  This bring
//	the cost in memory to around 150k for the main decoder data and 6k x numChannel per emitter.
//	Enabling shared data also prevent to recreate the codebook for each emitter. This setting 
//	is experimental at the moment and should be tested with the application data.
//
#ifndef VOX_ALLOW_STBVORBIS_SHARE_COMMON_DATA
#define VOX_ALLOW_STBVORBIS_SHARE_COMMON_DATA 0
#endif

//
//	If data sharing is enabled, STBVORBIS internal buffer cannot be used since the shared and 
//	private data share the same allocator.
//
#if VOX_ALLOW_STBVORBIS_SHARE_COMMON_DATA && VOX_USE_STBVORBIS_INTERNAL_BUFFER
#undef VOX_USE_STBVORBIS_INTERNAL_BUFFER
#define VOX_USE_STBVORBIS_INTERNAL_BUFFER 0
#endif

//******************************************************************************
//  10. REMOTEIO DRIVER       [REMOTEIO]
//******************************************************************************

#ifndef VOX_IPHONE_REMOTEIO_DRIVER_PLATFORM
#if (defined(_IPHONE_OS))
#define VOX_IPHONE_REMOTEIO_DRIVER_PLATFORM 1
#else
#define VOX_IPHONE_REMOTEIO_DRIVER_PLATFORM 0
#endif
#endif

#ifndef VOX_DRIVER_USE_IPHONE_REMOTEIO
#define VOX_DRIVER_USE_IPHONE_REMOTEIO 0
#endif

#ifndef VOX_IPHONE_REMOTEIO_DRIVER_PREFERRED_RATE
#define VOX_IPHONE_REMOTEIO_DRIVER_PREFERRED_RATE 32000.0 // Hz
#endif

#ifndef VOX_IPHONE_REMOTEIO_DRIVER_BUFFER_LENGTH
#define VOX_IPHONE_REMOTEIO_DRIVER_BUFFER_LENGTH	0.023f //seconds
#endif

#ifndef VOX_IPHONE_REMOTEIO_OVERRIDE_HW_IO_BUFFER_LENGTH
#define VOX_IPHONE_REMOTEIO_OVERRIDE_HW_IO_BUFFER_LENGTH 0
#endif

#ifndef VOX_REMOTEIO_FORCE_SW_RESAMPLER
#define VOX_REMOTEIO_FORCE_SW_RESAMPLER 1
#endif

//******************************************************************************
//  11. MACOSX DRIVER       [MACOSX]
//******************************************************************************

#ifndef VOX_MACOSX_AUDIOUNIT_DRIVER_PLATFORM
#if defined(_MAC_OSX_INTEL)
#define VOX_MACOSX_AUDIOUNIT_DRIVER_PLATFORM 1
#else
#define VOX_MACOSX_AUDIOUNIT_DRIVER_PLATFORM 0
#endif
#endif

#define VOX_DRIVER_USE_MACOSX_AUDIOUNIT 1

#ifndef VOX_MACOSX_AUDIOUNIT_DRIVER_PREFERRED_RATE
#define VOX_MACOSX_AUDIOUNIT_DRIVER_PREFERRED_RATE 44100.0 // Hz
#endif

//******************************************************************************
//  12. MULTISTREAM DRIVER    [PS3MS]
//******************************************************************************

#ifndef VOX_PS3_MULTISTREAM_DRIVER_PLATFORM
#if (defined(_PS3))
#define VOX_PS3_MULTISTREAM_DRIVER_PLATFORM 1
#else
#define VOX_PS3_MULTISTREAM_DRIVER_PLATFORM 0
#endif
#endif

#ifndef VOX_DRIVER_USE_PS3_MULTISTREAM
#define VOX_DRIVER_USE_PS3_MULTISTREAM 0
#endif

// If Vox is the only library using spu and spurs you can let it initialize
// both by setting this switch to 1.  However, if the Spurs manager is shared
// then you should not let Vox initialize it and the application should expose
// the method : 
//    CellSpurs* GetSpursStruct()
// To give Vox access to the spurs structure.
#ifndef VOX_PS3_INIT_SPURS
#define VOX_PS3_INIT_SPURS 0
#endif

// This enable Sulpha for MultiStream Debuging.  By enabling this switch the 
// user can use Sulpha PC Tool to connect to MultiStream and see what is 
// happening in real time.
// 
#ifndef VOX_PS3_USE_SULPHA
#define VOX_PS3_USE_SULPHA 0
#endif

// This define set the maximum number of stream available in MultiStream. Each
// channel of a sound file takes 1 stream (mono = 1, stereo = 2, quad = 4, ...)
// Each stream cost around 12k of ram (as of SDK 341).  Once you knw the maximum
// of stream needed, this define should be adjusted accordingly
//
#ifndef VOX_DRIVER_PS3_MS_MAX_STREAMS
#define VOX_DRIVER_PS3_MS_MAX_STREAMS	(400)
#endif

// This define set the output format to support in Multistream. By default, all
// available format are supported, with DTS preferred. Refer to mstream.h and
// Multistream documentation for more information on this setting. Removal of
// CELL_MS_AUDIOMODESELECT_SUPPORTSLPCM if an automatic TRC failure.
//
#ifndef VOX_DRIVER_PS3_MS_OUTPUT_FORMAT
#define VOX_DRIVER_PS3_MS_OUTPUT_FORMAT (CELL_MS_AUDIOMODESELECT_SUPPORTSLPCM | CELL_MS_AUDIOMODESELECT_SUPPORTSDOLBY | CELL_MS_AUDIOMODESELECT_SUPPORTSDTS | CELL_MS_AUDIOMODESELECT_PREFERDTS)
#endif

// This define set the output channel configuration.  By default, 8 channels
// mode is on. All games using 3D sound should leave to 8 channels.  Multistream
// will downmix to other configuration automatically to match the reciever.
// Supported modes are :
//	CELL_AUDIO_PORT_2CH
//	CELL_AUDIO_PORT_8CH
//
#ifndef VOX_DRIVER_PS3_MS_OUTPUT_CHANNEL
#define VOX_DRIVER_PS3_MS_OUTPUT_CHANNEL CELL_AUDIO_PORT_8CH
#endif


// This define set the mask to define the bus mode (frequecy or time domain) 
// Unless there is a warning about a bus creation failed because the manager ran
// out of bus of a type, do not change this value.  Valid range is from 
// 0xF0000000 to 0xFFFFFFF0 and must be continuous (0xF0F00000 is not valid)
#ifndef VOX_DRIVER_PS3_MS_BUS_MASK
#define VOX_DRIVER_PS3_MS_BUS_MASK 0xFFFF0000
#endif

//******************************************************************************
//  13. SDL DRIVER            [SDL]
//******************************************************************************

#ifndef VOX_SDL_DRIVER_PLATFORM
#if (defined(_WIN32) || defined(_PALMPRE))
#define VOX_SDL_DRIVER_PLATFORM 1
#else
#define VOX_SDL_DRIVER_PLATFORM 0
#endif
#endif

#ifndef VOX_DRIVER_USE_SDL
#define VOX_DRIVER_USE_SDL 0
#endif

#ifndef VOX_SDL_DRIVER_PREFERRED_RATE
#define VOX_SDL_DRIVER_PREFERRED_RATE 44100 // Hz
#endif

#ifndef VOX_SDL_DRIVER_BUFFER_LENGTH
#define VOX_SDL_DRIVER_BUFFER_LENGTH				0.016f //seconds
#endif

//******************************************************************************
//  30. MMSYSTEM DRIVER            [MMSYSTEM]
//******************************************************************************

#ifndef VOX_MMSYSTEM_DRIVER_PLATFORM
#if defined(_WIN32)
#define VOX_MMSYSTEM_DRIVER_PLATFORM 1
#else
#define VOX_MMSYSTEM_DRIVER_PLATFORM 0
#endif
#endif

#ifndef VOX_DRIVER_USE_MMSYSTEM
#if VOX_DRIVER_USE_SDL
#define VOX_DRIVER_USE_MMSYSTEM 0
#else
#define VOX_DRIVER_USE_MMSYSTEM 1
#endif
#endif

#ifndef VOX_MMSYSTEM_DRIVER_PREFERRED_RATE
#define VOX_MMSYSTEM_DRIVER_PREFERRED_RATE 44100 // Hz
#endif

#ifndef VOX_MMSYSTEM_DRIVER_BUFFER_LENGTH
#define VOX_MMSYSTEM_DRIVER_BUFFER_LENGTH  0.050f //seconds
#endif

//******************************************************************************
//  14. BADA DRIVER           [BADA]
//******************************************************************************

#ifndef VOX_BADA_DRIVER_PLATFORM
#if (defined(_BADA))
#define VOX_BADA_DRIVER_PLATFORM 1
#else
#define VOX_BADA_DRIVER_PLATFORM 0
#endif
#endif

#ifndef VOX_DRIVER_USE_BADA
#define VOX_DRIVER_USE_BADA 0
#endif

// Application needs to set VOX_BADA_DRIVER_USE_PREFERRED_RATE if it wants to impose
// VOX_BADA_DRIVER_PREFERRED_RATE as the sampling rate at which vox bada driver provides
// samples to the underlying audio API. If not, the driver will set this rate based upon
// the 'optimized' sample rate queried from the API. The reason for this is that sound
// problems have been experienced (in the emulator) when using a sample rate other than
// the 'optimized' rate. At this point, sound has not been tested on the devices.
#ifndef VOX_BADA_DRIVER_USE_PREFERRED_RATE
#define VOX_BADA_DRIVER_USE_PREFERRED_RATE 0
#endif

#ifndef VOX_BADA_DRIVER_PREFERRED_RATE
#define VOX_BADA_DRIVER_PREFERRED_RATE 44100 // Hz
#endif

#ifndef VOX_BADA_DRIVER_BUFFER_LENGTH
#define VOX_BADA_DRIVER_BUFFER_LENGTH				0.016f //seconds
#endif

//******************************************************************************
//  15. DATA DRIVER           [DATA]
//******************************************************************************

#ifndef VOX_DATA_DRIVER_PLATFORM
#if defined(_WIN32)
#define VOX_DATA_DRIVER_PLATFORM 1
#else
#define VOX_DATA_DRIVER_PLATFORM 0
#endif
#endif

#ifndef VOX_DRIVER_USE_DATA
#define VOX_DRIVER_USE_DATA 0
#endif

#ifndef VOX_DATA_DRIVER_PREFERRED_RATE
#define VOX_DATA_DRIVER_PREFERRED_RATE 44100 // Hz
#endif

//******************************************************************************
//   9. OPENAL DRIVER         [OPENAL]
//******************************************************************************

#ifndef VOX_OPENAL_DRIVER_PLATFORM
#if (defined(_WIN32) || defined(_IPHONE_OS) || defined(_PS3))
#define VOX_OPENAL_DRIVER_PLATFORM 1
#else
#define VOX_OPENAL_DRIVER_PLATFORM 0
#endif
#endif

// To use platform specific driver instead of OpenAL driver define one of the
// defines in the configuration file.  If minimal requirement to use the driver
// is not met, Vox will use OpenAL as a fallback.  See ProjectIntegration HowTo
// for more detail on each driver
#ifndef VOX_USE_OPENAL_DRIVER
#if !((VOX_DRIVER_USE_PS3_MULTISTREAM && VOX_PS3_MULTISTREAM_DRIVER_PLATFORM) || \
	  (VOX_DRIVER_USE_IPHONE_REMOTEIO && VOX_IPHONE_REMOTEIO_DRIVER_PLATFORM) || \
	  (VOX_DRIVER_USE_SDL && VOX_SDL_DRIVER_PLATFORM) || \
	  (VOX_DRIVER_USE_MMSYSTEM && VOX_MMSYSTEM_DRIVER_PLATFORM) || \
	  (VOX_DRIVER_USE_DATA && VOX_DATA_DRIVER_PLATFORM) || \
	  (VOX_DRIVER_USE_BADA && VOX_BADA_DRIVER_PLATFORM) || \
	  (VOX_DRIVER_USE_ANDROID && VOX_ANDROID_DRIVER_PLATFORM))
#define VOX_USE_OPENAL_DRIVER 1
#else
#define VOX_USE_OPENAL_DRIVER 0
#endif
#endif

#ifndef VOX_OPENAL_AL_HEADER_LOCATION
#define VOX_OPENAL_AL_HEADER_LOCATION "../Libs/OpenAL/include/al.h"
#endif

#ifndef VOX_OPENAL_ALC_HEADER_LOCATION
#define VOX_OPENAL_ALC_HEADER_LOCATION "../Libs/OpenAL/include/alc.h"
#endif

#ifndef VOX_OPENAL_ALEXT_HEADER_LOCATION
#define VOX_OPENAL_ALEXT_HEADER_LOCATION "../Libs/OpenAL/OpenAL soft/includes/common/al_gext.h"
#endif

#ifndef VOX_OPENAL_SOURCE_NUM_BUFFER
#define VOX_OPENAL_SOURCE_NUM_BUFFER VOX_DRIVER_SOURCE_NUM_BUFFER
#endif

#ifndef VOX_OPENAL_ENABLE_SOURCE_POOL
#define VOX_OPENAL_ENABLE_SOURCE_POOL 0
#endif

#ifndef VOX_OPENAL_MAX_SOURCE
#define VOX_OPENAL_MAX_SOURCE 10 //Engine will try to allocate, but actual driver can have lower limit
#endif

//******************************************************************************
//  16. PS3                   [PS3]
//******************************************************************************

// On the PS3, Vox thread need to have higher priority than the main thread 
// to avoid starving.  When using MultiStream driver, main thread priority
// need to be higher than 1000.  When using using OpenAL soft driver, this
// Vox thread priority needs to be higher than 402.
#ifndef VOX_THREAD_PS3_PRIORITY
#define VOX_THREAD_PS3_PRIORITY 1000
#endif

//******************************************************************************
//  17. DSP                   [DSP]
//******************************************************************************

// Enable DSPs, please refer to driver documentation to see if the DSP is
// supported.  Most DSPs will require to link to external binaries.
#ifndef VOX_DSP_ENABLE_COMPRESSOR
#define VOX_DSP_ENABLE_COMPRESSOR 0
#endif

#ifndef VOX_DSP_ENABLE_TDREVERB
#define VOX_DSP_ENABLE_TDREVERB 0
#endif

#ifndef VOX_DSP_ENABLE_FILTER
#define VOX_DSP_ENABLE_FILTER 0
#endif

#ifndef VOX_DSP_ENABLE_PITCHSHIFT
#define VOX_DSP_ENABLE_PITCHSHIFT 0
#endif

#ifndef VOX_DSP_ENABLE_IMPULSEREVERB
#define VOX_DSP_ENABLE_IMPULSEREVERB 0
#endif

#ifndef VOX_DSP_ENABLE_PARAMETRIC_EQ
#define VOX_DSP_ENABLE_PARAMETRIC_EQ 0
#endif

#ifndef VOX_DSP_ENABLE_DELAY
#define VOX_DSP_ENABLE_DELAY 0
#endif

#ifndef VOX_DSP_ENABLE_DISTORTION
#define VOX_DSP_ENABLE_DISTORTION 0
#endif

#ifndef VOX_DSP_ENABLE_OCCLUSION
#define VOX_DSP_ENABLE_OCCLUSION 0
#endif


//******************************************************************************
//  18. NO CATEGORY           [MISC]
//******************************************************************************

#ifndef VOX_BIG_ENDIAN
#if defined(_PS3)
#	define VOX_BIG_ENDIAN 1
#else
#	define VOX_BIG_ENDIAN 0
#endif
#endif

// Enable processing of sounds to give a front/back and up/down effect
// using filters derived from HRTFs. You will want to disable this on
// armv6 platforms, as cpu usage for mixing mono sounds gets
// multiplied by 8 unless the Neon mixer is turned on (see below).
// Even on platforms that support Neon, you might want to turn this
// off to improve performance.
// See documentations/vox_enhanced_3d.txt for more info.
#ifndef VOX_ENHANCED_3D
#define VOX_ENHANCED_3D 0
#endif

// Processes the enhanced 3d filters using floating point. No effect
// if the Neon mixer is used. Slightly slower than integer filters.
#ifndef VOX_ENHANCED_3D_FLOAT
#define VOX_ENHANCED_3D_FLOAT 0
#endif

#ifndef VOX_USE_NEON_MIXER
#define VOX_USE_NEON_MIXER 0
#endif

#if VOX_USE_NEON_MIXER
#if defined(__ARM_NEON__)
#define VOX_NEON_MIXER 1
#else // IPhone & Android armv6..
#define VOX_NEON_MIXER 0
#endif

#else
#define VOX_NEON_MIXER 0
#endif


#ifndef VOX_USE_HANDLABLE_MAP
#if !defined(_NN_CTR)
#define VOX_USE_HANDLABLE_MAP 1
#else
#define VOX_USE_HANDLABLE_MAP 0
#endif
#endif

//#ifndef _ANDROID
#define VOX_LIST_INCLUDE <list>
#define VOX_LIST std::list
#define VOX_VECTOR_INCLUDE <vector>
#define VOX_VECTOR std::vector
#define VOX_MAP_INCLUDE <map>
#define VOX_MAP std::map
#define VOX_STRING_INCLUDE <string>
#define VOX_STRING std::basic_string< char, std::char_traits<char>, SAllocator<char> > 
//#define VOX_STRING std::string
//#else
//#define VOX_LIST_INCLUDE <stlport/list>
//#define VOX_LIST std::list
//#define VOX_VECTOR_INCLUDE <stlport/vector>
//#define VOX_VECTOR std::vector
//#define VOX_MAP_INCLUDE <stlport/map>
//#define VOX_MAP std::map
//#define VOX_STRING_INCLUDE <stlport/string>
//#define VOX_STRING std::basic_string< char, std::char_traits<char>, SAllocator<char> > 
//#endif

//******************************************************************************
//  19. ALSA DRIVER           [ALSA]
//******************************************************************************

#ifndef VOX_ALSA_DRIVER_PLATFORM
#if defined(_LINUX) || defined(_LIMO)
#define VOX_ALSA_DRIVER_PLATFORM 1
#else
#define VOX_ALSA_DRIVER_PLATFORM 0
#endif
#endif

#ifndef VOX_DRIVER_USE_ALSA
#if defined(_LINUX) || defined(_LIMO)
#define VOX_DRIVER_USE_ALSA 1
#else
#define VOX_DRIVER_USE_ALSA 0
#endif
#endif

#ifndef VOX_ALSA_DRIVER_PREFERRED_RATE
#define VOX_ALSA_DRIVER_PREFERRED_RATE 32000 // Hz
#endif

#ifndef VOX_ALSA_DRIVER_BUFFER_LENGTH
#define VOX_ALSA_DRIVER_BUFFER_LENGTH	0.25f // In seconds. Used only in callback mode.
#endif

#ifndef VOX_ALSA_API_DRIVER_BUFFER_LENGTH
#define VOX_ALSA_API_DRIVER_BUFFER_LENGTH	3 * VOX_ALSA_DRIVER_BUFFER_LENGTH // In seconds. Used only in callback mode.
#endif

#define VOX_ALSA_DRIVER_STREAM_MODE_CALLBACK	1
#define VOX_ALSA_DRIVER_STREAM_MODE_THREAD		2

#ifndef VOX_ALSA_DRIVER_STREAM_MODE
#define VOX_ALSA_DRIVER_STREAM_MODE	VOX_ALSA_DRIVER_STREAM_MODE_THREAD
#endif


//******************************************************************************
//  20. ZIP           [ZIP]
//******************************************************************************

#ifndef VOX_ZIP_MAGIC_NUMBER
#define VOX_ZIP_MAGIC_NUMBER 0x05044c51 //'PK' 03 04 +1 //Glitch obfuscating
#endif

//******************************************************************************
//	21. IPOD				  [IPOD]
//******************************************************************************

#ifndef VOX_IPOD_QUERY_ASYNC
#define VOX_IPOD_QUERY_ASYNC 1
#endif 

// After sync notification are broken, this control the poll rate of the ipod
#ifndef VOX_IPOD_POLLING_DT
#define VOX_IPOD_POLLING_DT 1.0
#endif

#ifndef VOX_SEND_IPOD_STATE_AFTER_DUCKING
#define VOX_SEND_IPOD_STATE_AFTER_DUCKING 0
#endif


//******************************************************************************
//  22. IPHONE                [IPHONE]
//******************************************************************************

#ifndef VOX_USE_POSIX_FILESYSTEM
#define VOX_USE_POSIX_FILESYSTEM 0
#endif

//******************************************************************************
//  23. CTR					  [CTR]
//******************************************************************************

// Activate CTR code when it the active device
#ifndef VOX_CTR_DRIVER_PLATFORM
#ifdef _NN_CTR
#define VOX_CTR_DRIVER_PLATFORM 1
#else
#define VOX_CTR_DRIVER_PLATFORM 0
#endif
#endif

#ifndef VOX_DRIVER_USE_CTR_HW
#if VOX_CTR_DRIVER_PLATFORM
#define VOX_DRIVER_USE_CTR_HW 1
#else
#define VOX_DRIVER_USE_CTR_HW 0
#endif
#endif

// Define how many buffer each voice has (min 2, man 4 as of sdk 0.12)
#ifndef VOX_DRIVER_CTR_SOURCE_BUFFER
#define VOX_DRIVER_CTR_SOURCE_BUFFER 2
#endif

// Define size of voice buffer (must be a multiple 32 bytes, must hold enough
// data for your highest sampling rate * highest pitch for 5 ms)
#ifndef VOX_DRIVER_CTR_SOURCE_BUFFER_SAMPLE
#define VOX_DRIVER_CTR_SOURCE_BUFFER_SAMPLE 1024
#endif

// Define the maximum number of hardware voice to use (note that all emitter
// use a hardware voice, even when not playing), you can reduce this to reduce
// ram usage (min 1, max 24 as of sdk 0.13.2)
#ifndef VOX_DRIVER_CTR_MAX_VOICE
#define VOX_DRIVER_CTR_MAX_VOICE 24
#endif

// Define stack size for dsp callback thread, don't change unless you know what
// you are doing
#ifndef VOX_DRIVER_CTR_SOUND_THREAD_STACK_SIZE
#define VOX_DRIVER_CTR_SOUND_THREAD_STACK_SIZE 4096
#endif

// Define the priority for dsp callback thread,don't change unless you know what
// you are doing
#ifndef VOX_DRIVER_CTR_SOUND_THREAD_PRIORITY
#define VOX_DRIVER_CTR_SOUND_THREAD_PRIORITY 2
#endif

// Define CTR driver interpolation type (choices are nn::snd::INTERPOLATION_TYPE_POLYPHASE, 
// nn::snd::INTERPOLATION_TYPE_LINEAR and nn::snd::INTERPOLATION_TYPE_NONE). Note that there
// are sound playback problems with the linear mode when building with SDK 1.0. In this case,
// we suggest using the polyphase mode. These problems have been solved with SDK 1.1.0.
#ifndef VOX_DRIVER_CTR_INTERPOLATION_TYPE
#define VOX_DRIVER_CTR_INTERPOLATION_TYPE nn::snd::INTERPOLATION_TYPE_LINEAR
#endif

#ifndef VOX_NN_CTR_THREAD_STACK_SIZE
#define VOX_NN_CTR_THREAD_STACK_SIZE 16*1024
#endif

#ifndef VOX_NN_CTR_THREAD_PRIORITY
#define VOX_NN_CTR_THREAD_PRIORITY 15
#endif



//******************************************************************************
//  24. PROFILER              [PROFILER]
//******************************************************************************

// Enable Vox call to external profiler.  Vox doesn't have a profiler, but
// expose function to allow an application to pipe Vox profiling information
// to the profiler of their choice
// Note: Some profiling scope are fast and their scoped time may be of the same 
// order than the profiler added cost. You have to consider a "correction" for
// scoped with time near the average added cost of the profiler.
#ifndef VOX_ENABLE_CPU_PROFILING
#define VOX_ENABLE_CPU_PROFILING 0
#endif

// Bit mask of all Vox profiling event scopes
#define VOX_PROFILER_EVENT_TYPE_GENERAL		0x00000001
#define VOX_PROFILER_EVENT_TYPE_EMITTER		0x00000002
#define VOX_PROFILER_EVENT_TYPE_SOURCE		0x00000004
#define VOX_PROFILER_EVENT_TYPE_DRIVER		0x00000008
#define VOX_PROFILER_EVENT_TYPE_DECODER		0x00000010
#define VOX_PROFILER_EVENT_TYPE_STREAM		0x00000020
#define VOX_PROFILER_EVENT_TYPE_CALLBACK	0x00000040
#define VOX_PROFILER_EVENT_TYPE_IO			0x00000080
#define VOX_PROFILER_EVENT_TYPE_ALL			0xFFFFFFFF

// Bit mask to activate profiler scopes.  More than one scope can be active.
// If Vox is running in threaded mode, application profiler must be thread safe
// for any of the event scope.
// !!! IMPORTANT !!!
// VOX_PROFILER_EVENT_TYPE_CALLBACK require a thread safe application profiler,
// even when Vox is running in non-threaded mode.
#ifndef VOX_PROFILER_EVENT_ENABLED
#define VOX_PROFILER_EVENT_ENABLED 0
#endif

//******************************************************************************
//  25. VXN DECODER		[VXN DECODER]
//******************************************************************************

#ifndef VOX_NATIVE_REDUCE_LATENCY
	#define VOX_NATIVE_REDUCE_LATENCY 1
#endif

// Maximum time (in miliseconds) by which data overwrite can be performed in order to reduce latency.
#ifdef VOX_NATIVE_MAX_DATA_OVERWRITE_TIME
	#if VOX_NATIVE_MAX_DATA_OVERWRITE_TIME > ((VOX_DRIVER_SOURCE_NUM_BUFFER + 1) * VOX_EMITTER_BUFFER_DURATION_MS)
		#undef VOX_NATIVE_MAX_DATA_OVERWRITE_TIME
		#define VOX_NATIVE_MAX_DATA_OVERWRITE_TIME ((VOX_DRIVER_SOURCE_NUM_BUFFER + 1) * VOX_EMITTER_BUFFER_DURATION_MS)
	#endif
#else
	#define VOX_NATIVE_MAX_DATA_OVERWRITE_TIME ((VOX_DRIVER_SOURCE_NUM_BUFFER + 1) * VOX_EMITTER_BUFFER_DURATION_MS)
#endif

#ifndef VOX_NATIVE_LATENCY_SAFETY_MARGIN
	#if defined(VOX_DRIVER_USE_PS3_MULTISTREAM)
		#define VOX_NATIVE_LATENCY_SAFETY_MARGIN 3 // In number of driver callbacks
	#else
		#define VOX_NATIVE_LATENCY_SAFETY_MARGIN 2 // In number of driver callbacks
	#endif
#endif

//******************************************************************************
//  26. ANDROID				  [ANDROID]
//******************************************************************************

#ifndef VOX_DRIVER_USE_ANDROID
#define  VOX_DRIVER_USE_ANDROID 1
#endif

#ifndef VOX_ANDROID_DRIVER_PLATFORM
#ifdef _ANDROID
#define VOX_ANDROID_DRIVER_PLATFORM 1
#else
#define VOX_ANDROID_DRIVER_PLATFORM 0
#endif
#endif

#ifndef VOX_ANDROID_AUDIOTRACK_DRIVER_PREFERRED_RATE
#define VOX_ANDROID_AUDIOTRACK_DRIVER_PREFERRED_RATE 44100 // Hz
#endif

#ifndef VOX_ANDROID_AUDIOTRACK_DRIVER_BUFFER_LENGTH
#define VOX_ANDROID_AUDIOTRACK_DRIVER_BUFFER_LENGTH	0.02322f // In seconds. //1024 samples @ 44100
#endif

#ifndef VOX_ANDROID_OPENSLES_DRIVER_PREFERRED_RATE
#define VOX_ANDROID_OPENSLES_DRIVER_PREFERRED_RATE 44100 // Hz
#endif

#ifndef VOX_ANDROID_OPENSLES_DRIVER_BUFFER_LENGTH
#define VOX_ANDROID_OPENSLES_DRIVER_BUFFER_LENGTH 0.023f // In seconds.
#endif

#ifndef VOX_ANDROID_OPENSLES_DRIVER_BUFFER_NUM
#define VOX_ANDROID_OPENSLES_DRIVER_BUFFER_NUM 2 // size of buffer queue
#endif

//******************************************************************************
//  27. VITA				  [VITA]
//******************************************************************************

// This setting allows to set the cpu affinity for Vox update threads. User can either
// select one cpu (either SCE_KERNEL_CPU_MASK_USER_0, SCE_KERNEL_CPU_MASK_USER_1,
// or SCE_KERNEL_CPU_MASK_USER_2) in which case thread priority must be in the range [64, 127]
// or select SCE_KERNEL_CPU_MASK_USER_ALL in which case thread priority must be in the range
// [128,191]. Kernel default priority is (in general) internally set to 160 (even though 
// SCE_KERNEL_DEFAULT_PRIORITY is 0x10000100).
#ifndef VOX_THREAD_CPU_AFFINITY
#define VOX_THREAD_CPU_AFFINITY SCE_KERNEL_CPU_MASK_USER_ALL
#endif

// This setting is used to set vox update threads priority. When cpu affinity is set to 
// SCE_KERNEL_CPU_MASK_USER_ALL, the thread's priority must be in the range [128,191].
// When it is set to one CPU (either SCE_KERNEL_CPU_MASK_USER_0, SCE_KERNEL_CPU_MASK_USER_1,
// or SCE_KERNEL_CPU_MASK_USER_2, thread priority must be in the range [64, 127]. Kernel default
// priority is (in general) internally set to 160 (even though SCE_KERNEL_DEFAULT_PRIORITY is 0x10000100).
#ifndef VOX_VITA_THREAD_PRIORITY
#define VOX_VITA_THREAD_PRIORITY (SCE_KERNEL_DEFAULT_PRIORITY - 1)
#endif

#ifndef VOX_DRIVER_USE_VITA_SW 
#define VOX_DRIVER_USE_VITA_SW 1
#endif

#ifndef VOX_VITA_SW_DRIVER_PLATFORM
#ifdef SN_TARGET_PSP2
#define VOX_VITA_SW_DRIVER_PLATFORM 1
#else
#define VOX_VITA_SW_DRIVER_PLATFORM 0
#endif
#endif

// This setting allows to set the cpu affinity for AudioOutput callback thread. This thread
// should run at highest user priority. To avoid fighting for CPU you may explicitly set its
// affinity to a cpu different than the main/render thread. Setting the affinity to SCE_KERNEL_CPU_MASK_USER_ALL
// is possible but not encouraged. By doing so, the thread can only have a priority
// located in the lowest priority range [128, 191]. This may cause driver malfunction.
#ifndef VOX_VITA_SW_DRIVER_THREAD_CPU_AFFINITY
#define VOX_VITA_SW_DRIVER_THREAD_CPU_AFFINITY SCE_KERNEL_CPU_MASK_USER_2
#endif

// This setting is used to set the AudioOutput callback thread priority. This thread should run
// at highest user priority. In order to set a priority located in the high priority range [64,127],
// the affinity must be set to only one CPU (SCE_KERNEL_CPU_MASK_USER_0, SCE_KERNEL_CPU_MASK_USER_1
// or SCE_KERNEL_CPU_MASK_USER_2). Setting the thread affinity to SCE_KERNEL_CPU_MASK_USER_ALL is not
// encouraged. By doing so, the thread can only have a priority located in the lowest priority range
// [128, 191]. This may cause driver malfunction.
#ifndef VOX_VITA_SW_DRIVER_THREAD_PRIORITY
#define VOX_VITA_SW_DRIVER_THREAD_PRIORITY SCE_KERNEL_HIGHEST_PRIORITY_USER
#endif

#ifndef VOX_VITA_SW_DRIVER_BUFFER_LENGTH
#define VOX_VITA_SW_DRIVER_BUFFER_LENGTH	1024 // In samples. //will be round up to the next multiple of 64 samples //Min 64 Max 64*1024 - 64
#endif

#ifndef VOX_VITA_SW_DRIVER_ENABLE_OCCLUSION
#define VOX_VITA_SW_DRIVER_ENABLE_OCCLUSION 0
#endif


//******************************************************************************
//  28. GOOGLE CHROME NACL    [NACL]
//******************************************************************************

#ifndef VOX_DRIVER_USE_NACL
#ifdef __native_client__
#define VOX_DRIVER_USE_NACL 1
#else
#define VOX_DRIVER_USE_NACL 0
#endif
#endif

#ifndef VOX_NACL_DRIVER_PREFERRED_RATE
#define VOX_NACL_DRIVER_PREFERRED_RATE 44100 // Can only be 44.1khz or 48khz.
#endif

#ifndef VOX_NACL_DRIVER_BUFFER_LENGTH
#define VOX_NACL_DRIVER_BUFFER_LENGTH				0.032f //seconds
#endif

//******************************************************************************
//  29. QSA	DRIVER		  [BLACKBERRYPLAYBOOK]
//******************************************************************************

#ifndef VOX_QSA_DRIVER_PLATFORM
#if defined(__QNXNTO__)
#define VOX_QSA_DRIVER_PLATFORM 1
#else
#define VOX_QSA_DRIVER_PLATFORM 0
#endif
#endif

#ifndef VOX_DRIVER_USE_QSA
#if defined(__QNXNTO__)
#define VOX_DRIVER_USE_QSA 1
#else
#define VOX_DRIVER_USE_QSA 0
#endif
#endif

#ifndef VOX_QSA_DRIVER_PREFERRED_RATE
#define VOX_QSA_DRIVER_PREFERRED_RATE 32000 // Hz
#endif

#ifndef VOX_QSA_DRIVER_MAX_FRAGMENTS
#define VOX_QSA_DRIVER_MAX_FRAGMENTS	2
#endif

#ifndef VOX_QSA_DRIVER_MIN_FRAGMENTS
#define VOX_QSA_DRIVER_MIN_FRAGMENTS	1
#endif

#endif //_VOX_DEFAULT_CONFIG_H_
