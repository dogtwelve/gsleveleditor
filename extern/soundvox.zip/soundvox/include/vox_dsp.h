#pragma once
#ifndef _VOX_DSP_H_
#define _VOX_DSP_H_

#include "vox_default_config.h"

#include "vox_types.h"
#include "vox_internal.h"

#if defined (_PS3)
#include <cell/mstream.h>
#else
typedef vox::s32 CELL_MS_DSPSLOTS;
#endif

namespace vox
{

namespace VoxDSP
{
	enum DSPID
	{
#	if VOX_DSP_ENABLE_COMPRESSOR
		k_nCompressor,
#	endif
#	if VOX_DSP_ENABLE_TDREVERB
		k_nTDReverb,
#	endif
#	if VOX_DSP_ENABLE_FILTER
		k_nFilter,
#	endif
#	if VOX_DSP_ENABLE_PITCHSHIFT
		k_nPitchShift,
#	endif
#	if VOX_DSP_ENABLE_IMPULSEREVERB
		k_nImpulseReverb,
#	endif
#	if VOX_DSP_ENABLE_PARAMETRIC_EQ
		k_nParametricEQ,
#	endif
#	if VOX_DSP_ENABLE_DELAY
		k_nDelay,
#	endif
#	if VOX_DSP_ENABLE_DISTORTION
		k_nDistortion,
#	endif
		k_nDSPMax

	};

	enum DSPParameterID
	{
		//VOX_DSP_ENABLE_COMPRESSOR
/*	int firstBand;
	int lastBand;
	float ratio;
	float threshold;
	float attack;
	float release;
	float makeupGain;
	float CompressorCur;
	float multBy;
	float softKnee;
*/
		//k_nCompressor
	};
}

class DSP
{
public:
	DSP();
	virtual ~DSP(){}

	virtual s32 Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle)=0;
	virtual void Unload()=0;
	virtual void SetParameter(s32 paramId, void* param)=0;

	virtual void Update(f32 dt){}

protected:
	virtual void SetDSPSlotRoute();

	s32 m_busNo;
	CELL_MS_DSPSLOTS m_dspSlot;
};

// TODO Need to change to a generic implementation, redefined by platform
class DSPManager
{
public:
	DSPManager();
	~DSPManager();

	void Init();

	DSP* CreateDSP(char* mngFile, s32 busNo, CELL_MS_DSPSLOTS dspSlot);
	DSP* CreateSideChainDSP(char* mngFile);
	DSP* CreateFilterLFE();
	s32	 GetDSPHandle(VoxDSP::DSPID dspId);

private:
	//DSP binaries handle
	s32* m_pDSPHandles;
};
}
#endif
