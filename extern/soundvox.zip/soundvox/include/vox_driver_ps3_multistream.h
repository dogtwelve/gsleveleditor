#pragma once
#ifndef _VOX_DRIVER_PS3_MS_H_
#define _VOX_DRIVER_PS3_MS_H_

#include "vox_default_config.h"

#if VOX_DRIVER_USE_PS3_MULTISTREAM && VOX_PS3_MULTISTREAM_DRIVER_PLATFORM

#include "vox_driver.h"
#include "vox_internal.h"
#include "vox_bus.h"
#include "vox_dsp_ps3.h"
#include "vox_macro.h"

#include <sysutil/sysutil_sysparam.h>
#include <sys/ppu_thread.h>
#include <sys/process.h>

#include <cell/mstream.h>
#include <cell/audio.h>

#include VOX_VECTOR_INCLUDE

#ifdef MS_THREADED_SAMPLE
#define VOX_DRIVER_PS3_MS_THREADED
#endif

namespace vox {

#define VOX_PS3_MULTISTREAM_BUFFER_SAMPLE 1024

struct PS3MultiStreamSourceParam : public DriverSourceParam
{
};

struct PS3MultiStreamBuffer
{
	u8* m_data;
	s32 m_usedSize;
	s32 m_totalSize;
	s32 m_cursorPos;
	bool free;
};

enum DSPVolumeMode
{
	k_nReverb,
	k_nDelay,
	k_nOther,
};

//struct PS3MultiStreamListener
//{
//	VoxVector3f m_position;
//	VoxVector3f m_front;
//	VoxVector3f m_right;
//
//
//	void SetPosition(const VoxVector3f &position)
//	{
//		VOX_MUTEX_LEVEL_1(m_mutex.Lock());
//		m_position = position;
//		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
//	}
//	void SetAxes(const VoxVector3f &front, const VoxVector3f &right)
//	{
//		VOX_MUTEX_LEVEL_1(m_mutex.Lock());
//		m_front = front;
//		m_right = right;
//		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
//	}
//
//	void GetPosition(VoxVector3f &position) 
//	{
//		VOX_MUTEX_LEVEL_1(m_mutex.Lock());
//		position = m_position;
//		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
//	}
//	void GetAxes(VoxVector3f &front, VoxVector3f &right) 
//	{
//		VOX_MUTEX_LEVEL_1(m_mutex.Lock());
//		front = m_front;
//		right = m_right;
//		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
//	}
//
//	Mutex m_mutex;
//};

struct PS3SFXPreset
{
	PS3SFXPreset()
	{
		m_sfxPreset1 = Fader(1.0f, 1.0f, 0.0f);
		m_sfxPreset2 = Fader(0.0f, 0.0f, 0.0f);
		m_sfxPreset3 = Fader(0.0f, 0.0f, 0.0f);
	}

	void Reset()
	{
		VOX_MUTEX_LEVEL_1(m_mutex.Lock());
		m_sfxPreset1 = Fader(1.0f, 1.0f, 0.0f);
		m_sfxPreset2 = Fader(0.0f, 0.0f, 0.0f);
		m_sfxPreset3 = Fader(0.0f, 0.0f, 0.0f);
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	}

	void Update(f32 dt)
	{
		VOX_MUTEX_LEVEL_1(m_mutex.Lock());
		m_sfxPreset1.Update(dt);
		m_sfxPreset2.Update(dt);
		m_sfxPreset3.Update(dt);
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	}

	void SetPresetActive(s32 preset, bool active, f32 fadeTime)
	{
		VOX_MUTEX_LEVEL_1(m_mutex.Lock());
		switch(preset)
		{
			case 1 :
			{
				m_sfxPreset1 = Fader(m_sfxPreset1.GetCurrentValue(), active ? 1.0f : 0.f, fadeTime);
				break;
			}
			case 2 :
			{
				m_sfxPreset2 = Fader(m_sfxPreset2.GetCurrentValue(), active ? 1.0f : 0.f, fadeTime);
				break;
			}
			case 3 :
			{
				m_sfxPreset3 = Fader(m_sfxPreset3.GetCurrentValue(), active ? 1.0f : 0.f, fadeTime);
				break;
			}
		}
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	}

	void GetPresetValue(f32 &preset1, f32 &preset2, f32 &preset3)
	{
		VOX_MUTEX_LEVEL_1(m_mutex.Lock());
		preset1 = m_sfxPreset1.GetCurrentValue();
		preset2 = m_sfxPreset2.GetCurrentValue();
		preset3 = m_sfxPreset3.GetCurrentValue();
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	}

	Fader m_sfxPreset1;
	Fader m_sfxPreset2;
	Fader m_sfxPreset3;

	Mutex m_mutex;
};

class DriverPS3MultiStreamSource : public DriverSourceInterface
{
public:
	DriverPS3MultiStreamSource(void * trackParam, void* driverParam, s32 sourceId = 0);
	virtual ~DriverPS3MultiStreamSource();

	virtual void Play();
	virtual void Stop();
	virtual void Pause();
	virtual void Reset();

	virtual s32 GetState();

	virtual long GetByteOffset();
	virtual void SetByteOffset(s32 offset);

	virtual bool NeedData();
	virtual void UploadData(void* soundData, s32 bufferSize);

	virtual void SetGain(f32 gain);
	virtual void SetPitch(f32 pitch);
	virtual f32 GetGain();
	virtual f32 GetPitch();
	
	virtual void Set3DParameter(s32 paramId, void* param);
	virtual void SetDSPParameter(s32 paramId, void* param);

	virtual void Update(f32 dt);

	virtual void PrintDebug();

	virtual bool AllowBufferReference(){return true;}
	virtual s32 GetBufferCount(){return m_numBuffer;}

	virtual void FreeDisposableData(s32 maxNbBytes, s32 &nbBuffersFreed, s32 &nbBytesFreed);

	void ReleaseSource();

protected:

	virtual void Init();
	virtual void Cleanup();

private:

	static void StreamCallback(s32 streamNumber, void * userData, s32 callbackType, void * pWriteBuffer, s32 nBufferSize);
	void ProcessCallback(s32 callbackType, s32 nBufferSize);
	s32 FillBuffer(u8* buffer, s32 size);

	s32 ConvertSourceState(u32 state);

	s32 m_sourceId;
	s32 m_state;				// Only used to track Init() errors and prevent playback when it happens.
	bool m_useCellState;		// True if using state from cell... methods. If false, STATE_INITIAL is forced.
	bool m_isInit;
	TrackParams m_trackParams;
	s32 m_processedBytes;

	f32 m_gain;
	f32 m_userPitch;

	s32 m_busId;

	//buffers ...
	void FreeAllBuffer();
	s32 m_numBuffer;
	s32 m_currentWriteBuffer;
	s32 m_currentReadBuffer;
	VOX_VECTOR<PS3MultiStreamBuffer, SAllocator<PS3MultiStreamBuffer> > m_bufferList;

	s32 m_currentWorkBuffer;
	u8* m_workBuffer[2];
	s32 m_workBufferSize;

	VoxVector3f m_position;

#if VOX_DSP_ENABLE_OCCLUSION
	DSPOcclusion* m_dspFilter;
#endif

	Mutex m_mutex;
};

class DriverPS3MultiStream : public DriverInterface
{
public:
	DriverPS3MultiStream();
	virtual ~DriverPS3MultiStream();

	virtual void Init(void* param);
	virtual void Shutdown();

	virtual void Suspend();
	virtual void Resume();	

	virtual void Update(f32 dt);

	virtual void Set3DParameter(s32 paramId, void* param);
	virtual void SetDSPParameter(s32 paramId, void* param);

	virtual void SetStaticBusRouting(c8* filename);
	virtual void SetDynamicBusRouting(c8* filename);
	virtual void SetSFXPresetActive(s32 preset, bool active, f32 fadeTime);

	virtual VoxOutputMode GetOutputMode(){return VOX_DRIVER_PS3_MS_OUTPUT_CHANNEL == CELL_AUDIO_PORT_2CH ? k_nOutputModeStereo : k_nOutputModeSurround;}

	virtual void PrintDebug();

	virtual DriverSourceInterface* CreateDriverSource(void * trackParam, void* driverParam, s32 priority = 0);
	virtual void DestroyDriverSource(DriverSourceInterface* driverSource);

	static PS3SFXPreset s_sfxPreset;
//protected:

private:
	u32 GetPS3MS3DModel(s32 vox3DModel);
	void SetDefaultParameter();
	void _Set3DParameter(s32 paramId, void* param);

	//MS specifics
	
	s32 AudioInitCell();
	long InitialiseAudio( const s32 nStreams, const s32 nmaxSubs, s32 &_nPortNumber , CellAudioPortParam &_audioParam, CellAudioPortConfig &_portConfig, const s32 _nFlags);
	void ShutdownMultiStream();
	
	//SPURS
//#ifndef VOX_DRIVER_PS3_MS_THREADED
//	void InitSPURS(void);
//	CellSpurs spurs __attribute__((aligned (128)));
//#endif

	sys_ppu_thread_t     m_multiStreamPuThread;
	void *               m_pMultiStreamMemory;
	void *               m_pMSSurroundMemory;

	CellAudioPortParam   audioParam;
	CellAudioPortConfig  portConfig;
	s32					 m_portNum;

	BusManager* m_pBusMgr;

	bool m_driverActive;
	Mutex m_mutex;
};

};//namespace vox

#endif //VOX_DRIVER_USE_PS3_MULTISTREAM && defined(_PS3)

#endif //_VOX_DRIVER_PS3_MS__H_
