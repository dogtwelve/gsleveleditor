#pragma once
#ifndef _VOX_DECODER_STBVORBIS_H_
#define _VOX_DECODER_STBVORBIS_H_

#include "vox_decoder.h"
#include "stb_vorbis.h"

namespace vox {

class DecoderStbVorbis : public DecoderInterface 
{
public:
	DecoderStbVorbis():m_pVorbisFile(0){}
	virtual ~DecoderStbVorbis();

	virtual DecoderCursorInterface* CreateNewCursor( StreamCursorInterface* pStreamCursor );
	virtual void DestroyCursor(DecoderCursorInterface* pDecoderCursor);
	virtual s32 GetType(){return k_nDecoderTypeStbVorbis;}
	virtual void* GetParam(){return 0;}

	stb_vorbis* GetVorbisFile(){return m_pVorbisFile;} 
	void SetVorbisFile(stb_vorbis* f){m_pVorbisFile = f;}

	u32 GetStreamOffset(){return m_streamOffset;} 
	void SetStreamOffset(u32 offset){m_streamOffset = offset;}
private:
	stb_vorbis* m_pVorbisFile;
	u32 m_streamOffset;
};

DecoderInterface* DecoderStbVorbisFactory(void* params);

class DecoderStbVorbisCursor : public DecoderCursorInterface
{
protected:
	DecoderStbVorbisCursor(DecoderInterface* pDecoder, StreamCursorInterface* pStreamCursor );

public:
	virtual ~DecoderStbVorbisCursor();
	virtual s32  Decode( void* outputBuffer, s32 nbBytes );
	virtual s32  Seek(u32 sampleNum );
	virtual bool HasData();

protected:

	stb_vorbis* m_pVorbisFile;
	
#if VOX_USE_STBVORBIS_INTERNAL_BUFFER
	stb_vorbis_alloc m_internalBuffer;
#endif

	u32 m_totalSampleDecoded;

	friend class DecoderStbVorbis;
};

}
#endif //_VOX_DECODER_STBVORBIS_H_
