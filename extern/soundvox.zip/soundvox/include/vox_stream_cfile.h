#pragma once
#ifndef _VOX_STREAM_CFILE_H_
#define _VOX_STREAM_CFILE_H_

#include "vox_stream.h"
#include "vox_default_config.h"
#include "vox_filesystem.h"
#include VOX_STRING_INCLUDE

namespace vox {

class StreamCFile : public StreamInterface
{
public:
	StreamCFile( const c8* filename );

	virtual void Init();
	virtual StreamCursorInterface* CreateNewCursor();
	virtual void DestroyCursor(StreamCursorInterface* pStreamCursor);
	virtual s32 GetType(){return vox::k_nStreamTypeCFile;}

	const c8* GetFileName() const { return m_filename.c_str(); }
	FileSystemInterface* GetFileSystem() const { return m_pFS; }

protected:
	VOX_STRING m_filename;
	FileSystemInterface* m_pFS;
};

///

StreamInterface* StreamCFileFactory(void* params);

///

class StreamCFileCursor : public StreamCursorInterface
{
public:
	StreamCFileCursor(StreamInterface* pStream) 
		: StreamCursorInterface(pStream)
		, m_fp(0)
		, m_position(-1) 
#if VOX_BUFFERED_FILE_STREAM
		, m_bufferAvailableBytes(0)
		, m_bufferCursorPos(0)
		, m_bufferOffset(0)
#endif
			{Init();}
	virtual ~StreamCFileCursor(){Shutdown();}
	
	virtual void Init();
	virtual void Shutdown();
	virtual s32 Seek( s32 pos, s32 origin = ORIGIN_START );
	virtual bool IsSeekable(){return true;}
	virtual s32 Tell();
	virtual s32  Read( u8* buff, s32 len );
	virtual bool EndOfStream();

protected:
	FileInterface* m_fp;

	s32 m_position;

#if VOX_BUFFERED_FILE_STREAM
	c8 m_buffer[VOX_FILE_STREAM_BUFFER_SIZE];
	s32 m_bufferAvailableBytes;
	s32 m_bufferCursorPos;
	s32 m_bufferOffset;
#endif

	friend class StreamCFile;
};

}

#endif //_VOX_STREAM_CFILE_H_
