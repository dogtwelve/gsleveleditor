#pragma once
#ifndef _VOX_DSP_PS3_H_
#define _VOX_DSP_PS3_H_

#include "vox_default_config.h"

#if VOX_DRIVER_USE_PS3_MULTISTREAM && VOX_PS3_MULTISTREAM_DRIVER_PLATFORM 

#include "vox_dsp.h"
#include <cell/mstream.h>

namespace vox
{

#if VOX_DSP_ENABLE_TDREVERB
class DSPTDReverb : public DSP
{
public:
	DSPTDReverb();
	virtual ~DSPTDReverb();

	virtual s32 Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle);
	virtual void Unload();
	virtual void SetParameter(s32 paramId, void* param);

private:
	virtual void SetDSPSlotRoute();

	CellMSFXReverbParams m_params __attribute__((aligned (128)));
	void* m_pReverbBuffer;
};
#endif

#if VOX_DSP_ENABLE_COMPRESSOR
class DSPCompressor : public DSP
{
public:
	DSPCompressor(){}
	virtual ~DSPCompressor();

	virtual s32 Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle);
	virtual void Unload();
	virtual void SetParameter(s32 paramId, void* param);

protected:
	CellMSFXCompressorInfo m_params __attribute__((aligned (128)));
};
#endif

#if VOX_DSP_ENABLE_COMPRESSOR
class DSPSCCompressor : public DSPCompressor
{
public:
	DSPSCCompressor(){}
	//virtual ~DSPCompressor();

	virtual s32 Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle);
	virtual void Unload();
	virtual void SetParameter(s32 paramId, void* param);
};
#endif

#if VOX_DSP_ENABLE_PITCHSHIFT
class DSPPitchShift : public DSP
{
public:
	DSPPitchShift();
	virtual ~DSPPitchShift();

	virtual s32 Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle);
	virtual void Unload();
	virtual void SetParameter(s32 paramId, void* param);

private:
	f32 m_params;
	void* m_pPitchShiftBuffer;
};
#endif

#if VOX_DSP_ENABLE_IMPULSEREVERB
typedef struct CellImpulseInfo{
  unsigned char Channel;
  unsigned char Interleaved;
  unsigned char Reserved[2];
  unsigned int  Sample;
} CellImpulseInfo;

class DSPImpulseReverb : public DSP
{
public:
	DSPImpulseReverb();
	virtual ~DSPImpulseReverb();

	virtual s32 Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle);
	virtual void Unload();
	virtual void SetParameter(s32 paramId, void* param);

private:
	virtual void SetDSPSlotRoute();

	CellImpulseInfo m_impulseInfo;
	void* m_impulseFFTInfo;
	void* m_impulseArray[8];
};
#endif

#if VOX_DSP_ENABLE_PARAMETRIC_EQ
class DSPParametricEQ : public DSP
{
public:
	DSPParametricEQ();
	virtual ~DSPParametricEQ();

	virtual s32 Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle);
	s32 Load(s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle);
	virtual void Unload();
	virtual void SetParameter(s32 paramId, void* param);

private:
    CellMSFXParaEQ m_ParaEqParams;
    void* m_pParaEqMemBlock;
};
#endif

#if VOX_DSP_ENABLE_OCCLUSION
class DSPOcclusion : public DSP
{
public:
	DSPOcclusion();
	virtual ~DSPOcclusion();

	virtual s32 Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle){return -1;}
	s32 Load(s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle);
	virtual void Unload();

	virtual void Update(f32 dt);

	virtual void SetParameter(s32 paramId, void* param);
	void SetMaterialPreset(VoxDSPEmitterParameter::OcclusionMaterialPreset preset, f32 fadeTime = 0.3f);
	void SetDistanceAttenuation(f32 attenuation);

private:
	CellMSFXFilter m_filterParams;
	void* m_pFilterMemBlock;
	s32 m_currentMaterial;
	f32 m_attDistance;
	f32 m_cutoffFrequency;
};
#endif

#if VOX_DSP_ENABLE_PARAMETRIC_EQ
class DSPFilterLFE : public DSPParametricEQ
{
public:
	DSPFilterLFE();
	virtual ~DSPFilterLFE();

	virtual s32 Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle);
	virtual void Unload();
	virtual void SetParameter(s32 paramId, void* param);

private:
	virtual void SetDSPSlotRoute();

    CellMSFXParaEQ m_ParaEqParams;
    void* m_pParaEqMemBlock;
};
#endif


#if VOX_DSP_ENABLE_FILTER
class DSPFilter : public DSP
{
public:
	DSPFilter();
	virtual ~DSPFilter();

	virtual s32 Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle);
	s32 Load(s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle);
	virtual void Unload();
	virtual void SetParameter(s32 paramId, void* param);
	virtual void Update(f32 dt);

private:
    CellMSFXFilter m_filterParams;
    void* m_pFilterMemBlock;
};
#endif

#if VOX_DSP_ENABLE_DELAY
class DSPDelay : public DSP
{
public:
	DSPDelay();
	virtual ~DSPDelay();

	virtual s32 Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle);
	virtual void Unload();
	virtual void SetParameter(s32 paramId, void* param);

private:
    CellMSFXDelay m_delayParams;
    void* m_pDelayMemBlock;
};
#endif

#if VOX_DSP_ENABLE_DISTORTION
class DSPDistortion : public DSP
{
public:
	DSPDistortion(){}
	virtual ~DSPDistortion();

	virtual s32 Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle);
	virtual void Unload();
	virtual void SetParameter(s32 paramId, void* param);

protected:
	CellMSFXDistortion m_params __attribute__((aligned (128)));
};
#endif

}
#endif //VOX_DRIVER_USE_PS3_MULTISTREAM && VOX_PS3_MULTISTREAM_DRIVER_PLATFORM 
#endif //_VOX_DSP_PS3_H_
