#pragma once
#ifndef _VOX_DEBUG_SERVER_H_
#define _VOX_DEBUG_SERVER_H_

#include "vox_default_config.h"
#include "vox_macro.h"
#include "vox.h"
#include <cstring>
#include <string.h>

namespace vox
{
struct DebugPacketHeader
{
	DebugPacketHeader(){memcpy(pcktId, "VDBG" , 4);}
	char pcktId[4];
	u32 pcktSize;
	u32 type;
	u32 version;
	u32 id;
	f64 timestamp;
};

struct DebugExtendedPacketHeader_data
{
	DebugExtendedPacketHeader_data(){memcpy(pcktId, "EXDH" , 4);}
	char pcktId[4];
	u32 pcktSize;
	u32 groupChunkSize;
	u32 nGroupChunk;
	u32 bankChunkSize;
	u32 nBankChunk;
	u32 dataSourceChunkSize;
	u32 nDataSourceChunk;
	u32 emitterChunkSize;
	u32 nEmitterChunk;
	u32 general3dChunkSize;
	u32 nGeneral3dChunk;
};

struct DebugChunk_group
{
	f32 targetGain[32];
	f32 currentGain[32];
};

struct DebugChunk_bank
{
	s32 id;
	s32 type;
	s32 threshold;
	s32 max;
	s32 current;
};

struct DebugChunk_dataSource
{
	s64 id;
	s32 streamType;
	s32 decoderType;
	s32 bank;
	s32 samplingRate;
	s32 channel;
	s32 bps;
	f32 duration;
	s32 groupId;
	s32 referenceCount;
};

struct DebugChunk_emitter
{
	s64 id;
	s64 dataSourceId;
	f32 position[3];
	s32 state;
	f32 gain[2];
	f32 pitch[2];
	s32 loop;
	s32 referenceCount;
	s32 groupId;
	f32 velocity[3];
	f32 direction[3];
	Vox3DEmitterParameters param3D;
};

struct DebugChunk_general3d
{
	f32 listenerPosition[3];
	f32 listenerVelocity[3];
	f32 listenerDirection[3];
	f32 listenerUp[3];
	Vox3DGeneralParameters param3D;
};

}

#if VOX_DEBUG_SERVER_ENABLE
#ifdef _WIN32
#include <winsock2.h>
#endif

namespace vox
{

namespace DebugServerState
{
enum VoxDebugServerState
{
	k_nError = -1,
	k_nInitial = 0,
	k_nIdle = 1,
	k_nSendingData = 2,	
};
}

class DebugServer
{
public:
	DebugServer();
	~DebugServer();

	void Send(void* data, s32 size);
	s32 Receive();
	DebugServerState::VoxDebugServerState GetState(){return m_state;}

	c8 m_data[60*1024];

private:
	DebugServerState::VoxDebugServerState m_state;
	SOCKET m_socketOut;	
	//SOCKET m_socketIn;	

	sockaddr_in m_skAddrOut;
	sockaddr_in m_skAddrIn;

	s32 m_updateToAnnouce;
};

}
#else
namespace vox
{
class DebugServer
{
};
}
#endif
#endif
