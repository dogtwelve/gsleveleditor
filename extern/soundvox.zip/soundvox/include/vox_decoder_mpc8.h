#pragma once
#ifndef _VOX_DECODER_MPC8_H_
#define _VOX_DECODER_MPC8_H_

#include "vox_decoder.h"
#include "mpc/mpcdec.h"


namespace vox {

struct DecoderMPC8Params
{
	s32 m_forceSampleRate;
	DecoderMPC8Params(s32 forceSampleRate):m_forceSampleRate(forceSampleRate){}
};

class DecoderMPC8 : public DecoderInterface 
{
public:
	DecoderMPC8(DecoderMPC8Params* param);
	//virtual ~DecoderMPC8();

	virtual DecoderCursorInterface* CreateNewCursor( StreamCursorInterface* pStreamCursor );
	virtual void DestroyCursor(DecoderCursorInterface* pDecoderCursor);
	virtual s32 GetType(){return k_nDecoderTypeMPC8;}
	virtual void* GetParam(){return 0;}

	s32 GetForceSampleRate(){return m_forceSampleRate;}

private:
	s32 m_forceSampleRate;
};

DecoderInterface* DecoderMPC8Factory(void* params);

class DecoderMPC8Cursor : public DecoderCursorInterface
{
protected:
	DecoderMPC8Cursor(DecoderInterface* pDecoder, StreamCursorInterface* pStreamCursor );

public:
	virtual ~DecoderMPC8Cursor();
	virtual s32  Decode( void* outputBuffer, s32 nbSamples );
	virtual s32  Seek(u32 sampleNum );
	virtual bool HasData();

protected:

	void ConvertFloatToShort(s16* dest, vox::f32* src, s32 size);
	void ConvertFixedToShort(s16* dest, vox::s32* src, s32 size);

	u32 m_totalSampleDecoded;

	s32 m_samplesInBuffer;
	s32 m_samplesInBufferConsumed;
	mpc_demux* m_pDemux;
	mpc_reader m_reader;
	//MPC_SAMPLE_FORMAT m_sampleBuffer[MPC_DECODER_BUFFER_LENGTH];
	MPC_SAMPLE_FORMAT *m_sampleBuffer;

	friend class DecoderMPC8;
};

}
#endif //_VOX_DECODER_MPC8_H_
