#pragma once
#ifndef _VOX_FILE_SYSTEM_NULL_H_
#define _VOX_FILE_SYSTEM_NULL_H_

#include "vox_default_config.h"

#if defined(__native_client__)

#include "vox_filesystem.h"

namespace vox
{

class FileSystemNull : public FileSystemInterface
{
public:
	FileSystemNull();
	virtual ~FileSystemNull();
};

}

#endif
#endif //_VOX_FILE_SYSTEM_NULL_H_
