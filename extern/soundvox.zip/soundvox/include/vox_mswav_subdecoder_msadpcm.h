#pragma once
#ifndef _VOX_MSWAV_SUBDECODER_MSADPCM_H
#define _VOX_MSWAV_SUBDECODER_MSADPCM_H

#include "vox_mswav_subdecoder.h"

#define MAX_INT16 32767
#define MIN_INT16 -32768
#define MS_ADPCM_MONO_HEADER_SIZE	7
#define MS_ADPCM_STEREO_HEADER_SIZE	14

namespace vox
{

const s32 adaptive[] =
{
	230, 230, 230, 230, 307, 409, 512, 614,
	768, 614, 512, 409, 307, 230, 230, 230
};

struct MsAdpcmState
{
	u8	predictor;
	u16	delta;
	s16	sample1, sample2;
};


struct FmtExtendedInfos
{
	s16 m_cbSize;
	s16	m_samplesPerBlock;
	s16 m_nbCoefficients;
	s16	m_coefficients[256][2]; // TODO : See if should use allocation

	FmtExtendedInfos():m_cbSize(0), m_samplesPerBlock(0), m_nbCoefficients(0) {}
};

class VoxMSWavSubDecoderMSADPCM : public VoxMSWavSubDecoder
{
 public:
	VoxMSWavSubDecoderMSADPCM(StreamCursorInterface* pStreamCursor, WaveChunk* pWaveChunks);
	virtual ~VoxMSWavSubDecoderMSADPCM();

	virtual s32 Decode(void* outbuf, s32 nbBytes);
	virtual s32 Seek(u32 sample);
	virtual bool HasData();
 private:	
	s32 DecodeBlock(void* outbuf);
	s16 DecodeSample(MsAdpcmState *state, u32 code, const s16 *coefficient);
 protected:
	u8*	m_readBuffer;
	u32	m_totalDataBytesRead;
	s32	m_dataStartPosition;
	s32 m_samplesInBuffer;
	s32 m_samplesInBufferConsumed;
	u32 m_totalSampleDecoded;
	u8* m_blockReadBuffer;

	FmtExtendedInfos m_fmtExtendedInfos;
};

}

#endif // _VOX_MSWAV_SUBDECODER_MSADPCM_H
