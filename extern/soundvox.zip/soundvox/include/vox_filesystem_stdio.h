#pragma once
#ifndef _VOX_FILE_SYSTEM_STDIO_H_
#define _VOX_FILE_SYSTEM_STDIO_H_

#include "vox_default_config.h"

#if !defined(_PS3) && !defined(_NN_CTR) && !VOX_USE_GLF && !(defined(_IPHONE_OS) && VOX_USE_POSIX_FILESYSTEM) && !defined(__native_client__)

#include "vox_filesystem.h"

namespace vox
{

class FileSystemStdio : public FileSystemInterface
{
public:
	FileSystemStdio();
	virtual ~FileSystemStdio();
};

}

#endif
#endif //_VOX_FILE_SYSTEM_STDIO_H_
