#pragma once
#ifndef _VOX_DECODER_MSWAV_H_
#define _VOX_DECODER_MSWAV_H_

#include "vox_decoder.h"
#include "MSHeaders.h"
#include "vox_mswav_subdecoder.h"

namespace vox {

typedef TrackParams DecoderMSWavParams;

class DecoderMSWav : public DecoderInterface
{
public:
	DecoderMSWav();
	virtual ~DecoderMSWav();

	virtual DecoderCursorInterface* CreateNewCursor( StreamCursorInterface* pStreamCursor );
	virtual void DestroyCursor(DecoderCursorInterface* pDecoderCursor);
	virtual s32 GetType(){return k_nDecoderTypeMSWav;}
	virtual void* GetParam(){return 0;}

	WaveChunk* GetWaveChunks(){return &m_waveChunks;}
	bool NeedParsing(){return m_needParsing;}
	void SetParsed(){m_needParsing = false;}

private:
	WaveChunk m_waveChunks;
	bool m_needParsing;
};


DecoderInterface* DecoderMSWavFactory(void* params);


class DecoderMSWavCursor : public DecoderCursorInterface
{
protected:
	DecoderMSWavCursor(DecoderInterface* pDecoder, StreamCursorInterface* pStreamCursor );

public:
	virtual ~DecoderMSWavCursor();
	virtual s32  Decode( void* outputBuffer, s32 nbSamples );
	virtual s32  Seek( u32 sampleNum );
	virtual bool HasData();
	virtual void SetLoop(bool loop);

private:
	bool ParseFile();
	
	WaveChunk* m_pWaveChunks;
	VoxMSWavSubDecoder* m_pSubDecoder;

	friend class DecoderMSWav;
};

}

#endif //_VOX_DECODER_MSWAV_H_
