#pragma once
#ifndef _VOX_H_
#define _VOX_H_

#include "vox_default_config.h"

//! Main namespace for Vox Audio Engine
namespace vox {

#ifndef VOX_THREADING_MODE_NONE
class VoxThread;
#endif
class Mutex;

class Handlable;

class Handle;
class EmitterHandle;

class VoxEngine;
class VoxEngineInternal;

class StreamInterface;
typedef StreamInterface* (*StreamTypeFactoryFnPtr)(void* params);

class DecoderInterface;
typedef DecoderInterface* (*DecoderTypeFactoryFnPtr)(void* params);

typedef s64 HandleId;

///

class Handle
{
public:
	virtual ~Handle(){};
	Handle( const Handle &handle) : m_id(handle.m_id), m_timestamp(handle.m_timestamp), m_tsGroup(handle.m_tsGroup), m_pObject(handle.m_pObject), m_ppInternal(handle.m_ppInternal), m_debugPointerToObjectThatIsNotGaranteedToExistAnymore(handle.m_debugPointerToObjectThatIsNotGaranteedToExistAnymore){}

	bool operator==(const Handle &rhs) const;

protected:
	Handle(HandleId id, VoxEngineInternal** ppInternal = 0, Handlable* object = 0, u32 timestamp = 0, u32 tsGroup = 0) : m_id(id), m_timestamp(timestamp), m_tsGroup(tsGroup), m_pObject(object), m_ppInternal(ppInternal), m_debugPointerToObjectThatIsNotGaranteedToExistAnymore(object){}

protected:
	virtual HandleId GetId() const {return m_id;}
	virtual Handlable* GetObjectPointer() const {return m_pObject;};

	virtual void GetTimeStamp(u32 &timeStamp, u32 &tsGroup) const {timeStamp = m_timestamp;tsGroup = m_tsGroup;};
	virtual void SetTimeStamp(u32 timeStamp, u32 tsGroup){m_timestamp = timeStamp;m_tsGroup = tsGroup;};

protected:
	HandleId m_id;
	u32 m_timestamp;
	u32 m_tsGroup;
	Handlable* m_pObject;

	VoxEngineInternal** m_ppInternal;

	Handlable* m_debugPointerToObjectThatIsNotGaranteedToExistAnymore;
};

//! Opaque handle for data source object
class DataHandle : public Handle
{
public:
	virtual ~DataHandle();
	DataHandle( const DataHandle &handle);
	DataHandle(): Handle(-1){}
	DataHandle & operator=( const DataHandle &rhs);

protected:
	DataHandle(HandleId id, VoxEngineInternal** ppInternal = 0, Handlable* object = 0, u32 timestamp = 0, u32 tsGroup = 0);

	friend class Handlable;
	friend class HandlableContainer;
	friend class VoxEngineInternal;
	friend class VoxEngine;
};


//! Opaque handle for emitter object
class EmitterHandle : public Handle
{
public:
	virtual ~EmitterHandle();
	EmitterHandle( const EmitterHandle &handle);
	EmitterHandle(): Handle(-1){}
	EmitterHandle & operator=(const EmitterHandle &rhs);

protected:
	EmitterHandle(HandleId id, VoxEngineInternal** ppInternal = 0, Handlable* object = 0, u32 timestamp = 0, u32 tsGroup = 0);

	friend class Handlable;
	friend class HandlableContainer;
	friend class VoxEngineInternal;
	friend class VoxEngine;
};

//! Official Vox Audio Engine supported stream type
enum StreamTypes
{
	k_nStreamTypeInvalid = -1,  //!< Invalid/Unrecognized stream type
	k_nStreamTypeMemoryBuffer,  //!< Ram buffer
	k_nStreamTypeCFile,         //!< Internal file system file pointer (similar to C file pointer)
	
	// Add shared stream types here, then add dispatch code in Initialize().
	// Note: You can alternatively add new types through 'RegisterStreamType()', if you need game-specific stuff.

	k_nStreamTypeCount //!< Count of officially supported stream type
};

//! Official Vox Audio Engine supported encoding format type
enum FormatTypes
{
	k_nDecoderTypeInvalid = -1, //!< Invalid/Unrecognized encoding format
	k_nDecoderTypeRAW, //!< Raw PCM encoding
	k_nDecoderTypeMSWav, //!< Wave container encoding (sub decoder support PCM and IMA/DVI-ADPCM)
	k_nDecoderTypeStbVorbis, //!< Vorbis encoding 
	k_nDecoderTypeMPC8,	//!< Musepack version 8 encoding (legacy support of Musepack version 7)
	k_nDecoderTypeInteractiveMusic, //!< Vox Interactive Music format (VXN)
	k_nDecoderTypeBCWav, //!< CTR format compatible with hardware decoder
	
	// Add shared decoder types here, then add dispatch code in Initialize().
	// Note: You can alternatively add new types through 'RegisterDecoderType()', if you need game-specific stuff.

	k_nDecoderTypeCount	//!< Count of officially supported encoding format type
};

// Typical group flags, feel free to use your own
// Group are check through bitwise operator, so 1 bit per group
// Group Ids are within 1~31 and all needs to be different (only group 0 is reserved and cannot be redefined)
enum VoxGroupId
{
	k_nVoxGroupId_default	= 0,	//reserved group id
	k_nVoxGroupId_bgm		= 1,
	k_nVoxGroupId_sfx		= 2,

	k_nVoxGroupId_max		= 32   //reserved group id
};

enum VoxGroupTypes
{
	k_nVoxGroupType_invalid = 0,		//reserved group id
	k_nVoxGroupType_default	= 1 << k_nVoxGroupId_default,	//reserved group id
	k_nVoxGroupType_bgm		= 1 << k_nVoxGroupId_bgm,
	k_nVoxGroupType_sfx		= 1 << k_nVoxGroupId_sfx,
	
	k_nVoxGroupType_all  = 0xFFFFFFFF	//reserved group id
};

///
///
///

struct TrackParams
{
	s32 numChannels;
	s32 samplingRate;
	s32 bitsPerSample;
	u32 numSamples;

	TrackParams():numChannels(0), samplingRate(0), bitsPerSample(0), numSamples(0) {}

	void Reset(void)
	{
		numChannels = 0;
		samplingRate = 0;
		bitsPerSample = 0;
		numSamples = 0;
	}
};

///
///
///

/*!
	\brief Namespace for distance attenuation model
	\details See OpenAL specification 1.1 for more detail on distance attenuation model
	<br>For clamped attenuation model, distance is clamped to [ReferenceDistance, MaxDistance]
*/
namespace Vox3DDistanceModel
{
	enum
	{
		k_nNone=0, //!< All 3d is not computed (Not supported on OpenAL driver)
		k_nInverseDistance, //!< \f$ GainModifier = \frac{ReferenceDistance}{ReferenceDistance + RolloffFactor * (distance - ReferenceDistance)} \f$
		k_nInverseDistanceClamped, //!< \f$ GainModifier = \frac{ReferenceDistance}{ReferenceDistance + RolloffFactor * (distance - ReferenceDistance)} \f$
		k_nLinearDistance, //!< \f$ GainModifier = 1 - \frac{RolloffFactor * (distance - ReferenceDistance)}{MaxDistance - ReferenceDistance} \f$
		k_nLinearDistanceClamped, //!< \f$ GainModifier = 1 - \frac{RolloffFactor * (distance - ReferenceDistance)}{MaxDistance - ReferenceDistance} \f$
		k_nExponentDistance, //!< \f$ GainModifier = (\frac{distance}{ReferenceDistance})^{-ReferenceDistance} \f$
		k_nExponentDistanceClamped //!< \f$ GainModifier = (\frac{distance}{ReferenceDistance})^{-ReferenceDistance} \f$
	};
}

struct Vox3DEmitterParameters
{
	Vox3DEmitterParameters() :	relativeToListener(VOX_DEFAULT_3D_EMITTER_RELATIVE_TO_LISTENER)
							  , maxDistance(VOX_DEFAULT_3D_EMITTER_MAX_DISTANCE)
							  , referenceDistance(VOX_DEFAULT_3D_EMITTER_REFERENCE_DISTANCE)
							  , rolloffFactor(VOX_DEFAULT_3D_EMITTER_ROLLOFF_FACTOR)
							  , innerConeAngle(VOX_DEFAULT_3D_EMITTER_INNER_CONE_ANGLE)
							  , outerConeAngle(VOX_DEFAULT_3D_EMITTER_OUTER_CONE_ANGLE)
							  , outerConeGain(VOX_DEFAULT_3D_EMITTER_OUTER_CONE_GAIN)
							  , cullingDistance(VOX_DEFAULT_3D_EMITTER_CULLING_DISTANCE)
								{};


	s32		relativeToListener;   // default 0 (false)
	f32		maxDistance;			// default MAX_FLOAT
	f32		referenceDistance;	// default 1.0f
	f32		rolloffFactor;		// default 1.0f
	f32		innerConeAngle;		// default 360.0f
	f32		outerConeAngle;		// default 360.0f
	f32		outerConeGain;		// default0.0f
	f32		cullingDistance;		//Not in OpenAL, but might add it in soft
};

//! Namespace for emitter 3D parameter ids
/*
	See OpenAL specification 1.1 for more detail on each parameter
*/
namespace Vox3DEmitterParameter
{
	enum
	{
		k_nRelativeToListener=0, //!< Emitter position is world coordinate (0) or listener coordinate (1) <b>Default : 0</b>
		k_nMaxDistance, //!< Emitter maximum distance <b>Default : MAX_FLOAT</b>
		k_nReferenceDistance, //!< Emitter reference distance <b>Default : 1</b>
		k_nRolloffFactor, //!< Emitter rolloff factor <b>Default : 1</b>
		k_nInnerConeAngle, //!< Emitter inner cone angle <b>Default : 360.0f</b>
		k_nOuterConeAngle, //!< Emitter outer cone angle <b>Default : 360.0f</b>
		k_nOuterConeGain, //!< Emitter outer cone gain <b>Default : 0.0f</b>
		k_nCullingDistance, //!< Emitter culling distance (addition to specification, not supported on all driver) <b>Default : MAX_FLOAT</b>
		k_nPosition, //!< Emitter position  <b>Default : {0.0f, 0.0f, 0.0f} </b>
		k_nVelocity, //!< Emitter velocity  <b>Default : {0.0f, 0.0f, 0.0f} </b>
		k_nDirection, //!< Emitter direction <b>Default : {0.0f, 0.0f, 0.0f} </b>
		k_nCount//param count
	};
}

struct Vox3DGeneralParameters
{
	Vox3DGeneralParameters() : dopplerFactor(VOX_DEFAULT_3D_DOPPLER_FACTOR)
	                         , speedOfSound(VOX_DEFAULT_3D_SPEED_OF_SOUND)
							 , distanceModel(VOX_DEFAULT_3D_MODEL)
							 , enhanced3d(VOX_DEFAULT_3D_ENHANCED_3D)
							   {};

	f32 dopplerFactor;    // Default 1.0f
	f32 speedOfSound;     // Default 343.3f
	u32 distanceModel;    // Default InverseDistanceClamped
	u32 enhanced3d; // Default 0

};

//! Namespace for emitter DSP parameter ids
namespace VoxDSPEmitterParameter
{
	enum
	{
		k_nBusId //!< String id of bus to use for the emitter
	};

	enum OcclusionMaterialPreset
	{
		k_nNone = 0,
		k_nThinDoor,
		k_nThickDoor,
		k_nWoodWall,
		k_nBrickWall,
		k_nStoneWall,
		k_nCurtain
	};
}

//! Namespace for general 3D parameter ids
/*
	See OpenAL specification 1.1 for more detail on each parameter
*/
namespace Vox3DGeneralParameter
{
	enum
	{
		k_nDopplerFactor=0, //!< Factor to apply to doppler shift. <b>Default 1.0f</b>
		k_nSpeedOfSound,	//!< Speed of sound in meter per second. <b>If the unit uses for listener and emitter velocity is different, this value must be changed accordingly.</b> <b>Default 343.3f</b>
		k_nDistanceModel,	//!< Model of distance attenuation <b>Default : Vox3DDistanceModel::k_nInverseDistanceClamped</b>
		k_nEnhanced3d,      //!< Runtime switch to front/back and up/down 3d enhancement filters on(1) or off(0). <b>Default : 0</b>
		k_nListenerPosition, //!< Listener position <b>Default { 0.0f, 0.0f, 0.0f }</b>
		k_nListenerVelocity, //!< Listener velocity <b>Default { 0.0f, 0.0f, 0.0f }</b>
		k_nListenerOrientation, //!< Listener orientation <b>Default {{ 0.0f, 1.0f, 0.0f }, { 0.0f, 0.0f, -1.0f }}</b>
		k_nCount//param count
	};
}

//! Namespace for general DSP parameter ids
namespace VoxDSPGeneralParameter
{
	//! Routing path type
	enum BusRoutingType
	{
		k_nDry, //!< Dry path
		k_nWet, //!< Wet path
		k_nWetAndDry //!< Dry and Wet path
	};

	enum
	{
		k_nRoutingVolume, //!< Routing path volume
		k_nDSPModuleParameter
	};
}

struct VoxDSPModuleParameterChange
{
	c8* m_DSPModuleParameterName;
	c8* m_busName;
	s32 m_DSPSlot;
	void* m_parameterValue;
	f32 m_fadeTime;
};

enum VoxOutputMode
{
	k_nOutputModeUnknown = -1,
	k_nOutputModeMono,
	k_nOutputModeStereo,
	k_nOutputModeSurround
};

//! Behaviour of the priority bank is full
enum PriorityBankBehavior
{
	k_nStealOldest, //!< New emitter will steal oldest emitter slot
	k_nStealLowestPriority, //!< New emitter will steal emitter slot with lowest priority, if lower than his
	k_nStealLowestPriorityOldest, //!< New emitter will steal emitter slot with lowest priority, if lower than his or the oldest slot with the same priority
	k_nDoNothing //!< New emitter will not play
};

//! Loading flags for data source of StreamType k_nStreamTypeCFile
enum VoxSourceLoadingFlags
{
	//Loading flags
	k_nNone = 0, //!< Normal streaming mode
	k_nLoadToRam = 0x0001, //!< Load the file to a buffer in ram (StreamType changed to k_nStreamTypeMemoryBuffer)
	k_nLoadToRamAndDecode = 0x0002, //!< Decode the file to a buffer in ram (StreamType changed to k_nStreamTypeMemoryBuffer, DecoderType changed to k_nDecoderTypeRAW)
	k_mLoadFlagMask = 0xFFFF, //!< Mask for basic loading flag

	//Other Flags
	k_nAsync = 0x00010000, //!< Optional flags to postpone data source loading to next UpdateSources call
	k_mOtherFlags = 0xFFFF0000, //!< Mask for optional loading flags

	//Mixed Flags
	k_nAsyncLoadToRam = k_nAsync | k_nLoadToRam, //!< k_nAsync + k_nLoadToRam
	k_nAsyncLoadToRamAndDecode = k_nAsync | k_nLoadToRamAndDecode //!< k_nAsync + k_nLoadToRamAndDecode
};

//! Observable emitter state flags
enum EmitterExternState
{
	//state
	k_nError	=   0x00, //!< Emitter is in error
	k_nPlaying	=	0x01, //!< Emitter is playing
	k_nPaused	=	0x02, //!< Emitter is paused
	k_nStopped	=	0x04, //!< Emitter is stopped

	//sub-state
	k_nFadingIn	=	0x10, //!< Emitter volume is fading in
	k_nFadingOut=	0x20 //!< Emitter volume is fading out
};

//! Structure containing debug information
/*!
	\deprecated Application should now use debug server to get more accurate metrics
*/
struct DebugInfo
{
	s32 m_nDataSource; //!< Data source count
	s32 m_nEmitter; //!< Emitter count (all states)
	s32 m_nPlayingEmitter; //!< Emitter currently playing count
	s32 m_nApproxMem;
};

//
//
//

//! Callback definition for emitter state changed callback
/*!
	\param handle Handle of the emitter
	\param userData User data sent during callback
	\param state Current state of the emitter (main state only)
*/
typedef void (*VoxEmitterStateChangedCallbackFunc) (EmitterHandle &handle, void* userData, EmitterExternState state); 


//! Vox Engine User Interface
/*!
	This class is the user interface to Vox Audio Engine.  The user first has to get a reference through
	the static method GetVoxEngine.  This class follow singleton design patern and can have up to one instance
	at the time.
*/
class VoxEngine
{
protected:
	VoxEngine();
	VoxEngine(void*):m_isInitialized(false){}//dummy ctor
public:
	virtual ~VoxEngine();

	//! Retrieve current VoxEngine singleton
	/*!
		If VoxEngine doesn't exist yet, it's created.
		\return Reference to current VoxEngine object.
	*/	
	static VoxEngine& GetVoxEngine();

	//! VoxEngine singleton destructor
	/*!
		If VoxEngine exist, it's destroyed.
	*/	
	static void DestroyVoxEngine();

public:

	//
	// Initialization methods
	//	

	//! Initialize Vox Engine
	/*!
		Initialize internal component of the Vox Engine
	*/	
	virtual void Initialize();

	//! Shutdown Vox Engine
	/*!
		Internal shutdown of Vox Engine.  If thread are enabled, the threads are killed.
	*/	
	virtual void Shutdown();

	//! Register a new stream type
	/*!
		This method allow to add game specific stream type, according they repect StreamInterface.
		\param fnPtr Pointer to the factory function to create Stream object of this type
		\return The stream id to use for loading data source with stream of this type.  If the maximum number of stream type is already reach or an error occur, -1 is returned.
	*/	
	s32  RegisterStreamType( StreamTypeFactoryFnPtr fnPtr);
	
	//! Register a new decoder type
	/*!
		This method allow to add game specific decoder type, according they repect DecoderInterface.
		\param fnPtr Pointer to the factory function to create Decoder object of this type
		\return The decoder id to use for loading data source with decoder of this type.  If the maximum number of decoder type is already reach or an error occur, -1 is returned.
	*/	
	s32  RegisterDecoderType( DecoderTypeFactoryFnPtr fnPtr);

	//! Configure a priority bank
	/*!
		This method allow to configure a priority bank.
		\param bankId Id of the bank to configure
		\param threshold Minimum priority for a emitter to play
		\param maxplayback Maximum playing emitter registered in the bank
		\param behavior Behavior to follow when a bank is full and a play is requested
		\return True is the bank was configured successfully
	*/	
	bool SetPriorityBank(s32 bankId, s32 threshold, s32 maxplayback, PriorityBankBehavior behavior);

	//
	// Interruption methods
	//

	//! Suspend vox engine
	/*!
		This method suspends the vox engine. A counter is incremented each time the
		method is called and decremented each time ResumeEngine() is called. Actual
		resumption is effective when the counter gets to 0.
	*/	
	virtual void SuspendEngine(void);

	//! Resume vox engine
	/*!
		This method resumes the vox engine. A counter is decremented each time the
		method is called and incremented each time SuspendEngine() is called. Actual
		resumption is effective when the counter gets to 0.
	*/	
	virtual void ResumeEngine(void);

	//! Get engine suspension state
	/*!
		This method provides the suspension state resulting from SuspendEngine()
		and ResumeEngine() calls.
		\return True if the vox engine is suspended.
	*/	
	virtual bool IsEngineSuspended(void);

public:

	//
	// Update methods
	//

	//! Update all data sources
	/*!
		This method update all data sources.  
		This is where data sources auto-release is done.  
		If VOX_THREAD_SAFETY_LEVEL is set to 1, this method can be used in an external thread.
	*/	
	void UpdateSources();

	//! Update all emitters
	/*!
		This method update all emitters.  This is the moment all command are actually sent to the hardware driver.  If the time interval between call is long, delay in commande execution is to be expected.  
		This is where emitter auto-release is done.  
		If VOX_THREAD_SAFETY_LEVEL is set to 1, this method can be used in an external thread.
		\param dt Time elapsed since last call (seconds)
	*/	
	void UpdateEmitters(f32 dt); // Playing ( can be on a separate thread )
	// Note: Both of these update methods can be placed in SEPARATE threads, so that loading can be done asynchronously.
	
	//! Update both data sources and emitters
	/*!
		This method first call UpdateSources, than UpdateEmitters.  In non-threaded implementation, calling this method should be enough.
		\param dt Time elapsed since last call (seconds)
	*/	
	void Update(f32 dt);

private:
	//! Update method for single thread implementation loop
	/*!
		This method call UpdateThreaded then sleep for VOX_THREAD_UPDATE_DT ms, until thread is shutdown.
		\param caller Pointer to vox engine object
		\param param Parameter needed for VoxThread method signature <i>(unused)</i>
	*/	
	static void UpdateThreaded(void* caller, void* param);

	//! Data source update method for dual thread implementation loop
	/*!
		This method call UpdateSourcesThreaded then sleep for VOX_THREAD_UPDATE_DT ms, until thread is shutdown.
		\param caller Pointer to vox engine object
		\param param Parameter needed for VoxThread method signature <i>(unused)</i>
	*/	
	static void UpdateSourcesThreaded(void* caller, void* param);

	//! Emitter update method for dual thread implementation loop
	/*!
		This method call UpdateEmittersThreaded then sleep for VOX_THREAD_UPDATE_DT ms, until thread is shutdown.
		\param caller Pointer to vox engine object
		\param param Parameter needed for VoxThread method signature <i>(unused)</i>
	*/	
	static void UpdateEmittersThreaded(void* caller, void* param);


	//! Update data sources in dual thread implementation
	/*!
	*/
	void UpdateSourcesThreaded();

	//! Update emitters in dual thread implementation
	/*!
		This method keep track of update time and generate dt needed by UpdateEmitter
	*/
	void UpdateEmittersThreaded();

	//! Update both data sources and emitters in single thread implementation
	/*!
		This method first call UpdateSourcesThreaded, than UpdateEmittersThreaded.
	*/
	void UpdateThreaded();

#ifdef VOX_THREADING_MODE_SINGLE_THREAD
	VoxThread* m_updateThread;
	f64 m_lastUpdateTime;
#elif defined(VOX_THREADING_MODE_DUAL_THREAD)
	VoxThread* m_updateThread[2];
	f64 m_lastUpdateTime;
#endif

public:
	//
	// Data methods
	//

	//! Create a data source
	/*!
		Create a data source according to the parameter received.  
		If there's an error during the data source creation, data source isn't created and an invalid handle is returned.
		\param streamType Id of the stream type for the data source
		\param streamParams Parameters to initialize the stream
		\param decoderType Id of the decoder type for the data source
		\param decoderParams Parameters to initialize the decoder
		\param groupId Default group for all emitter created with this data handle
		\return Handle to the data source created.  The data handle might be invalid if data source creation didn't complete properly.
	*/
	DataHandle LoadDataSource( s32 streamType, void* streamParams, s32 decoderType, void* decoderParams, s32 groupId );

	//! Create a data source with asynchronous loading
	/*!
		Create a data source according to the parameter received.  
		If there's an error during the data source creation, data source isn't created and an invalid handle is returned.
		\param streamType Id of the stream type for the data source
		\param streamParams Parameters to initialize the stream
		\param decoderType Id of the decoder type for the data source
		\param decoderParams Parameters to initialize the decoder
		\param groupId Default group for all emitter created with this data handle
		\param loadingFlags Loading flags
		\return Handle to the data source created.  The data handle might be invalid if data source creation didn't complete properly.
	*/
	DataHandle LoadDataSourceAsync( s32 streamType, void* streamParams, s32 decoderType, void* decoderParams, s32 groupId, VoxSourceLoadingFlags loadingFlags);

	//! Create a new data source already decoded in a RAM buffer
	/*!
		Create a new data source with stream type k_nStreamTypeMemoryBuffer and decoder type k_nDecoderTypeRAW.  
		The data handle used for the conversion is not affected by this operation.
		\param handle Handle of the data source to convert
		\return Handle to the data source created.  The data handle might be invalid if data source creation didn't complete properly.
	*/	
	DataHandle ConvertToRawSource(DataHandle &handle );

	//! Create a new data source in a RAM buffer
	/*!
		Create a new data source with stream type k_nStreamTypeMemoryBuffer without any decoding.  
		The data handle used for the conversion is not affected by this operation.
		\param handle Handle of the data source to convert
		\return Handle to the data source created.  The data handle might be invalid if data source creation didn't complete properly.
	*/	
	DataHandle ConvertToRamBufferSource(DataHandle &handle );

	//! Set the user data linked to the data source
	/*!
		\param handle Handle of the data source to set the pointer to.
		\param data DataHandleUserData object containing user defined data.
	*/	
	void SetUserData( DataHandle &handle, DataHandleUserData &data);
	
	//! Get the user data linked to the data source
	/*!
		\param handle Handle of the data source to get the user data from.
		\return DataHandleUserData as defined by user.  If no user data was defined or data source doesn't exist, defaut one is returned.
	*/	
	DataHandleUserData GetUserData( DataHandle &handle);

	//! Set the priority bank for the data source
	/*!
		\param handle Handle of the data source to set the priority bank.
		\param bankId Id of the bank to use.
	*/	
	void SetPriorityBankId( DataHandle &handle, s32 bankId);

	//! Set unique numeric id for the sound entity in XML soundpack
	/*!
		\param handle Handle of the data source to set the priority bank.
		\param Uid Id of the sound entity in XML soundpack.
	*/
	void SetUid( DataHandle &handle, s32 Uid);

	//! Get unique numeric id for the sound entity in XML soundpack
	/*!
		\param handle Handle of the data source to set the priority bank.
		\return Unique id of the sound entity in XML soundpack.
	*/
	s32 GetUid( DataHandle &handle);

	//! Release a data source
	/*!
		Release the data source associated with the data handle in real time.  This is a blocking method when thread are enabled.  
		All emitters associated with the data source are killed before the data source is released.
		\param handle Handle of the data source to release
	*/	
	void ReleaseDatasource( DataHandle &handle ); // Forced release, no matter what the ref count is. Emitters should die gracefully.

	//! Release all data source with group matching the group mask
	/*!
		Release all the data source with group matching the group mask in real time.  This is a blocking method when thread are enabled.  
		All emitters associated with the data sources are killed before the data source is released.
		\param groupMask Group mask of the groups to apply the command to
	*/	
	void ReleaseDatasource( u32 groupMask ); // Forced release, based on groups.

	//! Test if a data source is valid and ready to receive command
	/*!
		\param handle Handle of the data source to test
		\return True if the data source is valid and ready to receive commands
	*/	
	bool IsReady( DataHandle &handle );

	//! Test if a data source is valid
	/*!
		\param handle Handle of the data source to test
		\return True if the data source is valid
	*/	
	bool IsValid( DataHandle &handle );

	//! Get the duration of the stream of the data source
	/*!
		\param handle Handle of the data source to get the duration
		\return Duration of the stream (seconds)
	*/	
	f32 GetDuration( DataHandle &handle );

	//! Get all current emitter for a data sources
	/*!
		Return up to bufferCount data source handles of current data sources.  These count as valid reference to data source. 
		\param handle Handle of the data source to get the emitters
		\param handlesBuffer Array to write emitter handles to 
		\param bufferCount Maximum emitter handles to write to array
		\return Actual number of emitter handles written to the array
	*/
	s32  GetEmitterHandles( DataHandle &handle, EmitterHandle* handlesBuffer, s32 bufferCount );

	//! Get all current data sources
	/*!
		Return up to bufferCount data source handles of current data sources.  These count as valid reference to data source. 
		\param handlesBuffer Array to write data source handles to 
		\param bufferCount Maximum data source handles to write to array
		\return Actual number of data source handles written to the array
	*/
	s32  GetAllDataSources( DataHandle* handlesBuffer, s32 bufferCount );

public:

	//
	// Emitter methods
	//

	//! Register a callback to notify of an emitter state changing
	/*!
		Register a state changed callback for an emitter with optional user
		data structure sent back when the callback occurs.  The state returned
		doesn't contain the substate, only the main state.  If emitter sending
		the callback has no reference, it might be already deleted when the 
		callback is sent.
		<br>
		<b>Note : The callback function should be thread-safe. It's best to keep 
		work light and avoid call to Vox Audio Engine methods during the 
		callback.</b>
		\param handle Handle of the emitter
		\param callback Function that will be called by when the state changes
		\param userData User data structure that will be available in callback
	*/
	void RegisterForEmitterStateChangeNotification( EmitterHandle &handle, VoxEmitterStateChangedCallbackFunc callback, void* userData = 0);

	//! Unregister a callback to notify of an emitter state changing
	/*!	
		Unregister a previously registered callback for an emitter state changed
		notification.
		<br>
		<b>Note : When Vox is in threaded mode, the callback may still be called
		one time after unregistering if the callback is currently in the 
		callback queue</b>
	*/
	void UnregisterForEmitterStateChangeNotification( EmitterHandle &handle);

	//! Create an active emitter from a data source 
	/*!
		Create an active emitter from the data source linked to the DataHandle. 
		If no more hardware source is available, will steal one from a lower priority emitter.
		If an error occurs during emitter creation, the emitter isn't created.
		\param handle DataHandle to the data source to use in the creation of the emitter
		\param priority Sound priority (natural number order). Only relevant if hardware source pooling is enabled.
		\param driverParam Parameter to overider the driver default parameter.  Must send the right type of parameter according to the active driver.
		\return Always return an EmitterHandle, but the handle return will not be link if the emitter wasn't created
	*/
	EmitterHandle CreateEmitter( DataHandle &handle, s32 priority = 0, void* driverParam = 0);

	//! Create an active emitter from a data source asynchronously
	/*!
		Create an active emitter from the data source linked to the DataHandle. 
		If no more hardware source is available, will steal one from a lower priority emitter.
		If an error occurs during emitter creation, the emitter isn't created.
		When using this method, some of the creation process is deferred to the first update, some commands on the emitter handle return might not work before the emitter is ready.
		\param handle DataHandle to the data source to use in the creation of the emitter
		\param priority Sound priority (natural number order). Only relevant if hardware source pooling is enabled.
		\param driverParam Parameter to overider the driver default parameter.  Must send the right type of parameter according to the active driver.
		\return Always return an EmitterHandle, but the handle return will not be link if the emitter wasn't created
	*/
	EmitterHandle CreateEmitterAsync( DataHandle &handle, s32 priority = 0, void* driverParam = 0);

	//! Set the user data linked to the emitter
	/*!
		\param handle Handle of the emitter to set the pointer to.
		\param data EmitterHandleUserData object containing user defined data.
	*/	
	void SetUserData( EmitterHandle &handle, EmitterHandleUserData &data);
	
	//! Get the user data linked to the emitter
	/*!
		\param handle Handle of the emitter to get the user data from.
		\return EmitterHandleUserData as defined by user.  If no user data was defined or emitter doesn't exist, defaut one is returned.
	*/	
	EmitterHandleUserData GetUserData( EmitterHandle &handle);

	//! Kill an active emitter 
	/*!
		Kill an active emitter in real time.  In threaded implementation, this method can block will waiting for 
		write access to the emitter list.  This method stop the playback of the emitter.
		\param handle EmitterHandle to the emitter to kill
	*/
	void KillEmitter( EmitterHandle &handle ); // Forced release, immediate stop.

	//! Get the data source used by the emitter
	/*!
		Get the data source used in the creation of the emitter.
		\param handle EmitterHandle to the emitter
		\return DataHandle to the the data source
	*/
	DataHandle GetData(EmitterHandle &handle);

	//! Play the emitter associated with the handle
	/*!
		The playback cursor is rewind to the start of the sound source.
		If no emitter is currently associated with the handle, the command is ignored.
		\param handle Handle of the emitter to play
		\param loop Initial looping state of the emitter
		\param fadeTime Duration of the fade in (seconds)
	*/
	void  Play( EmitterHandle &handle, bool loop = false, f32 fadeTime = VOX_DEFAULT_FADE_TIME );

	//! Stop the emitter associated with the handle
	/*!
		If no emitter is currently associated with the handle, the command is ignored.
		\param handle Handle of the emitter to stop
		\param fadeTime Duration of the fade out (seconds)
	*/
	void  Stop( EmitterHandle &handle, f32 fadeTime = VOX_DEFAULT_FADE_TIME );

	//! Pause the emitter associated with the handle
	/*!
		If no emitter is currently associated with the handle, the command is ignored.
		\param handle Handle of the emitter to pause
		\param fadeTime Duration of the fade out (seconds)
	*/
	void  Pause( EmitterHandle &handle, f32 fadeTime = VOX_DEFAULT_FADE_TIME );

	//! Resume the emitter associated with the handle
	/*!
		If no emitter is currently associated with the handle, the command is ignored.  
		Only a source in "paused" state can resume.
		\param handle Handle of the emitter to pause
		\param fadeTime Duration of the fade in (seconds)
	*/
	void  Resume( EmitterHandle &handle, f32 fadeTime = VOX_DEFAULT_FADE_TIME );

	//! Return the current playback position of a cursor
	/*!
		If the emitter is currently playing the precision of the value return is dependent of the hardware driver.
		\param handle Handle of the emitter to get position from
		\return Position of the playback (seconds)
	*/
	f32 GetPlayCursor( EmitterHandle &handle );

	//! Set the current playback position of a cursor
	/*!
		If the emitter is currently playing, the playback is first stopped, than the position is set and the emitter playback start again.  
		Setting play cursor on a playing source may result in clicking sound of short interruption in the sound playback.
		On a looping emitter, setting the cursor farther then the end of the stream will loop back and continue to advanced to the desired position.
		On non-looping emitter, the cursor will stop at the end.
		\param handle Handle of the emitter to set position to
		\param time Position, in seconds, to set the cursor to
	*/
	void  SetPlayCursor( EmitterHandle &handle, f32 time = 0.0f );
	
	//! Test if an emitter is valid and ready to accept a command
	/*!
		\param handle Handle of the emitter to test
		\return True if the handle is associated with a valid emitter ready to received a command.
	*/
	bool  IsReady( EmitterHandle &handle );

	//! Test if a emitter is valid
	/*!
		\param handle Handle of the emitter to test
		\return True if the emitter is valid
	*/	
	bool IsValid( EmitterHandle &handle );

	//! Test if an emitter is valid and not in the process of being deleted
	/*!
		\param handle Handle of the emitter to test
		\return True if the handle is associated with a valid emitter ready to received a command and not waiting to be deleted.
	*/
	bool  IsAlive( EmitterHandle &handle );

	//! Test if an emitter is currently playing
	/*!
		\param handle Handle of the emitter to test
		\return True if the handle is associated with a valid emitter currently playing.
	*/
	bool  IsPlaying( EmitterHandle &handle );

	//! Test if an emitter playback has ended
	/*!
		\param handle Handle of the emitter to test
		\return True if the handle is associated with a valid emitter currently in "stopped" state.
	*/
	bool  IsDone( EmitterHandle &handle );

	//! Return an extended state for the emitter
	/*!
		\param handle Handle of the emitter to test
		\return Extended state of the emitter
	*/
	u32 GetStatus( EmitterHandle &handle );

	//! Set the behavior of the emitter when playback is done
	/*!
		When set to true the emitter will be destroy after playback is done.
		This method has no effect is emitter autorelease is enabled (default).
		\param handle Handle of the emitter to get position from
		\param kill If set to true, the emitter will be release after playback
	*/
	void  SetAutoKillAfterDone( EmitterHandle &handle, bool kill = false );//only useful is VOX_AUTORELEASE_EMITTER is set to 0

	//! Set the group of an emitter
	/*!
		Use with no group parameter to reset group to default.  
		Upon creation, an emitter will receive its group from the data source.  
		This method allow to override default group assignation.
		\param handle Handle of the emitter to set group
		\param groupId Group id to set [1~31]
	*/
	void  SetGroup( EmitterHandle &handle, s32 groupId = k_nVoxGroupId_default ); // Note: Group flags are initialy inherited from the data source

	//! Get the group of an emitter
	/*!
		\param handle Handle of the emitter to set group
	*/
	s32   GetGroup( EmitterHandle &handle );

	//! Set looping state of an emitter
	/*!
		\param handle Handle of the emitter to set looping state
		\param loop Looping state to set
	*/
	void  SetLoop( EmitterHandle &handle, bool loop = false );

	//! Set the gain of an emitter
	/*!
		\param handle Handle of the emitter to set gain
		\param gain Gain to set [0.0~1.0]
		\param fadeTime Duration of the transition (seconds)
	*/
	void  SetGain( EmitterHandle &handle, f32 gain = 1.0f, f32 fadeTime = VOX_DEFAULT_FADE_TIME );

	//! Get the gain of an emitter
	/*!
		This method return the gain value for the emitter, it doesn't consider
		the value of the group gain or the master gain.  If the emitter is
		currently fading, this method will return the target gain, not the 
		current gain.<br>
		<b>Note : This value represent the value the user set, the driver might 
		clamp this value to match it's limitation.</b>
		\param handle Handle of the emitter to get gain
	*/
	f32  GetGain( EmitterHandle &handle );

	//! Set the pitch of an emitter
	/*!
		\param handle Handle of the emitter to set pitch
		\param pitch Pitch to set (0.0~2.0]
		\param fadeTime Duration of the transition (seconds)
	*/
	void  SetPitch( EmitterHandle &handle, f32 pitch = 1.0f, f32 fadeTime = VOX_DEFAULT_FADE_TIME );

	//! Get the pitch of an emitter
	/*!
		This method return the pitch value for the emitter.  If the emitter is
		currently fading, this method will return the target pitch, not the 
		current pitch.<br>
		<b>Note : This value represent the value the user set, the driver might 
		clamp this value to match it's limitation.</b>
		\param handle Handle of the emitter to get pitch
	*/
	f32  GetPitch( EmitterHandle &handle );

	//! Set the priority of an emitter
	/*!
		This method change the priority of an emitter. <b>If the priority is
		changed while the emitter is in a bank, the behaviour may be different
		from expected (Some check are only done when adding an emitter to a
		bank)</b>
		\param handle Handle of the emitter to set priority
		\param priority Priority to set
	*/
	void SetPriority( EmitterHandle &handle, s32 priority);

	//! Get the priority of an emitter
	/*!
		\param handle Handle of the emitter to set priority
		\return Priority of the emitter.  If the emitter is not valid, result undefined
	*/
	s32  GetPriority( EmitterHandle &handle);

	//3D

	//! Set an emitter position
	/*!
		\param handle Handle of the emitter to set position
		\param x x coordinate of the emitter
		\param y y coordinate of the emitter
		\param z z coordinate of the emitter
	*/
	void  Set3DEmitterPosition( EmitterHandle &handle, f32 x, f32 y, f32 z );

	//! Set an emitter velocity
	/*!
		\param handle Handle of the emitter to set velocity
		\param x Velocity x component of the emitter
		\param y Velocity y component of the emitter
		\param z Velocity z component of the emitter
	*/
	void  Set3DEmitterVelocity( EmitterHandle &handle, f32 x, f32 y, f32 z );

	//! Set an emitter direction
	/*!
		Doesn't affect emitter with 360 degree cone.
		\param handle Handle of the emitter to set velocity
		\param x Velocity x component of the emitter
		\param y Velocity y component of the emitter
		\param z Velocity z component of the emitter
	*/
	void  Set3DEmitterDirection( EmitterHandle &handle, f32 x, f32 y, f32 z );

	//! Set all emitter scalar 3D properties
	/*!
		Allow to set all scalar 3D properties at once.
		\param handle Handle of the emitter to set velocity
		\param param Structure containing all the 3D properties to set
	*/
	void  Set3DEmitterParameters( EmitterHandle &handle, const Vox3DEmitterParameters &param);

	//! Set a f32 3D property of an emitter
	/*!
		Non-float property will be ignored. The following properties can be used with this method:
		<ul>
		<li>k_nMaxDistance</li>
		<li>k_nReferenceDistance</li>
		<li>k_nRolloffFactor</li>
		<li>k_nInnerConeAngle</li>
		<li>k_nOuterConeAngle</li>
		<li>k_nOuterConeGain</li>
		<li>k_nCullingDistance</li>
		</ul>
		These properties are defined in Vox3DEmitterParameter namespace.
		\param handle Handle of the emitter to set velocity
		\param paramId Id of the property to set (see list above) 
		\param floatValue Value to set the property to
	*/
	void  Set3DEmitterParameterf( EmitterHandle &handle, s32 paramId, f32 floatValue );

	//! Set an integer 3D property of an emitter
	/*!
		Non-integer property will be ignored. The following property can be used with this method:
		<ul>
		<li>k_nRelativeToListener</li>
		</ul>
		This property is defined in Vox3DEmitterParameter namespace.
		\param handle Handle of the emitter to set velocity
		\param paramId Id of the property to set (see list above) 
		\param intValue Value to set the property to
	*/
	void  Set3DEmitterParameteri( EmitterHandle &handle, s32 paramId, s32 intValue );
	
	//! Get an emitter position
	/*!
		\param handle Handle of the emitter to get position
		\param x x coordinate of the emitter
		\param y y coordinate of the emitter
		\param z z coordinate of the emitter
	*/
	void  Get3DEmitterPosition( EmitterHandle &handle, f32 &x, f32 &y, f32 &z );

	//! Get an emitter velocity
	/*!
		\param handle Handle of the emitter to get velocity
		\param x Velocity x component of the emitter
		\param y Velocity y component of the emitter
		\param z Velocity z component of the emitter
	*/
	void  Get3DEmitterVelocity( EmitterHandle &handle, f32 &x, f32 &y, f32 &z );

	//! Set an emitter direction
	/*!
		Doesn't affect emitter with 360 degree cone.
		\param handle Handle of the emitter to get velocity
		\param x Velocity x component of the emitter
		\param y Velocity y component of the emitter
		\param z Velocity z component of the emitter
	*/
	void  Get3DEmitterDirection( EmitterHandle &handle, f32 &x, f32 &y, f32 &z );

	//! Get all emitter scalar 3D properties
	/*!
		Allow to set all scalar 3D properties at once.
		\param handle Handle of the emitter to set velocity
		\param param Structure containing all the 3D properties to set
	*/
	void  Get3DEmitterParameters( EmitterHandle &handle, Vox3DEmitterParameters &param);

	//! Get a f32 3D property of an emitter
	/*!
		Non-float property will be ignored. The following properties can be used with this method:
		<ul>
		<li>k_nMaxDistance</li>
		<li>k_nReferenceDistance</li>
		<li>k_nRolloffFactor</li>
		<li>k_nInnerConeAngle</li>
		<li>k_nOuterConeAngle</li>
		<li>k_nOuterConeGain</li>
		<li>k_nCullingDistance</li>
		</ul>
		These properties are defined in Vox3DEmitterParameter namespace.
		\param handle Handle of the emitter to get velocity
		\param paramId Id of the property to get (see list above) 
		\param floatValue Value to set the property to
	*/
	void  Get3DEmitterParameterf( EmitterHandle &handle, s32 paramId, f32 &floatValue );

	//! Get an integer 3D property of an emitter
	/*!
		Non-integer property will be ignored. The following property can be used with this method:
		<ul>
		<li>k_nRelativeToListener</li>
		</ul>
		This property is defined in Vox3DEmitterParameter namespace.
		\param handle Handle of the emitter to get velocity
		\param paramId Id of the property to get (see list above) 
		\param intValue Value to set the property to
	*/
	void  Get3DEmitterParameteri( EmitterHandle &handle, s32 paramId, s32 &intValue );

	//! Set a DSP property of an emitter
	/*!
		The following property can be used with this method:
		<ul>
		<li>k_nBusId (c8*)</li>
		</ul>
		This property is defined in VoxDSPEmitterParameter namespace.
		\param handle Handle of the emitter to set velocity
		\param paramId Id of the property to set (see list above) 
		\param param Value to set the property to
	*/
	void  SetDSPEmitterParameter( EmitterHandle &handle, s32 paramId, void* param );

	//! Set next state of an interactive music emitter
	/*!
		\param handle Emitter handle to set the state to
		\param stateLabel Label of the state to set
	*/
	void SetInteractiveMusicState(EmitterHandle &handle, const char *stateLabel);

	//! Get all current emitters
	/*!
		Return up to bufferCount emitter handles of current emitter.  These count as valid reference to emitter. 
		\param handlesBuffer Array to write emitter handles to 
		\param bufferCount Maximum emitter handles to write to array
		\return Actual number of emitter handles written to the array
	*/
	s32   GetAllEmitters( EmitterHandle* handlesBuffer, s32 bufferCount );

	//
	// Group methods
	//

	//! Play all emitters with group matching the group mask
	/*!
		\param groupMask Group mask of the groups to apply the command to
		\param fadeTime Duration of the fade in (seconds)
	*/
	void PlayAllEmitters( u32 groupMask, f32 fadeTime = VOX_DEFAULT_FADE_TIME );

	//! Stop all emitters with group matching the group mask
	/*!
		\param groupMask Group mask of the groups to apply the command to
		\param fadeTime Duration of the fade out (seconds)
	*/
	void StopAllEmitters( u32 groupMask, f32 fadeTime = VOX_DEFAULT_FADE_TIME );

	//! Pause all emitters with group matching the group mask
	/*!
		\param groupMask Group mask of the groups to apply the command to
		\param fadeTime Duration of the fade out (seconds)
	*/
	void PauseAllEmitters( u32 groupMask, f32 fadeTime = VOX_DEFAULT_FADE_TIME );

	//! Resume all emitters with group matching the group mask
	/*!
		\param groupMask Group mask of the groups to apply the command to
		\param fadeTime Duration of the fade in (seconds)
	*/
	void ResumeAllEmitters( u32 groupMask, f32 fadeTime = VOX_DEFAULT_FADE_TIME );

	
public:

	//
	// Listener methods
	//

	//! Set the master gain for Vox Engine
	/*!
		\param gain Gain to set
		\param fadeTime Duration of the volume transition (seconds)
	*/
	void  SetMasterGain( f32 gain, f32 fadeTime = VOX_DEFAULT_FADE_TIME );

	//! Get the master gain of Vox Engine
	f32 GetMasterGain();

	//! Set the gain for groups
	/*!
		\param groupMask Group mask of the groups to apply the command to
		\param gain Gain to set
		\param fadeTime Duration of the volume transition (seconds)
	*/
	void  SetGroupGain( u32 groupMask, f32 gain, f32 fadeTime = VOX_DEFAULT_FADE_TIME  );

	//! Get the gain of a group
	/*!
		\param groupId <b>Id</b> of the group to query
	*/
	f32 GetGroupGain( s32 groupId ); // Note: it is not a mask here, but the bit position.

	//! Set the listener position
	/*!
		\param x x coordinate of the listener
		\param y y coordinate of the listener
		\param z z coordinate of the listener
	*/
	void Set3DListenerPosition(f32 x, f32 y, f32 z);

	//! Set the listener position
	/*!
		\param x Velocity x component of the listener
		\param y Velocity y component of the listener
		\param z Velocity z component of the listener
	*/
	void Set3DListenerVelocity(f32 x, f32 y, f32 z);

	//! Set the listener position
	/*!
		<b>Note : Look at vector is the vector that goes from the listener to the point it look at.</b>
		\param x_at Look at vector x component of the listener
		\param y_at Look at vector y component of the listener
		\param z_at Look at vector z component of the listener
		\param x_up Up vector x component of the listener
		\param y_up Up vector y component of the listener
		\param z_up Up vector z component of the listener
	*/
	void Set3DListenerOrientation(f32 x_at, f32 y_at, f32 z_at, f32 x_up, f32 y_up, f32 z_up);

	//! Set all listener scalar 3D properties
	/*!
		Allow to set all scalar 3D properties at once.
		\param param Structure containing all the 3D properties to set
	*/
	void Set3DGeneralParameter(const Vox3DGeneralParameters &param);

	//! Set a f32 3D property of the listener
	/*!
		Non-f32 property will be ignored. The following properties can be used with this method:
		<ul>
		<li>k_nDopplerFactor</li>
		<li>k_nSpeedOfSound</li>
		</ul>
		These properties are defined in Vox3DGeneralParameter namespace.
		\param paramId Id of the property to set (see list above) 
		\param floatValue Value to set the property to
	*/
	void Set3DGeneralParameterf( s32 paramId, f32 floatValue );

	//! Set an integer 3D property of an emitter
	/*!
		Non-integer property will be ignored. The following property can be used with this method:
		<ul>
		<li>k_nDistanceModel</li>
		<li>k_nEnhanced3d</li>
		</ul>
		This property is defined in Vox3DGeneralParameter namespace.
		\param paramId Id of the property to set (see list above) 
		\param intValue Value to set the property to
	*/
	void Set3DGeneralParameteri( s32 paramId, s32 intValue );

	//! Get the listener position
	/*!
		\param x x coordinate of the listener
		\param y y coordinate of the listener
		\param z z coordinate of the listener
	*/
	void Get3DListenerPosition(f32 &x, f32 &y, f32 &z);

	//! Get the listener position
	/*!
		\param x Velocity x component of the listener
		\param y Velocity y component of the listener
		\param z Velocity z component of the listener
	*/
	void Get3DListenerVelocity(f32 &x, f32 &y, f32 &z);

	//! Get the listener position
	/*!
		\param x_at Look at x component of the listener
		\param y_at Look at y component of the listener
		\param z_at Look at z component of the listener
		\param x_up Up vector x component of the listener
		\param y_up Up vector y component of the listener
		\param z_up Up vector z component of the listener
	*/
	void Get3DListenerOrientation(f32 &x_at, f32 &y_at, f32 &z_at, f32 &x_up, f32 &y_up, f32 &z_up);

	//! Get all listener scalar 3D properties
	/*!
		Allow to get all scalar 3D properties at once.
		\param param Structure containing all the 3D properties to set
	*/
	void Get3DGeneralParameter(Vox3DGeneralParameters &param);

	//! Get a f32 3D property of the listener
	/*!
		Non-f32 property will be ignored. The following properties can be used with this method:
		<ul>
		<li>k_nDopplerFactor</li>
		<li>k_nSpeedOfSound</li>
		</ul>
		These properties are defined in Vox3DGeneralParameter namespace.
		\param paramId Id of the property to get (see list above) 
		\param floatValue Value to set the property to
	*/
	void Get3DGeneralParameterf( s32 paramId, f32 &floatValue );

	//! Get an integer 3D property of an emitter
	/*!
		Non-integer property will be ignored. The following property can be used with this method:
		<ul>
		<li>k_nDistanceModel</li>
		</ul>
		This property is defined in Vox3DGeneralParameter namespace.
		\param paramId Id of the property to get (see list above) 
		\param intValue Value to set the property to
	*/
	void Get3DGeneralParameteri( s32 paramId, s32 &intValue );

	//
	// DSP - Not available on all driver ...
	//

	//! Set the static bus routing
	/*!
		On driver supporting bus routing, this allow to set the static bus
		routing.  Normally, this should only be called once after initializing
		Vox Audio Engine.
		\param filename Name of the file to load bus routing from
	*/
	void  SetStaticBusRouting(c8* filename);

	//! Set the dynamic bus routing
	/*!
		On driver supporting bus routing, this allow to set the dynamic bus
		routing. This method should be called after the static routing was set.
		When this method is called, any previous dynamic routing will be
		unloaded.  To avoid sound glitches, do not change bus routing will they
		are in use.
		\param filename Name of the file to load bus routing from
	*/
	void  SetDynamicBusRouting(c8* filename);

    //! Set the bus routing volume
	/*!
		On driver supporting bus routing, this allows to set the volume of the bus
		routing. This method allow de modification of the volume on routing
		already set, this doesn't allow the creation of new routing path
		\param busFromName Bus identifier of the bus the routing is from
		\param busToName Bus identifier of the bus the routing is going into
		\param routingType Routing type to modify
		\param dryVolume Volume to set for dry path (ignore if routing type isn't dry)
		\param wetVolume Volume to set for wet path (ignore if routing type isn't wet)
		\param fadeTime Time to fade volume modification
	*/
	void  SetRoutingVolume(c8* busFromName, c8* busToName, VoxDSPGeneralParameter::BusRoutingType routingType, f32 dryVolume, f32 wetVolume, f32 fadeTime = VOX_DEFAULT_FADE_TIME);

	//! Enable or disable a sfx preset
	/*!
		On driver supporting sfx preset, this allows to enable or disable a sfx
		preset dsp chain.
		\param preset Preset id (preset id start at 1)
		\param active Set to true to enable, false to disable
		\param fadeTime Time, in second, to fade the preset
	*/
	void  SetSFXPresetActive(s32 preset, bool active, f32 fadeTime = VOX_DEFAULT_FADE_TIME);

	//! Get current current output mode
	/*!
		Return the current mode of the driver.
		\return Current output mode of the driver
	*/
	VoxOutputMode GetOutputMode();

	//! Set current output mode
	/*!
		Set the current output mode, if the driver support dynamic output
		configuration changes (Only support in CTR HW driver at this moment).
		Even when method return true, output mode change may not occur immediatly.
		\param mode Output mode to set
		\return True is mode is supported and modification is allowed
	*/
	bool SetOutputMode(VoxOutputMode mode);

	//
	// Other
	//

	//! Print all debug info of current engine objects
	/*!
		This call recursively the debug output of all vox objects.  If console is enabled, the result may be incomplete if console entry limit is low or if a lot of objects are active.
	*/
	void PrintDebug();

	void GetDebugInfo(DebugInfo &info);

protected:
	Mutex* m_mutex;

protected:
	bool m_isInitialized;
	static VoxEngine* s_voxEngine;
	static VoxEngineInternal* m_internal;
	
};

//VoxEngine& GetVoxEngine();
//void       DestroyVoxEngine();


} //namespace vox

#endif //_VOX_H_
