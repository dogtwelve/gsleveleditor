#pragma once
#ifndef _VOX_CONSOLE_H_
#define _VOX_CONSOLE_H_

#include "vox_default_config.h"
#include "vox_memory.h"
#include VOX_STRING_INCLUDE
#include VOX_LIST_INCLUDE
#include "vox_mutex.h"
#ifdef __QNXNTO__
#include <stdarg.h>
using std::va_list;
#endif

#ifdef __native_client__
#include <stdarg.h>
#endif

namespace vox
{

struct ConsoleEntry
{
	s32 level;
	VOX_STRING message;
};


//! Console Implementation Interface
/*!
	This class provides the interface for creating a console implementation. An object of a class satisfying
	this interface can be passed as parameter to method Console::GetInstance(ConsoleImplInterface *). The
	Console will then use the object provided as its implementation. The call to GetInstance() must however
	be done before vox initialization otherwise vox's ConsoleImplInterface implementation will be used.
	NOTE: Application is responsible for deleting its own ConsoleImplInterface implementation (if using one).
*/

class ConsoleImplInterface
{
 public:
	virtual ~ConsoleImplInterface(){}

	//! Send a message to be printed to console (may just be put in a queue at this stage)
	/*!
		This method allows sending a message to console.
		\param level Level of message.
		\param str The string to print.
		\param arguments Extra arguments (e.g. may be values replacing the string format tags).
	*/
	virtual void Print(s32 level, const c8* str, va_list arguments)=0;

	//! Flush messages
	/*!
		User interpretation of this method is loose. If a message queue is used in Print() calls,
		then Flush would print the message queue to console.
	*/
	virtual void Flush()=0;
};


//! Vox implementation of ConsoleImplInterface
/*!
	This class is vox's ConsoleImplInterface implementation. This is the default implementation used by the
	Console.
*/

class ConsoleVoxImpl : public ConsoleImplInterface
{
 public:
	ConsoleVoxImpl();
	virtual ~ConsoleVoxImpl();

	//! Send a message to be printed in console.
	/*!
		This method adds the message to a queue that is printed on a Flush() call.
		\param level Message is printed only if its level is lower than or equal to VOX_WARNING_LEVEL.
		\param str The string to print.
		\param arguments Values replacing the string format tags (e.g. a %d or %x).
	*/
	virtual void Print(s32 level, const c8* str, va_list arguments);

	//! Flush (prints) message queue to console
	/*!
		This method prints the message queue to console.
	*/
	virtual void Flush();
 private:
	VOX_LIST<ConsoleEntry, SAllocator<ConsoleEntry> > m_messageQueue;
};


//! Console
/*!
	This class is a singleton used for console printing. Apart from its PrintStatic() method,
	it relies on an implementation of interface ConsoleImplInterface to do its job. The (unique)
	Console class object is obtained through the GetInstance(ConsoleImplInterface *) method. A
	pointer to a (user) console	implementation can be passed as parameter. If no parameter is
	passed (or if parameter	is null), vox's ConsoleImplInterface implementation is used (see
	class ConsoleVoxImpl). In order to use a custom ConsoleImplInterface implementation, one
	must call GetInstance()	before initializing vox. Otherwise, vox's implementation is used.
*/

class Console
{
private:
	Console();

public:
	~Console();

	//! Get the unique instance of a Console
	/*!
		This method provides the unique instance of the Console class. It is thread safe
		when vox is used in a threaded mode.
		\param pImplementation A pointer to a custom implementation of the ConsoleImplInterface interface.
	*/
	static Console* GetInstance(ConsoleImplInterface *pImplementation = 0);

	//! Send a message to console
	/*!
		This method calls the Print() method of the ConsoleImplInterface implementation. It is thread safe
		when vox is used in a threaded mode.
		\param level Level of message.
		\param str The string to print.
		\param arguments Extra arguments (e.g. values replacing the string format tags).
	*/
	void Print(s32 level, const c8* str, ...);

	//! Print a message to console.
	/*!
		This method prints a message to the console. It doesn't use a message queue and the level
		parameter merely appears in the printout (it doesn't impact the fact of printing or not the
		message).
		\param level Level of message. No impact on whether or not the message is printed. 
		\param str The string to print.
		\param arguments Values replacing the string format tags (e.g. a %d or %x).
	*/
	static void PrintStatic(s32 level, const c8* str, ...);

	//! Flush messages
	/*!
		This method calls the Flush() method of the ConsoleImplInterface implementation. It is
		thread safe when vox is used in a threaded mode.
	*/
	void Flush();

private:
	static Console* m_pInstance;
	static Mutex m_mutex;

	static ConsoleImplInterface	*s_pConsoleImplementation;	// Pointer to actual console implementation.
	static bool s_isVoxImplementation;						// True if vox implementation is used.
};

}
#endif
