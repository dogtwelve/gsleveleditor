#pragma once
#ifndef _VOX_DECODER_H_
#define _VOX_DECODER_H_

#include "vox_internal.h"
#include "vox.h"

namespace vox {

class DecoderCursorInterface;
class EmitterObj;
class StreamCursorInterface;

///

class DecoderInterface
{
public:
	virtual ~DecoderInterface(){}
public:
	virtual void Init() {}
	virtual void Shutdown() {}
	virtual DecoderCursorInterface* CreateNewCursor( StreamCursorInterface* pStreamCursor ) = 0;
	virtual void DestroyCursor(DecoderCursorInterface* pDecoderCursor)=0;
	virtual s32 GetType()=0;
	virtual void* GetParam()=0;
};

class DecoderCursorInterface
{
protected:
	DecoderCursorInterface(DecoderInterface* pDecoder, StreamCursorInterface* pStreamCursor ) : 
		m_pDecoder(pDecoder), 
		m_pStreamCursor(pStreamCursor), 
		m_loop(false) {}
public:
	virtual ~DecoderCursorInterface(){}

public:
	virtual void Init() {}
	virtual void Shutdown() {}
	virtual s32  Decode( void* outputBuffer, s32 nbBytes ) = 0;
	virtual s32  DecodeRef( void* &outputBuffer, s32 nbBytes ){ return Decode(outputBuffer, nbBytes);}
	virtual bool HasData()=0;
	virtual void Reset(void){Seek(0);}
	virtual s32	GetRewindLimit(void){return 0;};
	virtual void Rewind(s32 nbBytes){};
	virtual s32  Seek(u32 sampleNum ) = 0;
	virtual void SetLoop(bool loop){m_loop = loop;}

	virtual StreamCursorInterface* GetStreamCursor(){return m_pStreamCursor;}

	virtual bool AllowBufferReference(){ return false; }

	const TrackParams& GetTrackParams() const { return m_trackParams; }
	s32  GetNumChannels() const { return m_trackParams.numChannels; }
	s32  GetSamplingRate() const { return m_trackParams.samplingRate; }
	s32  GetBitsPerSample() const { return m_trackParams.bitsPerSample; }
	s32  GetNumSamples() const { return m_trackParams.numSamples; }

protected:
	TrackParams m_trackParams; // Must be set by derived classes

protected:
	DecoderInterface* m_pDecoder; // TODO: make sure this pointer gets set to 0 if the decoder is deleted. TODO: remove this ptr, use emitter accessor instead?
	StreamCursorInterface* m_pStreamCursor;
	bool m_loop;
	
	friend class DecoderInterface;
};

}

#endif //_VOX_DECODER_H_
