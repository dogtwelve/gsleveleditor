#pragma once
#ifndef _VOX_DRIVER_QSA_H_
#define _VOX_DRIVER_QSA_H_

#include "vox_default_config.h"

#if VOX_DRIVER_USE_QSA && VOX_QSA_DRIVER_PLATFORM

#include "vox_driver_callback_template.h"
#include <sys/asoundlib.h>
#include <pthread.h>

namespace vox {

class DriverQSASource : public DriverCallbackSourceInterface
{
public:
	DriverQSASource(void * trackParam, void* driverParam, u32 sourceId = 0);
	virtual ~DriverQSASource();

	virtual void PrintDebug();
};

class DriverQSA : public DriverCallbackInterface
{
public:
	DriverQSA();
	virtual ~DriverQSA();

	virtual void Init(void* param);
	virtual void Shutdown();

	virtual void Suspend();
	virtual void Resume();	

	virtual void PrintDebug(){}

	virtual DriverSourceInterface* CreateDriverSource(void * trackParam, void* driverParam, s32 priority = 0);
	virtual void DestroyDriverSource(DriverSourceInterface* driverSource);
	
	static void* UpdateThreaded(void* caller);
	void DoCallback();

private:
	virtual void FillBuffer(s16* outBuffer, s32 nbSample);

	void Recover(void);
	s32 GetChannelRate(snd_pcm_channel_info_t *infos);

	snd_pcm_t *m_pcm_handle;
	c8* m_outBuffer;				// Buffer used to write to one fragment.
	s32 m_nbFragments;				// Nb of fragments forming the whole sound buffer.
	s32 m_frag_size;
	s32 m_card;
	s32 m_device;
	bool m_suspended;

	pthread_t m_internThread;
	static bool s_isThreadRunning;

	// Resampling parameters
	s32  m_hwSampleRate;			// Selected device sample rate
	bool m_needResampling;			// True if resampling from driver sources to QSA is needed.
	s16* m_resampleBuffer;
	s32	 m_resampleBufferSize;
	fx1814 m_resamplePos;
	s16  m_prevLeft;
	s16  m_prevRight;
	bool m_needRampIn;
};

};//namespace vox

#endif //VOX_DRIVER_USE_QSA && VOX_QSA_DRIVER_PLATFORM
#endif //_VOX_DRIVER_QSA_H_
