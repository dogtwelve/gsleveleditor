#pragma once
#ifndef _VOX_FILE_SYSTEM_PS3_H_
#define _VOX_FILE_SYSTEM_PS3_H_

#include "vox_default_config.h"

#if defined(_PS3) && !VOX_USE_GLF

#include "vox_filesystem.h"

namespace vox
{

class FileSystemPS3 : public FileSystemInterface
{
public:
	FileSystemPS3();
	virtual ~FileSystemPS3();
};
}

#endif
#endif
