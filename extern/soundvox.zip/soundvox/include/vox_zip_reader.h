#pragma once
#ifndef _VOX_ZIP_READER_H_
#define _VOX_ZIP_READER_H_

#include "vox_default_config.h"
#include "vox_memory.h"

#include VOX_STRING_INCLUDE
#include VOX_MAP_INCLUDE

namespace vox
{

class FileInterface;
const s16 ZIP_INFO_IN_DATA_DESCRITOR =	0x0008;

struct StringComp {
  bool operator() (const VOX_STRING& lhs, const VOX_STRING& rhs) const
  {return lhs<rhs;}
};

namespace os
{

template<typename T, u32 SIZE>
struct SSwap
{
	static T swap(const T& val)
	{
		T tmp;
		u8* dest = (u8*)&tmp;
		u8* src = (u8*)&val;
		for(u32 i = 0; i < SIZE; ++i){
			dest[i] = src[(SIZE - 1) - i];
		}
		return tmp;
	}
};

template<typename T>
T byteswap(const T& v)
{
	return SSwap<T, sizeof(T)>::swap(v);
}

}
#if defined(_MSC_VER) ||  defined(__BORLANDC__) || defined (__BCPLUSPLUS__) 
#	pragma pack( push, packing )
#	pragma pack( 1 )
#	define PACK_STRUCT
#	pragma warning(disable:4103)
#elif defined( __GNUC__ ) || defined(SN_TARGET_PSP2)
#	define PACK_STRUCT	__attribute__((packed))
#elif defined(__MWERKS__)
#	pragma pack(1)
#	define PACK_STRUCT
#elif defined(_NN_CTR)
#	pragma pack(1)
#	define PACK_STRUCT
#else
#	error compiler not supported
#endif

struct SZIPFileDataDescriptor
{
	s32 CRC32;
	s32 CompressedSize;
	s32 UncompressedSize;
} PACK_STRUCT;

struct SZIPFileHeader
{
	s32 Sig;
	s16 VersionToExtract;
	s16 GeneralBitFlag;
	s16 CompressionMethod;
	s16 LastModFileTime;
	s16 LastModFileDate;
	SZIPFileDataDescriptor DataDescriptor;
	s16 FilenameLength;
	s16 ExtraFieldLength;
} PACK_STRUCT;

#if defined(_MSC_VER) ||  defined(__BORLANDC__) || defined (__BCPLUSPLUS__) 
#	pragma pack( pop, packing )
#elif defined(__MWERKS__) 
#	pragma pack(0)
#endif

#undef PACK_STRUCT

struct SZipFileEntry
{
	VOX_STRING zipFileName;
	VOX_STRING simpleFileName;
	VOX_STRING path;
	s32 fileDataPosition; // position of compressed data in file
	SZIPFileHeader header;

	bool operator < (const SZipFileEntry& other) const
	{
		for(u32 i=0; i<simpleFileName.length() && i < other.simpleFileName.length(); ++i)
		{
			s32 diff = simpleFileName[i] - other.simpleFileName[i];
			if ( diff )
				return diff < 0;
		}
		return simpleFileName.length() < other.simpleFileName.length();
	}

	bool operator == (const SZipFileEntry& other) const
	{
		return simpleFileName.compare(other.simpleFileName) == 0;
	}
};

/*
	Zip file Reader written April 2002 by N.Gebhardt.
	Doesn't decompress data, only reads the file and is able to
	open uncompressed entries.
	Modified by A. Belanger June 2010
*/
class CZipReader
{
public:
	CZipReader(const c8* filename, bool ignoreCase, bool ignorePaths);

	virtual ~CZipReader();

	// opens a file by file name
	virtual bool getFileInfo(const c8* filename, s32 &baseOffset, s32 &fileSize);

	// returns the name of the zip file archive
	const c8* getZipFileName() const
	{
		return m_archiveName.c_str();
	}

	s32 getFileCount();

	bool isValid(){return File != 0;};
private:
		
	//! scans for a local header, returns false if there is no more
	//! local file header.
	bool scanLocalHeader();
	FileInterface* File;
	VOX_STRING m_archiveName;

protected:

	//! splits filename from zip file into useful filenames and paths
	void extractFilename(SZipFileEntry* entry);

	//! deletes the path from a filename
	void deletePathFromFilename(VOX_STRING& filename);


	bool IgnoreCase;
	bool IgnorePaths;
	VOX_MAP<VOX_STRING, SZipFileEntry, StringComp, SAllocator<std::pair<const VOX_STRING,SZipFileEntry> > > FileList;
};

}

#endif //_VOX_ZIP_READER_H_
