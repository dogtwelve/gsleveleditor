#pragma once
#ifndef _VOX_DRIVER_CALLBACK_TEMPLATE_H_
#define _VOX_DRIVER_CALLBACK_TEMPLATE_H_

#include "vox_default_config.h"
#include "vox_driver.h"
#include "vox_internal.h"

#include VOX_LIST_INCLUDE
#include VOX_VECTOR_INCLUDE

namespace vox {

#define AU_CHECKSTATUS(X) if(X){VOX_WARNING_LEVEL_1("%s:%d : Error in driver : %d", __FUNCTION__, __LINE__, (s32)X);}

struct DriverBuffer
{
	u8* m_data;
	s32 m_usedSize;			// In bytes.
	s32 m_totalSize;		// In bytes.
	fx1814 m_cursorPos;		// Contains fractional part of cursor position (on the 14 lsb).
	u32 m_cursorOffset;		// Contains integer part of cursor position
	bool free;
};

struct DriverMixingBuffer
{
	s32 m_nbSample;
	s32* m_mixingBuffer;
	DriverMixingBuffer():m_nbSample(0),m_mixingBuffer(0){}
};

struct DriverInternalBuffer
{
	s32 m_size;
	u8* m_buffer;
	DriverInternalBuffer():m_size(0), m_buffer(0){}
};

struct ListenerParameters
{
	VoxVector3f m_position;
	VoxVector3f m_velocity;
	VoxVector3f m_atOrientation;
	VoxVector3f m_upOrientation;
};


struct VoxFilter
{
public:
	VoxFilter();
	void setDistanceShelf(f32 attenuation, f32 sampleRate);
	void setDistanceBandpass(f32 attenuation, f32 cutoff, f32 sampleRate);
	void setNotch(f32 cutoff, f32 gain, f32 bandwidth, f32 sampleRate);
public:
	f32 a0,a1,a2;
	f32 b1,b2;
	f32 x1,x2;
	f32 y1,y2;
	s32 err; // For error diffusion in s32 version

	static inline int clip_s16(float value)
	{
		if(value>32767.f)
			return 32767;
		if(value<-32768.f)
			return -32768;
		return (int)(value+0.5);
	}

	static inline int clip_s32(float value)
	{
		if(value >=  2147483647.f)
		{
			return 0x7fffffff;
		}
		if(value <= -2147483648.f)
		{
			return -0x8000000;
		}

		return (int)(value+0.5);
	}

};

struct VoxFilterInteger
{
	s32 a0,a1,a2;
	s32 b1,b2;
	s32 x1,x2;
	s32 y1,y2;
	s32 err; // For error diffusion in s32 version
};


class DriverCallbackSourceInterface : public DriverSourceInterface
{
public:
	DriverCallbackSourceInterface(void * trackParam, void* driverParam, u32 sourceId = 0);
	virtual ~DriverCallbackSourceInterface();

	virtual void Play();
	virtual void Stop();
	virtual void Pause();
	virtual void Reset();

	virtual s32 GetState();

	virtual long GetByteOffset();
	virtual void SetByteOffset(s32 offset);

	virtual bool NeedData();
	virtual void UploadData(void* soundData, s32 bufferSize);

	virtual void SetGain(f32 gain);
	virtual void SetPitch(f32 pitch);
	virtual f32 GetGain();
	virtual f32 GetPitch();
	
	virtual void Set3DParameter(s32 paramId, void* param);
	virtual void Update(f32 dt);

	virtual bool AllowBufferReference(){return true;}

	virtual s32 GetBufferCount(){return m_numBuffer;}

	virtual void FreeDisposableData(s32 maxNbBytes, s32 &nbBuffersFreed, s32 &nbBytesFreed);

	virtual void PrintDebug()=0;

	virtual void FillBuffer(s32* buffer, s32 nbSample);

	static void Set3DParameters(ListenerParameters listenerParameters, Vox3DGeneralParameters parameters3D);
	static void SetDriverSampleRate(s32 sampleRate);
	static void SetDriverCallbackPeriod(f32 period);	// In seconds

	// This flag is set in DriverCallbackInterface::Init(void* param)
	static bool enableNeon;

	static u32 s_enable3dSimulation;
	bool m_enable3dSimulation;
#if VOX_NEON_MIXER
	static bool DetectNeon();
#endif

protected:
	static s32		s_driverSampleRate;
	static fx1814	s_driverCallbackPeriod;
	
	fx1814		m_averageDt;
	Mutex		m_mutex;
	fx1814		m_dataPitch;
	TrackParams	m_trackParams;

	virtual void Init();
	virtual void Cleanup();
protected:

	void FreeAllBuffer();

	void FillBufferMono8(s32* buffer, s32 nbSample){};
	void FillBufferStereo8(s32* buffer, s32 nbSample){};
	void FillBufferMono16(s32* buffer, s32 nbSample);
	void FillBufferStereo16(s32* buffer, s32 nbSample);
	void FillBufferMono8NoInter(s32* buffer, s32 nbSample){};
	void FillBufferStereo8NoInter(s32* buffer, s32 nbSample){};
	void FillBufferMono16NoInter(s32* buffer, s32 nbSample);
	void FillBufferStereo16NoInter(s32* buffer, s32 nbSample);

#if VOX_ENHANCED_3D
	void FillBufferMono16Biquad(s32* buffer, s32 nbSample);
#endif

#if VOX_NEON_MIXER
	void FillBufferNeonStereo16NoInter(s16* data, s32* buffer, int length, s32 volume_left, s32 volume_right, s32 ramp_left, s32 ramp_right);
	void FillBufferNeonMono16NoInter(s16* data, s32* buffer, int length, s32 volume_left, s32 volume_right, s32 ramp_left, s32 ramp_right);
	void FillBufferNeonStereo16(s16* data_buffer, unsigned int data_index, unsigned int data_delta, s32* buffer, int length, s32 volume_left, s32 volume_right, s32 ramp_left, s32 ramp_right);
	void FillBufferNeonMono16(s16* data_buffer, unsigned int data_index, unsigned int data_delta, s32* buffer, int length, s32 volume_left, s32 volume_right, s32 ramp_left, s32 ramp_right);
#if VOX_ENHANCED_3D
	void FillBufferNeonMono16Biquad(s16* data_buffer, unsigned int data_index, unsigned int data_delta, s32* buffer, int length, s32 volume_left, s32 volume_right, s32 ramp_left, s32 ramp_right);
#endif

#endif

	// Methods to calculate source volume attenuation (induced by distance and propagation direction), stereo panning and doppler pitch shift.
	fx1814 GetDirectionalGain(void);
	fx1814 GetDistanceGain(void);
	fx1814 GetDopplerPitch(void);
	void GetStereoPanning(fx1814 *leftPan, fx1814 *rightPan);
	void GetNormalizedPosition(f32 *resultX, f32 *resultY, f32 *resultZ);

	s32 GetNbAvailableSamples(s32 nbSamplesNeeded);
	s32 GetWorkData(u8* outbuf, s32 nbBytes, fx1814 nbSamples);

	// Ramping parameters
	s32 m_nominalRampLength;		// In samples (constant length in time).
	bool m_isFirstBufferFilled;		// True after first buffer is filled. Prevents ramping on initial Play().

	fx1814 m_gain;
	fx1814 m_previousLeftGain;
	fx1814 m_previousRightGain;
	
	fx1814 m_userPitch;				// Desired user pitch.
	fx1814 m_effectiveUserPitch;	// Effective user pitch during current callback.
	fx1814 m_deltaPitch;			// Step used in pitch ramping (between callbacks).
	fx1814 m_effectivePitch;		// Combination of user, data, doppler and ramping pitches.

	s32 m_numBuffer;
	s32 m_currentWriteBuffer;
	s32 m_currentReadBuffer;

	s32 m_state;
	s32 m_sourceId;
	s32 m_processedBytes;

	s32 m_bytesPerSample;			// To avoid calculating it every time.

	//PolyFilterResampler m_filter;

	//buffers ...
	VOX_VECTOR<DriverBuffer, SAllocator<DriverBuffer> > m_bufferList;

	// Listener and general 3D and doppler parameters
	static ListenerParameters	s_listenerParameters;
	static u32					s_distanceModel;
	static f32					s_dopplerFactor;			
	static f32					s_alteredSpeedOfSound;		// = speedOfSound / dopplerFactor
	
	// 3D and doppler parameters (per source)
	VoxVector3f	m_position;
	VoxVector3f	m_velocity;
	VoxVector3f	m_direction;
	s32			m_relativeToListener;
	f32			m_maxDistance;
	f32			m_referenceDistance;
	f32			m_rolloffFactor;
	f32			m_innerConeAngle;
	f32			m_outerConeAngle;
	f32			m_outerConeGain;
	f32			m_cullingDistance;
	fx1814		m_dopplerPitch;			// To avoid calculating it twice.


	// VOX_ENHANCED_3D parameters and counters
#if VOX_ENHANCED_3D
	VoxFilter m_filter[4]; 
	int m_leftSideDelay;
	short m_delayBuffer[128];
	int m_delayWriteCounter;
	int m_delayReadCounter;
#endif

};

class DriverCallbackInterface : public DriverInterface
{
public:
	DriverCallbackInterface();
	virtual ~DriverCallbackInterface();

	virtual void Init(void* param);
	virtual void Shutdown()=0;

	virtual void Suspend()=0;
	virtual void Resume()=0;	

	virtual void Set3DParameter(s32 paramId, void* param);

	virtual void PrintDebug()=0;

	virtual DriverSourceInterface* CreateDriverSource(void * trackParam, void* driverParam, s32 priority = 0)=0;
	virtual void DestroyDriverSource(DriverSourceInterface* driverSource)=0;

	static DriverInternalBuffer* GetWorkBuffer(int size);
protected:
	// Static buffers shared for mixing/interpolation
	static DriverInternalBuffer	m_sWorkBuffer;			//shared buffer for source interpolation
	static DriverMixingBuffer	m_sMixingBuffer;

	Mutex m_mutex;
	bool m_audioUnitActive;
	s32 m_nextSourceId;
	VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> > m_activeSources;

	void SetDefaultParameter();
	virtual void FillBuffer(s16* outBuffer, s32 nbSample);
	void _FillBuffer(s16* outBuffer, s32 nbSample);

private:
	void _Set3DParameter(s32 paramId, void* param);

	// Listener and general 3D parameters
	Vox3DGeneralParameters	m_3DGeneralParameters;
	ListenerParameters		m_listener;
};

};//namespace vox

#endif // _VOX_DRIVER_CALLBACK_TEMPLATE_H_
