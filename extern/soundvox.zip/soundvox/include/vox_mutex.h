#pragma once
#ifndef _VOX_MUTEX_H_
#define _VOX_MUTEX_H_

#include "vox_default_config.h"
#include "vox_types.h"

#if VOX_USE_GLF
#include <glf/core/mutex.h>
typedef glf::Mutex* voxMutexType;
#elif defined(_PS3)
#include <sys/synchronization.h>
#include <sys/timer.h>
#define voxMutexType sys_lwmutex_t
#elif defined(SN_TARGET_PSP2)
#include <kernel.h>
typedef SceUID voxMutexType;
#elif defined(_WIN32)
#if VOX_DEBUG_SERVER_ENABLE
#define _WINSOCKAPI_
#endif
#include <windows.h>
typedef HANDLE voxMutexType;
#elif VOX_USE_PTHREAD
#include <pthread.h>
typedef pthread_mutex_t voxMutexType;
#elif defined(_NN_CTR)
#include <nn/os.h>
#	ifdef VOX_THREADING_MODE_NONE
#define VOX_USE_LIGHT_MUTEX 1
#	else
#define VOX_USE_LIGHT_MUTEX 0
#	endif
#	if VOX_USE_LIGHT_MUTEX
typedef nn::os::LightSemaphore* voxMutexType;
#	else
typedef nn::os::Mutex* voxMutexType;
#	endif
#else // Dummy impl
typedef int voxMutexType;
#endif

namespace vox {

class Mutex
{
public:
	Mutex();
	Mutex(const Mutex &mutex);
	~Mutex();

public:
	void Lock();
	void Unlock();
	bool TryLock();

private:
	volatile voxMutexType m_mutex;
#if defined(_NN_CTR)
	int m_lockCount;
#elif defined(SN_TARGET_PSP2)
	SceKernelLwMutexWork m_mutexWorkArea __attribute__((aligned (8)));
#endif
};

struct ScopeMutex
{
	ScopeMutex(vox::Mutex* mutex):m(mutex){m->Lock();}
	~ScopeMutex()
	{
		m->Unlock();
	}
	
	Mutex* m;
};

}

namespace vox
{

class AccessController
{
public:
	AccessController():m_readers(0), m_writers(0){}
	~AccessController(){m_mutex.Unlock();}
	
	void GetReadAccess();
	void ReleaseReadAccess();
	void GetWriteAccess();
	void ReleaseWriteAccess();

private:
	s32 m_readers;
	s32 m_writers;
	Mutex m_mutex;
};

}

#endif //_VOX_MUTEX_H_
