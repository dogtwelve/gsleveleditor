#pragma once
#ifndef _VOX_INTERNAL_H_
#define _VOX_INTERNAL_H_

#include "vox_default_config.h"
#include "vox_mutex.h"
#include "vox.h"

#include "vox_decoder.h"
#include "vox_stream.h"

#include "vox_driver.h"

#include "vox_debug_server.h"

#include VOX_VECTOR_INCLUDE
#include VOX_LIST_INCLUDE
#if VOX_USE_HANDLABLE_MAP
#include VOX_MAP_INCLUDE
#endif

void* VoxAlloc(size_t size, const char* filename, const char* function, int line);
void* VoxAlloc(size_t size);
void* VoxAlloc(size_t size, const int memhint, const char* filename, const char* function, int line);
void* VoxAlloc(size_t size, const int memhint);
void VoxFree(void* ptr);
extern "C" void* VoxAlloc_c(size_t size, const char* filename, const char* function, int line);
extern "C" void VoxFree_c(void* ptr);

namespace vox {

class DataObj;
class EmitterObj;
class DataHandle;
class EmitterHandle;
class Mutex;
class DecoderCursorInterface;
class Handlable;
class HandleContainer;
struct BusRoutingChange;
	
class Fader
{
public:
	Fader():m_startValue(0.0f), m_endValue(1.0f), m_time(0.0f), m_totalTime(0.0f), m_done(true){}
	~Fader(){}
	Fader(f32 startValue, f32 endValue, f32 time):m_startValue(startValue), m_endValue(endValue), m_time(0.0f), m_totalTime(time), m_done(false){}

	void  Update(f32 dt){m_time < m_totalTime ? m_time += dt : m_done = true;}
	f32 GetStartValue(){return m_startValue;}
	f32 GetEndValue(){return m_endValue;}
	f32 GetCurrentValue(){return (m_time < m_totalTime ? (m_totalTime > 0.0f ? (m_startValue + (m_endValue - m_startValue) * m_time / m_totalTime) : m_startValue) : m_endValue);}
	//bool  IsFinished(){return (m_totalTime <= 0.0f) || (m_time >= m_totalTime);}
	bool  IsFinished(){return m_done;}
	float GetRemainingTime(){return m_totalTime - m_time;}
private:
	f32 m_startValue;
	f32 m_endValue;
	f32 m_time;
	f32 m_totalTime;
	bool m_done;
};

///
///
///

class Handlable
{
public:
	virtual ~Handlable(){}
protected:
	Handlable(): m_id(-1), m_refCount(0){}
	Handlable(HandleId id): m_id(id), m_refCount(0){}

public:
	HandleId GetId()const {return m_id;}

	void SetTimeStampGroup(u32 timeStampGroup){m_tsGroup = timeStampGroup;}
	u32 GetTimeStampGroup(){return m_tsGroup;}
protected:
	virtual void Retain();
	virtual void Release();

protected:
	HandleId m_id;
	s32 m_refCount;
	u32 m_tsGroup;

	VOX_MUTEX_LEVEL_1(Mutex m_mutex;)

	friend class HandlableContainer;
	friend class VoxEngineInternal;
	friend class VoxEngine;
};

#if VOX_USE_HANDLABLE_MAP
struct HandleIdCompStruct {
  bool operator() (const HandleId& lhs, const HandleId& rhs) const
  {return lhs<rhs;}
};
#ifdef _IPHONE_OS
#import <Availability.h>
#import <TargetConditionals.h>
#endif
#if TARGET_IPHONE_SIMULATOR && !defined(__IPHONE_4_0)
	typedef VOX_MAP<HandleId, Handlable*, HandleIdCompStruct, SAllocator<std::pair<const HandleId,Handlable*> > > HandlableVector;
#else
	typedef VOX_MAP<HandleId, Handlable*, HandleIdCompStruct, SAllocator<std::pair<HandleId,Handlable*> > > HandlableVector;
#endif
typedef HandlableVector::iterator HandlableContainerIterator;
#else
typedef VOX_LIST<Handlable*, SAllocator<Handlable*> > HandlableVector;
typedef HandlableVector::iterator HandlableContainerIterator;
#endif

///
///
///

class HandlableContainer
{
protected:
	HandlableContainer():m_nextId(1){}
	~HandlableContainer();

	void Add(Handlable* pElement);
	Handlable* Find(HandleId id);
	void Erase(HandleId id);
	void Clear();
	void EmptyContainer(){list.clear();} //doesn't delete element, just clear container
	Handlable* Detach(HandleId id);
	s32 Size()const{return list.size();}
	
	void Merge(HandlableContainer* toMerge);

	HandleId GetFreeHandleId();

	HandlableContainerIterator begin();
	HandlableContainerIterator end();

private:
	HandlableVector list;
	HandleId m_nextId;

	friend class VoxEngine;
	friend class VoxEngineInternal;
#ifdef _IPHONE_OS
	friend class VoxIphoneInternal;
#endif
};

///
///
///

typedef VOX_LIST<HandleId, SAllocator<HandleId> > EmitterInternalList;

namespace DataSource
{
	enum
	{
		STATE_ERROR = -1,
		STATE_READY = 0,
		STATE_INITIAL,
		STATE_LOADING_STATIC,
		STATE_CONVERTING,
		STATE_DYING
	};
};

class DataObj : public Handlable
{
public:
	virtual ~DataObj(){}
protected:
	DataObj(HandleId id, StreamInterface* pStream, DecoderInterface* pDecoder, s32 groupId = k_nVoxGroupId_default, s32 priorityBank = 0) : 		
		Handlable(id),
		m_groupId(groupId),
		m_priorityBank(priorityBank),
		m_uid(-1),
		m_pStream(pStream),
		m_pDecoder(pDecoder),
		m_isUpdating(false),
		m_needToDie(false),
		m_state(DataSource::STATE_INITIAL)
	{}

	DataObj(HandleId id, StreamInterface* pStream, DecoderInterface* pDecoder, s32 groupId = k_nVoxGroupId_default, VoxSourceLoadingFlags loadingFlags = vox::k_nNone, s32 priorityBank = 0) : 		
		Handlable(id),
		m_groupId(groupId),
		m_priorityBank(priorityBank),
		m_uid(-1),
		m_pStream(pStream),
		m_pDecoder(pDecoder),
		m_isUpdating(false),
		m_needToDie(false),
		m_state(DataSource::STATE_CONVERTING),
		m_loadingFlags(loadingFlags)
	{}

	DataObj(HandleId id, StreamInterface* pStream, DecoderInterface* pDecoder, const TrackParams &trackParams, s32 groupId = k_nVoxGroupId_default, s32 priorityBank = 0) : 		
		Handlable(id),
		m_groupId(groupId),
		m_priorityBank(priorityBank),
		m_uid(-1),
		m_trackParams(trackParams),
		m_pStream(pStream),
		m_pDecoder(pDecoder),	
		m_isUpdating(false),
		m_needToDie(false),
		m_state(DataSource::STATE_READY)
	{}
protected:
	void Update();
	
protected:
	StreamInterface*  GetStream() { return m_state == DataSource::STATE_READY ? m_pStream : 0;}
	DecoderInterface* GetDecoder() { return m_state == DataSource::STATE_READY ? m_pDecoder : 0;}

	StreamInterface*  GetStreamEx() { return m_pStream;}
	DecoderInterface* GetDecoderEx() { return m_pDecoder;}

	void RegisterEmitter(HandleId hid);
	void UnregisterEmitter(HandleId hid);
	EmitterInternalList* GetRegisteredEmitters(){return &m_currentEmitters;}

	s32 GetGroup();
	bool IsGroup(u32 groupMask);

	s32 GetPriorityBank(){return m_priorityBank;}
	void SetPriorityBank(s32 priorityBank){m_priorityBank = priorityBank;}

	void SetUid(s32 Uid){m_uid = Uid;}
	s32 GetUid(){return m_uid;}

	void NeedToDie();//mutex
	bool ShouldDie();
	
	void SetUpdating(bool needUpdate = true){m_isUpdating = needUpdate;}
	bool IsUpdating(){return m_isUpdating;}

	bool IsReady();
	f32 GetDuration();

	void SetUserData(DataHandleUserData &data);
	DataHandleUserData GetUserData();

	void PrintDebug();
	void GetDebugInfo(DebugChunk_dataSource &info);

	TrackParams GetTrackParams() const {return m_trackParams;}

protected:
	s32 m_groupId;
	s32 m_priorityBank;
	s32 m_uid;

	TrackParams m_trackParams;
	StreamInterface*  m_pStream;
	DecoderInterface* m_pDecoder;
	EmitterInternalList m_currentEmitters;

	DataHandleUserData m_userData;

	bool m_isUpdating;
	bool m_needToDie;
	s32 m_state;
	VoxSourceLoadingFlags m_loadingFlags;

	VOX_MUTEX_LEVEL_1(Mutex m_stateMutex;)

	friend class VoxEngine;
	friend class VoxEngineInternal;
	friend class DataHandle;
	friend class EmitterObj;
};

typedef HandlableContainer DataObjList;

///

struct VoxVector3f
{
	f32 x, y, z;
	VoxVector3f():x(0), y(0), z(0){}
	VoxVector3f(f32 _x, f32 _y, f32 _z):x(_x), y(_y), z(_z){}
	VoxVector3f(f32* fv):x(fv[0]), y(fv[1]), z(fv[2]){}
	void ToArray(f32* fv){fv[0]=x;fv[1]=y;fv[2]=z;}
};

class EmitterObj : public Handlable
{
protected:
	EmitterObj(HandleId id, s32 priority, s32 priorityBank, s32 bufferSize, DriverSourceInterface* phwSourceInterface, DecoderCursorInterface* pDecoderCursor, DataObj* pDataSource);
	EmitterObj(HandleId id, s32 priority, s32 priorityBank/*, s32 bufferSize*/, DriverSourceInterface* phwSourceInterface/*, DecoderCursorInterface* pDecoderCursor*/, DataObj* pDataSource);
public:
	virtual ~EmitterObj();

	void CleanUp();

protected:
	bool LoadAsync();

	void SetDefaultParameters();

	DataObj* GetDataSource() { return m_pDataSource; }
	//StreamCursorInterface*  GetStreamCursor() { return m_pStreamCursor; }
	DecoderCursorInterface* GetDecoderCursor() { return m_pDecoderCursor; }
	DriverSourceInterface* GetDriverSource() { return m_phwSource; }

	void Update(f32 dt); //mutex

	s32 GetGroup();
	void SetGroup(s32 groupId);
	bool IsGroup(u32 groupMask);

	s32 GetPriority(){return m_priority;}
	void SetPriority(s32 priority){m_priority = priority;} //mutex?

	s32 GetPriorityBank(){return m_priorityBank;}
	void SetPriorityBank(s32 priorityBank){m_priorityBank = priorityBank;} //mutex ?

	bool IsInPriorityBank(){return m_isInBank;}
	void SetInPriorityBank(bool inBank){m_isInBank = inBank;}

	f32 GetGain();//mutex
	void SetGain(f32 gain, f32 fadeTime = 0.f);//mutex
	void SetGainModifier(f32 gainModifier);

	f32 GetPitch();//mutex
	void SetPitch(f32 pitch, f32 fadeTime = 0.f);//mutex

	s32 GetState();//mutex
	void SetState(s32 state);//mutex
	void Play(f32 fadeIn = 0.0f);
	void Stop(f32 fadeOut = 0.0f);
	void Pause(f32 fadeOut = 0.0f);
	void Resume(f32 fadeIn = 0.0f);

	bool GetLoop();//mutex
	void SetLoop(bool loop);//mutex

	void Reset();//mutex

	void SetUserData(EmitterHandleUserData &data);
	EmitterHandleUserData GetUserData();

	void SetInteractiveMusicStateChange(const char *stateLabel);

	bool  IsReady();
	bool  IsAlive();
	bool  IsPlaying();
	bool  IsDone();
	u32 GetStatus();

	f32 GetPlayCursor();
	void  SetPlayCursor(f32 time);

	void SetAutoKillAfterDone(bool autokill);//mutex
	void NeedToDie();//mutex
	bool ShouldDie();//mutex

	//3D
	void Set3DParameteri(s32 parameterId, s32 intValue);
	void Set3DParameterf(s32 parameterId, f32 floatValue);
	void Set3DParameter3f(s32 parameterId, f32 floatValue_0, f32 floatValue_1, f32 floatValue_2);
	void Set3DParameterfv(s32 parameterId, const VoxVector3f &vector);

	void Get3DParameteri(s32 parameterId, s32 &intValue);
	void Get3DParameterf(s32 parameterId, f32 &floatValue);
	void Get3DParameter3f(s32 parameterId, f32 &floatValue_0, f32 &floatValue_1, f32 &floatValue_2);
	void Get3DParameterfv(s32 parameterId, VoxVector3f &vector);

	void Update3D();

	//DSP
	void SetDSPParameter(s32 parameterId, void* param);
	void UpdateDSP(f32 dt);

	// Callback
	void RegisterStateChangedCallback(VoxEmitterStateChangedCallbackFunc callback, void* userData);
	void UnregisterStateChangedCallback();
	bool NeedToSendStateChangedCallback(VoxEmitterStateChangedCallbackFunc &callback, void* &userData, EmitterExternState &state);

private:

	bool  _IsDone();

	bool m_needLoad;
	s32 m_bytesPerSecond;
	s32 m_bytesPerLoop;

	s32 m_groupId;

	s32 m_priority;
	s32 m_priorityBank;
	bool m_isInBank;

	f32 m_gain;
	f32 m_desiredGain;
	f32 m_baseGain;
	f32 m_gainModifier;
	Fader m_baseGainFader;
	Fader m_playbackFader;

	f32 m_pitch;
	f32 m_desiredPitch;
	Fader m_pitchFader;

	bool m_loop;
	bool m_desiredLoop;

	s32   m_currentState;
	s32   m_desiredState;
	bool  m_stateChanged;

	bool m_resetSource;

	//3D
	VoxVector3f m_position;
	VoxVector3f m_direction;
	VoxVector3f m_velocity;
	Vox3DEmitterParameters m_3Dparameters;
	bool m_3DNeedUpdate[Vox3DEmitterParameter::k_nCount];

	//DSP	
	c8* m_currentBus;
	c8* m_desiredBus;

	VOX_VECTOR<u8*, SAllocator<u8*> > m_pSndBuffer;
	s32 m_bufferId;
	s32 m_bufferQty;
	s32 m_bufferSize;
	s32 m_bufferPosition;

	DriverSourceInterface* m_phwSource;
	DecoderCursorInterface* m_pDecoderCursor;
	DataObj* m_pDataSource;

	bool m_needToDie;
	bool m_autoKill;

	Fader m_fader;

	EmitterHandleUserData m_userData;

	// Callback

	VoxEmitterStateChangedCallbackFunc m_stateChangedCallback;
	void* m_stateChangedCallbackUserData;

	s32 m_decoderType;

	// Interactive music (i.e. vxn native format) parameters
	bool m_hasNativeStateChanged;
	bool m_resetOnNativeStateChange;		// True when transition occurs while sound is not playing.
	char m_nativeStateLabel[32];			// Native state label provided on transition call.

	//Other
	void PrintDebug();
	void GetDebugInfo(DebugChunk_emitter &info);
	void ProcessNativeData(f32 dt);
	void ProcessNonNativeData(f32 dt);

	friend class VoxEngine;
	friend class VoxEngineInternal;
	friend class DecoderCursorInterface;
	friend class EmitterHandle;
	friend class PriorityBankManager;
#ifdef _IPHONE_OS
	friend class VoxIphoneInternal;
#endif	
};

typedef HandlableContainer EmitterObjList;

///

struct PriorityBankElement
{
	PriorityBankElement():m_pEmitter(0){}
	PriorityBankElement(EmitterObj* pEmitter, s32 priority):
		m_pEmitter(pEmitter),
		m_priority(priority)
	{}

	EmitterObj* m_pEmitter;
	s32 m_priority;
};

struct PriorityBank
{
	PriorityBank():
		m_threshold(-(s32)2147483647), 
		m_maxplayback(2147483647), 
		m_behavior(k_nDoNothing)
	{}

	PriorityBank(s32 threshold, s32 maxplayback, PriorityBankBehavior behavior):
		m_threshold(threshold), 
		m_maxplayback(maxplayback), 
		m_behavior(behavior)
	{
		m_bankElements.reserve(maxplayback);
	}

	~PriorityBank()
	{
		m_bankElements.clear();
	}

	s32 m_threshold;
	s32 m_maxplayback;
	PriorityBankBehavior m_behavior;
	VOX_VECTOR<PriorityBankElement, SAllocator<PriorityBankElement> > m_bankElements;
};

class PriorityBankManager
{
public:
	PriorityBankManager();
	PriorityBankManager(s32 size);
	~PriorityBankManager()
	{
		m_banks.clear();
	}

	s32 AddPriorityBank(s32 threshold, s32 maxplayback, PriorityBankBehavior behavior);
	bool SetPriorityBank(s32 bankId, s32 threshold, s32 maxplayback, PriorityBankBehavior behavior);

	bool AddEmitter(s32 bankId, EmitterObj* m_pEmitter); 
	bool RemoveEmitter(s32 bankId, EmitterObj* m_pEmitter);
	bool CanAddEmitter(s32 bankId, s32 priority);

	void Update();

	void GetDebugInfo(DebugChunk_bank* info);

private:
	bool _CanAddEmitter(s32 bankId, s32 priority);

	s32 m_bankQty;
	VOX_VECTOR<PriorityBank, SAllocator<PriorityBank> > m_banks;
	VOX_MUTEX_LEVEL_1(Mutex m_mutex;)
};

///

class VoxCallback
{
public:	
	VoxCallback(){}
	virtual ~VoxCallback(){}

	virtual void Send()=0;
};

class VoxEmitterStateChangedCallback : public VoxCallback
{
public:
	VoxEmitterStateChangedCallback( EmitterHandle handle, VoxEmitterStateChangedCallbackFunc callback, void* userData, EmitterExternState state)
	:m_handle(handle)
	,m_callback(callback)
	,m_userData(userData)
	,m_state(state)
	{}

	virtual ~VoxEmitterStateChangedCallback(){}

	virtual void Send()
	{
		if(m_callback)
			m_callback(m_handle, m_userData, m_state);
	}

private:
	EmitterHandle m_handle;
	VoxEmitterStateChangedCallbackFunc m_callback;
	void* m_userData;
	EmitterExternState m_state;
};

class VoxCallbackManager
{
public:
	VoxCallbackManager(){}
	~VoxCallbackManager();

	void Add(VoxCallback* callback);
	void SendAll();

private:
	VOX_LIST<VoxCallback*, SAllocator<VoxCallback*> > m_callbackList;
};

///
class VoxEngineInternal
{
protected:
	static VoxEngineInternal* GetVoxEngineInternal();
public:
	virtual ~VoxEngineInternal();

protected:
	VoxEngineInternal();

protected:

	virtual void Initialize();

// Interruptions //

	virtual void Suspend();
	virtual void Resume();
	virtual bool IsSuspended();

// Data Sources //

	virtual void UpdateSources();

	DataObj*    GetDataObject( DataHandle& handle );
	DataObj*	DetachDataObject( HandleId dataObjId );
	void DecreaseDataObjectRefCount( DataHandle& handle );
	void IncreaseDataObjectRefCount( DataHandle& handle );
	s32 GetAllDataSources( DataHandle* handlesBuffer, s32 bufferCount );

	HandleId GetFreeDataObjectId();

	DataHandle LoadDataSource( s32 streamType, void* streamParams, s32 decoderType, void* decoderParams, s32 groupId );
	DataHandle LoadDataSourceAsync( s32 streamType, void* streamParams, s32 decoderType, void* decoderParams, s32 groupId, VoxSourceLoadingFlags loadingFlags );
	DataHandle ConvertToRawSource(DataHandle &handle );
	DataHandle ConvertToRamBufferSource(DataHandle &handle );

	void SetUserData( DataHandle &handle, DataHandleUserData &data);
	DataHandleUserData GetUserData( DataHandle &handle);

	void SetPriorityBankId( DataHandle &handle, s32 bankId);
	void SetUid( DataHandle &handle, s32 Uid);
	s32 GetUid( DataHandle &handle);

	void ReleaseDatasource( DataObj* dataSource );
	void ReleaseDatasource( DataHandle &handle );
	void ReleaseDatasource( u32 groupMask );
	void _ReleaseAllDatasource();

	bool IsReady( DataHandle &handle );
	bool IsValid( DataHandle &handle );
	f32 GetDuration( DataHandle &handle );

	s32  GetEmitterHandles( DataHandle &handle, EmitterHandle* handlesBuffer, s32 bufferCount );

	DataObjList    m_dataObjects;
	DataObjList    m_dataObjectsToAdd;
	VOX_VECTOR<DataObj*, SAllocator<DataObj*> > m_dyingDataSource;
	AccessController m_sourcesAccessController;
	AccessController m_dataObjToAddAccessController;

	VOX_LIST<DataObj*, SAllocator<DataObj*> > m_dataSourceToUpdate;
	VOX_MUTEX_LEVEL_1(Mutex m_dataSourceToUpdateMutex;)

// Emitters //

	virtual void UpdateEmitters(f32 dt);
	void RegisterForEmitterStateChangeNotification( EmitterHandle &handle, VoxEmitterStateChangedCallbackFunc callback, void* userData);
	void UnregisterForEmitterStateChangeNotification( EmitterHandle &handle);

	EmitterObj* GetEmitterObject( EmitterHandle& handle );
	EmitterObj* DetachEmitterObject( HandleId emitterId );

	void DecreaseEmitterObjectRefCount( EmitterHandle& handle );
	void IncreaseEmitterObjectRefCount( EmitterHandle& handle );
	s32 GetAllEmitters( EmitterHandle* handlesBuffer, s32 bufferCount );
	DataHandle GetData(EmitterHandle &handle);

	HandleId GetFreeEmitterObjectId();

	EmitterHandle CreateEmitter( DataHandle &handle, s32 priority = 0, void* driverParam = 0 );
	EmitterHandle CreateEmitterAsync( DataHandle &handle, s32 priority = 0, void* driverParam = 0 );
	
	void SetUserData( EmitterHandle &handle, EmitterHandleUserData &data);
	EmitterHandleUserData GetUserData( EmitterHandle &handle);

	virtual void KillEmitter( EmitterObj* emitter );
	void KillEmitter( EmitterHandle &handle );

	// Emitter controls //

	void  SetAutoKillAfterDone( EmitterHandle &handle, bool kill = false );
	void  SetGain( EmitterHandle &handle, f32 gain = 1.0f, f32 fadeTime = 0.0f);
	void  SetLoop( EmitterHandle &handle, bool loop = false );
	void  SetPitch( EmitterHandle &handle, f32 pitch = 1.0f, f32 fadeTime = 0.0f );
	void  SetGroup( EmitterHandle &handle, s32 groupId = k_nVoxGroupId_default );
	void  SetPlayCursor( EmitterHandle &handle, f32 time = 0.0f );

	s32   GetGroup( EmitterHandle &handle );
	f32	  GetPlayCursor( EmitterHandle &handle );
	f32   GetGain( EmitterHandle &handle );
	f32   GetPitch( EmitterHandle &handle );

	void SetPriority( EmitterHandle &handle, s32 priority);
	s32  GetPriority( EmitterHandle &handle);

	//3D
	void  Set3DEmitterPosition( EmitterHandle &handle, f32 x, f32 y, f32 z );
	void  Set3DEmitterVelocity( EmitterHandle &handle, f32 x, f32 y, f32 z );
	void  Set3DEmitterDirection( EmitterHandle &handle, f32 x, f32 y, f32 z );
	void  Set3DEmitterParameters( EmitterHandle &handle, const Vox3DEmitterParameters &param );
	void  Set3DEmitterParameterf( EmitterHandle &handle, s32 paramId, f32 value );
	void  Set3DEmitterParameteri( EmitterHandle &handle, s32 paramId, s32 value );

	void  Get3DEmitterPosition( EmitterHandle &handle, f32 &x, f32 &y, f32 &z );
	void  Get3DEmitterVelocity( EmitterHandle &handle, f32 &x, f32 &y, f32 &z );
	void  Get3DEmitterDirection( EmitterHandle &handle, f32 &x, f32 &y, f32 &z );
	void  Get3DEmitterParameters( EmitterHandle &handle, Vox3DEmitterParameters &param );
	void  Get3DEmitterParameterf( EmitterHandle &handle, s32 paramId, f32 &value );
	void  Get3DEmitterParameteri( EmitterHandle &handle, s32 paramId, s32 &value );

	// DSP
	void  SetDSPEmitterParameter( EmitterHandle &handle, s32 paramId, void* param );

	void SetInteractiveMusicState(EmitterHandle &handle, const char *stateLabel);

	bool  IsReady( EmitterHandle &handle );
	bool  IsValid( EmitterHandle &handle );
	bool  IsAlive( EmitterHandle &handle );
	bool  IsPlaying( EmitterHandle &handle );
	bool  IsDone( EmitterHandle &handle );
	u32 GetStatus( EmitterHandle &handle );

	void  Play( EmitterObj* pEmitter, bool loop = false, f32 fadeTime = 0.0f );
	void  Stop( EmitterObj* pEmitter, f32 fadeTime = 0.0f );
	void  Pause( EmitterObj* pEmitter, f32 fadeTime = 0.0f );
	void  Resume( EmitterObj* pEmitter, f32 fadeTime = 0.0f );

	void  Play( EmitterHandle &handle, bool loop = false, f32 fadeTime = 0.0f );
	void  Stop( EmitterHandle &handle, f32 fadeTime = 0.0f );
	void  Pause( EmitterHandle &handle, f32 fadeTime = 0.0f );
	void  Resume( EmitterHandle &handle, f32 fadeTime = 0.0f );

	// Emitter group controls //

	virtual void  SetGroupGain( u32 groupMask, f32 gain, f32 fadeTime = 0.0f  );
	f32 GetGroupGain( s32 groupId );

	void PlayAllEmitters( u32 groupMask, f32 fadeTime = 0.0f );
	void StopAllEmitters( u32 groupMask, f32 fadeTime = 0.0f );
	void PauseAllEmitters( u32 groupMask, f32 fadeTime = 0.0f );
	void ResumeAllEmitters( u32 groupMask, f32 fadeTime = 0.0f );

	// Priority banks //
	bool SetPriorityBank(s32 bankId, s32 threshold, s32 maxplayback, PriorityBankBehavior behavior);

	// Global //

	virtual void  SetMasterGain( f32 gain, f32 fadeTime = 0.0f );
	f32 GetMasterGain();

	EmitterObjList m_emitterObjects;
	EmitterObjList m_emitterObjectsToAdd;
	VOX_VECTOR<EmitterObj*, SAllocator<EmitterObj*> > m_dyingEmitter;
	AccessController m_emittersAccessController;
	AccessController m_emittersToAddAccessController;
	
	PriorityBankManager* m_pPriorityBankMgr;

	Fader m_masterGainFader;
	Fader m_groupGainFader[k_nVoxGroupId_max];
	f32 m_groupGainModifier[k_nVoxGroupId_max];

	VOX_MUTEX_LEVEL_1(Mutex m_mutex;)
// Listener //

	//3D
	void Set3DListenerPosition(f32 x, f32 y, f32 z);
	void Set3DListenerVelocity(f32 x, f32 y, f32 z);
	void Set3DListenerOrientation(f32 x_at, f32 y_at, f32 z_at, f32 x_up, f32 y_up, f32 z_up);
	void Set3DGeneralParameter(const Vox3DGeneralParameters &param);
	void Set3DGeneralParameterf( s32 paramId, f32 value );
	void Set3DGeneralParameteri( s32 paramId, s32 value );

	void Get3DListenerPosition(f32 &x, f32 &y, f32 &z);
	void Get3DListenerVelocity(f32 &x, f32 &y, f32 &z);
	void Get3DListenerOrientation(f32 &x_at, f32 &y_at, f32 &z_at, f32 &x_up, f32 &y_up, f32 &z_up);
	void Get3DGeneralParameter(Vox3DGeneralParameters &param);
	void Get3DGeneralParameterf( s32 paramId, f32 &value );
	void Get3DGeneralParameteri( s32 paramId, s32 &value );

	void _SetDefault3DParameters();
	void Update3D();

	VoxVector3f m_position;
	VoxVector3f m_velocity;
	VoxVector3f m_lookAt;
	VoxVector3f m_upVector;
	Vox3DGeneralParameters m_3Dparameters;
	bool m_3DNeedUpdate[Vox3DGeneralParameter::k_nCount];

// DSP //
	void  SetStaticBusRouting(c8* filename);
	void  SetDynamicBusRouting(c8* filename);
	void  SetRoutingVolume(c8* busFromName, c8* busToName, VoxDSPGeneralParameter::BusRoutingType routingType, f32 dryVolume, f32 wetVolume, f32 fadeTime);
	void  SetSFXPresetActive(s32 preset, bool active, f32 fadeTime);

	void UpdateDSP(f32 dt);

	VOX_LIST<BusRoutingChange*, SAllocator<BusRoutingChange*> > m_busRoutingChanges;


// General //

	VoxOutputMode GetOutputMode();
	bool SetOutputMode(VoxOutputMode mode);

	// Register a game-specific stream type factory.
	// The id is returned ( >= k_nStreamTypeCount ).
	s32  RegisterStreamType( StreamTypeFactoryFnPtr );
	
	// Register a game-specific decoder type factory.
	// The id is returned ( >= k_nDecoderTypeCount ).	
	s32  RegisterDecoderType( DecoderTypeFactoryFnPtr );

	StreamTypeFactoryFnPtr  m_streamTypes[ VOX_MAX_STREAM_TYPES ];
	s32                     m_streamTypeCount;
	
	DecoderTypeFactoryFnPtr m_decoderTypes[ VOX_MAX_DECODER_TYPES ];
	s32                     m_decoderTypeCount;
	
	DriverInterface* m_hwDriver;

	static VoxEngineInternal* s_voxEngineInternal; 

	u32 m_timeStamps[VOX_NB_TIMESTAMP_GROUP];
	u32 m_nextTimeStamp;

#if VOX_ENABLE_EMITTER_STATE_CHANGED_CALLBACK
	// Callbacks
	VoxCallbackManager m_callbackManager;
#endif

	// Interruptions
	volatile s32 m_suspendCount;

// Other //

	DebugServer* m_debugServer;	
	s32 m_debugRate;

	void PrintDebug();
	void UpdateDebugServer();
	void GetDebugInfo(DebugInfo &info);

	friend class VoxEngine;
	friend class DataHandle;
	friend class EmitterHandle;
};

} //namespace vox

#endif //_VOX_INTERNAL_H_
