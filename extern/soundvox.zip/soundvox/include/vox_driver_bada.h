#pragma once
#ifndef _VOX_DRIVER_BADA_H_
#define _VOX_DRIVER_BADA_H_

#include "vox_default_config.h"

#if VOX_DRIVER_USE_BADA && VOX_BADA_DRIVER_PLATFORM

#include "vox_driver_callback_template.h"
#include "vox_internal.h"

#include <FMedia.h>						// Access to AudioOut, IAudioOutEventListener

using namespace Osp::Media;				// TODO : See if we should keep namespaces
using namespace Osp::Base;
using namespace Osp::Base::Collection;


namespace vox {

class DriverBada;

class AudioOutListener : public IAudioOutEventListener
{
 public:
    void OnAudioOutBufferEndReached(void);
    void OnAudioOutErrorOccurred(result r);
	void OnAudioOutInterrupted(void);
	void OnAudioOutReleased(void);
	void SetDriver(DriverBada *pDriver);
 private:
	DriverBada *m_pBadaDriver;
};




class DriverBadaSource : public DriverCallbackSourceInterface
{
 public:
	DriverBadaSource(void * trackParam, void* driverParam, u32 sourceId = 0);
	virtual ~DriverBadaSource();

	virtual void PrintDebug();
};

class DriverBada : public DriverCallbackInterface
{
 public:
	DriverBada();
	virtual ~DriverBada();

	virtual void Init(void* param);
	virtual void Shutdown();

	virtual void Suspend();
	virtual void Resume();

	virtual void PrintDebug();

	virtual DriverSourceInterface* CreateDriverSource(void * trackParam, void* driverParam, s32 priority = 0);
	virtual void DestroyDriverSource(DriverSourceInterface* driverSource);

	void Update(void);	// Method called by AudioOutListener when a buffer has been read.

 private:

	AudioOut			m_audioOut;
	AudioOutListener	m_audioOutListener;	// Listens for events upon the AudioOut object (e.g. end of buffer).
	s16 				*m_pDataArray;		// Intermediate buffer (between m_sMixingBuffer and m_pWriteBuffer).
	ByteBuffer 			m_writeBuffer;		// Buffer used to provide samples to AudioOut object.
};

};//namespace vox

#endif //VOX_DRIVER_USE_BADA && VOX_BADA_DRIVER_PLATFORM
#endif //_VOX_DRIVER_BADA_H_
