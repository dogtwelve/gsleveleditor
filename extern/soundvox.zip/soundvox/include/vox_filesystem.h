#pragma once
#ifndef _VOX_FILE_SYSTEM_H_
#define _VOX_FILE_SYSTEM_H_

#include "vox_default_config.h"
#include "vox_types.h"
#include "vox_memory.h"
#include VOX_LIST_INCLUDE
#include VOX_STRING_INCLUDE

namespace vox
{
class FileSystemInterface;
class CZipReader;
extern FileSystemInterface* VoxNewFileSystem();

enum VoxFileType
{
	k_nNormalFile,
	k_nLimitedFile
};

enum VoxFileSeekOrigin
{
	k_nSeekSet,
	k_nSeekCur,
	k_nSeekEnd
};

enum VoxFileAccessMode
{
	k_nRead,
	k_nCreateWrite,
	k_nAppend,
	k_nReadWrite,
	k_nCreateReadWrite,
	k_nReadAndAppend,
	k_nReadBinary,
	k_nCreateWriteBinary,
	k_nAppendBinary,
	k_nReadWriteBinary,
	k_nCreateReadWriteBinary,
	k_nReadAndAppendBinary
};

struct IOFunc {

	IOFunc():read(0), write(0), seek(0), tell(0), open(0), close(0){}

    /// Reads size bytes of data into buffer at ptr.
	s32 (*read) ( void * ptr, s32 size, s32 count, void * stream );

	s32 (*write) ( const void * ptr, s32 size, s32 count, void * stream );

    /// Seeks to byte position offset.
	s32 (*seek) ( void * stream, s32 offset, VoxFileSeekOrigin origin );

    /// Returns the current byte offset in the stream.
	s32 (*tell) ( void * stream );

	void* (*open) ( const c8 * filename, VoxFileAccessMode mode );

	s32 (*close) ( void * stream );
};

class FileInterface
{
public:
	FileInterface():m_filePtr(0), m_type(k_nNormalFile){}
	FileInterface(void* filePtr, const char* fullpath):m_filePtr(filePtr), m_type(k_nNormalFile)
	{
		if(fullpath)
			m_filePath = fullpath;
	}

	virtual ~FileInterface(){}

	virtual s32 Read(void* dest, s32 size, s32 count);
	virtual s32 Seek(s32 offset, VoxFileSeekOrigin origin);
	virtual s32 Tell();
	virtual s32 Write(const void * dest, s32 size, s32 count);

	virtual const char* GetFilePath(){return m_filePath.c_str();}

	virtual void* GetFilePtr(){return m_filePtr;}

protected:
	VOX_STRING m_filePath;
	void* m_filePtr;
	VoxFileType m_type;
};

// read-only scoped file
class FileLimited : public FileInterface
{
public:
	FileLimited();
	FileLimited(void* filePtr, const char* fullpath, s32 baseOffset, s32 fileSize);
	virtual ~FileLimited(){}

	virtual s32 Read(void* dest, s32 size, s32 count);
	virtual s32 Seek(s32 offset, VoxFileSeekOrigin origin);
	virtual s32 Tell();
	virtual s32 Write(const void * dest, s32 size, s32 count){return 0;}

protected:
	s32 m_baseOffset;
	s32 m_fileSize;
	s32 m_filePosition;
};

class FileSystemInterface
{
public:
	static FileSystemInterface* GetInstance();
	static void DestroyInstance();
	virtual ~FileSystemInterface();

	virtual FileInterface* OpenFile(c8* filename, VoxFileAccessMode mode = k_nReadBinary);
	virtual s32 CloseFile(FileInterface* fileInterface);

	virtual s32 SetArchive(const c8* zipfilename, bool ignoreCase, bool ignorePath, bool tryArchiveFirst);

	virtual s32 PushDirectory(c8* directory);
	virtual s32 PopDirectory();

	static s32 GetDirectory(c8* dest, s32 size, c8* fullPath);

	static IOFunc m_IOFunc;

protected:
	FileSystemInterface():m_archiveFirst(false), m_archive(0){};

	static FileSystemInterface* m_instance;

protected:
	bool m_archiveFirst;
#if !defined(_NN_CTR)
	CZipReader* m_archive;
#else
	void* m_archive;
#endif

	VOX_LIST<VOX_STRING, SAllocator<VOX_STRING> > m_directoriesStack;
};
}

#endif
