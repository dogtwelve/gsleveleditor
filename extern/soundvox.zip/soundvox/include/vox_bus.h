#pragma once
#ifndef _VOX_BUS_H_
#define _VOX_BUS_H_

#include "vox.h"
#include "vox_internal.h"
#include "vox_default_config.h"
#include "vox_types.h"
#include "vox_dsp.h"

#include VOX_LIST_INCLUDE

namespace vox
{
//Defines
#define BUS_MASTER		CELL_MS_MASTER_BUS
#define BUS_COMP_APPLY	CELL_MS_SUBBUS_14
#define BUS_COMP_CALC	CELL_MS_SUBBUS_15
#define BUS_FILTER_LFE  CELL_MS_SUBBUS_31
#define BUS_SFX1		CELL_MS_SUBBUS_30
#define BUS_SFX2		CELL_MS_SUBBUS_29
#define BUS_SFX3		CELL_MS_SUBBUS_28

#define VRF_VERSION 2
#define VRT_VERSION 2

enum BusIds
{
	k_nBusIdPresetSFX	= -2,
	k_nBusIdInvalid		= -1
};

namespace VoxBusDomain
{
	enum
	{
		k_nUnknown = -1,
		k_nFrequencyDomain,
		k_nTimeDomain
	};
};

struct BusRoutingChange
{
	BusRoutingChange(c8* busFromName, c8* busToName, VoxDSPGeneralParameter::BusRoutingType routingType, f32 dryVolume, f32 wetVolume, f32 fadeTime);
	~BusRoutingChange();

	c8* BusFrom;
	c8* BusTo;
	VoxDSPGeneralParameter::BusRoutingType RoutingType;
	f32 DryVolume;
	f32 WetVolume;
	f32 FadeTime;
};

struct BusRoutingChangeInternal
{
	BusRoutingChangeInternal(s32 busTo, VoxDSPGeneralParameter::BusRoutingType routingType, Fader dryVolume, Fader wetVolume):
		BusTo(busTo), RoutingType(routingType), DryVolume(dryVolume), WetVolume(wetVolume){}

	s32 BusTo;
	VoxDSPGeneralParameter::BusRoutingType RoutingType;
	Fader DryVolume;
	Fader WetVolume;
};

class BusOutput
{
public:
	BusOutput(c8* name, f32 volumeDry, f32 volumeWet);
	~BusOutput();

	c8* GetName(){return m_name;}
	f32 GetVolumeDry(){return m_volumeDry;}
	f32 GetVolumeWet(){return m_volumeWet;}

private:
	c8* m_name;
	f32 m_volumeDry;
	f32 m_volumeWet;
};

namespace VoxBusType
{
	enum
	{
		k_nMandatory,
		k_nStatic,
		k_nDynamic
	};
}

class BusManager;

class Bus
{
public:
	Bus();
	virtual ~Bus();

	virtual s32 Load(void *data, DSPManager* pDSPMgr, BusManager* pBusMgr);
	virtual void Unload();

	s32 GetBusId(){return m_busId;}
	c8* GetName(){return m_name;}
	s32 AttachBusOutput(BusManager* pBusMgr);

	void Update(f32 dt);
	void SetBusRoutingVolumeChange(BusRoutingChange* busRoutingChange);

protected:
	c8* m_name;
	DSP* m_dsp[8];
	f32 m_volumeDry[64];
	f32 m_volumeWet[64];

	s32 m_busId;
	s32 m_domain;

	s32 m_type;

	VOX_LIST<BusOutput*, SAllocator<BusOutput*> > m_busOutputs;
	VOX_LIST<BusRoutingChangeInternal*, SAllocator<BusRoutingChangeInternal*> > m_volumeFader;
};

class BusMaster : public Bus
{
public:
	BusMaster();
	virtual ~BusMaster();

	virtual s32 Load(void *data, DSPManager* pDSPMgr, BusManager* pBusMgr);
};

class BusFilterLFE : public Bus
{
public:
	BusFilterLFE();
	virtual ~BusFilterLFE();

	virtual s32 Load(void *data, DSPManager* pDSPMgr, BusManager* pBusMgr);
};

class BusCompressorCalc : public Bus
{
public:
	BusCompressorCalc();
	virtual ~BusCompressorCalc();

	virtual s32 Load(void *data, DSPManager* pDSPMgr, BusManager* pBusMgr);
};

class BusCompressorApply : public Bus
{
public:
	BusCompressorApply();
	virtual ~BusCompressorApply();

	virtual s32 Load(void *data, DSPManager* pDSPMgr, BusManager* pBusMgr);
};

class BusManager
{
public:
	static BusManager* GetInstance();
	static void Destroy();
	~BusManager();

	void Init();

	s32 ReserveBusId(s32 domain);
	void ReleaseBusId(s32 busId);

	s32 GetBusId(char* busName);

	s32 LoadFixedBuses();
	s32 LoadVRT(char* vrtfile);
	s32 LoadVRF(char* vrffile);

	s32 UnloadVRF();
	s32 UnloadVRT();

	void SetBusRoutingVolumeChange(BusRoutingChange* busRoutingChange);

	void Update(f32 dt);

private:
	BusManager();

	void AttachBusOutputs(VOX_LIST<Bus*, SAllocator<Bus*> > busesList);

	bool m_revervedBuses[32];

	VOX_LIST<Bus*, SAllocator<Bus*> > m_fixedBuses;
	VOX_LIST<Bus*, SAllocator<Bus*> > m_staticBuses;
	VOX_LIST<Bus*, SAllocator<Bus*> > m_dynamicBuses;

	DSPManager* m_pDSPMgr;

	static BusManager* m_instance;

	s32 m_timeDomainBusStart;
};

}
#endif
