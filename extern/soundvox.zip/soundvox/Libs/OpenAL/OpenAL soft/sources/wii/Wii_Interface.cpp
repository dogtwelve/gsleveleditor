#include "Wii_Interface.h"
#include <math.h>
#include <cstring>


// **************************************************************************************** //
// ********************************* PlatformVoice class ********************************** //
// **************************************************************************************** //

ALfloat PlatformVoice::s_pOutputVolumes[AL_NB_OUTPUTS] = {1.0f, 1.0f, 1.0f, 1.0f, 1.0f};
ALshort	PlatformVoice::s_totalWiimoteConnections = 0;
ALshort	PlatformVoice::s_pNbWiimotePlayingVoices[WPAD_MAX_CONTROLLERS];	
ALshort	PlatformVoice::s_pWiimoteBuffer[WIIMOTE_NB_SAMPLES_BUFFER];
ALubyte	PlatformVoice::s_pWiimoteEncodedData[WIIMOTE_ENCODED_DATA_SIZE];
ALuint	PlatformVoice::s_wiimoteEncodeFlag[WPAD_MAX_CONTROLLERS];
WENCInfo PlatformVoice::s_pWiimoteEncodeInfos[WPAD_MAX_CONTROLLERS];
ALboolean PlatformVoice::s_isWiimoteUpdated = AL_FALSE;


PlatformVoice::PlatformVoice(ALshort voiceID)
{	
	m_voiceID = voiceID;
	m_pVoiceBlock = NULL;
			
	// Buffer parameters
	m_bufferSize = VOICE_BUFFER_SIZE;
	m_bufferSizeBytes = VOICE_BUFFER_SIZE * sizeof(ALshort);
	m_bufferToFillIndex = SECOND_BUFFER;
			
	// Set the maximal pitch so that DSP sample transfer is such that 'm_pPlaybackBuffer'
	// cannot be unaccessible to filling.	
	m_pitchUpperLimit = (ALfloat) VOICE_BUFFER_SIZE / (ALfloat) NOMINAL_DSP_SAMPLE_TRANSFER / 2.0f;
	if(m_pitchUpperLimit > MAXIMAL_PITCH)
	{
		m_pitchUpperLimit = MAXIMAL_PITCH;
	}	
	
	// Set the minimal pitch so that DSP sample transfer is at least 8 samples.
	//m_pitchLowerLimit = 8.0f / (ALfloat) NOMINAL_DSP_SAMPLE_TRANSFER;
	
	// Set the minimal pitch to the AX min pitch from documentation.
	m_pitchLowerLimit = 1.0f / 512.0f;
	
	// Playback state parameters
	m_playbackState = PLAYBACK_STATE_NONE;
	
	// Position parameters
	m_position.m_x = 0.0f;
	m_position.m_y = 0.0f;
	m_position.m_z = 0.0f;
	
	// Volume parameters
	m_currentVolume = 0;
	m_currentGain = 0.0f;
	
	// Create voice playback buffer and fill it with zeroes.
	ALuint totalSizeBytes = m_bufferSizeBytes * DOUBLE_BUFFER;
	m_pPlaybackBuffer = alnew ALchar[totalSizeBytes];			
	std::memset(m_pPlaybackBuffer, 0, totalSizeBytes);	
	DCFlushRange(m_pPlaybackBuffer, totalSizeBytes);
	
	// Acquire a voice from the AX interface.
	Acquire();
	
	// Set speaker parameters (Wii speakers by default)	
	m_nbActiveWiimoteChannels = 0;
	
	// Set the wiimote speakers Off.
	for(ALshort i = 0; i < WPAD_MAX_CONTROLLERS; i++)
	{
		m_pOutputsStates[i] = AL_OUTPUT_OFF;
	}
		
	AXSetVoiceRmtOn(m_pVoiceBlock, AX_PB_REMOTE_OFF);
	
	// Set the normal Wii speakers ON.
	m_pOutputsStates[AL_OUTPUT_PRIMARY] = AL_OUTPUT_ON;
	
	m_wiiMixing = alnew AXPBMIX();
	std::memset(m_wiiMixing, 0, sizeof(AXPBMIX));
	m_wiimoteMixing = alnew AXPBRMTMIX();
	std::memset(m_wiimoteMixing, 0, sizeof(AXPBRMTMIX));
}
	


PlatformVoice::~PlatformVoice(void)
{
	aldelete m_wiiMixing;
	aldelete m_wiimoteMixing;	
	aldelete [] m_pPlaybackBuffer;
}



void PlatformVoice::Clean(void)
{
	MIXQuit();
	AXQuit();
}



// Method 'CloseOutput()' is used to turn the wiimote speaker off for channel 'outputID'.
// Possible return values are WPAD_ERR_NONE (= 0), WPAD_ERR_NO_CONTROLLER (= -1) or
// WPAD_ERR_BUSY (= -2)

ALint PlatformVoice::CloseOutput(ALshort outputID)
{
	ALint result = WPAD_ERR_NONE;
		
	if((outputID >= WPAD_CHAN0) && (outputID < WPAD_MAX_CONTROLLERS))
	{			
			WPADControlSpeaker(outputID, WPAD_SPEAKER_MUTE, NULL);
			result = WPADControlSpeaker(outputID, WPAD_SPEAKER_OFF, NULL);			
	}
	return(result);	
}	



// Method 'EnableOutputUpdates()' is used to enable or disable wiimote sounds updates
// (which are done through method UpdateWiimoteSounds()).

void PlatformVoice::EnableOutputUpdates(ALboolean enable)
{
	s_isWiimoteUpdated = enable;
}



// Method 'GetBufferToFill()' returns the address of the half of the double buffer
// that needs to be filled. NULL is returned if none of the two halves need to be
// filled at the time of the call.

void *PlatformVoice::GetBufferToFill(void)
{	 	
 	if(m_playbackState == PLAYBACK_STATE_PLAYING)
 	{
 		ALuint cursorPosition = (ALuint)(m_pVoiceBlock->pb.addr.currentAddressHi << 16) |
 				 			 	(ALuint)(m_pVoiceBlock->pb.addr.currentAddressLo);
 		
		if((m_bufferToFillIndex == FIRST_BUFFER) && (cursorPosition >= m_halfAddress))			     
    	{       
    		return((void *)m_pPlaybackBuffer);    	
    	}     
		else if((m_bufferToFillIndex == SECOND_BUFFER) && (cursorPosition >= m_startAddress) &&
				(cursorPosition < m_halfAddress))
    	{     	
    		return((void *) (m_pPlaybackBuffer + m_bufferSizeBytes));
    	}
    }
    
    return(NULL);
}



ALuint PlatformVoice::GetNbSamplesNeeded(void)
{
	return(m_bufferSize);
}



ALuint PlatformVoice::GetPlaybackState(void)
{	
 	return(m_playbackState);
}



void PlatformVoice::Init(void)
{   
	AIInit(NULL);
	AXInit();
	MIXInit();
		
	// Initialize WPAD if not already done.
	if(WPADGetStatus() != WPAD_STATE_SETUP)
	{	
		// TODO : See if necessary (Robert Houde)
		//		WPADInit();	
		// End TODO	
    }
		
	// Wiimote playback parameters.	
	for(ALshort i = 0; i < WPAD_MAX_CONTROLLERS; i++)
	{								
		s_pNbWiimotePlayingVoices[i] = 0;
	}					
			
	std::memset(s_pWiimoteBuffer, 0, WIIMOTE_NB_SAMPLES_BUFFER << 1);
	s_totalWiimoteConnections = 0;
}



ALboolean PlatformVoice::IsOutputOpen(ALshort outputID)
{
	return(WPADIsSpeakerEnabled(outputID));
}



// Method 'OpenOutput()' is used to turn the wiimote speaker ON for channel 'outputID'.
// Possible return values are WPAD_ERR_NONE (= 0), WPAD_ERR_NO_CONTROLLER (= -1) or
// WPAD_ERR_BUSY (= -2).

ALint PlatformVoice::OpenOutput(ALshort outputID)
{
	ALint result = WPAD_ERR_NONE;
	
	if((outputID >= WPAD_CHAN0) && (outputID < WPAD_MAX_CONTROLLERS))
	{				
			s_wiimoteEncodeFlag[outputID] = (u32) WENC_FLAG_FIRST;
			result = WPADControlSpeaker(outputID, WPAD_SPEAKER_ON, WiimoteOnCallback);
			s_isWiimoteUpdated = AL_TRUE;		
	}
	return(result);
}



void PlatformVoice::Pause(void)
{	
	// Stop the cursor from moving.
	AXSetVoiceState(m_pVoiceBlock, AX_PB_STATE_STOP);
			
	// Stop voice calculations for wiimote.
	AXSetVoiceRmtOn(m_pVoiceBlock, AX_PB_REMOTE_OFF);
		
	// Stop voice playback
	m_playbackState = PLAYBACK_STATE_PAUSED;
}



// Method 'Play()' starts the playback of AX voice. If the voice must play
// on a wiimote, it also activates the amplifier of the correponding speaker.

void PlatformVoice::Play(void)
{			
	if(m_playbackState != PLAYBACK_STATE_PLAYING)
	{					
		for(ALshort k = 0; k < WPAD_MAX_CONTROLLERS; k++)
		{					
			// If voice must play on a wiimote, unmute the corresponding speaker.				
			if(m_pOutputsStates[k] >= AL_OUTPUT_ON)
			{			
				if(WPADIsSpeakerEnabled(k))
				{	
					WPADControlSpeaker(k, WPAD_SPEAKER_MUTE_OFF, NULL);	
				}
				// Update voice/wiimote connections only if voice output state is not greater
				// than AL_OUTPUT_ON = 1 to avoid counting the same voice twice.
				if(m_pOutputsStates[k] == AL_OUTPUT_ON)
				{
					s_pNbWiimotePlayingVoices[k]++;
					s_totalWiimoteConnections++;
				}					
			}
		}
		
		// Start voice calculations for wiimote if some channels are active.
		if(m_nbActiveWiimoteChannels > 0)		
		{				
			AXSetVoiceRmtOn(m_pVoiceBlock, AX_PB_REMOTE_ON);			
		}
		
		// Start the AX voice buffer cursor and fill the second buffer.		
		AXSetVoiceState(m_pVoiceBlock, AX_PB_STATE_RUN);
		
		m_playbackState = PLAYBACK_STATE_PLAYING;
	}		
}



void PlatformVoice::Reset(void)
{			
	m_playbackState = PLAYBACK_STATE_NONE;
	
	// Set the cursor position to the half of the first buffer (to minimize latency)
	// and set the second buffer to be filled.		
    AXSetVoiceCurrentAddr(m_pVoiceBlock, m_cursorStart);    	
	m_bufferToFillIndex = SECOND_BUFFER;
	
	// Playback state parameters
	m_playbackState = PLAYBACK_STATE_NONE;

	// Position parameters
	m_position.m_x = 0.0f;
	m_position.m_y = 0.0f;
	m_position.m_z = 0.0f;	
	
	// Volume parameters
	m_currentVolume = 0;
	m_currentGain = 0.0f;
	
	// Set speaker parameters (Wii speakers by default)	
	m_nbActiveWiimoteChannels = 0;
	
	// Set the wiimote speakers Off.
	for(ALshort i = 0; i < WPAD_MAX_CONTROLLERS; i++)
	{
		m_pOutputsStates[i] = AL_OUTPUT_OFF;
	}
		
	AXSetVoiceRmtOn(m_pVoiceBlock, AX_PB_REMOTE_OFF);
	
	// Set the normal Wii speakers ON.
	m_pOutputsStates[AL_OUTPUT_PRIMARY] = AL_OUTPUT_ON;	
}
	


// Method 'SetOutputMasterVolume()' sets the master volume of the output (either
// primary speakers or wiimote speakers) provided by 'outputID'.

void PlatformVoice::SetOutputMasterVolume(ALshort outputID, ALfloat volume)
{
	if((outputID >= WPAD_CHAN0) && (outputID < AL_NB_OUTPUTS))
	{
		// Put limits on volume.			
		if(volume > 1.0f)
		{
			volume = 1.0f;
		}
		else if(volume < 0.0f)
		{
			volume = 0.0f;
		}
		s_pOutputVolumes[outputID] = volume;
	}
}
	


// Method 'SetOutputState()' activates (state = AL_OUTPUT_ON) or desactivate
// (state = AL_OUTPUT_OFF) output on either primary or wiimote speakers for voice with
// index 'voiceID'. It also registers how many voices are active on each output. If
// the are no active outputs on a wiimote channel, it turns that particular channel OFF.
// TODO : Complete description for global parameters.

void PlatformVoice::SetOutputState(ALshort outputID, ALshort state)
{		
	if(state == AL_OUTPUT_OFF && m_pOutputsStates[outputID] != AL_OUTPUT_OFF)
	{
		m_pOutputsStates[outputID] = AL_OUTPUT_OFF;
		
		// Verify if output is a Wiimote channel.
		if((outputID >= WPAD_CHAN0) && (outputID < WPAD_MAX_CONTROLLERS))
		{
			// Update the number of active Wiimote channels for the current voice.			
			m_nbActiveWiimoteChannels--;		
		
			// Update number of voices on wiimote channel 'outputID'.
			if(m_playbackState == PLAYBACK_STATE_PLAYING)
			{
				s_pNbWiimotePlayingVoices[outputID]--;
				s_totalWiimoteConnections--;
					
				// If no voice uses a wiimote channel, mute the associated wiimote speaker.
				if(s_pNbWiimotePlayingVoices[outputID] == 0)
				{								
					if(WPADIsSpeakerEnabled(outputID))
					{
						WPADControlSpeaker(outputID, WPAD_SPEAKER_MUTE, NULL);																					
					}
				}
			}
				
			// Activate of desactivate voice calculations for Wiimote.
			if(m_nbActiveWiimoteChannels == 0)
			{
				AXSetVoiceRmtOn(m_pVoiceBlock, AX_PB_REMOTE_OFF);
			}			
		}
	}
	else if(state == AL_OUTPUT_ON)
	{			
		if(m_pOutputsStates[outputID] == AL_OUTPUT_OFF)
		{						
			m_pOutputsStates[outputID]++;
			
			// Verify if output is a Wiimote channel.
			if((outputID >= WPAD_CHAN0) && (outputID < WPAD_MAX_CONTROLLERS))
			{
				// Update the number of active Wiimote channels for the current voice.
				m_nbActiveWiimoteChannels++;
		
				// Activate of desactivate voice calculations for Wiimote.			
				if(m_playbackState == PLAYBACK_STATE_PLAYING)
				{
					if(m_pOutputsStates[outputID] == AL_OUTPUT_ON)
					{
						s_pNbWiimotePlayingVoices[outputID]++;
						s_totalWiimoteConnections++;
					}
					if(WPADIsSpeakerEnabled(outputID))
					{						
						WPADControlSpeaker(outputID, WPAD_SPEAKER_MUTE_OFF, NULL);	
					}
					AXSetVoiceRmtOn(m_pVoiceBlock, AX_PB_REMOTE_ON);
				}		
			}
		}
		else
		{
			m_pOutputsStates[outputID]++;
		}			
	}
}



// Method 'SetPitch()' is indirectly called every 3ms via a callback mechanism.

void PlatformVoice::SetPitch(ALfloat pitch)
{							
	// Pitch cannot be changed when a voice is paused or stopped. It is however automatically
	// changed by a call from SourceVoiceLinks::PlaySource() when playback starts.
	if(m_playbackState == PLAYBACK_STATE_PLAYING)
	{				
		// Limit pitch within acceptable bounds.
		if(pitch > m_pitchUpperLimit)
		{
			pitch = m_pitchUpperLimit;		
		}	
		else if(pitch < m_pitchLowerLimit)
		{
			pitch = m_pitchLowerLimit;	
		}
		
		m_currentPitch = pitch;						
		AXSetVoiceSrcRatio(m_pVoiceBlock, m_currentPitch);		
	}
}



// Method 'SetPosition()' sets voice panning according to the position received in parameter.
// The method is called each 3ms by a callback mechanism.

void PlatformVoice::SetPosition(ALposition *position)
{	
	// Position cannot be changed when a voice is paused or stopped. It is however automatically
	// changed by a call from SourceVoiceLinks::PlaySource() when playback starts.
	if(m_playbackState == PLAYBACK_STATE_PLAYING)
	{
		m_position.m_x = position->m_x;
		m_position.m_y = position->m_y;
		m_position.m_z = position->m_z;
	
		if(m_pOutputsStates[WPAD_MAX_CONTROLLERS] >= AL_OUTPUT_ON)
		{
			if(m_position.m_x < 0.0f)
			{
				ALfloat absolute_x = -m_position.m_x;
				ALfloat panLeft = absolute_x * VOICE_PAN_FACTOR + SQRT_2_INVERSE;
				ALfloat panRight = std::sqrt(1.0f - panLeft * panLeft);

				m_wiiMixing->vL = (ALushort) (panLeft * SIDE_PAN_LIMIT);
				m_wiiMixing->vR = (ALushort) (panRight * SIDE_PAN_LIMIT);
			}
			else if(m_position.m_x > 0.0f)
			{
				ALfloat panRight = m_position.m_x * VOICE_PAN_FACTOR + SQRT_2_INVERSE;
				ALfloat panLeft = std::sqrt(1.0f - panRight * panRight);				
				
				m_wiiMixing->vL = (ALushort) (panLeft * SIDE_PAN_LIMIT);
				m_wiiMixing->vR = (ALushort) (panRight * SIDE_PAN_LIMIT);		
			}
	
			else // m_pPosition.m_x = 0.0f
			{			
				// Set volumes so that a single mono channel has the same power than
				// two stereo channels.
				m_wiiMixing->vL = CENTER_PAN_VALUE;
				m_wiiMixing->vR = CENTER_PAN_VALUE;
			
			}
		}
		else // Wii normal speakers are OFF, mute them.						
		{
			// Mute Wii speakers.
			m_wiiMixing->vL = 0;
			m_wiiMixing->vR = 0;
		}	
    	
		AXSetVoiceMix(m_pVoiceBlock, m_wiiMixing);	// See NOTE 2 at the end of file.		
	}
}



// Method 'SetVolume()' is (indirectly) called through a callback function and
// does a voice volume update with ramping (fade IN or fade OUT) done through
// the volume envelope property of AX voices. The current volume (i.e. before update)
// is set directly in the AXPBVE structure (instead of setting only the ramp delta
// with AXSetVoiceVeDelta()) in order to avoid cumulative drifts from the desired
// volume due to (float->integer) conversion errors.

void PlatformVoice::SetVolume(ALfloat gain)
{		
	// Volume cannot be set when a voice is paused or stopped. It is however automatically
	// set according to current source gain (by a call from SourceVoiceLinks::PlaySource())
	// when playback starts.
		
	if(m_playbackState == PLAYBACK_STATE_PLAYING)
	{			
		ALfloat totalGain = gain * s_pOutputVolumes[WPAD_MAX_CONTROLLERS];
		
		// Put limits on gain.			
		if(totalGain > 1.0f)
		{
			totalGain = 1.0f;
		}
		else if(totalGain < 0.0f)
		{
			totalGain = 0.0f;
		}		
		
		// Calculate the volume change since last update.
		ALfloat gainChange = totalGain - m_currentGain;									
		ALint volumeChange = (ALint) (MAX_VOLUME * gainChange * FLOAT_FIXED_1_15_FACTOR);
				
		if(volumeChange != 0)
		{
			// Set the volume envelope of the voice for ramping. 
			AXPBVE volumeEnvelope;				
			volumeEnvelope.currentVolume = m_currentVolume;
    		volumeEnvelope.currentDelta = (ALshort) (volumeChange / NOMINAL_DSP_SAMPLE_TRANSFER);
    		AXSetVoiceVe(m_pVoiceBlock, &volumeEnvelope);
    	}
    	else
    	{
    		// Set volume envelope delta to zero to stop ramping.
			AXSetVoiceVeDelta(m_pVoiceBlock, 0);		
    	}			

		// Update the current gain and volume values.
		m_currentVolume = (ALushort) (MAX_VOLUME * totalGain * FLOAT_FIXED_1_15_FACTOR);
    	m_currentGain = totalGain;
							
		UpdateWiimoteVolumes();						
	}
}

   
// Method 'Stop()' stops playback of the AX voice. If the voice was the only one playing
// on a wiimote channel, the method mutes the correponding speaker.

void PlatformVoice::Stop(void)
{	
	// If voice is playing on wiimote speaker, mute the wiimote speaker.
	for(ALshort i = 0; i < WPAD_MAX_CONTROLLERS; i++)
	{
		if(m_playbackState == PLAYBACK_STATE_PLAYING)
		{			
			if(m_pOutputsStates[i] >= AL_OUTPUT_ON)
			{
				s_pNbWiimotePlayingVoices[i]--;
				s_totalWiimoteConnections--;
					
				// If no voice uses a wiimote channel, mute the corresponding wiimote speaker.								
				if(s_pNbWiimotePlayingVoices[i] == 0)
				{					
					if(WPADIsSpeakerEnabled(i))
					{
						WPADControlSpeaker(i, WPAD_SPEAKER_MUTE, NULL);					
					}
				}
			}
		}
	}
	
	// Stop the cursor from moving.
	AXSetVoiceState(m_pVoiceBlock, AX_PB_STATE_STOP);
			
	// Stop voice calculations for wiimote.
	AXSetVoiceRmtOn(m_pVoiceBlock, AX_PB_REMOTE_OFF);
		
	// Stop voice playback
	m_playbackState = PLAYBACK_STATE_STOPPED;			
}



// Method 'Update()' is called each time half of the double buffer 'm_playbackBuffer'
// is filled. It sets the index of the next buffer to be filled and flushes the cache
// (i.e. commits to RAM data that was just written to cache).
   
void PlatformVoice::Update(ALshort *buffer)
{		
	if(m_playbackState == PLAYBACK_STATE_PLAYING)
	{
		m_bufferToFillIndex = 1 - m_bufferToFillIndex; // m_bufferToFillIndex = 0 or 1.
	}
	
	DCFlushRange((void *) buffer, m_bufferSizeBytes);
}



// Method 'UpdateWiimoteSounds()' encodes data from the AX voices and sends it to the
// corresponding wiimotes. the method is called every 6.666 ms by an alarm set with
// OSSetPeriodicAlarm().

void PlatformVoice::UpdateWiimoteSounds()
{	
	if(s_isWiimoteUpdated && s_totalWiimoteConnections > 0)	
	{
		ALint nbSamples;		
			
		if(AXRmtGetSamplesLeft() >= 0)
		{			
			// Transfer data on the active Wiimote channels.
			for(ALshort i = 0; i < WPAD_MAX_CONTROLLERS; i++)
			{						
				if(s_pNbWiimotePlayingVoices[i] > 0)
				{			
					nbSamples = AXRmtGetSamples(i, s_pWiimoteBuffer, WIIMOTE_NB_SAMPLES_BUFFER);
									
					if(nbSamples > 0)									
					{				
						ALboolean wereInterruptsEnabled = OSDisableInterrupts();
										
						if(WPADCanSendStreamData(i))
						{																				
							WENCGetEncodeData(&s_pWiimoteEncodeInfos[i], s_wiimoteEncodeFlag[i], 
									  	  	  s_pWiimoteBuffer, nbSamples, s_pWiimoteEncodedData);	
																					
							WPADSendStreamData(i, s_pWiimoteEncodedData, nbSamples >> 1);						
					
							if(s_wiimoteEncodeFlag[i] == ((u32) WENC_FLAG_FIRST))
							{
								s_wiimoteEncodeFlag[i] = (u32) WENC_FLAG_CONT;
							}
						}
						OSRestoreInterrupts(wereInterruptsEnabled);
					}							
				}				
			}
			AXRmtAdvancePtr(WIIMOTE_NB_SAMPLES_BUFFER);			
		}
	}
}



// ----------------------------------------------------------------- //
// ---------------------- PRIVATE METHODS -------------------------- //
// ----------------------------------------------------------------- //


// Method 'Acquire()' acquires a voice from the AX interface and registers the address
// of the double buffer used to send data to AX. It also set initial pitch to 1 and
// volume to 0.

void PlatformVoice::Acquire(void)
{	
	AXPBADDR voiceAddresses;
	ALuint nbBytes = m_bufferSizeBytes * DOUBLE_BUFFER;

	// Acquire voice from AX API.
	m_pVoiceBlock = AXAcquireVoice(VOICE_PRIORITY_MEDIUM, NULL, 0);
	
    // Provide start, middle and end addresses of playback buffer to AX interface.
    if(m_pVoiceBlock)
    {    
    	// Set double buffer addresses (>> 1 needed when dealing with 16 bits samples).
       	// Cursor starts at half of first buffer (i.e. 1/4 of whole double buffer).           
    	m_startAddress = (ALuint)OSCachedToPhysical(m_pPlaybackBuffer) >> 1;
    	m_endAddress = m_startAddress + (nbBytes >> 1) - 1;                    
    	m_halfAddress = m_startAddress + (nbBytes >> 2);
    	m_cursorStart = m_startAddress + ((m_halfAddress - m_startAddress) >> 1);
                          
    	voiceAddresses.loopFlag = AXPBADDR_LOOP_ON;
    	voiceAddresses.format   = AX_PB_FORMAT_PCM16;
    	voiceAddresses.loopAddressHi    = (ALushort)(m_startAddress >> 16);
    	voiceAddresses.loopAddressLo    = (ALushort)(m_startAddress &  0xFFFF);
    	voiceAddresses.endAddressHi     = (ALushort)(m_endAddress >> 16);
    	voiceAddresses.endAddressLo     = (ALushort)(m_endAddress &  0xFFFF);
    	voiceAddresses.currentAddressHi = (ALushort)(m_cursorStart >> 16);
    	voiceAddresses.currentAddressLo = (ALushort)(m_cursorStart &  0xFFFF);
    
    	AXSetVoiceAddr(m_pVoiceBlock, &voiceAddresses);

    	// Set voice sampling rate conversion parameters.    
    	ALuint srcBits = (ALuint)(0x00010000);

		m_voiceSrc.ratioHi = (ALushort)(srcBits >> 16);
		m_voiceSrc.ratioLo = (ALushort)(srcBits & 0xFFFF);
		m_voiceSrc.currentAddressFrac = 0;
		m_voiceSrc.last_samples[0] = 0;
		m_voiceSrc.last_samples[1] = 0;
		m_voiceSrc.last_samples[2] = 0;
		m_voiceSrc.last_samples[3] = 0;
	
    	AXSetVoiceSrc(m_pVoiceBlock, &m_voiceSrc);
    	AXSetVoiceSrcType(m_pVoiceBlock, AX_SRC_TYPE_LINEAR);			
		
    	// Set initial volume to 0 in order to have a correct ramp-up to the desired
    	// volume when first starting playback. -904 = -90.4 db is sufficient so that
    	// axvpb.pb.ve.currentVolume = 0 (see NOTE 1 at the end of this file).    	
    	MIXInitChannel(m_pVoiceBlock, 0, -904, -904, -904, -904, 64, 127, 1);
    }
}


// Wiimote volumes are updated according to each wiimote master volume (kept in
// array 's_pOutputVolumes');

void PlatformVoice::UpdateWiimoteVolumes(void)
{					    	    	    	
	ALushort volume;
	
	for(ALshort i = 0; i < WPAD_MAX_CONTROLLERS; i++)
	{	
		if(m_pOutputsStates[i] >= AL_OUTPUT_ON)
		{
			volume = (ALushort) ((ALfloat) m_currentVolume * s_pOutputVolumes[i]);				
				
			if(i == WPAD_CHAN0)
			{									
				m_wiimoteMixing->vMain0 = volume;      // channel 0, main volume.						
			}
			else if(i == WPAD_CHAN1)
			{					
				m_wiimoteMixing->vMain1 = volume;      // channel 1, main volume.
			}
			else if(i == WPAD_CHAN2)
			{				
				m_wiimoteMixing->vMain2 = volume;      // channel 2, main volume.				
			}			
			else if(i == WPAD_CHAN3)
			{				
				m_wiimoteMixing->vMain3 = volume;      // channel 3, main volume.				
			}
		}
										
		AXSetVoiceRmtMix(m_pVoiceBlock, m_wiimoteMixing);	
	}				
}



// Method 'WiimoteOnCallback()' is called by 'WPADControlSpeaker()' when its second
// parameter is WPAD_SPEAKER_ON.

void PlatformVoice::WiimoteOnCallback(s32 outputID, s32 result)
{	
	if (result == WPAD_ERR_NONE)
    {
        WPADControlSpeaker(outputID, WPAD_SPEAKER_PLAY, WiimotePlayCallback);
    }    
}



// Method 'WiimotePlayCallback()' is called by 'WPADControlSpeaker()' when its second
// parameter is WPAD_SPEAKER_PLAY.

void PlatformVoice::WiimotePlayCallback(s32 outputID, s32 result)
{
    if (result == WPAD_ERR_NONE)
    {
        WPADControlSpeaker(outputID, WPAD_SPEAKER_MUTE, NULL);
    }    
}



// **************************************************************************************** //
// **************************************** NOTES ***************************************** //
// **************************************************************************************** //

// NOTE 1 : The 3rd parameter of MIXInitChannel() affects the value of the 'currentVolume'
//			parameter of the 'axvpb.pb.ve' structure in increments of 0.1dB. Value 0
//			corresponds	to currentVolume = 32767. For example, -100 corresponds to -10db of
//			32767, i.e.	currentVolume = 10361. It is important to notice that parameter
//			currentVolume can be set linearly with function AXSetVoiceVe().

// NOTE 2 : Update pan parameters axvpb.pb.mix.vL and axvpb.pb.mix.vR through AXSetVoiceMix()
//			rather than via MIXSetPan(). The latter function doesn't seem to work properly. 
//			Indeed it provides the (out of bound) value of 33147 when pan is set to 0 and
//			value 23466 (way of center) when pan = 64. This causes malfunction when fading
//			the sound through volume envelopes.
//			