#include "OpenALMutex.h"


// **************************************************************************************** //
// ************************************** ALMutex class *********************************** //
// **************************************************************************************** //


ALMutex::ALMutex()
{
	#ifdef USE_OPENAL_MUTEX		
		#ifdef PLATFORM_PS3
			sys_lwmutex_attribute_t lwmutex_attr;
			sys_lwmutex_attribute_initialize(lwmutex_attr);
			sys_lwmutex_create(&m_mutex, &lwmutex_attr);
		#elif defined PLATFORM_WII
			OSInitMutex(&m_mutex);
			m_wereInterruptsEnabled = AL_FALSE;
		#elif defined PLATFORM_WINDOWS
			m_mutex = CreateMutex(NULL,AL_FALSE,NULL);
		#endif
	#endif
}


ALMutex::~ALMutex()
{
	#ifdef USE_OPENAL_MUTEX	
		#ifdef PLATFORM_PS3
			sys_lwmutex_destroy(&m_mutex);
		#elif defined PLATFORM_WII
			// Haven't found any OS...Mutex method to close mutex created with OSInitMutex().
		#elif defined PLATFORM_WINDOWS
			CloseHandle(m_mutex);
		#endif
	#endif
}


void ALMutex::Lock()
{
	#ifdef USE_OPENAL_MUTEX
		#ifdef PLATFORM_PS3
			sys_lwmutex_lock(&m_mutex, 0);
		#elif defined PLATFORM_WII
			// Disable interrupts and lock mutex (see NOTE 1 at the end of file).
			m_wereInterruptsEnabled = OSDisableInterrupts();
			OSLockMutex(&m_mutex);        
		#elif defined PLATFORM_WINDOWS
			WaitForSingleObject(m_mutex,INFINITE);
		#endif
	#endif
}


void ALMutex::Unlock()
{
	#ifdef USE_OPENAL_MUTEX	
		#ifdef PLATFORM_PS3
			sys_lwmutex_unlock(&m_mutex);
		#elif defined PLATFORM_WII
			// Unlock mutex and restore interrupts.
			OSUnlockMutex(&m_mutex);			
			OSRestoreInterrupts(m_wereInterruptsEnabled);
		#elif defined PLATFORM_WINDOWS
			ReleaseMutex(m_mutex);
		#endif
	#endif
}


// **************************************************************************************** //
// ******************************** ScopedALMutexLock class ******************************* //
// **************************************************************************************** //


ScopedALMutexLock::ScopedALMutexLock(ALMutex* mutex)
{
	#ifdef USE_OPENAL_MUTEX
		m_mutex = mutex;
		m_mutex->Lock();
	#endif
}


ScopedALMutexLock::~ScopedALMutexLock(void)
{
	m_mutex->Unlock();
}


// **************************************************************************************** //
// **************************************** NOTES ***************************************** //
// **************************************************************************************** //

// NOTE 1 : On Wii, the OpenAL API is accessed concurently by threads from the application
//			and interruptions (AX callback for voice buffer filling and interruption from
//			a 6.6 ms timer used to encode and send date to wiimotes). Therefore, whenever a
//			thread wants to lock a portion of OpenAL code, it must also disable interrupts.