#include "Buffers.h"


// **************************************************************************************** //
// ************************************* Buffer class ************************************* //
// **************************************************************************************** //


Buffer::Buffer(ALuint bufferID)
{
	m_bufferID = bufferID;
	m_state = UNUSED;
	m_referenceCount = 0;
	m_dataSize = 0;
	m_nbSamples = 0;
	m_nbChannels = 0;
	m_pNext = NULL;
	m_memorySize = 0;
	m_pDataMemory = 0;
	m_deleteOldMemory = AL_TRUE;
}


Buffer::~Buffer(void)
{	
	if(m_deleteOldMemory)
	{
		aldelete [] m_pDataMemory;
	}
}


void Buffer::DecreaseReferenceCount(void)
{
	if(m_referenceCount > 0)
	{
		m_referenceCount--;
		if(m_referenceCount == 0)
		{
			m_state = UNUSED; // Buffer is not queued for any source.
		}
	}
}


ALenum Buffer::GetFormat(void)
{
	return(m_format);
}


ALsizei Buffer::GetFrequency(void)
{
	return(m_frequency);
}
	
	
	
ALuint Buffer::GetID(void)
{
	return(m_bufferID);
}


ALchar *Buffer::GetMemory(void)
{
	return(m_pDataMemory);
}



ALint Buffer::GetNbChannels(void)
{
	return(m_nbChannels);
}



ALuint Buffer::GetNbSamples(void)
{
	return(m_nbSamples);
}



Buffer *Buffer::GetNext(void)
{
	return(m_pNext);
}


ALuint Buffer::GetReferenceCount(void)
{
	return(m_referenceCount);
}



ALuint Buffer::GetSampleWidth(void)
{
	switch(m_format)
    {
    	case AL_FORMAT_MONO16:					
			return(SAMPLE_WIDTH_16_BITS);       		
    	case AL_FORMAT_STEREO16:
    		return(SAMPLE_WIDTH_16_BITS);       		
		#ifdef PLATFORM_PS3
			case AL_FORMAT_MONO32F:
				return(SAMPLE_WIDTH_32_BITS);       			
       		case AL_FORMAT_STEREO32F:					
				return(SAMPLE_WIDTH_32_BITS);       			
		#endif
    	case AL_FORMAT_MONO8:
    		return(SAMPLE_WIDTH_8_BITS);       		
		case AL_FORMAT_STEREO8:
			return(SAMPLE_WIDTH_8_BITS);       		    			
    	default:
			return(UNKNOWN_FORMAT);       		
    }
}


ALsizei Buffer::GetSize(void)
{
	return(m_dataSize);
}



ALenum Buffer::GetState(void)
{
	return(m_state);
}


void Buffer::IncreaseReferenceCount(void)
{
	m_referenceCount++;
}



void Buffer::SetData(ALenum format, const ALvoid* data, ALsizei size, ALsizei frequency)
{							
	if(size > m_memorySize) // New memory allocation is necessary.				
	{				
		aldelete [] m_pDataMemory;	
		m_pDataMemory = alnew ALchar[size];
		m_memorySize = size;	
	}
		
	m_dataSize = size;			 	
	std::memcpy(m_pDataMemory, data, size);	
	SetFormat(format);
	m_frequency = frequency;		
}



ALboolean Buffer::SetDataNoCopy(ALenum format, const ALvoid* data, ALsizei size,
								ALsizei frequency, ALboolean deleteOldMemory)
{									
	if(deleteOldMemory)
	{
		aldelete [] m_pDataMemory;
	}
	m_deleteOldMemory = deleteOldMemory;
	m_memorySize = size;					
	m_dataSize = size;			 	
	m_pDataMemory = (ALchar *) data;		
	SetFormat(format);
	m_frequency = frequency;
	
	return(m_pDataMemory != NULL);
}



void Buffer::SetFormat(ALenum format)
{
	m_format = format;

	switch(format)
    {
    	case AL_FORMAT_MONO16:					
			m_nbSamples = m_dataSize >> 1;
			m_nbChannels = 1;	
       		break;
    	case AL_FORMAT_STEREO16:
    		m_nbSamples = m_dataSize >> 2;
			m_nbChannels = 2;	
       		break;
		#ifdef PLATFORM_PS3
			case AL_FORMAT_MONO32F:
				m_nbSamples = m_dataSize >> 2;
				m_nbChannels = 1;		
       			break;
       		case AL_FORMAT_STEREO32F:					
				m_nbSamples = m_dataSize >> 3;
				m_nbChannels = 2;	
       			break;
		#endif
    	case AL_FORMAT_MONO8:
    		m_nbSamples = m_dataSize;
			m_nbChannels = 1;
       		break;
		case AL_FORMAT_STEREO8:
			m_nbSamples = m_dataSize >> 1;
			m_nbChannels = 2;
       		break;       			
    	default:
			m_nbSamples = 0;
			m_nbChannels = 0;
       		break;
    }
}


void Buffer::SetFrequency(ALenum frequency)
{
	m_frequency = frequency;
}



void Buffer::SetNext(Buffer *buffer)
{
	m_pNext = buffer;
}


void Buffer::SetState(ALenum state)
{
	m_state = state;
}	
	

// **************************************************************************************** //
// ************************************* Buffers class ************************************ //
// **************************************************************************************** //


ALuint Buffers::s_IDGenerator = 1; // Buffers ID cannot be 0.


Buffers::Buffers(void)
{		
	m_pBuffers = alnew Buffer* [AL_BUFFERS_TABLE_SIZE];	
	
	for(ALuint i = 0; i < AL_BUFFERS_TABLE_SIZE; i++)
	{
		m_pBuffers[i] = NULL;		
	}
}



Buffers::~Buffers(void)
{
	Buffer *currentBuffer;
	Buffer *nextBuffer;

	// For each hash table entry, delete all buffers in associated linked list.
	for(ALuint i = 0; i < AL_BUFFERS_TABLE_SIZE; i++)
	{			
		nextBuffer = m_pBuffers[i];
		currentBuffer = nextBuffer;
	
		while(currentBuffer)	
		{
			nextBuffer = currentBuffer->GetNext();
			aldelete currentBuffer;
			currentBuffer = nextBuffer;					
		}
	}			
	
	aldelete [] m_pBuffers;
}


ALCboolean Buffers::AreAllBuffersDeleted(void)
{
	// Search if any buffer remaining in the hash table.
	for(ALuint i = 0; i < AL_BUFFERS_TABLE_SIZE; i++)
	{			
		if(m_pBuffers[i])		
		{
			return(ALC_FALSE);
		}		
	}
	return(ALC_TRUE);
}



ALenum Buffers::DeleteBuffers(ALsizei nbBuffers, const ALuint* buffers)
{	
	ALuint bufferID;
	ALboolean isBufferFound;
	ALuint tableEntry;
	Buffer *currentBuffer;
	Buffer *previousBuffer;
			
	ALenum error = VerifyBuffersUnusedState(nbBuffers, buffers);
	
	if(error == AL_NO_ERROR)
	{
		for(int i = 0; i < nbBuffers; i++)
		{
			isBufferFound = AL_FALSE;
			bufferID = buffers[i];
			tableEntry = bufferID % AL_BUFFERS_TABLE_SIZE;
	
			currentBuffer = m_pBuffers[tableEntry];		
	
			while(!isBufferFound && (currentBuffer != NULL))	
			{
				if(currentBuffer->GetID() == bufferID)
				{				
					isBufferFound = AL_TRUE;
			
					if(currentBuffer == m_pBuffers[tableEntry])
					{
						m_pBuffers[tableEntry] = currentBuffer->GetNext();
					}
					else
					{
						previousBuffer->SetNext(currentBuffer->GetNext());
					}					
					aldelete currentBuffer;									
				}
				else
				{			
					previousBuffer = currentBuffer;
					currentBuffer = currentBuffer->GetNext();
				}
			}
		}										
	}

	return(error);
}



ALenum Buffers::GenerateBuffers(ALsizei nbBuffers, ALuint* buffers)
{	
	Buffer *newBuffer;
	ALuint tableEntry;
	Buffer *bufferList;
	
	for(int i = 0; i < nbBuffers; i++)
	{
		newBuffer = alnew Buffer(s_IDGenerator);
		
		if(newBuffer)
		{			
			buffers[i] = s_IDGenerator;
			
			// Insert buffer into hash table.			
			tableEntry = s_IDGenerator % AL_BUFFERS_TABLE_SIZE;
			bufferList = m_pBuffers[tableEntry];
			if(bufferList)	
			{
				newBuffer->SetNext(bufferList);		
			}
			m_pBuffers[tableEntry] = newBuffer;
			
			s_IDGenerator++;
		}
		else
		{
			buffers[i] = 0;				// 0 is an invalid buffer number.
			return(AL_OUT_OF_MEMORY);
		}								
	}
	return(AL_NO_ERROR);
}



Buffer *Buffers::GetBuffer(ALuint bufferID)
{	
	if(bufferID > 0)
	{
		ALuint tableEntry = bufferID % AL_BUFFERS_TABLE_SIZE;
	
		Buffer *currentBuffer = m_pBuffers[tableEntry];
		
		while(currentBuffer)	
		{		
			if(currentBuffer->GetID() == bufferID)
			{
				return(currentBuffer);
			}
			else
			{
				currentBuffer = currentBuffer->GetNext();
			}		
		}
	}
	
	return(NULL);
}


// ----------------------------------------------------------------- //
// ---------------------- PRIVATE METHODS -------------------------- //
// ----------------------------------------------------------------- //



ALenum Buffers::VerifyBuffersUnusedState(ALsizei nbBuffers, const ALuint* buffers)
{
	if((nbBuffers > 0) && (buffers != NULL))
	{
		ALuint bufferID;
		ALboolean isBufferFound;
		ALuint tableEntry;
		Buffer *currentBuffer;	
		ALenum error = AL_NO_ERROR;	
		
		for(int i = 0; i < nbBuffers; i++)
		{
			isBufferFound = AL_FALSE;
			bufferID = buffers[i];
			tableEntry = bufferID % AL_BUFFERS_TABLE_SIZE;
	
			currentBuffer = m_pBuffers[tableEntry];		
		
			while(!isBufferFound && (currentBuffer != NULL))	
			{
				if(currentBuffer->GetID() == bufferID)
				{
					isBufferFound = AL_TRUE;
					if(currentBuffer->GetState() != UNUSED)
					{					
						error = AL_INVALID_OPERATION;
					}
				}
				else
				{							
					currentBuffer = currentBuffer->GetNext();
				}		
			}
			if(!isBufferFound)
			{
				error = AL_INVALID_NAME;
			}									
		}
		return(error);
	}
	return(AL_INVALID_VALUE);
}