#include "SourceListener.h"
#include "GeneralSettings.h"
#include "Buffers.h"

// **************************************************************************************** //
// *********************************** Listener class ************************************* //
// **************************************************************************************** //


ALlistener::ALlistener(void)
{
	m_position.m_x = 0.0f;
	m_position.m_y = 0.0f;
	m_position.m_z = 0.0f;
	
	m_velocity.m_x = 0.0f;
	m_velocity.m_y = 0.0f;
	m_velocity.m_z = 0.0f;
	
	// By default, listener's front points to the back of the screen.
	m_atOrientation.m_x = 0.0f;
	m_atOrientation.m_y = 0.0f;
	m_atOrientation.m_z = -1.0f;

    // By default, listener's up orientation points towards the ceiling.
    m_upOrientation.m_x = 0.0f;
    m_upOrientation.m_y = 1.0f;
    m_upOrientation.m_z = 0.0f;

	m_gain = 1.0f;
}



ALlistener::~ALlistener(void)
{		
}



ALdirection *ALlistener::GetAtOrientation(void)
{
	return(&m_atOrientation);
}



ALfloat ALlistener::GetGain(void)
{
	return(m_gain);
}



ALposition *ALlistener::GetPosition(void)
{
	return(&m_position);
}



ALdirection *ALlistener::GetUpOrientation(void)
{
	return(&m_upOrientation);
}



ALvelocity *ALlistener::GetVelocity(void)
{
	return(&m_velocity);
}



void ALlistener::SetAtOrientation(ALfloat atX, ALfloat atY, ALfloat atZ)
{
	m_atOrientation.m_x = atX;
	m_atOrientation.m_y = atY;
	m_atOrientation.m_z = atZ;
}



void ALlistener::SetGain(ALfloat gain)
{
	m_gain = gain;
}



void ALlistener::SetPosition(ALfloat x, ALfloat y, ALfloat z)
{
	m_position.m_x = x;
	m_position.m_y = y;
	m_position.m_z = z;		
}



void ALlistener::SetUpOrientation(ALfloat upX, ALfloat upY, ALfloat upZ)
{
	m_upOrientation.m_x = upX;
	m_upOrientation.m_y = upY;
	m_upOrientation.m_z = upZ;	
}



void ALlistener::SetVelocity(ALfloat vx, ALfloat vy, ALfloat vz)
{
	m_velocity.m_x = vx;
	m_velocity.m_y = vy;
	m_velocity.m_z = vz;
}


// **************************************************************************************** //
// *********************************** ALSource class ************************************* //
// **************************************************************************************** //

ALuint ALsource::s_IDGenerator = 1;
Buffers *ALsource::s_pBuffers = NULL;

ALsource::ALsource(void)
{
	m_sourceID = s_IDGenerator++;

	m_pNext = NULL;
	m_type = AL_UNDETERMINED;
	
	// Pitch parameters
	m_pitch = 1.0f;
	m_effectivePitch = 1.0f;	

	// Playback parameters
	m_playbackState = AL_INITIAL;
	m_intraPlaybackState = SOURCE_WAITING;	
	m_isSourceLinkedToVoices = AL_FALSE;
	m_nbExecutedChannels = 0;
	m_isSourceLooping = AL_FALSE;
	for(ALuint i = 0; i < MAX_NB_SOURCE_CHANNELS; i++)
	{
		m_pNbVoiceBufferResets[i] = 0;
		m_pChannelsStatus[i] = SOURCE_CHANNEL_UNUSED;
	}
	m_existenceStatus = KEEP_SOURCE_ALIVE;
	m_postResetState = AL_STOPPED;	

	// Volume parameters
	m_minGain = 0.0f;
	m_maxGain = 1.0f;
	m_gain = 1.0f;
		
	// 3D positioning parameters
	m_isRelativeToListener = AL_FALSE;
	m_position.m_x = 0.0f;
	m_position.m_y = 0.0f;
	m_position.m_z = 0.0f;
	m_velocity.m_x = 0.0f;
	m_velocity.m_y = 0.0f;
	m_velocity.m_z = 0.0f;
	m_referenceDistance = 1.0f;
	m_maxDistance = FLT_MAX;	
	m_rollOffFactor = 1.0f;
	m_direction.m_x = 0.0f;
	m_direction.m_y = 0.0f;
	m_direction.m_z = 0.0f;
	m_coneInnerAngle = 360.0f;
	m_coneOuterAngle = 360.0f;
	m_coneOuterGain = 0.0f;

	// Buffers queue parameters	
	m_nbQueuedBuffers = 0;
	m_nbProcessedBuffers = 0;
	m_nbListItems = 0;
	m_pBufferQueue = NULL;
	m_pItemListStart = NULL;
	m_cursorPosition = 0;
	m_sampleWidth = 0;
	m_nbChannels = 0;

	// Outputs (speakers) parameters.
	#ifdef PLATFORM_WII	
		// Set the wiimote speakers Off.
		for(ALshort i = 0; i < WPAD_MAX_CONTROLLERS; i++)
		{
			m_pOutputsStates[i] = AL_OUTPUT_OFF;
		}
		
		// Set the primary Wii speakers On.
		m_pOutputsStates[WPAD_MAX_CONTROLLERS] = AL_OUTPUT_ON;
	#endif
}



ALsource::~ALsource(void)
{
	ALbufferlistitem *currentListItem = m_pItemListStart;
	ALbufferlistitem *nextListItem; 
		
	// Delete all list items.
	for(ALuint i = 0; i < m_nbListItems; i++)
	{				
		nextListItem = currentListItem->m_pNext;
		aldelete currentListItem;
		currentListItem = nextListItem;				
	}
	m_pBufferQueue = NULL;
	m_pItemListStart = NULL;	
}



void ALsource::AddExecutedChannel(void)
{
	m_nbExecutedChannels++;
	if(m_nbExecutedChannels == m_nbChannels)
	{
		m_nbExecutedChannels = 0;
	} 
}



void ALsource::AddVoiceBufferReset(ALshort channel)
{
	m_pNbVoiceBufferResets[channel]++;	
}



ALboolean ALsource::AreChannelsUnused(void)
{
	for(ALshort i = 0; i < MAX_NB_SOURCE_CHANNELS; i++)
	{
		if(m_pChannelsStatus[i] == SOURCE_CHANNEL_IN_USE)
		{
			return(AL_FALSE);
		}
	}
	return(AL_TRUE);
}



void ALsource::AttachStaticBuffer(ALuint bufferID)
{		
	if(m_type == AL_UNDETERMINED && bufferID > 0)
	{		
		ALbufferlistitem *bufferListItem;
		Buffer *currentBuffer;
				
		// If there is an item list, put the buffer in the first list item.
		if(m_pItemListStart)
		{						
			bufferListItem = m_pItemListStart;
		}				
		else // No item list, create one list item.
		{
			bufferListItem = alnew ALbufferlistitem();
			bufferListItem->m_pNext = bufferListItem; // Item list is circular.
			m_pItemListStart = bufferListItem;
			m_nbListItems++;
		}

		bufferListItem->m_bufferID = bufferID;
		bufferListItem->m_bufferState = PENDING;		

		m_pBufferQueue = bufferListItem;
		m_nbQueuedBuffers++;
		m_firstUnprocessedBuffer = bufferListItem;
																																																			
		currentBuffer = s_pBuffers->GetBuffer(bufferListItem->m_bufferID);							
		currentBuffer->SetState(PENDING);
		currentBuffer->IncreaseReferenceCount();								
										     
   		// Set source buffers format, frequency, effective pitch and number of channels.
  		m_buffersFormat = currentBuffer->GetFormat(); 
   		m_buffersFrequency = currentBuffer->GetFrequency();
		m_sampleWidth = currentBuffer->GetSampleWidth();
		m_effectivePitch = m_pitch * (ALfloat) m_buffersFrequency / (ALfloat) PLATFORM_SAMPLING_RATE;
   		m_nbChannels = currentBuffer->GetNbChannels();
   		
		// Set source state and initialize cursor position.
		m_type = AL_STATIC;
		m_cursorPosition = 0;
	}
}    


// Method 'DetachAllBuffers()' unqueues all buffers in the source's queue. This is a way
// to force unqueuing no matter if buffers are PROCESSED or not. This is valid for both
// AL_STREAMING and AL_STATIC sources. Note that the linked list of 'ALbufferlistitem'
// objects still exists and contains buffers with ID = AL_NONE.

void ALsource::DetachAllBuffers(void)
{
	if(m_nbQueuedBuffers > 0)
	{
		Buffer *currentBuffer;
		ALbufferlistitem *currentListItem;
		
		currentListItem = m_pBufferQueue;
		for(ALuint i = 0; i < m_nbListItems; i++)		
		{
			if(currentListItem->m_bufferID != AL_NONE)			
			{										
				currentBuffer = s_pBuffers->GetBuffer(currentListItem->m_bufferID);					
				currentBuffer->DecreaseReferenceCount();			
				currentListItem->m_bufferID = AL_NONE; // Set unqueued list item ID to zero.			
			}
			currentListItem = currentListItem->m_pNext;
		}
		// Reset number of queued and processed buffers.
		m_nbProcessedBuffers = 0;
		m_nbQueuedBuffers = 0;
	
		// Reset pointers to buffers in the queue.	
		m_pBufferQueue = NULL;
		m_firstUnprocessedBuffer = NULL;
	
		m_type = AL_UNDETERMINED; 	// Source is not AL_STREAMING nor AL_STATIC anymore.
		m_cursorPosition = 0;
	}
}



void ALsource::FinalizeVoiceBufferReset(void)
{
	for(ALuint i = 0; i < m_nbChannels; i++)
	{
		m_pNbVoiceBufferResets[i] = 0;
	} 
	
	m_intraPlaybackState = SOURCE_WAITING;	// Informs that the source is properly paused (stopped).
}



ALenum ALsource::GetBuffersFormat(void)
{
	return(m_buffersFormat);
}



ALsizei ALsource::GetBuffersFrequency(void)
{
	return(m_buffersFrequency);
}



// Method 'GetByteOffset()' returns the cursor position from the beginning of the
// queue in bytes (including all channels).

ALint ALsource::GetByteOffset(void)
{
	ALint result = GetSampleOffset();		// Nb of samples per channel.	

	// Transition from sample to bytes.
	if(m_sampleWidth == SAMPLE_WIDTH_16_BITS)
	{
		result <<= 1;
	}
	else if(m_sampleWidth == SAMPLE_WIDTH_32_BITS)
	{
		result <<= 2;
	}
	
	// Include bytes of all channels.
	result *= m_nbChannels;
	
	return(result);
}



ALfloat ALsource::GetConeInnerAngle(void)
{
	return(m_coneInnerAngle);
}



ALfloat ALsource::GetConeOuterAngle(void)
{
	return(m_coneOuterAngle);
}



ALfloat ALsource::GetConeOuterGain(void)
{
	return(m_coneOuterGain);
}



ALuint ALsource::GetCursorPosition(void)
{
	return(m_cursorPosition);	
}



ALdirection *ALsource::GetDirection(void)
{
	return(&m_direction);
}



ALfloat ALsource::GetEffectivePitch(void)
{
	return(m_effectivePitch);
}



ALuint ALsource::GetExistenceStatus(void)
{
	return(m_existenceStatus);
}



ALuint ALsource::GetFirstBufferID(void)
{
	if(m_pBufferQueue)
	{
		return(m_pBufferQueue->m_bufferID);
	}
	else // No buffers are presently queued for the current source.
	{
		return(0);
	}	
}



ALfloat ALsource::GetGain(void)
{
	return(m_gain);
}



ALuint ALsource::GetID(void)
{
	return(m_sourceID);
}



ALfloat ALsource::GetMinGain(void)
{
	return(m_minGain);
}



ALfloat ALsource::GetMaxDistance(void)
{
	return(m_maxDistance);
}



ALfloat ALsource::GetMaxGain(void)
{
	return(m_maxGain);
}	
	


ALuint ALsource::GetNbChannels(void)
{
	return(m_nbChannels);
}



ALuint ALsource::GetNbExecutedChannels(void)
{
	return(m_nbExecutedChannels);
}



ALuint ALsource::GetNbProcessedBuffers(void)
{
	return(m_nbProcessedBuffers);
}



ALuint ALsource::GetNbQueuedBuffers(void)
{
	return(m_nbQueuedBuffers);
}



ALuint ALsource::GetNbVoiceBufferResets(ALshort channel)
{
	return(m_pNbVoiceBufferResets[channel]);
}



ALsource *ALsource::GetNext(void)
{
	return(m_pNext);
}



#ifdef PLATFORM_WII

ALshort ALsource::GetOutputState(ALshort outputID)
{
	if(outputID < AL_NB_OUTPUTS)
	{
		return(m_pOutputsStates[outputID]);
	}
	else
	{
		return(-1);
	}
}

#endif


ALfloat ALsource::GetPitch(void)
{
	return(m_pitch);
}



ALenum ALsource::GetPlaybackState(void)
{
	return(m_playbackState);
}



ALposition *ALsource::GetPosition(void)
{
	return(&m_position);
}



ALuint ALsource::GetPostResetState(void)
{
	return(m_postResetState);
}



ALfloat ALsource::GetReferenceDistance(void)
{
	return(m_referenceDistance);
}



ALfloat ALsource::GetRollOffFactor(void)
{
	return(m_rollOffFactor);
}



// Method 'GetSampleOffset()' returns the cursor position from the beginning of the
// queue in samples per channel.

ALint ALsource::GetSampleOffset(void)
{
	Buffer *currentBuffer;
	ALint nbSamplesPerChannel = 0;
	ALbufferlistitem *currentListItem = m_pBufferQueue;	
	
	// Calculate total nb of samples in processed buffers.
	for(ALuint i = 0; i < m_nbProcessedBuffers; i++)
	{				
		currentBuffer = s_pBuffers->GetBuffer(currentListItem->m_bufferID);
		nbSamplesPerChannel += currentBuffer->GetNbSamples();
		currentListItem = currentListItem->m_pNext;					
	}

	// Add cursor position in first unprocessed buffer.
	if(m_firstUnprocessedBuffer)
	{
		nbSamplesPerChannel += m_cursorPosition;		
	}
	return(nbSamplesPerChannel);
}



// Method 'GetSecOffset()' returns the cursor position from the beginning of the
// queue in seconds.

ALfloat ALsource::GetSecOffset(void)
{
	return((ALfloat) GetSampleOffset() / (ALfloat) m_buffersFrequency);
}



ALint ALsource::GetType(void)
{
	return(m_type);
}



ALuint ALsource::GetUnprocessedBufferID(ALuint bufferIndex)
{			
	if(bufferIndex < m_nbQueuedBuffers - m_nbProcessedBuffers)
	{		
		ALbufferlistitem *currentListItem = m_firstUnprocessedBuffer;	
		ALuint i = 0;

		while(i < bufferIndex)
		{
			currentListItem = currentListItem->m_pNext;
			if((currentListItem->m_bufferID != AL_NONE) && 
				currentListItem->m_bufferState != PROCESSED)
			{
				i++;
			}
		}
		return(currentListItem->m_bufferID);
	}
		
	return(AL_NONE); // From Open AL specification, no buffer has ID = 0.			 
}



ALvelocity *ALsource::GetVelocity(void)
{
	return(&m_velocity);
}



ALboolean ALsource::IsRelativeToListener(void)
{
	return(m_isRelativeToListener);
}



ALboolean ALsource::IsSourceLinkedToVoices(void)
{
	return(m_isSourceLinkedToVoices);
}



ALboolean ALsource::IsSourceLooping(void)
{
	return(m_isSourceLooping);
}



// The buffer item queue is implemented as a circular linked list. The list can contain
// null buffer items (those with ID = 0) which are not considered part of the queue.
// When adding a buffer item to the queue, two situations can arise. If there are no
// null buffers in the list, then a new buffer item has to be created and inserted
// into the list. If there is a null buffer in the list, then the first null buffer
// encountered from the start of the queue is used to contain information of the new
// buffer item. Unqueing a buffer item simply consists in setting its ID to zero.

ALenum ALsource::QueueBuffers(ALsizei nbBuffers, const ALuint *bufferIDs)
{
	if((m_type == AL_STREAMING) || (m_type == AL_UNDETERMINED))
	{
		ALenum integrityResult = VerifyBuffersIntegrity(nbBuffers, bufferIDs);
	
		if(integrityResult == AL_NO_ERROR)
		{
			ALbufferlistitem *currentListItem = m_pBufferQueue;	// Beginning of buffer queue.
			ALbufferlistitem *previousListItem = NULL;			
			ALbufferlistitem *bufferListItem;
			Buffer *currentBuffer;
			ALboolean isNullBufferFound = AL_FALSE;
				
			// If there is a queue, search for the end of the queue which is either
			// the m_nbListItems'th buffer from the start of the queue (if there is
			// no null buffer in the list) or the buffer preceding the first null buffer.
			if(currentListItem)
			{						
				ALuint i = 0;
			
				while(!isNullBufferFound && (i < m_nbListItems))
				{				
					if(currentListItem->m_bufferID == AL_NONE)
					{
						isNullBufferFound = AL_TRUE;
					}
					else
					{
						previousListItem = currentListItem;
						currentListItem = currentListItem->m_pNext;
					}
					i++;
				}
			}				
			else if(m_pItemListStart) // No queue, but list with null buffer items.
			{
				currentListItem = m_pItemListStart;
				isNullBufferFound = AL_TRUE;
			}
		
			for(int i = 0; i < nbBuffers; i++)
			{		
				if(isNullBufferFound)
				{
					bufferListItem = currentListItem;
				
					if(!m_pBufferQueue) // There is a list with null buffer items, but no queue.
					{
						m_pBufferQueue = bufferListItem; // New buffer item is the head of queue.					
					}
				}
				else // There are not enough list items to contain the queue. Create one more.
				{				
					bufferListItem = alnew ALbufferlistitem();
				
					if(previousListItem)
					{					
						bufferListItem->m_pNext = previousListItem->m_pNext;
						previousListItem->m_pNext = bufferListItem;						    
					}
					else // This is the first item inserted in the list.
					{					
						m_pBufferQueue = bufferListItem;	// Start of the buffer item queue.
						m_pItemListStart = bufferListItem;	// Start of the buffer item linked list.
						bufferListItem->m_pNext = bufferListItem;					
					}
					m_nbListItems++;				
				}
			
				bufferListItem->m_bufferID = bufferIDs[i];
				bufferListItem->m_bufferState = PENDING;					
						
				// If all buffers are processed, set the new buffer as the first unprocessed buffer.
				if(m_nbProcessedBuffers == m_nbQueuedBuffers)
				{ 
					m_firstUnprocessedBuffer = bufferListItem;
					m_cursorPosition = 0;
				}
																																								
				currentBuffer = s_pBuffers->GetBuffer(bufferListItem->m_bufferID);							
				currentBuffer->SetState(PENDING);
				currentBuffer->IncreaseReferenceCount();
						
				previousListItem = bufferListItem;
			
				// Check if the next list item is a null buffer.
				currentListItem = bufferListItem->m_pNext;			
				isNullBufferFound = (currentListItem->m_bufferID == AL_NONE);
				
				m_nbQueuedBuffers++;
    		}
     
    		// Set source buffers format, frequency and nb of channels according to the last queued
    		// buffer. Queued buffers have been verified as having the same format and frequency.
    		m_buffersFormat = currentBuffer->GetFormat(); 
    		m_buffersFrequency = currentBuffer->GetFrequency();
			m_sampleWidth = currentBuffer->GetSampleWidth();
			m_effectivePitch = m_pitch * (ALfloat) m_buffersFrequency / (ALfloat) PLATFORM_SAMPLING_RATE;
			m_nbChannels = currentBuffer->GetNbChannels();
			    					
    		m_type = AL_STREAMING;	// When buffers are queued, source is considered streaming.    	
		}
		else
		{    	
    		return(integrityResult);
		}		
	}
	else // Source has already a static buffer attached. New buffers cannot be queued.
	{
		return(AL_INVALID_OPERATION);
	}
    return(AL_NO_ERROR); 
}



void ALsource::ResetNbExecutedChannels(void)
{
	m_nbExecutedChannels = 0;
}



// Method "Rewind()" sets all buffers in the queue as PENDING and cursor position to 0.

void ALsource::Rewind(void)
{
	ALbufferlistitem *currentListItem = m_pBufferQueue;

	if(currentListItem)
	{
		ALuint i = 0;		
		
		while(i < m_nbListItems)
		{	
			if(currentListItem->m_bufferID != AL_NONE)
			{
				currentListItem->m_bufferState = PENDING;				
				if(i == 0)
				{
					m_firstUnprocessedBuffer = currentListItem;
				}				
			}

			currentListItem = currentListItem->m_pNext;
			i++;
		}
		m_nbProcessedBuffers = 0;		
		m_cursorPosition = 0;		
	}	
}



void ALsource::SetAllBuffersAsProcessed(void)
{
	ALbufferlistitem *currentListItem = m_firstUnprocessedBuffer;

	if(currentListItem)
	{
		ALuint i = 0;

		while(i < m_nbListItems)
		{	
			if((currentListItem->m_bufferID != AL_NONE) &&
			   (currentListItem->m_bufferState != PROCESSED))
			{
				currentListItem->m_bufferState = PROCESSED;									
				m_nbProcessedBuffers++;
			}
			currentListItem = currentListItem->m_pNext;
			i++;
		}
		m_firstUnprocessedBuffer = NULL;
		m_cursorPosition = 0;
	}
}



// Method 'SetBuffer()' forces unqueuing of all queued buffers on a source that is
// either in AL_INITIAL or AL_STOPPED state. The buffer provided in parameter is then
// attached statically to the source (whose type becomes AL_STATIC). If bufferID = 0,
// no buffer is attached and the source becomes of type AL_UNDETERMINED. Since the
// stopping process cannot be entirely accomplished during the alSourceStop() call,
// sources called to stop but not properly stopped yet can have their buffer queue
// removed (through condition m_postResetState == AL_STOPPED).

ALenum ALsource::SetBuffer(ALint bufferID)
{       			
	if(m_playbackState == AL_INITIAL || m_playbackState == AL_STOPPED ||
	   m_postResetState == AL_STOPPED)
	{
     	if(bufferID >= 0)
		{			
			DetachAllBuffers();		
			AttachStaticBuffer(bufferID);			
		}	
		else
		{
			return(AL_INVALID_VALUE); // Invalid buffer ID.
		}
	}
	else
	{
		return(AL_INVALID_OPERATION);
	}
	
	return(AL_NO_ERROR);
}



// Method 'SetBufferAsProcessed()' sets the first unprocessed buffer as PROCESSED
// and then assigns the next unprocessed buffer (if any) to 'm_firstUnprocessedBuffer'.
void ALsource::SetBufferAsProcessed(void)
{		
	if(m_firstUnprocessedBuffer)
	{
		ALboolean isUnprocessedBufferFound = AL_FALSE;
		m_firstUnprocessedBuffer->m_bufferState = PROCESSED;
		m_nbProcessedBuffers++;
		m_cursorPosition = 0;	// Set cursor position to 0 even if no unprocessed buffer found.
		
		// If there is still an unprocessed buffer, find the first one.
		if(m_nbProcessedBuffers < m_nbQueuedBuffers)
		{
			ALbufferlistitem *currentListItem = m_firstUnprocessedBuffer->m_pNext;
			m_firstUnprocessedBuffer = NULL;
									
			ALuint i = 0;
			
			while(!isUnprocessedBufferFound && (i < m_nbListItems))
			{													
				if((currentListItem != AL_NONE) && (currentListItem->m_bufferState != PROCESSED))
				{
					m_firstUnprocessedBuffer = currentListItem;					
					isUnprocessedBufferFound = AL_TRUE;
				}			
				else
				{					
					currentListItem = currentListItem->m_pNext;
				}
				i++;
			}
		}
		else
		{
			m_firstUnprocessedBuffer = NULL;
		}								
	}		
}



void ALsource::SetBuffers(Buffers *buffers)
{
	s_pBuffers = buffers;
}



void ALsource::SetBuffersFormat(ALenum format)
{
	m_buffersFormat = format;
}



void ALsource::SetBuffersFrequency(ALsizei frequency)
{
	m_buffersFrequency = frequency;
}



void ALsource::SetChannelStatus(ALshort channel, ALuint status)
{
	m_pChannelsStatus[channel] = status;	
}



void ALsource::SetConeInnerAngle(ALfloat angle)
{
	m_coneInnerAngle = angle;
	
	if(m_coneInnerAngle > 360.0f)
	{
		m_coneInnerAngle = 360.0f;
	}
	else if(m_coneInnerAngle < 0.0f)
	{
		m_coneInnerAngle = 0.0f;
	}
}



void ALsource::SetConeOuterAngle(ALfloat angle)
{
	m_coneOuterAngle = angle;
	
	if(m_coneOuterAngle > 360.0f)
	{
		m_coneOuterAngle = 360.0f;
	}
	else if(m_coneOuterAngle < 0.0f)
	{
		m_coneOuterAngle = 0.0f;
	}
}



void ALsource::SetConeOuterGain(ALfloat gain)
{
	m_coneOuterGain = gain;
	
	if(m_coneOuterGain > 1.0f)
	{
		m_coneOuterGain = 1.0f;
	}
	else if(m_coneOuterGain < 0.0f)
	{
		m_coneOuterGain = 0.0f;
	}
}

	
	
void ALsource::SetCursorPosition(ALuint cursorPosition)
{
	m_cursorPosition = cursorPosition;	
}



void ALsource::SetDirection(ALfloat x_direction, ALfloat y_direction, ALfloat z_direction)
{
	m_direction.m_x = x_direction;
	m_direction.m_y = y_direction;
	m_direction.m_z = z_direction;		
}	
	
	
	
void ALsource::SetExistenceStatus(ALuint status)
{
	m_existenceStatus = status;
}



void ALsource::SetGain(ALfloat gain)
{
	if(gain >= 0.0f)
	{ 
		m_gain = gain;
	}
}



void ALsource::SetLoopState(ALboolean state)
{
	m_isSourceLooping = state;
}



void ALsource::SetMaxDistance(ALfloat maxDistance)
{	
	if(maxDistance < 0.0f)
	{
		m_maxDistance = 0.0f;
	}	
	else
	{
		m_maxDistance = maxDistance;
	}
}



void ALsource::SetMaxGain(ALfloat maxGain)
{
	if(maxGain < 0.0f)
	{
		m_maxGain = 0.0f;
	}
	else if(maxGain > 1.0f)
	{
		m_maxGain = 1.0f;
	}
	else
	{
		m_maxGain = maxGain;
	}
}



void ALsource::SetMinGain(ALfloat minGain)
{
	if(minGain < 0.0f)
	{
		m_minGain = 0.0f;
	}
	else if(minGain > 1.0f)
	{		
		m_minGain = 1.0f;
	}
	else
	{
		m_minGain = minGain;
	}
}



void ALsource::SetNext(ALsource *source)
{
	m_pNext = source;
}



#ifdef PLATFORM_WII
void ALsource::SetOutputState(ALshort outputID, ALshort state)
{
	if(outputID < AL_NB_OUTPUTS)
	{
		m_pOutputsStates[outputID] = state;
	}
}
#endif



void ALsource::SetPitch(ALfloat pitch)
{	
	if(pitch < SOURCE_MIN_PITCH)
	{	
		m_pitch = SOURCE_MIN_PITCH;
	}
	else
	{
		m_pitch = pitch;
	}

	m_effectivePitch = m_pitch * (ALfloat) m_buffersFrequency / (ALfloat) PLATFORM_SAMPLING_RATE;	
}



// Method 'SetPlaybackState()' manages the transitions between source's playback states
// (AL_INITIAL, AL_PLAYING, AL_PAUSED and AL_STOPPED). It is important to note that PAUSE
// and STOP processes are not done instantaneously to make sure that data provided to the
// voice buffers has been completely read before stopping playback. It is therefore possible
// that a call to another state (e.g. AL_PLAYING) is done before this process is over. The
// method makes sure that in such a case, PAUSE or STOP processes are properly terminated 
// with the use of variables 'm_intraPlaybackState' (= RESET_SOURCE at the beginning of PAUSE
// or STOP process and set to SOURCE_WAITING after process is done) and 'm_postResetState'
// (indicating the state to go after PAUSE or STOP process is done). 

void ALsource::SetPlaybackState(ALenum state)
{								
	if((state == AL_PAUSED) && (m_playbackState == AL_PLAYING))
	{		
		m_playbackState = AL_PAUSED;
		m_intraPlaybackState = RESET_SOURCE;
		m_postResetState = AL_PAUSED;	
	}
	else if(state == AL_PLAYING)
	{
		if(m_playbackState == AL_STOPPED)
		{
			if(m_intraPlaybackState == SOURCE_WAITING) // Source is properly stopped.
			{
				Rewind();
				m_playbackState = AL_PLAYING;			
			}
			else // Source is in the process of being stopped.
			{
				m_postResetState = AL_PLAYING;
			}
		}
		else if(m_playbackState == AL_PLAYING)
		{
			Rewind();			
		}
		else if(m_playbackState == AL_PAUSED)
		{
			if(m_intraPlaybackState == SOURCE_WAITING) // Source is properly paused.
			{				
				m_playbackState = AL_PLAYING;			
			}
			else // Source is in the process of being paused.
			{
				m_postResetState = AL_PLAYING;
			}
		}
		else // m_playbackState = AL_INITIAL
		{
			m_playbackState = AL_PLAYING;
		}	
	}	
	else if(state == AL_STOPPED)
	{
		if(m_playbackState == AL_PLAYING)
		{
			m_playbackState = AL_STOPPED;
			m_intraPlaybackState = RESET_SOURCE;
			m_postResetState = AL_STOPPED;			
		}
		else if(m_playbackState == AL_PAUSED)
		{
			if(m_intraPlaybackState == SOURCE_WAITING)	// Source is properly paused.
			{				
				m_playbackState = AL_STOPPED;			// See NOTE 2.						
			}
			else // Source is in the process of being paused.
			{
				// Let the pause process continue normally and stop it after.
				m_postResetState = AL_STOPPED;
			}
		}
		SetAllBuffersAsProcessed();				// See NOTE 1.
	}
	else if(state == AL_INITIAL) // Case when alSourceRewind() has been called.
	{
		if(m_playbackState == AL_PLAYING)		
		{
			// Stop source and put postResetState = AL_INITIAL so that it will be rewinded after.
			m_playbackState = AL_STOPPED;
			m_intraPlaybackState = RESET_SOURCE;
			m_postResetState = AL_INITIAL;
		}
		else if(m_playbackState == AL_PAUSED)
		{
			if(m_intraPlaybackState == SOURCE_WAITING) // Source is properly paused.
			{
				// Stop source and put postResetState = AL_INITIAL so that it will be rewinded after.
				m_playbackState = AL_STOPPED;
				m_intraPlaybackState = RESET_SOURCE;
				m_postResetState = AL_INITIAL;
			}
			else // Source is in the process of being paused.
			{
				m_postResetState = AL_INITIAL;
			}
		}
		else if(m_playbackState == AL_STOPPED)
		{
			if(m_intraPlaybackState == SOURCE_WAITING) // Source is properly stopped.
			{
				Rewind();
				m_playbackState = AL_INITIAL;								
			}
			else // Source is in the process of being stopped.
			{
				m_postResetState = AL_INITIAL;
			}
		}	
	}		
}



void ALsource::SetPosition(ALfloat x, ALfloat y, ALfloat z)
{
	m_position.m_x = x;
	m_position.m_y = y;
	m_position.m_z = z;	
}



void ALsource::SetRelativeToListener(ALboolean isRelativeToListener)
{
	m_isRelativeToListener = isRelativeToListener;
}



void ALsource::SetPostResetState(ALuint state)
{
	m_postResetState = state;
}



void ALsource::SetReferenceDistance(ALfloat distance)
{
	if(distance >= 0.0f)
	{
		m_referenceDistance = distance;
	}
	else
	{
		m_referenceDistance = 0.0f;
	}
}



void ALsource::SetRollOffFactor(ALfloat rollOffFactor)
{
	m_rollOffFactor = rollOffFactor;
	
	if(rollOffFactor < 0.0f)
	{
		m_rollOffFactor = 0.0f;
	}
	else if(rollOffFactor > 1.0f)
	{
		m_rollOffFactor = 1.0f;
	}
}



void ALsource::SetSourceVoiceLink(ALboolean isSourceLinkedToVoices)
{
	m_isSourceLinkedToVoices = isSourceLinkedToVoices;
}



void ALsource::SetType(ALint type)
{	
	m_type = type;
}



void ALsource::SetVelocity(ALfloat vx, ALfloat vy, ALfloat vz)
{
	m_velocity.m_x = vx;
	m_velocity.m_y = vy;
	m_velocity.m_z = vz;
}



ALenum ALsource::UnqueueBuffers(ALsizei nbBuffers, ALuint *bufferIDs)
{			
	if(nbBuffers <= (ALsizei) m_nbProcessedBuffers)
	{
		Buffer *currentBuffer;
		ALbufferlistitem *currentListItem;
		ALbufferlistitem *unqueuedListItem;
		ALuint k, i = 0;
		ALboolean isNewQueueBufferFound;
		ALsizei nbUnqueuedBuffers = 0;		

		currentListItem = m_pBufferQueue;
		while((nbUnqueuedBuffers < nbBuffers) && (i < m_nbListItems))
		{
			if((currentListItem->m_bufferID != AL_NONE) &&
				currentListItem->m_bufferState == PROCESSED)
			{
				bufferIDs[nbUnqueuedBuffers] = currentListItem->m_bufferID;
				unqueuedListItem = currentListItem;				
										
				currentBuffer = s_pBuffers->GetBuffer(currentListItem->m_bufferID);					
				currentBuffer->DecreaseReferenceCount();				
				
				// If the unqueued list item was the head of the queue, update the queue head.
				if(currentListItem->m_bufferID == m_pBufferQueue->m_bufferID)
				{			
					k = 0;
					currentListItem = currentListItem->m_pNext;
					// Set unqueued list item ID to zero here to make sure that it doesn't
					// become the new head of the queue !!!
					unqueuedListItem->m_bufferID = AL_NONE; 
					isNewQueueBufferFound = AL_FALSE;
					m_pBufferQueue = NULL;
												
					while(!isNewQueueBufferFound && (k < m_nbListItems))
					{
						if(currentListItem->m_bufferID != AL_NONE)
						{								
							isNewQueueBufferFound = AL_TRUE;						
							m_pBufferQueue = currentListItem;
						}
						else
						{
							currentListItem = currentListItem->m_pNext;
							k++;
						}
							
					}
				}
				else
				{
					unqueuedListItem->m_bufferID = AL_NONE; // Set unqueued list item ID to zero.
				}
				m_nbProcessedBuffers--;				
				m_nbQueuedBuffers--;
				nbUnqueuedBuffers++;
				currentListItem = unqueuedListItem->m_pNext;
			}
			else // Buffer is either already unqueued or not processed. Go to the next one.
			{
				currentListItem = currentListItem->m_pNext;
			}
			i++;
		}	// End while

		// If all buffers have been unqueued, source type becomes undetermined.
		if(m_nbQueuedBuffers == 0)
		{
			m_type = AL_UNDETERMINED;			
		}
		return(AL_NO_ERROR);
	}

    return(AL_INVALID_VALUE); // Buffers couldn't be unqueued because at least one is not processed.
}



// ----------------------------------------------------------------- //
// ---------------------- PRIVATE METHODS -------------------------- //
// ----------------------------------------------------------------- //

// Method 'VerifyBuffersIntegrity()' verifies that provided buffers have the same 
// format and frequency as other already queued source buffers. If there are no
// queued buffers, the method verifies that all provided buffers have the same format
// and frequency. This method assumes that source and bufferIDs are not NULL.

ALenum ALsource::VerifyBuffersIntegrity(ALsizei nbBuffers, const ALuint *bufferIDs)
{
	ALenum format;
	ALsizei frequency;
	Buffer *currentBuffer;		
	
	for(int i = 0; i < nbBuffers; i++)
	{		
		currentBuffer =	s_pBuffers->GetBuffer(bufferIDs[i]);
		if(currentBuffer)
		{
			if(i == 0)		
			{
				if(m_nbQueuedBuffers > 0)
				{
					format = m_buffersFormat;
					frequency = m_buffersFrequency;
				}
				else
				{
					format = currentBuffer->GetFormat();
					frequency = currentBuffer->GetFrequency();
				}
			}
				
			if((currentBuffer->GetFormat() != format) ||
			   (currentBuffer->GetFrequency() != frequency))
			{
				return(AL_INVALID_OPERATION);
			}
		}
		else
		{
			return(AL_INVALID_NAME);
		}
	}
	m_buffersFormat = format;
	m_buffersFrequency = frequency;
	return(AL_NO_ERROR);
}


// **************************************************************************************** //
// **************************************** NOTES ***************************************** //
// **************************************************************************************** //

// NOTE 1 : OpenAL specification says to set all buffers as processed when stopping a source.
//			"Removal of a given queue entry is not possible unless either the source is stopped
//			(in which case then entire queue is considered processed) ...". Note that the call
//			to SetAllBuffersAsProcessed() is done in SetPlaybackState() instead of being done in
//			FinalizeVoiceBufferReset() so that the calling application can unqueue all buffers after
//			a call to alSourceStop(). This doesn't impair the stopping process since queued buffers
//			are not used in this process (done in SourceToVoice::ResetVoiceBuffers()).
//
// NOTE 2 : In the case when a source is called to be stopped after being properly paused,
//			voice buffer resets are not performed since it has been done by the pause process.
//			The playback state is just put to AL_STOPPED and the source will be properly
//			stopped and disconnected from voices in the 'else if((playbackState == AL_STOPPED)'
//			condition of SourceVoiceLinks::UpdateVoices().
//