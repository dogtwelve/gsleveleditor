#include "Errors.h"


Errors::Errors(void)
{
	m_alcErrorCode = ALC_NO_ERROR;
}


Errors::~Errors(void)
{
}

	
ALenum Errors::GetALErrorCode(void)
{
	ALCcontext *context = ContextList::GetCurrentContext();
	if(context)
	{
		return(context->GetErrorCode());
	}
	
	// There is no context.
	return(AL_INVALID_OPERATION);	
}


ALCenum Errors::GetALCErrorCode(void)
{
	ALenum errorCode = m_alcErrorCode;
	m_alcErrorCode = ALC_NO_ERROR;			// Clear error code.	
	return(errorCode);
}

		
void Errors::SetALErrorCode(ALenum errorCode)
{
	ALCcontext *context = ContextList::GetCurrentContext();
	context->SetErrorCode(errorCode);
}


void Errors::SetALCErrorCode(ALCenum errorCode)
{
	// OpenAL specification states that an error code cannot be overwritten by another
	// except through clearing error code with alcGetError().
	if(m_alcErrorCode == ALC_NO_ERROR)
	{
		m_alcErrorCode = errorCode;
	}	
}