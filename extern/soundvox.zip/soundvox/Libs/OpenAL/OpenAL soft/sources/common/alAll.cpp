#include "CurrentAudioPlatform.h"

#ifdef PLATFORM_WII
	#include "Wii_Settings.h"	
#elif defined PLATFORM_PS3
	#include "PS3/PS3_Settings.h"	
#endif

#include "GeneralSettings.h"
#include "DeviceContext.h"
#include "SourceListener.h"
#include "ALManager.h"

#ifdef __cplusplus
	extern "C" {
#endif


// **************************************************************************************** //
// ***************************************** AL API *************************************** //
// **************************************************************************************** //


AL_API void AL_APIENTRY alBuffer3f(ALuint bid, ALenum param, ALfloat value1,
								   ALfloat value2, ALfloat value3)
{
	// There are no relevant buffer properties defined in OpenAL 1.1 which can be
	// affected by this call, but this function may be used by OpenAL extensions.
}								   


AL_API void AL_APIENTRY alBuffer3i(ALuint bid, ALenum param, ALint value1,
								   ALint value2, ALint value3)
{
	// There are no relevant buffer properties defined in OpenAL 1.1 which can be
	// affected by this call, but this function may be used by OpenAL extensions.
}


AL_API void AL_APIENTRY alBufferData(ALuint bid, ALenum format, const ALvoid* data,
									 ALsizei size, ALsizei freq)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->BufferData(bid, format, data, size, freq);
}


AL_API void AL_APIENTRY alBufferf(ALuint bid, ALenum param, ALfloat value)
{
	// There are no relevant buffer properties defined in OpenAL 1.1 which can be
	// affected by this call, but this function may be used by OpenAL extensions.
}


AL_API void AL_APIENTRY alBufferfv(ALuint bid, ALenum param, const ALfloat* values)
{
	// There are no relevant buffer properties defined in OpenAL 1.1 which can be
	// affected by this call, but this function may be used by OpenAL extensions.
}


AL_API void AL_APIENTRY alBufferi(ALuint bid, ALenum param, ALint value)
{
	// There are no relevant buffer properties defined in OpenAL 1.1 which can be
	// affected by this call, but this function may be used by OpenAL extensions.
}


AL_API void AL_APIENTRY alBufferiv(ALuint bid, ALenum param, const ALint* values)
{
	// There are no relevant buffer properties defined in OpenAL 1.1 which can be
	// affected by this call, but this function may be used by OpenAL extensions.
}


AL_API void AL_APIENTRY alDeleteBuffers(ALsizei n, const ALuint* buffers)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->DeleteBuffers(n, buffers);
}


AL_API void AL_APIENTRY alDeleteSources(ALsizei n, const ALuint* sources)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->DeleteSources(n, sources);
}


AL_API void AL_APIENTRY alDisable(ALenum capability)
{
	// There are no capabilities defined in OpenAL 1.1 to be used with this function, 
	// but it may be used by an extension.
}


AL_API void AL_APIENTRY alDistanceModel(ALenum distanceModel)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->DistanceModel(distanceModel);
}


AL_API void AL_APIENTRY alDopplerVelocity(ALfloat value)
{
	// This method is there only to be backward compatible with specification 1.0
	// of OpenAL. It is not implemented here. Use alSpeedOfSound() instead.
}


AL_API void AL_APIENTRY alDopplerFactor(ALfloat value)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->DopplerFactor(value);
}


AL_API void AL_APIENTRY alEnable(ALenum capability)
{
	// There are no capabilities defined in OpenAL 1.1 to be used with this function, 
	// but it may be used by an extension.
}


AL_API void AL_APIENTRY alGenBuffers(ALsizei n, ALuint* buffers)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->GenBuffers(n, buffers);
}


AL_API void AL_APIENTRY alGenSources(ALsizei n, ALuint* sources)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->GenSources(n, sources);
}


AL_API ALboolean AL_APIENTRY alGetBoolean(ALenum param)
{	
	if(alGetInteger(param) == 0)
	{
		return(AL_FALSE);
	}
	
	return(AL_TRUE);
}


AL_API void AL_APIENTRY alGetBooleanv(ALenum param, ALboolean* data)
{
	*data = alGetBoolean(param);
}


AL_API void AL_APIENTRY alGetBuffer3f(ALuint bid, ALenum param, ALfloat* value1,
									  ALfloat* value2, ALfloat* value3)
{
	// There are no relevant buffer properties defined in OpenAL 1.1 which can be
	// affected by this call, but this function may be used by OpenAL extensions.
}


AL_API void AL_APIENTRY alGetBuffer3i(ALuint bid, ALenum param, ALint* value1,
									  ALint* value2, ALint* value3)
{
	// There are no relevant buffer properties defined in OpenAL 1.1 which can be
	// affected by this call, but this function may be used by OpenAL extensions.
}


AL_API void AL_APIENTRY alGetBufferf(ALuint bid, ALenum param, ALfloat* value)
{
	// There are no relevant buffer properties defined in OpenAL 1.1 which can be
	// affected by this call, but this function may be used by OpenAL extensions.
}


AL_API void AL_APIENTRY alGetBufferfv(ALuint bid, ALenum param, ALfloat* values)
{
	// There are no relevant buffer properties defined in OpenAL 1.1 which can be
	// affected by this call, but this function may be used by OpenAL extensions.
}


AL_API void AL_APIENTRY alGetBufferi(ALuint bid, ALenum param, ALint* value)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->GetBufferi(bid, param, value);
}


AL_API void AL_APIENTRY alGetBufferiv(ALuint bid, ALenum param, ALint* values)
{
	// There are no relevant buffer properties defined in OpenAL 1.1 which can be
	// affected by this call, but this function may be used by OpenAL extensions.
}


AL_API ALdouble AL_APIENTRY alGetDouble(ALenum param)
{
	return((ALdouble) alGetFloat(param));
}


AL_API void AL_APIENTRY alGetDoublev(ALenum param, ALdouble* data)
{
	*data = alGetDouble(param);
}


AL_API ALenum AL_APIENTRY alGetEnumValue(const ALchar* ename)
{
	return(0);
}


ALAPI ALenum ALAPIENTRY alGetError(ALvoid)
{	
	ALManager *alManager = ALManager::GetInstance();
	return(alManager->GetALError());
}


AL_API ALfloat AL_APIENTRY alGetFloat(ALenum param)
{	
	ALManager *alManager = ALManager::GetInstance();
	return(alManager->GetFloat(param));
}


AL_API void AL_APIENTRY alGetFloatv( ALenum param, ALfloat* data )
{
	*data = alGetFloat(param);
}


AL_API ALint AL_APIENTRY alGetInteger(ALenum param)
{	
	ALManager *alManager = ALManager::GetInstance();
	return(alManager->GetALInteger(param));
}


AL_API void AL_APIENTRY alGetIntegerv(ALenum param, ALint* data)
{
	*data = alGetInteger(param);
}


AL_API void AL_APIENTRY alGetListener3f(ALenum param, ALfloat *value1, 
										ALfloat *value2, ALfloat *value3)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->GetListener3f(param, value1, value2, value3);
}


AL_API void AL_APIENTRY alGetListener3i(ALenum param, ALint *value1, ALint *value2, ALint *value3)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->GetListener3i(param, value1, value2, value3);
}


AL_API void AL_APIENTRY alGetListenerf(ALenum param, ALfloat* value)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->GetListenerf(param, value);
}


AL_API void AL_APIENTRY alGetListenerfv(ALenum param, ALfloat* values)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->GetListenerfv(param, values);
}


AL_API void AL_APIENTRY alGetListeneri( ALenum param, ALint* value )
{
	// There are no integer listener attributes defined for OpenAL 1.1,
	// but this function may be used by an extension.
}


AL_API void AL_APIENTRY alGetListeneriv(ALenum param, ALint* values)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->GetListeneriv(param, values);
}


AL_API void* AL_APIENTRY alGetProcAddress(const ALchar* fname)
{
	return(NULL);
}


AL_API void AL_APIENTRY alGetSource3f(ALuint sid, ALenum param,
									  ALfloat* value1, ALfloat* value2, ALfloat* value3)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->GetSource3f(sid, param, value1, value2, value3);
}


AL_API void AL_APIENTRY alGetSource3i(ALuint sid, ALenum param, ALint* value1,
									  ALint* value2, ALint* value3)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->GetSource3i(sid, param, value1, value2, value3);
}


AL_API void AL_APIENTRY alGetSourcef(ALuint sid, ALenum param, ALfloat* value)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->GetSourcef(sid, param, value);
}


AL_API void AL_APIENTRY alGetSourcefv(ALuint sid, ALenum param, ALfloat* values)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->GetSourcefv(sid, param, values);
}


AL_API void AL_APIENTRY alGetSourcei(ALuint sid, ALenum param, ALint* value)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->GetSourcei(sid, param, value);
}


AL_API void AL_APIENTRY alGetSourceiv(ALuint sid,  ALenum param, ALint* values)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->GetSourceiv(sid, param, values);
}


AL_API const ALchar* AL_APIENTRY alGetString(ALenum param)
{
	ALManager *alManager = ALManager::GetInstance();
	return(alManager->GetALString(param));
}


AL_API ALboolean AL_APIENTRY alIsBuffer(ALuint bid)
{
	ALManager *alManager = ALManager::GetInstance();
	return(alManager->IsBuffer(bid));
}


AL_API ALboolean AL_APIENTRY alIsEnabled( ALenum capability )
{
	// There are no capabilities defined in OpenAL 1.1 to be used with this function, 
	// but it may be used by an extension.

	return(AL_FALSE);
}


AL_API ALboolean AL_APIENTRY alIsExtensionPresent(const ALchar* extname)
{
	return(AL_FALSE);
}


ALboolean AL_APIENTRY alIsSource(ALuint sid)
{
	ALManager *alManager = ALManager::GetInstance();
	return(alManager->IsSource(sid));
}


AL_API void AL_APIENTRY alListener3f(ALenum param, ALfloat value1, ALfloat value2, ALfloat value3)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->Listener3f(param, value1, value2, value3);
}


AL_API void AL_APIENTRY alListener3i(ALenum param, ALint value1, ALint value2, ALint value3)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->Listener3i(param, value1, value2, value3);
}


AL_API void AL_APIENTRY alListenerf(ALenum param, ALfloat value)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->Listenerf(param, value);
}


AL_API void AL_APIENTRY alListenerfv(ALenum param, const ALfloat* values)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->Listenerfv(param, values);
}


AL_API void AL_APIENTRY alListeneri(ALenum param, ALint value)
{
	// There are no integer listener attributes defined for OpenAL 1.1,
	// but this function may be used by an extension.
}


AL_API void AL_APIENTRY alListeneriv(ALenum param, const ALint* values)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->Listeneriv(param, values);
}


AL_API void AL_APIENTRY alSource3f(ALuint sid, ALenum param,
								   ALfloat value1, ALfloat value2, ALfloat value3)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->Source3f(sid, param, value1, value2, value3);
}


AL_API void AL_APIENTRY alSource3i(ALuint sid, ALenum param,
								   ALint value1, ALint value2, ALint value3)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->Source3i(sid, param, value1, value2, value3);
}


AL_API void AL_APIENTRY alSourcef(ALuint sid, ALenum param, ALfloat value)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->Sourcef(sid, param, value);	
} 


AL_API void AL_APIENTRY alSourcefv(ALuint sid, ALenum param, const ALfloat* values)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->Sourcefv(sid, param, values);
}


AL_API void AL_APIENTRY alSourcei(ALuint sid, ALenum param, ALint value)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->Sourcei(sid, param, value);
}


AL_API void AL_APIENTRY alSourceiv(ALuint sid, ALenum param, const ALint* values)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->Sourceiv(sid, param, values);
}


AL_API void AL_APIENTRY alSourcePause(ALuint sid)
{	
	alSourcePausev(1, &sid);
}


AL_API void AL_APIENTRY alSourcePausev(ALsizei ns, const ALuint *sids)
{
	ALManager *alManager = ALManager::GetInstance();	
	alManager->SourcePausev(ns, sids);
}


AL_API void AL_APIENTRY alSourcePlay(ALuint sid)
{	
	alSourcePlayv(1, &sid);
}


AL_API void AL_APIENTRY alSourcePlayv(ALsizei ns, const ALuint *sids)
{
	ALManager *alManager = ALManager::GetInstance();	
	alManager->SourcePlayv(ns, sids);
}


AL_API void AL_APIENTRY alSourceQueueBuffers(ALuint sid, ALsizei numEntries, const ALuint *bids)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->SourceQueueBuffers(sid, numEntries, bids);
}


AL_API void AL_APIENTRY alSourceRewind(ALuint sid)
{
	alSourceRewindv(1, &sid);
}


AL_API void AL_APIENTRY alSourceRewindv(ALsizei ns, const ALuint *sids)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->SourceRewindv(ns, sids);
}


void AL_APIENTRY alSourceStop(ALuint sid)
{
	alSourceStopv(1, &sid);
}


AL_API void AL_APIENTRY alSourceStopv(ALsizei ns, const ALuint *sids)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->SourceStopv(ns, sids);
}


AL_API void AL_APIENTRY alSourceUnqueueBuffers(ALuint sid, ALsizei numEntries, ALuint *bids)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->SourceUnqueueBuffers(sid, numEntries, bids);
}


AL_API void AL_APIENTRY alSpeedOfSound(ALfloat value)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->SpeedOfSound(value);
}


// **************************************************************************************** //
// **************************************** ALC API *************************************** //
// **************************************************************************************** //


ALC_API ALCboolean ALC_APIENTRY alcCaptureCloseDevice(ALCdevice *device)
{
	// No capture device is provided by this implementation.
	return(ALC_FALSE);
}



ALC_API ALCdevice* ALC_APIENTRY alcCaptureOpenDevice(const ALCchar *devicename, ALCuint frequency,
													 ALCenum format, ALCsizei buffersize)
{
	// No capture device is provided by this implementation.
	return(NULL);
}



ALC_API void ALC_APIENTRY alcCaptureSamples(ALCdevice *device, ALCvoid *buffer, ALCsizei samples)
{
	// No capture device is provided by this implementation.	
}



ALC_API void ALC_APIENTRY alcCaptureStart(ALCdevice *device)
{
	// No capture device is provided by this implementation.	
}



ALC_API void ALC_APIENTRY alcCaptureStop(ALCdevice *device)
{
	// No capture device is provided by this implementation.	
}



ALC_API ALCboolean ALC_APIENTRY alcCloseDevice(ALCdevice *device)
{
	ALManager *alManager = ALManager::GetInstance();
	ALCboolean isDeviceClosed = alManager->CloseDevice(device);
	if(isDeviceClosed)
	{
		aldelete alManager;
	}
		
	return(isDeviceClosed);		
}



ALC_API ALCcontext * ALC_APIENTRY alcCreateContext(ALCdevice *device, const ALCint* attrlist)
{	
	ALManager *alManager = ALManager::GetInstance();
	return(alManager->CreateContext(device, attrlist));	
}



ALC_API void ALC_APIENTRY alcDestroyContext(ALCcontext *context)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->DestroyContext(context);
}



ALC_API ALCdevice* ALC_APIENTRY alcGetContextsDevice(ALCcontext *context)
{
	ALManager *alManager = ALManager::GetInstance();
	return(alManager->GetContextsDevice(context));
}


ALC_API ALCcontext *ALC_APIENTRY alcGetCurrentContext(void)
{
	ALManager *alManager = ALManager::GetInstance();
	return(alManager->GetCurrentContext());
}



ALC_API ALCenum ALC_APIENTRY alcGetEnumValue(ALCdevice *device, const ALCchar *enumname)
{
	ALManager *alManager = ALManager::GetInstance();
	return(alManager->GetALCEnumValue(device, enumname));	
}



ALC_API ALCenum ALC_APIENTRY alcGetError(ALCdevice *device)
{
	ALManager *alManager = ALManager::GetInstance();
	return(alManager->GetALCError(device));
}



ALC_API void ALC_APIENTRY alcGetIntegerv(ALCdevice *device, ALCenum param,
										 ALCsizei size, ALCint *data)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->GetALCIntegerv(device, param, size, data);
}



ALC_API void *ALC_APIENTRY alcGetProcAddress(ALCdevice *device, const ALCchar *funcname)
{
	// TODO : Implement if necessary
	return(NULL);
}



ALC_API const ALCchar * ALC_APIENTRY alcGetString(ALCdevice *device, ALCenum param)
{
	ALManager *alManager = ALManager::GetInstance();
	return(alManager->GetALCString(device, param));	
}



ALC_API ALCboolean ALC_APIENTRY alcIsExtensionPresent(ALCdevice *device, const ALCchar *extname)
{
	// TODO : Implement if extensions are to be added.
	return(ALC_FALSE);
}



ALC_API ALCboolean ALC_APIENTRY alcMakeContextCurrent(ALCcontext *context)
{	
	ALManager *alManager = ALManager::GetInstance();
	return(alManager->MakeContextCurrent(context));
}



ALC_API ALCdevice * ALC_APIENTRY alcOpenDevice(const ALCchar *devicename)
{	
	ALManager *alManager = ALManager::GetInstance();
	return(alManager->OpenDevice(devicename));
}



ALC_API void ALC_APIENTRY alcProcessContext(ALCcontext *context)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->ProcessContext(context);
}



ALC_API void ALC_APIENTRY alcSuspendContext(ALCcontext *context)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->SuspendContext(context);
}



// **************************************************************************************** //
// ************************************** AL_GEXT API ************************************* //
// **************************************************************************************** //

// Note : AL_GEXT contains Gameloft (G) extensions (EXT) to OpenAL. Declaration of those
//		  methods are found in 'al_gext.h'.


AL_API ALboolean AL_APIENTRY alBufferDataNoCopy(ALuint bufferID, ALenum format, const ALvoid* data,
											    ALsizei size, ALsizei frequency,
											    ALboolean deleteOldBuffer)
{
	ALManager *alManager = ALManager::GetInstance();
	return(alManager->BufferDataNoCopy(bufferID, format, data, size, frequency, deleteOldBuffer));
}


#ifdef PLATFORM_WII


AL_API void	AL_APIENTRY alEnableOutputUpdates(ALboolean enable)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->EnableOutputUpdates(enable);
}


AL_API ALboolean AL_APIENTRY alIsOutputOpen(ALshort outputID)
{
	ALManager *alManager = ALManager::GetInstance();
	return(alManager->IsOutputOpen(outputID));
}

AL_API ALint AL_APIENTRY alOutputClose(ALshort outputID)
{
	ALManager *alManager = ALManager::GetInstance();
	return(alManager->OutputClose(outputID));
}

AL_API void AL_APIENTRY alOutputMasterVolume(ALshort outputID, ALfloat volume)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->OutputMasterVolume(outputID, volume);
}


AL_API ALint AL_APIENTRY alOutputOpen(ALshort outputID)
{
	ALManager *alManager = ALManager::GetInstance();
	return(alManager->OutputOpen(outputID));
}


AL_API void AL_APIENTRY alSourceOutputState(ALuint sourceID, ALshort outputID, ALshort state)
{
	ALManager *alManager = ALManager::GetInstance();
	alManager->SourceOutputState(sourceID, outputID, state);		
}

#endif // PLATFORM_WII


#ifdef __cplusplus
	}				// closing brace for 'extern "C" {' line
#endif


// **************************************************************************************** //
// ************************* Memory allocation operators definitions ********************** //
// **************************************************************************************** //



void* operator new(size_t size, AlMemHint hint)
{
	return AlAlloc(size, hint);
}


void operator delete(void* ptr, AlMemHint hint)
{
	AlFree(ptr);
}


void* operator new[](size_t  size, AlMemHint hint)
{
	return AlAlloc(size, hint);
}


void operator delete[](void* ptr, AlMemHint hint)
{
	AlFree(ptr);
}


void* operator new(size_t size, AlMemHint hint, const char* filename, int line)
{
	return AlAlloc(size, hint, filename, line);
}


void operator delete(void* ptr, AlMemHint hint, const char* filename, int line)
{
	AlFree(ptr);
}


void* operator new[](size_t size, AlMemHint hint, const char* filename, int line)
{
	return AlAlloc(size, hint, filename, line);
}


void operator delete[](void* ptr, AlMemHint hint, const char* filename, int line)
{
	AlFree(ptr);
}