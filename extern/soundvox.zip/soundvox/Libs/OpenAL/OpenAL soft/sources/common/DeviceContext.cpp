#include "DeviceContext.h"

#ifdef PLATFORM_WII
	#include <cmath>
#endif

// **************************************************************************************** //
// ****************************** ALCdevice_struct structure ****************************** //
// **************************************************************************************** //


ALCdevice_struct::ALCdevice_struct(const char *deviceName)
{		
	// Get the name of the device in 'm_pName'.
	#ifdef PLATFORM_PS3
		ALint i = 0;
		while(deviceName[i] != 0)
		{
			m_pName[i] = deviceName[i];
			i++;
		}
		m_pName[i] = 0;
	#else
		std::strcpy(m_pName, deviceName);
	#endif	
	
	m_pNext = NULL;
}



ALCdevice_struct::~ALCdevice_struct(void)
{

}



ALCchar *ALCdevice_struct::GetDeviceName(void)
{
	return(m_pName);
}



ALCdevice_struct *ALCdevice_struct::GetNext(void)
{
	return(m_pNext);
}



void ALCdevice_struct::SetNext(ALCdevice_struct *device)
{	
	m_pNext = device;
}


// **************************************************************************************** //
// ************************************ Devices class ************************************* //
// **************************************************************************************** //


Devices::Devices(void)
{
	m_pFirst = NULL;
	m_nbDevices = 0;
}



Devices::~Devices(void)
{
	// Delete all devices
	ALCdevice *nextDevice = m_pFirst;
	ALCdevice *currentDevice = nextDevice;		
	
	while(currentDevice)	
	{
		nextDevice = currentDevice->GetNext();
		aldelete currentDevice;
		currentDevice = nextDevice;					
	}				
	
	m_pFirst = NULL;
}



ALCdevice *Devices::CreateDevice(const ALCchar *deviceName)
{
	ALCdevice_struct *device = alnew ALCdevice(deviceName);
	
	// Add new device to linked list.
	device->SetNext(m_pFirst);
	m_pFirst = device;
	m_nbDevices++;
	
	return(device);
}



ALCdevice *Devices::GetDevice(const ALCchar *devicename)
{
	ALCdevice *currentDevice = m_pFirst;
	
	while(currentDevice)
	{
		if(std::strcmp(devicename, currentDevice->GetDeviceName()) == 0)
		{
			return(currentDevice);
		}
		else
		{
			currentDevice = currentDevice->GetNext();
		}
	}	
	return(NULL);
} 


// **************************************************************************************** //
// ************************************ Context class ************************************* //
// **************************************************************************************** //


ALuint ALCcontext_struct::s_IDGenerator = 0;


ALCcontext_struct::ALCcontext_struct(ALCdevice *device, const ALCint* attributesList)
{
	m_pDevice = device;
	m_ID = s_IDGenerator++;
	m_pNext = NULL;
	m_errorCode = AL_NO_ERROR;	
	
	// Create hash table of sources.	
	m_pSources = alnew ALsource* [AL_SOURCES_TABLE_SIZE];	
	
	for(ALuint i = 0; i < AL_SOURCES_TABLE_SIZE; i++)
	{
		m_pSources[i] = NULL;		
	}
	
	// 3D positioning parameters.
	m_distanceModel = AL_INVERSE_DISTANCE_CLAMPED;
	m_dopplerFactor = 1.0f;
	m_speedOfSound = 343.3f;
	m_alteredSpeedOfSound = 343.3f;
	
	// Create the context's listener.
	m_pListener = alnew ALlistener();
}



ALCcontext_struct::~ALCcontext_struct(void)
{		
	// Delete all sources in hash table.
	ALsource *currentSource;
	ALsource *nextSource;
	
	for(ALuint i = 0; i < AL_SOURCES_TABLE_SIZE; i++)
	{			
		nextSource = m_pSources[i];
		currentSource = nextSource;
	
		while(currentSource)	
		{
			nextSource = currentSource->GetNext();
			aldelete currentSource;
			currentSource = nextSource;					
		}
	}			
	
	aldelete [] m_pSources;
	m_pSources = NULL;
	
	// Delete unique listener.
	aldelete m_pListener;
}



// Method 'DeleteSources()' tags the sources received in parameter 'sources' as
// 'DELETE_SOURCE'. After that, it passes through all sources and actually deletes
// those tagged as 'DELETE_SOURCE' and totally stopped (or in AL_INITIAL state). If
// a source to be deleted in the current call is not totally stopped when it's time
// to delete it, its deletion will be deferred at a further call (generally the next).
// The reason for this is to avoid synchronization problems between the current method
// and method 'SourceToVoice::ResetVoiceBuffer()' (responsible for stopping sources)
// that could result in a source never being deleted.

ALenum ALCcontext_struct::DeleteSources(ALsizei nbSources, const ALuint* sources)
{
	ALenum playbackState;
	ALsource *currentSource;
	ALsource *previousSource;

	ALenum error = ValidateSources(nbSources, sources);
	
	if(error == AL_NO_ERROR)
	{
		ALboolean isSourceFound;		
		ALuint tableEntry;				
			
		// Simply tag sources to be deleted.
		for(int i = 0; i < nbSources; i++)
		{
			isSourceFound = AL_FALSE;			
			tableEntry = sources[i] % AL_SOURCES_TABLE_SIZE;	
			currentSource = m_pSources[tableEntry];
			
			// Search source within current linked list and tag it as DELETE_SOURCE.
			while((!isSourceFound) && (currentSource != NULL))
			{				
				if(currentSource->GetID() == sources[i])
				{
					isSourceFound = AL_TRUE;					
					playbackState = currentSource->GetPlaybackState();					
														
					// If source is playing or paused, stop it properly before deleting it.
					if((playbackState == AL_PLAYING) || (playbackState == AL_PAUSED))
					{					
						currentSource->SetPlaybackState(AL_STOPPED);
					}
					else if(playbackState == AL_INITIAL)
					{
						// Force unqueuing of source buffers in case application forgot !
						currentSource->SetBuffer(0);
					}
				
					// Defer actual deletion of source.
					currentSource->SetExistenceStatus(DELETE_SOURCE);
				}
				
				currentSource = currentSource->GetNext();
			}
		}
	}
	
	// Delete all sources tagged as 'DELETE_SOURCE' that are not linked to voices.	
	for(ALuint i = 0; i < AL_SOURCES_TABLE_SIZE; i++)
	{			
		currentSource = m_pSources[i];		
	
		while(currentSource)	
		{			
			if(currentSource->GetExistenceStatus() == DELETE_SOURCE)
			{
			   	if(currentSource->IsSourceLinkedToVoices()) // Source cannot be deleted
			   	{			   		
			   		previousSource = currentSource;
					currentSource = currentSource->GetNext();	
			   	}
			   	else // Source is not linked to voices, delete it.
				{					
					if(currentSource == m_pSources[i])
					{
						m_pSources[i] = currentSource->GetNext();
						aldelete currentSource;
						currentSource = m_pSources[i];
					}
					else
					{
						previousSource->SetNext(currentSource->GetNext());
						aldelete currentSource;
						currentSource = previousSource->GetNext();
					}															
				}				
			}
			else // Source is not tagged as DELETE_SOURCE, go to next.
			{				
				previousSource = currentSource;
				currentSource = currentSource->GetNext();
			}					
		}
	}

	return(error);
}



// Method 'GenerateSources() generates 'nbSources' sources, inserts them into the
// hash table of sources and returns their IDs in array 'sources'.

ALenum ALCcontext_struct::GenerateSources(ALsizei nbSources, ALuint* sources)
{	
	ALsource *source;
	ALuint tableEntry;
	ALsource *sourceList;
	
	for(int i = 0; i < nbSources; i++)
	{
		source = alnew ALsource();
		
		if(source)
		{			
			sources[i] = source->GetID();
			
			// Insert source into hash table (as first entry of the linked list).			
			tableEntry = sources[i] % AL_SOURCES_TABLE_SIZE;	
			sourceList = m_pSources[tableEntry];
			if(sourceList)	
			{
				source->SetNext(sourceList);		
			}
			m_pSources[tableEntry] = source;				
		}
		else // Source could not be created.
		{
			sources[i] = 0;				// 0 is an invalid source number.
			return(AL_OUT_OF_MEMORY);
		}								
	}
	return(AL_NO_ERROR);
}



ALCdevice *ALCcontext_struct::GetDevice(void)
{
	return(m_pDevice);
}



ALenum ALCcontext_struct::GetDistanceModel(void)
{
	return(m_distanceModel);
}



ALfloat ALCcontext_struct::GetDopplerFactor(void)
{
	return(m_dopplerFactor);
}



ALenum ALCcontext_struct::GetErrorCode(void)
{
	ALenum errorCode = m_errorCode;
	m_errorCode = AL_NO_ERROR;			// Clear error code.
	return(errorCode);
}



ALuint	ALCcontext_struct::GetID(void)
{
	return(m_ID);
}



ALlistener *ALCcontext_struct::GetListener(void)
{
	return(m_pListener);
}
	
	
	
ALCcontext *ALCcontext_struct::GetNext(void)
{
	return(m_pNext);
}



ALsource *ALCcontext_struct::GetSource(ALuint sourceID)
{		
	if(sourceID > 0)
	{
		ALuint tableEntry = sourceID % AL_SOURCES_TABLE_SIZE;		
	
		ALsource *currentSource = m_pSources[tableEntry];
		
		while(currentSource)	
		{			
			if(currentSource->GetID() == sourceID)
			{				
				return(currentSource);
			}
			else
			{
				currentSource = currentSource->GetNext();
			}		
		}
	}
	
	return(NULL);
}



// Method 'GetSourceDirectionalGain()' calculates the source gain related to direction of
// propagation. The gain depends upon the angle between the source-to-listener and source
// direction vectors as follow:
//
// 1) If the angle is smaller than the cone inner angle, gain = 1.0f
// 2) If the angle is larger than the cone outer angle, gain = outConeGain.
// 3) If the angle is between the cone inner and outer angles, gain is interpolated
//	  between 1.0f and outConeGain.
//
// The angle between source-to-listener and sourceDirection vectors is calculted according to:
//
// angle = arccos(sqrt((slVector.sourceDirection)^2 / (slVector^2 * sourceDirection^2)),
//
// when scalar product slVector.sourceDirection is positive. For negative values of the
// scalar product, the calculated angle is transformed with "angle = 180 - angle;".
// Directional volume gain apply only on mono sources.

ALfloat ALCcontext_struct::GetSourceDirectionalGain(ALsource *source)
{
	// Get source direction vector
	ALdirection *sourceDirection = source->GetDirection();
	ALfloat sourceDirectionX = sourceDirection->m_x;
	ALfloat sourceDirectionY = sourceDirection->m_y;
	ALfloat sourceDirectionZ = sourceDirection->m_z;

	// Get inner cone angle
	ALfloat innerConeAngle = source->GetConeInnerAngle();
	
	// Calculate gain only if source is directional (but not omni-directional).
	if(innerConeAngle < 360.0f &&
	   (sourceDirectionX != 0.0f || 
	    sourceDirectionY != 0.0f || 
		sourceDirectionZ != 0.0f))
	{
		ALfloat angle;				// Angle between sourceDirection and sourceToListener vectors.
		ALfloat scalarProduct;
		ALfloat numerator;
		ALfloat denominator;
		ALfloat slVectorX;			// x component of source to listener vector.
		ALfloat slVectorY;			// y component of source to listener vector.
		ALfloat slVectorZ;			// z component of source to listener vector.
		ALfloat slVectorSquare;
		ALfloat sourceDirectionSquare;
		
		// Calculate source-to-listener vector
		ALposition *sourcePosition = source->GetPosition();
		ALposition *listenerPosition = m_pListener->GetPosition();

		if(source->IsRelativeToListener()) // Source position is relative to listener.
		{
			slVectorX = -sourcePosition->m_x;
			slVectorY = -sourcePosition->m_y;
			slVectorZ = -sourcePosition->m_z;
		}
		else // Source position is not relative to listener.
		{
			slVectorX = listenerPosition->m_x - sourcePosition->m_x;
			slVectorY = listenerPosition->m_y - sourcePosition->m_y;
			slVectorZ = listenerPosition->m_z - sourcePosition->m_z;
		}
	
		// Calculate square of scalar product between sourceToListener and sourceDirection vectors.
		scalarProduct = slVectorX * sourceDirectionX + slVectorY * sourceDirectionY +
						slVectorZ * sourceDirectionZ;
					
		ALfloat scalarProductSquare = scalarProduct * scalarProduct;	
		
		// Calculate square of length of source-to-listener vector.
		slVectorSquare = slVectorX * slVectorX + slVectorY * slVectorY + slVectorZ * slVectorZ;			
	
		// Calculate square of length of source direction vector.
		sourceDirectionSquare = sourceDirectionX * sourceDirectionX +
					  			sourceDirectionY * sourceDirectionY +
					  			sourceDirectionZ * sourceDirectionZ;	
		
		// Calculate the angle between source-to-listener and direction vectors (in degrees).
		angle = std::acos(std::sqrt(scalarProductSquare / (slVectorSquare * sourceDirectionSquare)));
		angle = angle * ANGLE_180_DEGREES / AL_PI; 	// Conversion from radians to degrees.

		// Convert angle when scalar product is negative (because argument of acos is positive).
		if(scalarProduct < 0.0f)
		{
			angle = ANGLE_180_DEGREES - angle;
		}
		
		// Get the angle between direction vector and inner cone (half the cone inner angle).
		ALfloat halfInConeAngle = innerConeAngle / 2.0f;
		
		if(angle > halfInConeAngle)
		{
			// Get the angle between direction vector and outer cone (half the cone outer angle).
			ALfloat halfOutConeAngle = source->GetConeOuterAngle() / 2.0f;
						
			ALfloat outConeGain = source->GetConeOuterGain();
			
			// If the source-to-listener vector is located between the inner and outer cones,
			// interpolate the gain between 1.0f and coneOuterGain.
			if(angle < halfOutConeAngle)
			{
				numerator = (halfOutConeAngle - angle) + outConeGain * (angle - halfInConeAngle);
				denominator = halfOutConeAngle - halfInConeAngle;
				if(denominator > 0.0f)
				{
					return(numerator / denominator);
				}
			}
			else // Angle is larger than halfOutConeAngle, gain = outConeGain.
			{
				return(outConeGain);
			}
		}
	}
	
	// If source is non-directional or if angle <= halfInConeAngle, gain = 1.0f.
	return(1.0f);
}



// Method 'GetSourceDistanceGain()' calculates source volume attenuation based upon
// distance between listener and source for all distance models defined in OpenAL.

ALfloat ALCcontext_struct::GetSourceDistanceGain(ALsource *source)
{
	ALfloat distanceX;
	ALfloat distanceY;
	ALfloat distanceZ;
	ALfloat distance;
	ALfloat numerator = 1.0f;
	ALfloat denominator = 1.0f;
	ALfloat attenuation;
		
	// Calculate source-listener distance
	ALposition *sourcePosition = source->GetPosition();
	ALposition *listenerPosition = m_pListener->GetPosition();

	if(source->IsRelativeToListener()) // Source position is relative to listener.
	{
		distanceX = sourcePosition->m_x;
		distanceY = sourcePosition->m_y;
		distanceZ = sourcePosition->m_z;
	}
	else // Source position is not relative to listener.
	{
		distanceX = sourcePosition->m_x - listenerPosition->m_x;
		distanceY = sourcePosition->m_y - listenerPosition->m_y;
		distanceZ = sourcePosition->m_z - listenerPosition->m_z;
	}
		
	distanceX *= distanceX;
	distanceY *= distanceY;
	distanceZ *= distanceZ;
	
	distance = std::sqrt(distanceX + distanceY + distanceZ);
			
	// Get source 3D parameters needed for attenuation calculations.
	ALfloat referenceDistance = source->GetReferenceDistance();
	ALfloat maxDistance = source->GetMaxDistance();
	ALfloat rollOffFactor = source->GetRollOffFactor();

	// Evaluate volume attenuation according to distance model.
	if(m_distanceModel == AL_INVERSE_DISTANCE)
	{
		denominator = distance - referenceDistance;
		denominator *= rollOffFactor;
		denominator += referenceDistance;
	
		if(denominator > 0.0f)
		{			
			return(referenceDistance / denominator);
		}
	}
	else if(m_distanceModel == AL_INVERSE_DISTANCE_CLAMPED)
	{
		if(distance < referenceDistance)
		{
			distance = referenceDistance;
		}
		else if(distance > maxDistance)
		{
			distance = maxDistance;
		}
		
		denominator = distance - referenceDistance;
		denominator *= rollOffFactor;
		denominator += referenceDistance;
	
		if(denominator > 0.0f)
		{			
			return(referenceDistance / denominator);
		}
	}
	else if(m_distanceModel == AL_LINEAR_DISTANCE)
	{
		numerator = (distance - referenceDistance) * rollOffFactor;
		denominator = maxDistance - referenceDistance;
		
		if(denominator > 0.0f)
		{
			attenuation = 1.0f - (numerator / denominator);
			if(attenuation < 0.0f)
			{
				attenuation = 0.0f;
			}
			return(attenuation);
		}
	}
	else if(m_distanceModel == AL_LINEAR_DISTANCE_CLAMPED)
	{
		if(distance < referenceDistance)
		{
			distance = referenceDistance;
		}
		else if(distance > maxDistance)
		{
			distance = maxDistance;
		}
		
		numerator = (distance - referenceDistance) * rollOffFactor;
		denominator = maxDistance - referenceDistance;
		
		if(denominator > 0.0f)
		{
			return(1.0f - (numerator / denominator));
		}		
	}
	else if(m_distanceModel == AL_EXPONENT_DISTANCE)
	{
		if(rollOffFactor > 0.0f && referenceDistance > 0.0f)
		{					
			attenuation = (distance / referenceDistance);
			return(std::pow(attenuation, -rollOffFactor));
		}					
	}
	else if(m_distanceModel == AL_EXPONENT_DISTANCE_CLAMPED)
	{	
		if(rollOffFactor > 0.0f && referenceDistance > 0.0f)
		{		
			if(distance < referenceDistance)
			{
				distance = referenceDistance;
			}
			else if(distance > maxDistance)
			{
				distance = maxDistance;
			}

			attenuation = (distance / referenceDistance);
			return(std::pow(attenuation, -rollOffFactor));
		}					
	}
	
	return 1.0f;
}



// Method 'GetSourcePanPosition()' returns a transformed version of the source position
// to be used for left-right voice panning. Since panning is performed in the left-right
// mode, only the 'x' coordinate of position is calculated. Transformation from the source
// absolute position to the returned value is performed according to the following steps:
//
// 1) The relative position between source and listener is calculated and the 'listener to
//	  source' vector is normalized.
// 2) Vector product between the listener's 'at' and 'up' orientation vectors is performed
//	  and the calculated vector is normalized. The generated vector is orthogonal to both
//	  the 'at' and 'up' vector and points to the right of the listener.
// 3) The normalized 'source to listener' vector is projected upon the vector calculated in
//	  item (2) by taking the scalar product of both vectors. This provides a value between
//	  -1.0 and 1.0 which forms the 'x' coordinate of the returned position vector.
//
// NOTE : When AL_SOURCE_RELATIVE is set to AL_TRUE, the 'at x up' vector equals (1, 0, 0).
// Therefore items (1) and (2) the whole procedure simply amounts to taking the 'x'
// coordinate of the position vector divided by its norm.

ALposition ALCcontext_struct::GetSourcePanPosition(ALsource *source)
{
	ALposition position;	

	// Get source and listener absolute positions.
	ALposition *sourcePosition = source->GetPosition();
	ALposition *listenerPosition = m_pListener->GetPosition();
		
	if(source->IsRelativeToListener())
	{
		// Calculate the norm of the source (relative) position vector.
		ALfloat positionNorm = std::sqrt(sourcePosition->m_x * sourcePosition->m_x +
										 sourcePosition->m_y * sourcePosition->m_y +
										 sourcePosition->m_z * sourcePosition->m_z);
		
		if(positionNorm > 0.0f)
		{
			position.m_x = sourcePosition->m_x / positionNorm;
		}
		else
		{
			position.m_x = 0.0f;
		}

	}
	else // Source position is not relative to listener.
	{
		// Get source position relative to listener.
		position.m_x = sourcePosition->m_x - listenerPosition->m_x;
		position.m_y = sourcePosition->m_y - listenerPosition->m_y;
		position.m_z = sourcePosition->m_z - listenerPosition->m_z;

		// Calculate the norm of the source (relative) position vector.
		ALfloat positionNorm = std::sqrt(position.m_x * position.m_x + position.m_y * position.m_y +
										 position.m_z * position.m_z);

		// Calculate vector product between 'at' and 'up' vectors
		ALdirection *listenerAt = m_pListener->GetAtOrientation();
		ALdirection *listenerUp = m_pListener->GetUpOrientation();
		ALfloat atUpVectorProductX = listenerAt->m_y * listenerUp->m_z - listenerAt->m_z * listenerUp->m_y;
		ALfloat atUpVectorProductY = listenerAt->m_z * listenerUp->m_x - listenerAt->m_x * listenerUp->m_z;
		ALfloat atUpVectorProductZ = listenerAt->m_x * listenerUp->m_y - listenerAt->m_y * listenerUp->m_x;

		// Calculate the norm of the ('at' x 'up') vector product.
		ALfloat atUpNorm = std::sqrt(atUpVectorProductX * atUpVectorProductX +
									 atUpVectorProductY * atUpVectorProductY +
									 atUpVectorProductZ * atUpVectorProductZ);

		if(positionNorm > 0.0f && atUpNorm > 0.0f)
		{
			// Normalize source (relative) position
			position.m_x /= positionNorm;
			position.m_y /= positionNorm;
			position.m_z /= positionNorm;
				
			// Normalize ('at' x 'up') vector product.
			atUpVectorProductX /= atUpNorm;
			atUpVectorProductY /= atUpNorm;
			atUpVectorProductZ /= atUpNorm;

			// Project the 'listener to source' vector upon the 'at' x 'up' vector product and provide
			// the result as the 'x' coordinate of the position vector.
			position.m_x = position.m_x * atUpVectorProductX + position.m_y * atUpVectorProductY +
						   position.m_z * atUpVectorProductZ;
		}
		else
		{
			position.m_x = 0.0f;
		}
	}

	position.m_y = 0.0f;
	position.m_z = 0.0f;	// Necessary since signal gets sometimes truncated if not.
	
	return(position);	
}


// Method 'GetSourcePitch()' calculates source pitch including doppler shift. The
// doppler shift calculation differs slightly from the one provided in the Open AL
// specification in order to minimize multiplications and divisions (but the result
// is the same). The implemented formula is :
//
// pitch = sourcePitch + dopplerShift
// where,
// dopplerShitf = sourcePitch * (psv - plv) / (speedOfSound / dopplerFactor * slVectorLength - psv)
// and
// psv = projected source velocity (projected on source to listener vector).
// plv = projected listener velocity (projected on source to listener vector).
// m_speedOfSound = speed of sound
// DopplerFactor = doppler factor.
// slVectorLength = magnitude of source to listener vector.

ALfloat ALCcontext_struct::GetSourcePitch(ALsource *source)
{			
	// Get source pitch (before doppler shift)
	ALfloat sourcePitch = source->GetEffectivePitch();

	// Apply doppler effect on mono sources.	
	if(source->GetNbChannels() == 1 && m_dopplerFactor > 0.0f)
	{
		ALfloat slVectorX;
		ALfloat slVectorY;
		ALfloat slVectorZ;
		ALfloat plv = 0.0f;
		ALfloat	psv;
	
		// Get source position and velocity
		ALposition *sourcePosition = source->GetPosition();
		ALvelocity *sourceVelocity = source->GetVelocity();
	
		// Calculate source to listener vector.
		if(source->IsRelativeToListener())
		{
			slVectorX = -sourcePosition->m_x;
			slVectorY = -sourcePosition->m_y;
			slVectorZ = -sourcePosition->m_z;
		}
		else // Source is not relative to listener.
		{
			// Get listener position and velocity
			ALposition *listenerPosition = m_pListener->GetPosition();
			ALvelocity *listenerVelocity = m_pListener->GetVelocity();

			slVectorX = listenerPosition->m_x - sourcePosition->m_x;
			slVectorY = listenerPosition->m_y - sourcePosition->m_y;
			slVectorZ = listenerPosition->m_z - sourcePosition->m_z;

			// Calculate projection of listener velocity on sourceToListener vector.
			plv = (listenerVelocity->m_x * slVectorX +
				   listenerVelocity->m_y * slVectorY +
	   			   listenerVelocity->m_z * slVectorZ);
		}

		// Calculate projection of source velocity on sourceToListener vector.
		psv = (sourceVelocity->m_x * slVectorX +
	   		   sourceVelocity->m_y * slVectorY +
	   		   sourceVelocity->m_z * slVectorZ);
	
		// Calculate the length of source to listener vector.
		ALfloat slVectorLength = std::sqrt(slVectorX * slVectorX +
										   slVectorY * slVectorY +
										   slVectorZ * slVectorZ);

		// Limit source and listener absolute velocities with the speedOfSound/dopplerFactor ratio.
		ALfloat speedOfSoundFactor = m_alteredSpeedOfSound * slVectorLength;
	
		// Limit projected listener velocity to speedOfSoundFactor
		if(plv > speedOfSoundFactor)
		{
			plv = speedOfSoundFactor;
		}
	
		// Calculate source pitch including doppler shift.	
		ALfloat numerator = sourcePitch * (psv - plv);
		ALfloat denominator = speedOfSoundFactor - psv;
	
		// Return calculated pitch only is denominator is larger than 0.
		if(denominator > 0.0f)
		{			
			return(sourcePitch + numerator / denominator);
		}
	}

	return(sourcePitch);
}



ALfloat ALCcontext_struct::GetSpeedOfSound(void)
{
	return(m_speedOfSound);
}



void ALCcontext_struct::SetDistanceModel(ALenum model)
{
	m_distanceModel = model;
}



void ALCcontext_struct::SetDopplerFactor(ALfloat dopplerFactor)
{
	m_dopplerFactor = dopplerFactor;
	if(m_dopplerFactor > 0.0f)
	{
		m_alteredSpeedOfSound = m_speedOfSound / m_dopplerFactor;
	}
}



void ALCcontext_struct::SetErrorCode(ALenum errorCode)
{	
	// OpenAL specification states that an error code cannot be overwritten by another
	// except through clearing error code with alGetError().
	if(m_errorCode == AL_NO_ERROR)
	{
		m_errorCode = errorCode;
	}
}



void ALCcontext_struct::SetNext(ALCcontext	*context)
{
	m_pNext = context;
}



void ALCcontext_struct::SetSpeedOfSound(ALfloat speed)
{
	m_speedOfSound = speed;
	if(m_dopplerFactor > 0.0f)
	{
		m_alteredSpeedOfSound = m_speedOfSound / m_dopplerFactor;
	}
}


// ----------------------------------------------------------------- //
// ---------------------- PRIVATE METHODS -------------------------- //
// ----------------------------------------------------------------- //


ALenum ALCcontext_struct::ValidateSources(ALsizei nbSources, const ALuint* sources)
{			
	if((nbSources > 0) && (sources != NULL))
	{	
		ALuint sourceID;
		ALsource *currentSource;
		ALboolean isSourceFound;
		ALuint tableEntry;	
		
		for(int i = 0; i < nbSources; i++)
		{									
			isSourceFound = AL_FALSE;			
			sourceID = sources[i];
			tableEntry = sourceID % AL_SOURCES_TABLE_SIZE;	
			currentSource = m_pSources[tableEntry];				
			
			while(!isSourceFound && (currentSource != NULL))
			{
				if(currentSource->GetID() == sourceID)
				{
					isSourceFound = AL_TRUE;				
				}
		
				currentSource = currentSource->GetNext();
			}
			if(!isSourceFound)
			{
				return(AL_INVALID_NAME);
			}
		}
		return(AL_NO_ERROR);
	}
	return(AL_INVALID_VALUE);
}


// **************************************************************************************** //
// ************************************* ContextList ************************************** //
// **************************************************************************************** //


ALCcontext *ContextList::s_pCurrentContext = NULL;


ContextList::ContextList(void)
{		
	m_pContexts = NULL;
}



ContextList::~ContextList(void)
{
	// Delete all contexts
	ALCcontext *nextContext = m_pContexts;
	ALCcontext *currentContext = nextContext;		
	
	while(currentContext)	
	{
		nextContext = currentContext->GetNext();
		aldelete currentContext;
		currentContext = nextContext;					
	}				
	
	m_pContexts = NULL;
}



ALCboolean ContextList::AreContextsMappedToDevice(ALCdevice_struct *device)
{
	if(m_pContexts)
	{
		ALCcontext *currentContext = m_pContexts;		
		
		while(currentContext)
		{
			if(currentContext->GetDevice() == device)
			{				
				return(AL_TRUE);
			}
			else
			{
				currentContext = currentContext->GetNext();
			}			
		}		
	}
	return(AL_FALSE);
}



ALCcontext *ContextList::CreateContext(ALCdevice *device, const ALCint* attributesList)
{
	ALCcontext *context = alnew ALCcontext_struct(device, attributesList);
	if(context)
	{
		context->SetNext(m_pContexts);
		m_pContexts = context;
	}
	
	return(context);
}



ALCcontext *ContextList::GetCurrentContext(void)
{
	return(s_pCurrentContext);
}



// Method 'IsContextValid()' verifies if the context received in parameter is in
// the contexts list and returns true if so.

ALCboolean ContextList::IsContextValid(ALCcontext *context)
{
	if(m_pContexts)
	{
		ALCcontext *currentContext = m_pContexts;
		ALuint contextID = context->GetID();
		
		while(currentContext)
		{
			if(currentContext->GetID() == contextID)
			{
				s_pCurrentContext = context;
				return(AL_TRUE);
			}
			else
			{
				currentContext = currentContext->GetNext();
			}			
		}		
	}
	
	return(AL_FALSE);
}



// Method 'DestroyContext()' removes the context received in parameter from
// the contexts list.

void ContextList::DestroyContext(ALCcontext *context)
{
	if(m_pContexts)
	{
		ALboolean isContextFound = AL_FALSE;		
		ALCcontext *currentContext = m_pContexts;
		ALCcontext *previousContext = m_pContexts;		
		
		while(isContextFound == AL_FALSE && currentContext != NULL)
		{
			if(currentContext == context)
			{
				isContextFound = AL_TRUE;
				if(currentContext == m_pContexts)
				{
					m_pContexts = currentContext->GetNext();
				}
				else
				{
					previousContext->SetNext(currentContext->GetNext());
				}
				aldelete currentContext;				
			}
			else
			{
				previousContext = currentContext;
				currentContext = currentContext->GetNext();
			}			
		}							
	}		
}



void ContextList::SetCurrentContext(ALCcontext *context)
{
	s_pCurrentContext = context;
}