#include "CurrentAudioPlatform.h"

#ifdef PLATFORM_WII
	#include "Wii_Interface.h"
#elif defined PLATFORM_PS3
	#include "PS3_Interface.h"
#endif

#include "ALManager.h"
#include "DeviceContext.h"
#include "SourceListener.h"
#include "SourceVoiceLinks.h"
#include "Buffers.h"


// **************************************************************************************** //
// ****************************** PlatformVoicesCallback class **************************** //
// **************************************************************************************** //

ALint PlatformVoicesCallback::s_nbInstances = 0;
ALMutex *PlatformVoicesCallback::s_pALMutex = NULL;
SourceVoiceLinks *PlatformVoicesCallback::s_pSourceVoiceLinks = NULL;


PlatformVoicesCallback::PlatformVoicesCallback(ALMutex *alMutex, SourceVoiceLinks *sourceVoiceLinks)
{	
	if(s_nbInstances == 0)
	{				
		s_pALMutex = alMutex;		
		s_pSourceVoiceLinks = sourceVoiceLinks;		

		#ifdef PLATFORM_WII
			// Register 3 ms audio callback.
			AXRegisterCallback(&VoicesUpdate);

			//OS alarms for wiimote sound
			OSCreateAlarm(&m_wiimoteAlarm);
			OSSetAlarmTag(&m_wiimoteAlarm, AL_ALARM_TAG);
			OSSetPeriodicAlarm(&m_wiimoteAlarm, OSGetTime(), WPAD_STRM_INTERVAL, WiimoteAudioCallback);
		#elif defined PLATFORM_PS3
			// Register 5 ms audio callback and start it.
			cellSurMixerSetNotifyCallback(&VoicesUpdate, NULL);
			cellSurMixerStart();
		#endif

		s_nbInstances = 1;
	}
}



PlatformVoicesCallback::~PlatformVoicesCallback(void)
{		
	#ifdef PLATFORM_WII
		OSCancelAlarms(AL_ALARM_TAG);	
	#elif defined PLATFORM_PS3		
		cellSurMixerPause(CELL_SURMIXER_CONT_PAUSE_ON_IMMEDIATE);		
		cellSurMixerRemoveNotifyCallback(&VoicesUpdate);	
	#endif

	s_nbInstances = 0;	
	s_pSourceVoiceLinks = NULL;
}



#ifdef PLATFORM_WII

void PlatformVoicesCallback::VoicesUpdate(void)
{	
	if(s_pSourceVoiceLinks)
	{
		s_pSourceVoiceLinks->UpdateVoices();
	}
}

void PlatformVoicesCallback::WiimoteAudioCallback(OSAlarm *alarm, OSContext *context)
{
	PlatformVoice::UpdateWiimoteSounds();
}

#elif defined PLATFORM_PS3

int PlatformVoicesCallback::VoicesUpdate(void *arg, uint32_t counter, uint32_t samples)
{			
	ScopedALMutexLock lock(s_pALMutex);
	if(s_pSourceVoiceLinks)
	{
		s_pSourceVoiceLinks->UpdateVoices();
	}
	return(0);
}

#endif



// **************************************************************************************** //
// ************************************ ALManager class *********************************** //
// **************************************************************************************** //


ALManager *ALManager::s_pInstance = NULL;


ALManager::ALManager(void)
{
	m_pALMutex = alnew ALMutex();
	m_pDevices = alnew Devices();
	
	#ifdef PLATFORM_WII
		m_pPreferredDevice = m_pDevices->CreateDevice("axDevice");
	#elif defined PLATFORM_PS3	
		m_pPreferredDevice = m_pDevices->CreateDevice("ps3Device");		
	#endif
	
 	m_pOpenedDevice = m_pPreferredDevice;
 	
 	m_pContexts = alnew ContextList();
 	
 	m_pBuffers = alnew Buffers();
 	ALsource::SetBuffers(m_pBuffers);
 		
 	PlatformVoice::Init();
 	
 	// Current context is provided to 'm_pSourceVoiceLinks' by MakeContextCurrent() calls.
	m_pSourceVoiceLinks = alnew SourceVoiceLinks(MAX_VOICES, NULL, m_pBuffers); 	
 	m_isVoicesCallbackStarted = AL_FALSE;
 	m_pError = alnew Errors(); 		
}



ALManager::~ALManager(void)
{
	m_pALMutex->Lock();

	aldelete m_pError;
	aldelete m_pSourceVoiceLinks;
	aldelete m_pBuffers;
	aldelete m_pContexts;
	aldelete m_pDevices;
	PlatformVoice::Clean();

	m_pALMutex->Unlock();

	aldelete m_pALMutex;
	m_pALMutex = NULL;
	s_pInstance = NULL;	
}



void ALManager::BufferData(ALuint bufferID, ALenum format, const ALvoid* data, 
						   ALsizei size, ALsizei freq)
{	
	ScopedALMutexLock lock(m_pALMutex);

	if(IsAudioFormatValid(format))
	{		
		if((data != NULL) && IsBufferSizeValid(format, size))
		{
			Buffer *buffer = m_pBuffers->GetBuffer(bufferID);
			
			if(buffer)
			{
				// Fill buffer with data only if it is not attached to a source.
				if(buffer->GetState() == UNUSED)
				{
					buffer->SetData(format, data, size, freq);
					return;
				}											
			}
			// Buffer is either in use or not found.
			m_pError->SetALErrorCode(AL_INVALID_VALUE);
		}
		else // Buffer size not conform to audio format.
		{
			m_pError->SetALErrorCode(AL_INVALID_VALUE);
		}
	}
	else // Audio format is invalid.
	{
		m_pError->SetALErrorCode(AL_INVALID_ENUM);
	}	
}



ALboolean ALManager::BufferDataNoCopy(ALuint bufferID, ALenum format, const ALvoid* data, 
									  ALsizei size, ALsizei freq, ALboolean deleteOldBuffer)
{	
	ScopedALMutexLock lock(m_pALMutex);

	if(IsAudioFormatValid(format))
	{		
		if((data != NULL) && IsBufferSizeValid(format, size))
		{
			Buffer *buffer = m_pBuffers->GetBuffer(bufferID);
			
			if(buffer)
			{
				// Fill buffer with data only if it is not attached to a source.
				if(buffer->GetState() == UNUSED)
				{
					return(buffer->SetDataNoCopy(format, data, size, freq, deleteOldBuffer));				
				}
			}
			// Buffer is either in use or not found.
			m_pError->SetALErrorCode(AL_INVALID_VALUE);			
		}
		else // Buffer size not conform to audio format.
		{
			m_pError->SetALErrorCode(AL_INVALID_VALUE);
		}
	}
	else // Audio format is invalid.
	{
		m_pError->SetALErrorCode(AL_INVALID_ENUM);
	}

	return(AL_FALSE);
}



ALCboolean ALManager::CloseDevice(ALCdevice *device)
{				
	ScopedALMutexLock lock(m_pALMutex);

	if(device != NULL && m_pOpenedDevice == device)
	{			
		// Verify that no context is mapped to that device.
		if(!m_pContexts->AreContextsMappedToDevice(device))
		{
			// Verify that all buffers have been deleted.
			if(m_pBuffers->AreAllBuffersDeleted())
			{					
				m_pOpenedDevice = NULL;					
				return(ALC_TRUE);
			}
		}		
	}
	else // Device doesn't exist or is not opened.
	{
		m_pError->SetALCErrorCode(ALC_INVALID_DEVICE);
	}					
	return(ALC_FALSE);
}



ALCcontext *ALManager::CreateContext(ALCdevice *device, const ALCint* attributesList)
{	
	ScopedALMutexLock lock(m_pALMutex);

	if(device)
	{		
		ALCcontext *newContext = m_pContexts->CreateContext(device, attributesList);
		if(newContext)
		{
			return(newContext);
		}
		else // A new context cannot be created.
		{
			m_pError->SetALCErrorCode(ALC_INVALID_VALUE);
		}
	}
	else
	{
		m_pError->SetALCErrorCode(ALC_INVALID_DEVICE);
	}
	
	return(NULL);
}



void ALManager::DeleteBuffers(ALsizei nbBuffers, const ALuint* buffers)
{			
	ScopedALMutexLock lock(m_pALMutex);

	ALenum deleteResult = m_pBuffers->DeleteBuffers(nbBuffers, buffers);
		
	if(deleteResult != AL_NO_ERROR)
	{
		m_pError->SetALErrorCode(deleteResult);
	}
}



void ALManager::DeleteSources(ALsizei nbSources, const ALuint* sources)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{
		ALenum deleteResult = m_pCurrentContext->DeleteSources(nbSources, sources);
		
		if(deleteResult != AL_NO_ERROR)
		{
			m_pError->SetALErrorCode(deleteResult);
		}		
	}
	else // There is no context to create the sources in.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::DestroyContext(ALCcontext *context)
{
	ScopedALMutexLock lock(m_pALMutex);	

	if(context)
	{
		if(context != m_pCurrentContext) // Cannot destroy the current context.
		{
			m_pContexts->DestroyContext(context);
			
			// If no more context attached to device, stop voices callbacks.
			if(!m_pContexts->AreContextsMappedToDevice(m_pOpenedDevice))
			{
				aldelete m_pVoicesCallback;				
				m_isVoicesCallbackStarted = AL_FALSE;				
			}			
		}		
	}
	else // Invalid context.
	{
		m_pError->SetALCErrorCode(ALC_INVALID_CONTEXT);
	}
}


// Method 'DistanceModel()' sets the distance model used to calculate source volume
// according to source-listener distance to the value received in parameter.

void ALManager::DistanceModel(ALenum model)
{
	ScopedALMutexLock lock(m_pALMutex);
	
	if(m_pCurrentContext)
	{
		if(model == AL_NONE ||
		   model == AL_INVERSE_DISTANCE || model == AL_INVERSE_DISTANCE_CLAMPED ||
		   model == AL_LINEAR_DISTANCE || model == AL_LINEAR_DISTANCE_CLAMPED ||
		   model == AL_EXPONENT_DISTANCE || model == AL_EXPONENT_DISTANCE_CLAMPED)
		{
			m_pCurrentContext->SetDistanceModel(model);
		}		
		else // Invalid model value.
		{
			m_pError->SetALErrorCode(AL_INVALID_VALUE);
		}
	}
	else // There is no context to create the sources in.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::DopplerFactor(ALfloat value)
{
	ScopedALMutexLock lock(m_pALMutex);
	
	if(m_pCurrentContext)
	{
		if(value >= 0.0f)
		{
			m_pCurrentContext->SetDopplerFactor(value);
		}		
		else // Invalid value.
		{
			m_pError->SetALErrorCode(AL_INVALID_VALUE);
		}
	}
	else // There is no context to create the sources in.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::GenBuffers(ALsizei nbBuffers, ALuint* buffers)
{
	ScopedALMutexLock lock(m_pALMutex);

	if((nbBuffers > 0) && (buffers != NULL))
	{		
		ALenum errorState = m_pBuffers->GenerateBuffers(nbBuffers, buffers);
		m_pError->SetALErrorCode(errorState);
	}
	else
	{
		m_pError->SetALErrorCode(AL_INVALID_VALUE);			
	}	
}



void ALManager::GenSources(ALsizei nbSources, ALuint* sources)
{	
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{
		if((nbSources > 0) && (sources != NULL))
		{		
			ALenum errorState = m_pCurrentContext->GenerateSources(nbSources, sources);						
			m_pError->SetALErrorCode(errorState);
		}
		else
		{
			m_pError->SetALErrorCode(AL_INVALID_VALUE);			
		}
	}
	else // There is no context to create the sources in.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



ALCenum ALManager::GetALCEnumValue(ALCdevice *device, const ALCchar *enumname)
{
	if(enumname)
	{
		// TODO : Implement if necessary
	}
	else
	{
		m_pError->SetALCErrorCode(ALC_INVALID_VALUE);		
	}
	return(AL_NONE);
}



ALCenum ALManager::GetALCError(ALCdevice *device)
{
	ScopedALMutexLock lock(m_pALMutex);

	return(m_pError->GetALCErrorCode());
}



void ALManager::GetALCIntegerv(ALCdevice *device, ALCenum parameter, ALCsizei size, ALCint *data)
{
	ScopedALMutexLock lock(m_pALMutex);
	
	// TODO : Implement if necessary
	if(device)
	{
		if(data != NULL && size > 0)
		{
			switch(parameter)
    		{
    			case ALC_FREQUENCY:					
					
       				break;
    			case ALC_REFRESH:
    			
       				break;
				case ALC_SYNC:
					
       				break;
       			case ALC_MONO_SOURCES:					
				
       				break;
    			case ALC_STEREO_SOURCES:
    			
       				break;
				case ALC_ATTRIBUTES_SIZE:
					
       				break;
       			case ALC_ALL_ATTRIBUTES:
					
       				break;
       			case ALC_MAJOR_VERSION:					
				
       				break;
    			case ALC_MINOR_VERSION:
    			
       				break;
				case ALC_CAPTURE_SAMPLES:
					
       				break;
    			default:
					m_pError->SetALCErrorCode(ALC_INVALID_ENUM); // Parameter is invalid.
       				break;
    		}
    	}
    	else
    	{
    		m_pError->SetALCErrorCode(ALC_INVALID_VALUE);
    	}
    }
    else
    {
    	m_pError->SetALCErrorCode(ALC_INVALID_DEVICE);
    }
}



// TODO : Finish implementing if necessary.
const ALCchar *ALManager::GetALCString(ALCdevice *device, ALCenum parameter)
{	
	ScopedALMutexLock lock(m_pALMutex);

	if(parameter == ALC_DEFAULT_DEVICE_SPECIFIER)
	{
		return(m_pPreferredDevice->GetDeviceName());
	}
	else if(parameter == ALC_CAPTURE_DEFAULT_DEVICE_SPECIFIER)
	{
		return("");
	}
	else if(parameter == ALC_DEVICE_SPECIFIER)
	{
		if(device)
		{
			return(device->GetDeviceName());
		}
		else
		{
			// TODO : Return a list of all devices.			
			return("");
		}
	}
	else if(parameter == ALC_CAPTURE_DEVICE_SPECIFIER)
	{
		return("");
	}
	else if(parameter == ALC_EXTENSIONS)
	{
		return("");
	}
	else
	{
		m_pError->SetALCErrorCode(ALC_INVALID_ENUM);
	}

	return("");
}



ALenum ALManager::GetALError(ALvoid)
{
	ScopedALMutexLock lock(m_pALMutex);
		
	return(m_pError->GetALErrorCode());
}



ALint ALManager::GetALInteger(ALenum parameter)
{
	ScopedALMutexLock lock(m_pALMutex);		
	
	if(m_pCurrentContext)
	{
		if(parameter == AL_DOPPLER_FACTOR)
		{
			return((ALint) m_pCurrentContext->GetDopplerFactor());
		}
		else if(parameter == AL_SPEED_OF_SOUND)
		{
			return((ALint) m_pCurrentContext->GetSpeedOfSound());
		}
		else if(parameter == AL_DISTANCE_MODEL)
		{
			return(m_pCurrentContext->GetDistanceModel());
		}
		else // Invalid parameter
		{
			m_pError->SetALErrorCode(AL_INVALID_ENUM);
		}
	}
	else // There is no current context.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
	return(-1);
}



// TODO : Implement if necessary.
const ALchar *ALManager::GetALString(ALenum parameter)
{	
	ScopedALMutexLock lock(m_pALMutex);

	if(parameter == AL_VENDOR)
	{
		return("");
	}
	else if(parameter == AL_VERSION)
	{
		return("");
	}
	else if(parameter == AL_RENDERER)
	{				
		return("");	
	}
	else if(parameter == AL_EXTENSIONS)
	{
		return("");
	}
	else
	{
		m_pError->SetALErrorCode(AL_INVALID_ENUM);
	}

	return("");
}



void ALManager::GetBufferi(ALuint bufferID, ALenum parameter, ALint* value)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(value)
	{
		Buffer *buffer = m_pBuffers->GetBuffer(bufferID);
		
		if(parameter == AL_FREQUENCY)
		{
			*value = buffer->GetFrequency();
		}
		else if(parameter == AL_BITS)
		{
			*value = buffer->GetSampleWidth();
		}
		else if(parameter == AL_CHANNELS)
		{
			*value = buffer->GetNbChannels();
		}
		else if(parameter == AL_SIZE)
		{
			*value = buffer->GetSize();
		}
		else // Invalid parameter
		{
			m_pError->SetALErrorCode(AL_INVALID_ENUM);
		}
	}
	else
	{
		m_pError->SetALErrorCode(AL_INVALID_VALUE);
	}
}



ALCdevice* ALManager::GetContextsDevice(ALCcontext *context)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pContexts->IsContextValid(context))
	{
		return(context->GetDevice());
	}
	else // Provided context is invalid.
	{
		m_pError->SetALCErrorCode(ALC_INVALID_CONTEXT);
	}
	return(NULL);
}



ALCcontext *ALManager::GetCurrentContext(void)
{
	ScopedALMutexLock lock(m_pALMutex);

	return(m_pCurrentContext);
}



ALManager* ALManager::GetInstance()
{
	if(!s_pInstance)
	{
		s_pInstance = alnew ALManager();
	}
	return s_pInstance;
}



ALfloat ALManager::GetFloat(ALenum parameter)
{
	ScopedALMutexLock lock(m_pALMutex);		
	
	if(m_pCurrentContext)
	{
		if(parameter == AL_DOPPLER_FACTOR)
		{
			return(m_pCurrentContext->GetDopplerFactor());
		}
		else if(parameter == AL_SPEED_OF_SOUND)
		{
			return(m_pCurrentContext->GetSpeedOfSound());
		}
		else if(parameter == AL_DISTANCE_MODEL)
		{
			return(m_pCurrentContext->GetDistanceModel());
		}
		else // Invalid parameter
		{
			m_pError->SetALErrorCode(AL_INVALID_ENUM);
		}
	}
	else // There is no current context.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
	
	return(0.0f);
}



void ALManager::GetListener3f(ALenum parameter, ALfloat *value1, ALfloat *value2, ALfloat *value3)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{
		if(value1 != NULL && value2 != NULL & value3 != NULL)
		{				
			ALlistener *listener = m_pCurrentContext->GetListener();
			ALvector *vector;

			if(parameter == AL_POSITION)
			{
				vector = listener->GetPosition();
				*value1 = vector->m_x;
				*value2 = vector->m_y;
				*value3 = vector->m_z;
			}
			else if(parameter == AL_VELOCITY)
			{
				vector = listener->GetVelocity();
				*value1 = vector->m_x;
				*value2 = vector->m_y;
				*value3 = vector->m_z;
			}								
			else
			{
				m_pError->SetALErrorCode(AL_INVALID_ENUM);
			}			
		}
		else // value parameter is NULL.
		{
			m_pError->SetALErrorCode(AL_INVALID_VALUE);
		}
	}
	else
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::GetListener3i(ALenum parameter, ALint *value1, ALint *value2, ALint *value3)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{
		if(value1 != NULL && value2 != NULL & value3 != NULL)
		{				
			ALlistener *listener = m_pCurrentContext->GetListener();
			ALvector *vector;

			if(parameter == AL_POSITION)
			{
				vector = listener->GetPosition();
				*value1 = (ALint) vector->m_x;
				*value2 = (ALint) vector->m_y;
				*value3 = (ALint) vector->m_z;
			}
			else if(parameter == AL_VELOCITY)
			{
				vector = listener->GetVelocity();
				*value1 = (ALint) vector->m_x;
				*value2 = (ALint) vector->m_y;
				*value3 = (ALint) vector->m_z;
			}								
			else
			{
				m_pError->SetALErrorCode(AL_INVALID_ENUM);
			}			
		}
		else // value parameter is NULL.
		{
			m_pError->SetALErrorCode(AL_INVALID_VALUE);
		}
	}
	else
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::GetListenerf(ALenum parameter, ALfloat* value)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{
		if(value)
		{				
			if(parameter == AL_GAIN)
			{
				*value = m_pCurrentContext->GetListener()->GetGain();
			}				
			else
			{
				m_pError->SetALErrorCode(AL_INVALID_ENUM);
			}			
		}
		else // value parameter is NULL.
		{
			m_pError->SetALErrorCode(AL_INVALID_VALUE);
		}
	}
	else
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::GetListenerfv(ALenum parameter, ALfloat* values)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{
		if(values)
		{				
			ALlistener *listener = m_pCurrentContext->GetListener();
			ALvector *vector;

			if(parameter == AL_POSITION)
			{
				vector = listener->GetPosition();
				values[0] = vector->m_x;
				values[1] = vector->m_y;
				values[2] = vector->m_z;
			}
			else if(parameter == AL_VELOCITY)
			{
				vector = listener->GetVelocity();
				values[0] = vector->m_x;
				values[1] = vector->m_y;
				values[2] = vector->m_z;
			}
			else if(parameter == AL_ORIENTATION)
			{
				vector = listener->GetAtOrientation();
				values[0] = vector->m_x;
				values[1] = vector->m_y;
				values[2] = vector->m_z;
				
				vector = listener->GetUpOrientation();
				values[3] = vector->m_x;
				values[4] = vector->m_y;
				values[5] = vector->m_z;
			}								
			else
			{
				m_pError->SetALErrorCode(AL_INVALID_ENUM);
			}			
		}
		else // value parameter is NULL.
		{
			m_pError->SetALErrorCode(AL_INVALID_VALUE);
		}
	}
	else
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::GetListeneriv(ALenum parameter, ALint* values)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{
		if(values)
		{				
			ALlistener *listener = m_pCurrentContext->GetListener();
			ALvector *vector;

			if(parameter == AL_POSITION)
			{
				vector = listener->GetPosition();
				values[0] = (ALint) vector->m_x;
				values[1] = (ALint) vector->m_y;
				values[2] = (ALint) vector->m_z;
			}
			else if(parameter == AL_VELOCITY)
			{
				vector = listener->GetVelocity();
				values[0] = (ALint) vector->m_x;
				values[1] = (ALint) vector->m_y;
				values[2] = (ALint) vector->m_z;
			}
			else if(parameter == AL_ORIENTATION)
			{
				vector = listener->GetAtOrientation();
				values[0] = (ALint) vector->m_x;
				values[1] = (ALint) vector->m_y;
				values[2] = (ALint) vector->m_z;
				
				vector = listener->GetUpOrientation();
				values[3] = (ALint) vector->m_x;
				values[4] = (ALint) vector->m_y;
				values[5] = (ALint) vector->m_z;
			}								
			else
			{
				m_pError->SetALErrorCode(AL_INVALID_ENUM);
			}			
		}
		else // value parameter is NULL.
		{
			m_pError->SetALErrorCode(AL_INVALID_VALUE);
		}
	}
	else
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::GetSource3f(ALuint sourceID, ALenum parameter, 
							ALfloat* value1, ALfloat* value2, ALfloat* value3)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{
		if(value1 != NULL && value2 != NULL & value3 != NULL)
		{
			ALsource *source = m_pCurrentContext->GetSource(sourceID);
			if(source)
			{			
				ALvector *vector;
				
				if(parameter == AL_POSITION)
				{
					vector = source->GetPosition();
					*value1 = vector->m_x;
					*value2 = vector->m_y;
					*value3 = vector->m_z;
				}
				else if(parameter == AL_VELOCITY)
				{					
					vector = source->GetVelocity();
					*value1 = vector->m_x;
					*value2 = vector->m_y;
					*value3 = vector->m_z;
				}
				else if(parameter == AL_DIRECTION)
				{
					vector = source->GetDirection();
					*value1 = vector->m_x;
					*value2 = vector->m_y;
					*value3 = vector->m_z;
				}						
				else
				{
					m_pError->SetALErrorCode(AL_INVALID_ENUM);
				}
			}
			else
			{
				m_pError->SetALErrorCode(AL_INVALID_NAME);
			}
		}
		else // value parameter is NULL.
		{
			m_pError->SetALErrorCode(AL_INVALID_VALUE);
		}
	}
	else
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::GetSource3i(ALuint sourceID, ALenum parameter, ALint* value1,
							ALint* value2, ALint* value3)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{
		if(value1 != NULL && value2 != NULL & value3 != NULL)
		{
			ALsource *source = m_pCurrentContext->GetSource(sourceID);
			if(source)
			{			
				ALvector *vector;
				
				if(parameter == AL_POSITION)
				{
					vector = source->GetPosition();
					*value1 = (ALint) vector->m_x;
					*value2 = (ALint) vector->m_y;
					*value3 = (ALint) vector->m_z;
				}
				else if(parameter == AL_VELOCITY)
				{					
					vector = source->GetVelocity();
					*value1 = (ALint) vector->m_x;
					*value2 = (ALint) vector->m_y;
					*value3 = (ALint) vector->m_z;
				}
				else if(parameter == AL_DIRECTION)
				{
					vector = source->GetDirection();
					*value1 = (ALint) vector->m_x;
					*value2 = (ALint) vector->m_y;
					*value3 = (ALint) vector->m_z;
				}						
				else
				{
					m_pError->SetALErrorCode(AL_INVALID_ENUM);
				}
			}
			else
			{
				m_pError->SetALErrorCode(AL_INVALID_NAME);
			}
		}
		else // value parameter is NULL.
		{
			m_pError->SetALErrorCode(AL_INVALID_VALUE);
		}
	}
	else
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}

}



void ALManager::GetSourcef(ALuint sourceID, ALenum parameter, ALfloat* value)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{
		if(value)
		{
			ALsource *source = m_pCurrentContext->GetSource(sourceID);
			
			if(source)
			{			
				switch(parameter)
    			{
					case AL_PITCH:
						*value = source->GetPitch();
       					break;
					case AL_GAIN:
						*value = source->GetGain();
       					break;
					case AL_MIN_GAIN:
						*value = source->GetMinGain();
       					break;
					case AL_MAX_GAIN:
						*value = source->GetMaxGain();
       					break;
					case AL_MAX_DISTANCE:
						*value = source->GetMaxDistance();
       					break;
					case AL_ROLLOFF_FACTOR:
						*value = source->GetRollOffFactor();
       					break;
					case AL_CONE_OUTER_GAIN:
						*value = source->GetConeOuterGain();
       					break;
					case AL_CONE_INNER_ANGLE:
						*value = source->GetConeInnerAngle();
       					break;
					case AL_CONE_OUTER_ANGLE:
						*value = source->GetConeOuterAngle();
       					break;
					case AL_REFERENCE_DISTANCE:
						*value = source->GetReferenceDistance();
       					break;			
					case AL_BYTE_OFFSET:
						*value = (ALfloat) source->GetByteOffset();
       					break;
       				case AL_SAMPLE_OFFSET:
						*value = (ALfloat) source->GetSampleOffset();	
       					break;
       				case AL_SEC_OFFSET:					
						*value = source->GetSecOffset();
       					break;
       				default:
						m_pError->SetALErrorCode(AL_INVALID_ENUM); // Parameter is invalid.
       					break;			
				}
			}
			else
			{
				m_pError->SetALErrorCode(AL_INVALID_NAME);
			}
		}
		else // value parameter is NULL.
		{
			m_pError->SetALErrorCode(AL_INVALID_VALUE);
		}
	}
	else
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::GetSourcefv(ALuint sourceID, ALenum parameter, ALfloat* values)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{
		if(values != NULL)
		{
			ALsource *source = m_pCurrentContext->GetSource(sourceID);
			if(source)
			{			
				ALvector *vector;
				
				if(parameter == AL_POSITION)
				{
					vector = source->GetPosition();
					values[0] = vector->m_x;
					values[1] = vector->m_y;
					values[2] = vector->m_z;
				}
				else if(parameter == AL_VELOCITY)
				{					
					vector = source->GetVelocity();
					values[0] = vector->m_x;
					values[1] = vector->m_y;
					values[2] = vector->m_z;
				}
				else if(parameter == AL_DIRECTION)
				{
					vector = source->GetDirection();
					values[0] = vector->m_x;
					values[1] = vector->m_y;
					values[2] = vector->m_z;
				}						
				else
				{
					m_pError->SetALErrorCode(AL_INVALID_ENUM);
				}
			}
			else
			{
				m_pError->SetALErrorCode(AL_INVALID_NAME);
			}
		}
		else // value parameter is NULL.
		{
			m_pError->SetALErrorCode(AL_INVALID_VALUE);
		}
	}
	else
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}




void ALManager::GetSourcei(ALuint sourceID, ALenum parameter, ALint* value)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{
		if(value)
		{
			ALsource *source = m_pCurrentContext->GetSource(sourceID);
			if(source)
			{			
				switch(parameter)
    			{
    				case AL_SOURCE_RELATIVE:					
						*value = (ALint) source->IsRelativeToListener();
       					break;
    				case AL_BUFFER:
    					*value = (ALint) source->GetFirstBufferID();
       					break;
					case AL_SOURCE_STATE:
						*value = (ALint) source->GetPlaybackState();
       					break;
       				case AL_BUFFERS_QUEUED:					
						*value = (ALint) source->GetNbQueuedBuffers();
       					break;
    				case AL_BUFFERS_PROCESSED:
    					*value = (ALint) source->GetNbProcessedBuffers();
       					break;
					case AL_BYTE_OFFSET:
						*value = source->GetByteOffset();
       					break;
       				case AL_SAMPLE_OFFSET:
						*value = source->GetSampleOffset();	
       					break;
       				case AL_SEC_OFFSET:					
						*value = (ALint) source->GetSecOffset();
       					break;
    				case AL_LOOPING:					
						*value = (ALint) source->IsSourceLooping();
       					break;
    				default:
						m_pError->SetALErrorCode(AL_INVALID_ENUM); // Parameter is invalid.
       					break;
    			}				
			}
			else
			{
				m_pError->SetALErrorCode(AL_INVALID_NAME);
			}
		}
		else // value parameter is NULL.
		{
			m_pError->SetALErrorCode(AL_INVALID_VALUE);
		}
	}
	else
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::GetSourceiv(ALuint sourceID,  ALenum parameter, ALint* values)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{
		if(values != NULL)
		{
			ALsource *source = m_pCurrentContext->GetSource(sourceID);
			if(source)
			{			
				ALvector *vector;
				
				if(parameter == AL_POSITION)
				{
					vector = source->GetPosition();
					values[0] = (ALint) vector->m_x;
					values[1] = (ALint) vector->m_y;
					values[2] = (ALint) vector->m_z;
				}
				else if(parameter == AL_VELOCITY)
				{					
					vector = source->GetVelocity();
					values[0] = (ALint) vector->m_x;
					values[1] = (ALint) vector->m_y;
					values[2] = (ALint) vector->m_z;
				}
				else if(parameter == AL_DIRECTION)
				{
					vector = source->GetDirection();
					values[0] = (ALint) vector->m_x;
					values[1] = (ALint) vector->m_y;
					values[2] = (ALint) vector->m_z;
				}						
				else
				{
					m_pError->SetALErrorCode(AL_INVALID_ENUM);
				}
			}
			else
			{
				m_pError->SetALErrorCode(AL_INVALID_NAME);
			}
		}
		else // value parameter is NULL.
		{
			m_pError->SetALErrorCode(AL_INVALID_VALUE);
		}
	}
	else
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



// In 'IsBuffer()', the separation in cases 'bufferID == 0' and 'bufferID > 0' is
// necessary since 'GetBuffer()' returns NULL either if 'bufferID = 0' or if 
// 'bufferID > 0' and buffer is not found.
ALboolean ALManager::IsBuffer(ALuint bufferID)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(bufferID > 0)
	{
		if(m_pBuffers->GetBuffer(bufferID))
		{
			return(AL_TRUE);
		}
	}
	else if(bufferID == 0) // The null buffer is accepted as a valid buffer.
	{
		return(AL_TRUE);
	}
	return(AL_FALSE);
}



ALboolean ALManager::IsSource(ALuint sourceID)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{	
		if(m_pCurrentContext->GetSource(sourceID))
		{
			return(AL_TRUE);
		}			
	}
	else // There is no context to create the sources in.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}	

	return(AL_FALSE);	
}



void ALManager::Listener3f(ALenum parameter, ALfloat value1, ALfloat value2, ALfloat value3)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{
		ALlistener *listener = m_pCurrentContext->GetListener();
		
        if(parameter == AL_POSITION)
        {					
			listener->SetPosition(value1, value2, value3);
        }
        else if(parameter == AL_VELOCITY)
        {
        	listener->SetVelocity(value1, value2, value3);
        }		
        else
        {
			m_pError->SetALErrorCode(AL_INVALID_ENUM); // Parameter is invalid.
        }       
	}
	else // There is no context to create the sources in.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::Listener3i(ALenum parameter, ALint value1, ALint value2, ALint value3)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{
		ALlistener *listener = m_pCurrentContext->GetListener();
	
       	if(parameter == AL_POSITION)
       	{					
			listener->SetPosition((ALfloat) value1, (ALfloat) value2, (ALfloat) value3);
       	}
       	else if(parameter == AL_VELOCITY)
       	{
       		listener->SetVelocity((ALfloat) value1, (ALfloat) value2, (ALfloat) value3);
       	}		
       	else
       	{
			m_pError->SetALErrorCode(AL_INVALID_ENUM); // Parameter is invalid.
       	}    
	}
	else // There is no context to create the sources in.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}

}



void ALManager::Listenerf(ALenum parameter, ALfloat value)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{		
		if(parameter == AL_GAIN)
		{
			if(value >= 0.0f && value <= 1.0f)
			{
				m_pCurrentContext->GetListener()->SetGain(value);
			}
			else
			{
				m_pError->SetALErrorCode(AL_INVALID_VALUE);            	
        	}    
		}
		else // Source ID is not valid.
		{
			m_pError->SetALErrorCode(AL_INVALID_ENUM);
		}	
	}
	else // There is no context to create the sources in.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}	
}



void ALManager::Listenerfv(ALenum parameter, const ALfloat* values)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{		
		if(values)
		{
			ALlistener *listener = m_pCurrentContext->GetListener();
			
			if(parameter == AL_POSITION)
			{
				listener->SetPosition(values[0], values[1], values[2]);
			}
			else if(parameter == AL_VELOCITY)
			{
				listener->SetVelocity(values[0], values[1], values[2]);
			}
			else if(parameter == AL_ORIENTATION)
			{
		    	// TODO : See if necessary to verify linear independence of 'at' and 'up' values.		    	
		    	listener->SetAtOrientation(values[0], values[1], values[2]);
		    	listener->SetUpOrientation(values[3], values[4], values[5]);
        	}    	
			else // Parameter is invalid.
			{
				m_pError->SetALErrorCode(AL_INVALID_ENUM);
			}
		}
		else
		{
			m_pError->SetALErrorCode(AL_INVALID_VALUE);
		}		
	}
	else // There is no context to create the sources in.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::Listeneriv(ALenum parameter, const ALint* values)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{		
		if(values)
		{
			ALlistener *listener = m_pCurrentContext->GetListener();
			
			if(parameter == AL_POSITION)
			{
				listener->SetPosition((ALfloat) values[0], (ALfloat) values[1], (ALfloat) values[2]);
			}
			else if(parameter == AL_VELOCITY)
			{
				listener->SetVelocity((ALfloat) values[0], (ALfloat) values[1], (ALfloat) values[2]);
			}
			else if(parameter == AL_ORIENTATION)
			{
		    	// TODO : See if necessary to verify linear independence of 'at' and 'up' values.		    	
		    	listener->SetAtOrientation((ALfloat) values[0], (ALfloat) values[1], (ALfloat) values[2]);
		    	listener->SetUpOrientation((ALfloat) values[3], (ALfloat) values[4], (ALfloat) values[5]);
        	}    	
			else // Parameter is invalid.
			{
				m_pError->SetALErrorCode(AL_INVALID_ENUM);
			}
		}
		else
		{
			m_pError->SetALErrorCode(AL_INVALID_VALUE);
		}		
	}
	else // There is no context to create the sources in.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



ALCboolean ALManager::MakeContextCurrent(ALCcontext *context)
{	
	ScopedALMutexLock lock(m_pALMutex);

	if(context == NULL || m_pContexts->IsContextValid(context))
	{
		m_pCurrentContext = context;
		m_pContexts->SetCurrentContext(context);
		return(ALC_TRUE);
	}
	
	m_pError->SetALCErrorCode(ALC_INVALID_CONTEXT);
	return(ALC_FALSE);			
}



ALCdevice *ALManager::OpenDevice(const ALCchar *deviceName)
{
	ScopedALMutexLock lock(m_pALMutex);

	ALCdevice *device;
		
	if(deviceName == NULL)
	{
		m_pOpenedDevice = m_pPreferredDevice;				
	}
	else
	{
		device = m_pDevices->GetDevice(deviceName);
		if(device)
		{
			m_pOpenedDevice = device;
		}
		else // Return NULL but don't change the opened device.
		{			
			return(NULL);
		}
	}

	return(m_pOpenedDevice);
}



void ALManager::ProcessContext(ALCcontext *context)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(context)
	{
		// TODO : Implement if necessary.	
	}
	else // Invalid context.
	{
		m_pError->SetALCErrorCode(ALC_INVALID_CONTEXT);
	}
}



void ALManager::Source3f(ALuint sourceID, ALenum parameter, ALfloat value1,
						 ALfloat value2, ALfloat value3)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{
		ALsource *source = m_pCurrentContext->GetSource(sourceID);
		if(source)
		{
			switch(parameter)
        	{
        		case AL_POSITION:					
					source->SetPosition(value1, value2, value3);
            		break;
        		case AL_VELOCITY:
        			source->SetVelocity(value1, value2, value3);
            		break;
				case AL_DIRECTION:
					source->SetDirection(value1, value2, value3);
            		break;
        		default:
					m_pError->SetALErrorCode(AL_INVALID_ENUM); // Parameter is invalid.
            		break;
        	}
		}
		else // Source ID is not valid.
		{
			m_pError->SetALErrorCode(AL_INVALID_NAME);
		}	
	}
	else // There is no context to create the sources in.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::Source3i(ALuint sourceID, ALenum parameter, ALint value1,
						 ALint value2, ALint value3)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{
		ALsource *source = m_pCurrentContext->GetSource(sourceID);
		if(source)
		{
			switch(parameter)
        	{
        		case AL_POSITION:					
					source->SetPosition((ALfloat) value1, (ALfloat) value2, (ALfloat) value3);
            		break;
        		case AL_VELOCITY:
        			source->SetVelocity((ALfloat) value1, (ALfloat) value2, (ALfloat) value3);
            		break;
				case AL_DIRECTION:
					source->SetDirection((ALfloat) value1, (ALfloat) value2, (ALfloat) value3);
            		break;
        		default:
					m_pError->SetALErrorCode(AL_INVALID_ENUM); // Parameter is invalid.
            		break;
        	}    
		}
		else // Source ID is not valid.
		{
			m_pError->SetALErrorCode(AL_INVALID_NAME);
		}	
	}
	else // There is no context to create the sources in.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}						 



void ALManager::Sourcef(ALuint sourceID, ALenum parameter, ALfloat value)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{	
		ALsource *source = m_pCurrentContext->GetSource(sourceID);
		if(source)
		{			
			switch(parameter)
        	{
        		case AL_PITCH:					
        			source->SetPitch(value);					
            		break;
        		case AL_GAIN:
        			source->SetGain(value);					
            		break;
				case AL_MIN_GAIN:
            		m_pCurrentContext->GetSource(sourceID)->SetMinGain(value);
            		break;
            	case AL_MAX_GAIN:
            		m_pCurrentContext->GetSource(sourceID)->SetMaxGain(value);
            		break;
            	case AL_MAX_DISTANCE:
            		source->SetMaxDistance(value);         
            		break;
            	case AL_ROLLOFF_FACTOR:
            		source->SetRollOffFactor(value);           
            		break;
            	case AL_CONE_OUTER_GAIN:
            		source->SetConeOuterGain(value);     
            		break;
            	case AL_CONE_INNER_ANGLE:
            		source->SetConeInnerAngle(value);
            		break;
            	case AL_CONE_OUTER_ANGLE:
            		source->SetConeOuterAngle(value);          
            		break;
            	case AL_REFERENCE_DISTANCE: 
            		source->SetReferenceDistance(value);         
            		break;
        		default:
					m_pError->SetALErrorCode(AL_INVALID_ENUM); // Parameter is invalid.
            		break;
        	}    
		}
		else // Source ID is not valid.
		{
			m_pError->SetALErrorCode(AL_INVALID_NAME);
		}		
	}
	else // There is no current context.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}	
}



void ALManager::Sourcefv(ALuint sourceID, ALenum parameter, const ALfloat* values)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{		
		ALsource *source = m_pCurrentContext->GetSource(sourceID);
		if(source)
		{
			if(values)
			{						
				if(parameter == AL_POSITION)
				{
					source->SetPosition(values[0], values[1], values[2]);
				}
				else if(parameter == AL_VELOCITY)
				{
					source->SetVelocity(values[0], values[1], values[2]);
				}
				else if(parameter == AL_DIRECTION)
				{
		    		source->SetDirection(values[0], values[1], values[2]);
        		}    	
				else // Parameter is invalid.
				{
					m_pError->SetALErrorCode(AL_INVALID_ENUM);
				}
			}				
			else
			{
				m_pError->SetALErrorCode(AL_INVALID_VALUE);
			}
		}
		else // Source ID is not valid.
		{
			m_pError->SetALErrorCode(AL_INVALID_NAME);
		}		
	}
	else // There is no context to create the sources in.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}


}



void ALManager::Sourcei(ALuint sourceID, ALenum parameter, ALint value)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{
		ALsource *source = m_pCurrentContext->GetSource(sourceID);
		if(source)
		{
			ALenum errorState;
			switch(parameter)
        	{
        		case AL_BUFFER:			
					errorState = source->SetBuffer(value);					
					if(errorState != AL_NO_ERROR)
					{
						m_pError->SetALErrorCode(errorState);
					}	
            		break;
        		case AL_SOURCE_RELATIVE:
        			source->SetRelativeToListener((ALboolean) value);      			        		
            		break;
				case AL_CONE_INNER_ANGLE:
				    source->SetConeInnerAngle((ALfloat) value);          		
            		break;            	
            	case AL_CONE_OUTER_ANGLE:
            	    source->SetConeOuterAngle((ALfloat) value);           
            		break;            	
            	case AL_LOOPING:
					source->SetLoopState((ALboolean) value);
            		break;
            	case AL_SOURCE_STATE:
            	 	// Source state should be queried only.  
            		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
            		break;
        		default:
					m_pError->SetALErrorCode(AL_INVALID_ENUM); // Parameter is invalid.
            		break;
        	}    
		}
		else // Source ID is not valid.
		{
			m_pError->SetALErrorCode(AL_INVALID_NAME);
		}	
	}
	else // There is no context to create the sources in.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::Sourceiv(ALuint sourceID, ALenum parameter, const ALint* values)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{
		ALsource *source = m_pCurrentContext->GetSource(sourceID);
		if(source)
		{
			switch(parameter)
        	{
        		case AL_POSITION:					
					source->SetPosition((ALfloat) values[0], (ALfloat) values[1], (ALfloat) values[2]);
            		break;
        		case AL_VELOCITY:
        			source->SetVelocity((ALfloat) values[0], (ALfloat) values[1], (ALfloat) values[2]);
            		break;
				case AL_DIRECTION:
					source->SetDirection((ALfloat) values[0], (ALfloat) values[1], (ALfloat) values[2]);
            		break;
        		default:
					m_pError->SetALErrorCode(AL_INVALID_ENUM); // Parameter is invalid.
            		break;
        	}    
		}
		else // Source ID is not valid.
		{
			m_pError->SetALErrorCode(AL_INVALID_NAME);
		}	
	}
	else // There is no context to create the sources in.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::SourcePausev(ALsizei nbSources, const ALuint *sourceIDs)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{				
		if((sourceIDs != NULL) && AreSourcesValid(nbSources, sourceIDs))
		{			
			ALsource *source;			
				
			for(ALsizei i = 0; i < nbSources; i++)
			{						
				source = m_pCurrentContext->GetSource(sourceIDs[i]);
				if(source)
				{											
					source->SetPlaybackState(AL_PAUSED);									
				}				
			}			
		}
		else // Some or all sources are invalid.
		{
			m_pError->SetALErrorCode(AL_INVALID_NAME);
		}
	}
	else // There is no current context.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::SourcePlayv(ALsizei nbSources, const ALuint *sourceIDs)
{			
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{				
		if((sourceIDs != NULL) && AreSourcesValid(nbSources, sourceIDs))
		{			
			// If voice callbacks are not started, start them.
			if(!m_isVoicesCallbackStarted)
			{
				m_pVoicesCallback = alnew PlatformVoicesCallback(m_pALMutex, m_pSourceVoiceLinks);
				m_isVoicesCallbackStarted = AL_TRUE;
			}			

			ALsource *source;

			for(ALsizei i = 0; i < nbSources; i++)
			{				
				source = m_pCurrentContext->GetSource(sourceIDs[i]);
						
				if(source)
				{
					if(source->IsSourceLinkedToVoices())
					{											
						source->SetPlaybackState(AL_PLAYING);				
					}
					else if(m_pSourceVoiceLinks->ConnectSourceToVoices(source))						
					{
						source->SetPlaybackState(AL_PLAYING);
					}					
				}				
			}								
		}
		else // Some or all sources are invalid.
		{
			m_pError->SetALErrorCode(AL_INVALID_NAME);
		}
	}
	else // There is no current context.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}	
}



void ALManager::SourceQueueBuffers(ALuint sourceID, ALsizei nbBuffers, const ALuint *bufferIDs)
{	
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{		
		ALsource * source = m_pCurrentContext->GetSource(sourceID);
		
		if(source)
		{		
			if(source->GetType() != AL_STATIC)
			{				
				if((bufferIDs != NULL) && (nbBuffers >= 0))
				{															
					ALenum queueResult = source->QueueBuffers(nbBuffers, bufferIDs);					
											
					if(queueResult != AL_NO_ERROR)
					{	
						m_pError->SetALErrorCode(queueResult);
					}								
				}
				else
				{
					m_pError->SetALErrorCode(AL_INVALID_OPERATION);
				}				
			}
			else
			{
				m_pError->SetALErrorCode(AL_INVALID_OPERATION);
			}
		}
		else
		{
			m_pError->SetALErrorCode(AL_INVALID_NAME);
		}					
	}
	else
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::SourceRewindv(ALsizei nbSources, const ALuint *sourceIDs)
{
	ScopedALMutexLock lock(m_pALMutex);
	
	if(m_pCurrentContext)
	{		
		if((sourceIDs != NULL) && AreSourcesValid(nbSources, sourceIDs))
		{							
			ALsource *source;			
			
			for(ALsizei i = 0; i < nbSources; i++)
			{
				source = m_pCurrentContext->GetSource(sourceIDs[i]);
				if(source)
				{					
					source->SetPlaybackState(AL_INITIAL);													
				}				
			}				
		}
		else // Some or all sources are invalid.
		{
			m_pError->SetALErrorCode(AL_INVALID_NAME);
		}
	}
	else // There is no current context.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::SourceStopv(ALsizei nbSources, const ALuint *sourceIDs)
{	
	ScopedALMutexLock lock(m_pALMutex);
	
	if(m_pCurrentContext)
	{		
		if((sourceIDs != NULL) && AreSourcesValid(nbSources, sourceIDs))
		{							
			ALsource *source;			
			
			for(ALsizei i = 0; i < nbSources; i++)
			{
				source = m_pCurrentContext->GetSource(sourceIDs[i]);
				if(source)
				{						
					source->SetPlaybackState(AL_STOPPED);										
				}				
			}				
		}
		else // Some or all sources are invalid.
		{
			m_pError->SetALErrorCode(AL_INVALID_NAME);
		}
	}
	else // There is no current context.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::SourceUnqueueBuffers(ALuint sourceID, ALsizei nbBuffers, ALuint *bufferIDs)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{				
		ALsource * source = m_pCurrentContext->GetSource(sourceID);
		if(source)
		{
			if(source->GetType() == AL_STREAMING)
			{
				if((bufferIDs != NULL) && (nbBuffers > 0))
				{					
					ALenum unqueueResult = source->UnqueueBuffers(nbBuffers, bufferIDs);
					if(unqueueResult != AL_NO_ERROR )
					{
						m_pError->SetALErrorCode(unqueueResult);
					}			
				}
				else
				{
					m_pError->SetALErrorCode(AL_INVALID_OPERATION);
				}				
			}
			else
			{
				m_pError->SetALErrorCode(AL_INVALID_OPERATION);
			}
		}
		else
		{
			m_pError->SetALErrorCode(AL_INVALID_NAME);
		}				
	}
	else
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::SpeedOfSound(ALfloat value)
{
	ScopedALMutexLock lock(m_pALMutex);
	
	if(m_pCurrentContext)
	{
		if(value >= 0.0f)
		{
			m_pCurrentContext->SetSpeedOfSound(value);
		}		
		else // Invalid value.
		{
			m_pError->SetALErrorCode(AL_INVALID_VALUE);
		}
	}
	else // There is no context to create the sources in.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



void ALManager::SuspendContext(ALCcontext *context)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(context)
	{
		// TODO : Implement if necessary.		
	}
	else // Invalid context.
	{
		m_pError->SetALCErrorCode(ALC_INVALID_CONTEXT);
	}
}



// ----------------------------------------------------------------- //
// ---------------------- PRIVATE METHODS -------------------------- //
// ----------------------------------------------------------------- //


// 'AreSourcesValid()' assumes that current context is not NULL.
ALCboolean ALManager::AreSourcesValid(ALsizei nbSources, const ALuint *sourceIDs)
{		
	for(ALsizei i = 0; i < nbSources; i++)
	{		
		if(!(m_pCurrentContext->GetSource(sourceIDs[i])))
		{
			return(AL_FALSE);
		}			
	}
	return(AL_TRUE);
}


// Method 'IsBufferSizeValid()' verifies if provided buffer size and format are compatible
// using the following modulo optimization : x % y <-> x & (y - 1) if x >= 0 and y is a
// power of 2.

ALCboolean ALManager::IsBufferSizeValid(ALenum format, ALsizei size)
{
	if(size > 0)
	{		
		switch(format)
    	{
    		case AL_FORMAT_MONO16:					
				return((size & 1) == 0);
    		case AL_FORMAT_STEREO16:
    			return((size & 3) == 0);
       		#ifdef PLATFORM_PS3
				case AL_FORMAT_MONO32F:
					return((size & 3) == 0);       				
       			case AL_FORMAT_STEREO32F:					
					return((size & 7) == 0);       				
       		#endif
    		case AL_FORMAT_MONO8:
    			return(ALC_TRUE);       			
			case AL_FORMAT_STEREO8:
				return((size & 1) == 0);       			
       	}	
	}

	return(ALC_FALSE);
}



ALCboolean ALManager::IsAudioFormatValid(ALenum format)
{
	if(format >= AL_FORMAT_MONO8 && format <= AL_FORMAT_STEREO16)	
	{
		return(AL_TRUE);	
	}
	#ifdef PLATFORM_PS3
	else if(format == AL_FORMAT_MONO32F || format == AL_FORMAT_STEREO32F)
	{
		return(AL_TRUE);	
	}	
	#endif
	else
	{
		return(AL_FALSE);
	}
}


// ----------------------------------------------------------------- //
// --------------------- WII SPECIFIC METHODS ---------------------- //
// ----------------------------------------------------------------- //

#ifdef PLATFORM_WII

void ALManager::EnableOutputUpdates(ALboolean enable)
{
	ScopedALMutexLock lock(m_pALMutex);
	
	if(m_pCurrentContext)
	{
		PlatformVoice::EnableOutputUpdates(enable);
	}
	else // There is no context to create the sources in.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
}



ALboolean ALManager::IsOutputOpen(ALshort outputID)
{
	ScopedALMutexLock lock(m_pALMutex);

	ALboolean isOutputOpen = AL_FALSE;
	
	if(m_pOpenedDevice)
	{		
		isOutputOpen = PlatformVoice::IsOutputOpen(outputID);											
	}
	else // There is no opened device.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
	return(isOutputOpen);	
}



ALint ALManager::OutputClose(ALshort outputID)
{
	ScopedALMutexLock lock(m_pALMutex);

	ALint result = WPAD_ERR_NONE;
	
	if(m_pOpenedDevice)
	{		
		result = PlatformVoice::CloseOutput(outputID);											
	}
	else // There is no opened device.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
	return(result);	
}



void ALManager::OutputMasterVolume(ALshort outputID, ALfloat volume)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pOpenedDevice)
	{
		PlatformVoice::SetOutputMasterVolume(outputID, volume);											
	}
	else // There is no opened device.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}	
}



ALint ALManager::OutputOpen(ALshort outputID)
{
	ScopedALMutexLock lock(m_pALMutex);
	
	ALint result = WPAD_ERR_NONE;

	if(m_pOpenedDevice)
	{
		result = PlatformVoice::OpenOutput(outputID);											
	}
	else // There is no opened device.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}
	return(result);
}



void ALManager::SourceOutputState(ALuint sourceID, ALshort outputID, ALshort state)
{
	ScopedALMutexLock lock(m_pALMutex);

	if(m_pCurrentContext)
	{
		ALsource *source = m_pCurrentContext->GetSource(sourceID);
		if(source)
		{																		
			source->SetOutputState(outputID, state);													
		}
		else // Source ID is not valid.
		{
			m_pError->SetALErrorCode(AL_INVALID_NAME);
		}
	}
	else // There is no context to create the sources in.
	{
		m_pError->SetALErrorCode(AL_INVALID_OPERATION);
	}	
}

#endif

// **************************************************************************************** //
// **************************************** NOTES ***************************************** //
// **************************************************************************************** //


// NOTE 1 : There is some concurrence between the threads calling the OpenAl API and
//			the callback function (PlatformVoicesCallback::VoicesUpdate()) responsible
//			of transferring source buffer data into voice buffers. The main sources of
//			concurrence are:
//
// a) Management of the 'SourceVoiceLinks::m_pLinks' array containing links between sources
//	  and voices. This array is mainly accessed through the OpenAL API but also by the callback
//	  section via 'SourceVoiceLinks::DisconnectSourceFromVoices()'.
//
// b) Management of the sources queues (ALsource::m_pBufferQueue, ALsource::m_pItemListStart).
//	  These queues are mainly accessed through the OpenAL API but also by the callback section
//	  via SetBufferAsProcessed() and SetAllBuffersAsProcessed().
//
// c) Management of PlatformVoices::m_pVoiceStatus array containing the availability status
//	  of voices. This array is accessed by the OpenAL API through ALManager::SourcePlayv()
//	  and by the callback section call to SourceVoiceLinks::DisconnectSourceFromVoices().
//
//			Therefore, internal calls by methods of the OpenAL API (contained in alAll.cpp)
//			targeting one of the mentioned portions of code must desactivate interrupts
//			in order to prevent the callback function of interrupting the calling thread.
//			In order to minimize the time interval during which interrupts are disabled,
//			those code portions are mostly taken directly in methods of classes Alsource
//			and SourceVoiceLinks (instead of ALManager). Methods that must disable interrupts
//			are the following:
//
// 1) ALManager::GetSourcei()
// 2) ALManager::Source3f()
// 3) ALManager::Sourcef()
// 4) ALManager::Sourcei()
// 5) ALManager::SourceOutputState()
// 6) ALManager::SourcePausev()
// 7) ALManager::SourcePlayv()
// 8) ALManager::SourceStopv()
// 3) ALsource:: QueueBuffers().
// 4) ALsource::UnqueueBuffers().