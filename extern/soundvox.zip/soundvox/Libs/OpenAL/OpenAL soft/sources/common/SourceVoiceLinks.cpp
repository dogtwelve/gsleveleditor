#include "SourceVoiceLinks.h"
#include "ALManager.h"
#include <cstring>
#include <math.h>


// **************************************************************************************** //
// ********************************** SourceToVoice class ********************************* //
// **************************************************************************************** //


SourceToVoice::SourceToVoice(ALshort voiceID)
{
	m_pVoice = alnew PlatformVoice(voiceID);
	m_pSource = NULL;
	m_sourceID = 0;
}



SourceToVoice::~SourceToVoice(void)
{
	aldelete m_pVoice;
	// Sources must not be deleted here. They should be deleted in their own container
	// (which is the hash table 'm_pSources' of 'ALCcontext_struct' structure.
}



// Method 'Connect()' makes a connection between the source channel received in parameter
// and the (permanent) voice associated with the SourceToVoice object.

void SourceToVoice::Connect(ALsource *source, ALshort sourceChannel)
{
	if(source)
	{	
		m_pSource = source;
		m_sourceID = source->GetID();
		m_nbSourceChannels = source->GetNbChannels();
		m_sourceChannel = sourceChannel;
	}
}



void SourceToVoice::Disconnect(void)
{	
	m_pSource = NULL;	
	m_sourceID = 0;	
	
	// Don't put m_pVoice to NULL. The same voice is always associated with SourceToVoice.				
}



// Method 'FillVoiceBufferWithStaticSource()' transfers data from a unique 'static' source
// buffer into the voice buffer received in parameter. This method is used when data
// in source buffers is in short 16-bits format. Prefixes 'sb' and 'vb' are used within
// this method to respectively describe source buffers and voice buffer.

void SourceToVoice::FillVoiceBufferStatic(Buffers *sourceBuffers, ALshort *voiceBuffer)
{		
	ALuint k;							// Loop index in source buffers.
	ALuint sourceBufferID;			
	Buffer *sourceBuffer;	
	ALuint nbSourceSamplesLeft;			// Nb of remaining samples to read from source buffer.
	ALuint nbSourceBufferSamples;		// Total number of samples in the source buffer.
	ALuint sbCursorPosition;			// Source buffer initial cursor position (as an offset).		
	ALshort *sbStartPosition = NULL;	// Source buffer start read address.		
	ALuint startIndex, endIndex;
	ALuint nbVoiceSamplesNeeded;		// Total number of samples to write to voice buffer.
	ALuint nbSamplesToWrite;			// Nb of samples to write in a particular 'while' pass.
	ALuint sourceLoopIndex = 0;
	ALboolean isChannelDone = AL_FALSE; // AL_TRUE if buffer read for non-looping source.
		
	nbVoiceSamplesNeeded = m_pVoice->GetNbSamplesNeeded();
	ALuint nbWriteSamplesLeft = nbVoiceSamplesNeeded;
	ALuint nbExecutedChannels = m_pSource->GetNbExecutedChannels();		

	while(nbWriteSamplesLeft > 0)
	{					
		// Get the only source buffer (if it is not processed).
		sourceBufferID = m_pSource->GetUnprocessedBufferID(0);
		sourceBuffer = sourceBuffers->GetBuffer(sourceBufferID);
		
		if(!isChannelDone && (sourceBuffer != NULL))
		{										
			// Get the number of samples in the source buffer.
			nbSourceBufferSamples = sourceBuffer->GetNbSamples();
				
			// Get source buffer cursor position (as an offset in samples). For every
			// source channel, except the last executed, if more than one source buffer
			// is needed, the cursor position is incremented in the current method.
			if(sourceLoopIndex == 0)
			{								
				sbCursorPosition = m_pSource->GetCursorPosition();				
			}			
				
			// Determine how many samples have to be copied in the present 'while pass'.
			nbSourceSamplesLeft = nbSourceBufferSamples - sbCursorPosition;
			if(nbSourceSamplesLeft < nbWriteSamplesLeft)
			{
				nbSamplesToWrite = nbSourceSamplesLeft;
			}
			else
			{
				nbSamplesToWrite = nbWriteSamplesLeft;
			}
				
			// Determine the start index to write samples in voice buffer.
			startIndex = nbVoiceSamplesNeeded - nbWriteSamplesLeft;

			// Copy samples from source buffer to voice buffer.
			if(m_nbSourceChannels == 1)
			{	
				sbStartPosition = (ALshort *) sourceBuffer->GetMemory() + (sbCursorPosition);
				std::memcpy(voiceBuffer + startIndex, sbStartPosition, nbSamplesToWrite << 1);
			}
			else if(m_nbSourceChannels == 2)
			{
				sbStartPosition = (ALshort *) sourceBuffer->GetMemory() + (sbCursorPosition << 1);
				
				k = m_sourceChannel;			
				endIndex = startIndex + nbSamplesToWrite;				// In nb of samples.																					
			
				for(ALuint i = startIndex; i < endIndex; i++)
				{    					    								
   					voiceBuffer[i] = sbStartPosition[k]; 					
   					k += m_nbSourceChannels;    				    				 					
   				} 
			}

   	    	// Source channel has finished reading the current source buffer, but there
   	    	// are still some samples to write in voice buffer.
   			if(nbSourceSamplesLeft < nbWriteSamplesLeft)
   			{    				
				if(m_pSource->IsSourceLooping())
				{
					// If channel is the last to execute, set the source cursor position to 0.
					if(nbExecutedChannels == m_nbSourceChannels - 1)
   					{
						m_pSource->SetCursorPosition(0);
					}
					else // Cursor position is incremented in this method only.
					{
						sbCursorPosition = 0;	// Cursor starts at 0 in the next source buffer.
						sourceLoopIndex++;		// Continue looping.
					}						
				}
				else // Source is not looping
				{
					// If all channels have executed, stop the source.
					if(nbExecutedChannels == m_nbSourceChannels - 1)
   					{														
						if(m_pSource->GetPlaybackState() != AL_STOPPED)
						{						
							m_pSource->SetPlaybackState(AL_STOPPED);							
						}
					}						
					isChannelDone = AL_TRUE;
				}					
   			}
   			// Writing is finished but still some samples to read in source buffer.			  		
			else if(nbSourceSamplesLeft > nbWriteSamplesLeft)
			{													
				sbCursorPosition += nbSamplesToWrite;									

				// Set cursor position for source if the last channel has been written
				if(nbExecutedChannels == m_nbSourceChannels - 1)
				{					
					m_pSource->SetCursorPosition(sbCursorPosition);					
				}
				m_pSource->AddExecutedChannel();
			}
			else // Writing is finished and source buffer is done for current channel.
			{					
				if(m_pSource->IsSourceLooping())
				{
					if(nbExecutedChannels == m_nbSourceChannels - 1)
   					{    						
   						m_pSource->SetCursorPosition(0);
   					}	
				}
				else // Source is not looping
				{
					// If all channels have executed, stop the source.
					if(nbExecutedChannels == m_nbSourceChannels - 1)
   					{
						if(m_pSource->GetPlaybackState() != AL_STOPPED)
						{						
							m_pSource->SetPlaybackState(AL_STOPPED);							
						}
   					}						
				}
				m_pSource->AddExecutedChannel();
			}
			
			nbWriteSamplesLeft -= nbSamplesToWrite;		
		}
		else // No AL buffer available, fill the voice buffer with zeroes and stop the source.
		{						
			startIndex = nbVoiceSamplesNeeded - nbWriteSamplesLeft;

			// Copy samples from source buffer to voice buffer.
			if(m_nbSourceChannels == 1)
			{				
				std::memset(voiceBuffer + startIndex, 0, nbWriteSamplesLeft << 1);
			}
			else if(m_nbSourceChannels == 2)
			{
				std::memset(voiceBuffer + startIndex, 0, nbWriteSamplesLeft << 2);
			}			
    			
   			m_pSource->AddExecutedChannel();
   			nbWriteSamplesLeft = 0;

			// If all channels have executed, stop the source.
			if(nbExecutedChannels == m_nbSourceChannels - 1)
			{
				m_pSource->SetPlaybackState(AL_STOPPED);
			}
		}
	}		// End while
}



// Method 'FillVoiceBufferWithStaticSource()' transfers data from a unique 'static' source
// buffer into the voice buffer received in parameter. This method is used when data
// in source buffers is in float 32-bits format. Prefixes 'sb' and 'vb' are used within
// this method to respectively describe source buffers and voice buffer.

void SourceToVoice::FillVoiceBufferStatic(Buffers *sourceBuffers, ALfloat *voiceBuffer)
{		
	ALuint k;							// Loop index in source buffers.
	ALuint sourceBufferID;			
	Buffer *sourceBuffer;	
	ALuint nbSourceSamplesLeft;			// Nb of remaining samples to read from source buffer.
	ALuint nbSourceBufferSamples;		// Total number of samples in the source buffer.
	ALuint sbCursorPosition;			// Source buffer initial cursor position (as an offset).		
	ALfloat *sbStartPosition = NULL;	// Source buffer start read address.		
	ALuint startIndex, endIndex;
	ALuint nbVoiceSamplesNeeded;		// Total number of samples to write to voice buffer.
	ALuint nbSamplesToWrite;			// Nb of samples to write in a particular 'while' pass.
	ALuint sourceLoopIndex = 0;
	ALboolean isChannelDone = AL_FALSE; // AL_TRUE if buffer read for non-looping source.
		
	nbVoiceSamplesNeeded = m_pVoice->GetNbSamplesNeeded();
	ALuint nbWriteSamplesLeft = nbVoiceSamplesNeeded;
	ALuint nbExecutedChannels = m_pSource->GetNbExecutedChannels();		

	while(nbWriteSamplesLeft > 0)
	{					
		// Get the only source buffer (if it is not processed).
		sourceBufferID = m_pSource->GetUnprocessedBufferID(0);
		sourceBuffer = sourceBuffers->GetBuffer(sourceBufferID);
		
		if(!isChannelDone && (sourceBuffer != NULL))
		{										
			// Get the number of samples in the source buffer.
			nbSourceBufferSamples = sourceBuffer->GetNbSamples();
				
			// Get source buffer cursor position (as an offset in samples). For every
			// source channel, except the last executed, if more than one source buffer
			// is needed, the cursor position is incremented in the current method.
			if(sourceLoopIndex == 0)
			{								
				sbCursorPosition = m_pSource->GetCursorPosition();				
			}			
				
			// Determine how many samples have to be copied in the present 'while pass'.
			nbSourceSamplesLeft = nbSourceBufferSamples - sbCursorPosition;
			if(nbSourceSamplesLeft < nbWriteSamplesLeft)
			{
				nbSamplesToWrite = nbSourceSamplesLeft;
			}
			else
			{
				nbSamplesToWrite = nbWriteSamplesLeft;
			}
			
			// Determine the start index to write samples in voice buffer.
			startIndex = nbVoiceSamplesNeeded - nbWriteSamplesLeft;

			// Copy samples from source buffer to voice buffer.
			if(m_nbSourceChannels == 1)
			{	
				sbStartPosition = (ALfloat *) sourceBuffer->GetMemory() + sbCursorPosition;
				std::memcpy(voiceBuffer + startIndex, sbStartPosition, nbSamplesToWrite << 2);
			}
			else if(m_nbSourceChannels == 2)
			{
				sbStartPosition = (ALfloat *) sourceBuffer->GetMemory() + (sbCursorPosition << 1);
				
				k = m_sourceChannel;			
				endIndex = startIndex + nbSamplesToWrite;				// In nb of samples.																					
			
				for(ALuint i = startIndex; i < endIndex; i++)
				{    					    								
   					voiceBuffer[i] = sbStartPosition[k]; 					
   					k += m_nbSourceChannels;    				    				 					
   				} 
			}

   	    	// Source channel has finished reading the current source buffer, but there
   	    	// are still some samples to write in voice buffer.
   			if(nbSourceSamplesLeft < nbWriteSamplesLeft)
   			{    				
				if(m_pSource->IsSourceLooping())
				{
					// If channel is the last to execute, set the source cursor position to 0.
					if(nbExecutedChannels == m_nbSourceChannels - 1)
   					{
						m_pSource->SetCursorPosition(0);
					}
					else // Cursor position is incremented in this method only.
					{
						sbCursorPosition = 0;	// Cursor starts at 0 in the next source buffer.
						sourceLoopIndex++;		// Continue looping.
					}						
				}
				else // Source is not looping
				{
					// If all channels have executed, stop the source.
					if(nbExecutedChannels == m_nbSourceChannels - 1)
   					{														
						if(m_pSource->GetPlaybackState() != AL_STOPPED)
						{						
							m_pSource->SetPlaybackState(AL_STOPPED);							
						}
					}						
					isChannelDone = AL_TRUE;
				}					
   			}
   			// Writing is finished but still some samples to read in source buffer.			  		
			else if(nbSourceSamplesLeft > nbWriteSamplesLeft)
			{													
				sbCursorPosition += nbSamplesToWrite;									

				// Set cursor position for source if the last channel has been written
				if(nbExecutedChannels == m_nbSourceChannels - 1)
				{					
					m_pSource->SetCursorPosition(sbCursorPosition);					
				}
				m_pSource->AddExecutedChannel();
			}
			else // Writing is finished and source buffer is done for current channel.
			{					
				if(m_pSource->IsSourceLooping())
				{
					if(nbExecutedChannels == m_nbSourceChannels - 1)
   					{    						
   						m_pSource->SetCursorPosition(0);
   					}	
				}
				else // Source is not looping
				{
					// If all channels have executed, stop the source.
					if(nbExecutedChannels == m_nbSourceChannels - 1)
   					{
						if(m_pSource->GetPlaybackState() != AL_STOPPED)
						{						
							m_pSource->SetPlaybackState(AL_STOPPED);							
						}
   					}						
				}
				m_pSource->AddExecutedChannel();
			}
			
			nbWriteSamplesLeft -= nbSamplesToWrite;		
		}
		else // No AL buffer available, fill the voice buffer with zeroes and stop the source.
		{						
			startIndex = nbVoiceSamplesNeeded - nbWriteSamplesLeft;

			// Copy samples from source buffer to voice buffer.
			if(m_nbSourceChannels == 1)
			{				
				std::memset(voiceBuffer + startIndex, 0, nbWriteSamplesLeft << 2);
			}
			else if(m_nbSourceChannels == 2)
			{
				std::memset(voiceBuffer + startIndex, 0, nbWriteSamplesLeft << 3);
			}

			// If all channels have executed, stop the source.
			if(nbExecutedChannels == m_nbSourceChannels - 1)
			{
				m_pSource->SetPlaybackState(AL_STOPPED);
			}
		}
	}		// End while
}



// Method 'FillVoiceBufferWithStreamingSource()' transfers data from the 'streamed' source
// buffers into the voice buffer received in parameter. This method is used when data
// in source buffers is in short 16-bits format. Prefixes 'sb' and 'vb' are used within
// this method to respectively describe source buffers and voice buffer.

void SourceToVoice::FillVoiceBufferStreaming(Buffers *sourceBuffers, ALshort *voiceBuffer)
{		
	ALuint k;							// Loop index in source buffers.
	ALuint sourceBufferID;			
	Buffer *sourceBuffer;	
	ALuint nbSourceSamplesLeft;			// Nb of remaining samples to read from source buffer.
	ALuint nbSourceBufferSamples;		// Total number of samples in the source buffer.
	ALuint sbCursorPosition;			// Source buffer initial cursor position (as an offset).		
	ALshort *sbStartPosition = NULL;	// Source buffer start read address.		
	ALuint startIndex, endIndex;
	ALuint nbVoiceSamplesNeeded;		// Total number of samples to write to voice buffer.
	ALuint nbSamplesToWrite;			// Nb of samples to write in a particular 'while' pass.
	ALuint sourceBufferIndex = 0;		
		
	nbVoiceSamplesNeeded = m_pVoice->GetNbSamplesNeeded();
	ALuint nbWriteSamplesLeft = nbVoiceSamplesNeeded;	
	ALuint nbExecutedChannels = m_pSource->GetNbExecutedChannels();
	
	while(nbWriteSamplesLeft > 0)
	{					
		// Get the next source buffer that is not processed.
		sourceBufferID = m_pSource->GetUnprocessedBufferID(sourceBufferIndex);
		sourceBuffer = sourceBuffers->GetBuffer(sourceBufferID);					
		
		if(sourceBuffer)
		{										
			// Get the number of samples in the source buffer.
			nbSourceBufferSamples = sourceBuffer->GetNbSamples();
				
			// Get source buffer cursor position (as an offset in samples). For every
			// source channel, except the last executed, if more than one source buffer
			// is needed, the cursor position is incremented in the current method.
			if(sourceBufferIndex == 0)
			{				
				sbCursorPosition = m_pSource->GetCursorPosition();				
			}
				
			// Determine how many samples have to be copied in the present 'while pass'.
			nbSourceSamplesLeft = nbSourceBufferSamples - sbCursorPosition;
			if(nbSourceSamplesLeft < nbWriteSamplesLeft)
			{
				nbSamplesToWrite = nbSourceSamplesLeft;
			}
			else
			{
				nbSamplesToWrite = nbWriteSamplesLeft;
			}
				
			// Determine the start index to write samples in voice buffer.
			startIndex = nbVoiceSamplesNeeded - nbWriteSamplesLeft;

			// Copy samples from source buffer to voice buffer.
			if(m_nbSourceChannels == 1)
			{	
				sbStartPosition = (ALshort *) sourceBuffer->GetMemory() + (sbCursorPosition);
				std::memcpy(voiceBuffer + startIndex, sbStartPosition, nbSamplesToWrite << 1);
			}
			else if(m_nbSourceChannels == 2)
			{
				sbStartPosition = (ALshort *) sourceBuffer->GetMemory() + (sbCursorPosition << 1);
				
				k = m_sourceChannel;			
				endIndex = startIndex + nbSamplesToWrite;				// In nb of samples.																					
			
				for(ALuint i = startIndex; i < endIndex; i++)
				{    					    								
   					voiceBuffer[i] = sbStartPosition[k]; 					
   					k += m_nbSourceChannels;    				    				 					
   				} 
			}			
				
        	// Source channel has finished reading the current source buffer, but there
        	// are still some samples to write in voice buffer.
    		if(nbSourceSamplesLeft < nbWriteSamplesLeft)
    		{    				
				// If the current channel is the last to execute, set buffer as processed.
    			if(nbExecutedChannels == m_nbSourceChannels - 1)
    			{
    				m_pSource->SetBufferAsProcessed();    										
    			}
    			else // Increment buffer index since it is not set as processed yet.
    			{
    				sourceBufferIndex++; // Go to next source buffer.
    			}
    			sbCursorPosition = 0; // Cursor starts at 0 in the next source buffer.
    		}
    		// Writing is finished but still some samples to read in source buffer.			  		
			else if(nbSourceSamplesLeft > nbWriteSamplesLeft)
			{													
				sbCursorPosition += nbSamplesToWrite;					
				
				// Set cursor position for source if the last channel has been written
				if(nbExecutedChannels == m_nbSourceChannels - 1)
				{
					m_pSource->SetCursorPosition(sbCursorPosition);
				}
				m_pSource->AddExecutedChannel();
			}
			else // Writing is finished and source buffer is done for current channel.
			{					
				if(nbExecutedChannels == m_nbSourceChannels - 1)
    			{
    				m_pSource->SetBufferAsProcessed();    				
    			}
				m_pSource->AddExecutedChannel();
			}
		
			nbWriteSamplesLeft -= nbSamplesToWrite;		
		}
		else // No AL buffer available, fill the voice buffer with zeroes and stop the source.
		{														
			startIndex = nbVoiceSamplesNeeded - nbWriteSamplesLeft;

			// Copy samples from source buffer to voice buffer.
			if(m_nbSourceChannels == 1)
			{				
				std::memset(voiceBuffer + startIndex, 0, nbWriteSamplesLeft << 1);
			}
			else if(m_nbSourceChannels == 2)
			{
				std::memset(voiceBuffer + startIndex, 0, nbWriteSamplesLeft << 2);
			}

    		m_pSource->AddExecutedChannel();
    		nbWriteSamplesLeft = 0;

			// If all channels have executed, stop the source.
			if(nbExecutedChannels == m_nbSourceChannels - 1)
			{
				m_pSource->SetPlaybackState(AL_STOPPED);
			}			
		}
	}		// End while
}



// Method 'FillVoiceBufferWithStreamingSource()' transfers data from the 'streamed' source
// buffers into the voice buffer received in parameter. This method is used when data
// in source buffers is in float 32-bits format. Prefixes 'sb' and 'vb' are used within
// this method to respectively describe source buffers and voice buffer.

void SourceToVoice::FillVoiceBufferStreaming(Buffers *sourceBuffers, ALfloat *voiceBuffer)
{		
	ALuint k;							// Loop index in source buffers.
	ALuint sourceBufferID;			
	Buffer *sourceBuffer;	
	ALuint nbSourceSamplesLeft;			// Nb of remaining samples to read from source buffer.
	ALuint nbSourceBufferSamples;		// Total number of samples in the source buffer.
	ALuint sbCursorPosition;			// Source buffer initial cursor position (as an offset).		
	ALfloat *sbStartPosition = NULL;	// Source buffer start read address.		
	ALuint startIndex, endIndex;
	ALuint nbVoiceSamplesNeeded;		// Total number of samples to write to voice buffer.
	ALuint nbSamplesToWrite;			// Nb of samples to write in a particular 'while' pass.
	ALuint sourceBufferIndex = 0;		
		
	nbVoiceSamplesNeeded = m_pVoice->GetNbSamplesNeeded();
	ALuint nbWriteSamplesLeft = nbVoiceSamplesNeeded;	
	ALuint nbExecutedChannels = m_pSource->GetNbExecutedChannels();
	
	while(nbWriteSamplesLeft > 0)
	{					
		// Get the next source buffer that is not processed.
		sourceBufferID = m_pSource->GetUnprocessedBufferID(sourceBufferIndex);
		sourceBuffer = sourceBuffers->GetBuffer(sourceBufferID);					
		
		if(sourceBuffer)
		{										
			// Get the number of samples in the source buffer.
			nbSourceBufferSamples = sourceBuffer->GetNbSamples();
				
			// Get source buffer cursor position (as an offset in samples). For every
			// source channel, except the last executed, if more than one source buffer
			// is needed, the cursor position is incremented in the current method.
			if(sourceBufferIndex == 0)
			{				
				sbCursorPosition = m_pSource->GetCursorPosition();				
			}			
				
			// Determine how many samples have to be copied in the present 'while pass'.
			nbSourceSamplesLeft = nbSourceBufferSamples - sbCursorPosition;
			if(nbSourceSamplesLeft < nbWriteSamplesLeft)
			{
				nbSamplesToWrite = nbSourceSamplesLeft;
			}
			else
			{
				nbSamplesToWrite = nbWriteSamplesLeft;
			}
			
			// Determine the start index to write samples in voice buffer.
			startIndex = nbVoiceSamplesNeeded - nbWriteSamplesLeft;

			// Copy samples from source buffer to voice buffer.
			if(m_nbSourceChannels == 1)
			{	
				sbStartPosition = (ALfloat *) sourceBuffer->GetMemory() + sbCursorPosition;
				std::memcpy(voiceBuffer + startIndex, sbStartPosition, nbSamplesToWrite << 2);
			}
			else if(m_nbSourceChannels == 2)
			{
				sbStartPosition = (ALfloat *) sourceBuffer->GetMemory() + (sbCursorPosition << 1);
				
				k = m_sourceChannel;			
				endIndex = startIndex + nbSamplesToWrite;				// In nb of samples.																					
			
				for(ALuint i = startIndex; i < endIndex; i++)
				{    					    								
   					voiceBuffer[i] = sbStartPosition[k]; 					
   					k += m_nbSourceChannels;    				    				 					
   				} 
			}
			
        	// Source channel has finished reading the current source buffer, but there
        	// are still some samples to write in voice buffer.
    		if(nbSourceSamplesLeft < nbWriteSamplesLeft)
    		{    				
				// If the current channel is the last to execute, set buffer as processed.
    			if(nbExecutedChannels == m_nbSourceChannels - 1)
    			{
    				m_pSource->SetBufferAsProcessed();    										
    			}
    			else // Increment buffer index since it is not set as processed yet.
    			{
    				sourceBufferIndex++; // Go to next source buffer.
    			}
    			sbCursorPosition = 0; // Cursor starts at 0 in the next source buffer.
    		}
    		// Writing is finished but still some samples to read in source buffer.			  		
			else if(nbSourceSamplesLeft > nbWriteSamplesLeft)
			{													
				sbCursorPosition += nbSamplesToWrite;					
				
				// Set cursor position for source if the last channel has been written
				if(nbExecutedChannels == m_nbSourceChannels - 1)
				{
					m_pSource->SetCursorPosition(sbCursorPosition);
				}
				m_pSource->AddExecutedChannel();
			}
			else // Writing is finished and source buffer is done for current channel.
			{					
				if(nbExecutedChannels == m_nbSourceChannels - 1)
    			{
    				m_pSource->SetBufferAsProcessed();    				
    			}
				m_pSource->AddExecutedChannel();
			}
		
			nbWriteSamplesLeft -= nbSamplesToWrite;		
		}
		else // No AL buffer available, fill the voice buffer with zeroes and stop the source.
		{														
			startIndex = nbVoiceSamplesNeeded - nbWriteSamplesLeft;

			// Copy samples from source buffer to voice buffer.
			if(m_nbSourceChannels == 1)
			{				
				std::memset(voiceBuffer + startIndex, 0, nbWriteSamplesLeft << 2);
			}
			else if(m_nbSourceChannels == 2)
			{
				std::memset(voiceBuffer + startIndex, 0, nbWriteSamplesLeft << 3);
			}

    		m_pSource->AddExecutedChannel();
    		nbWriteSamplesLeft = 0;

			// If all channels have executed, stop the source.
			if(nbExecutedChannels == m_nbSourceChannels - 1)
			{
				m_pSource->SetPlaybackState(AL_STOPPED);
			}			
		}
	}		// End while
}



ALsource *SourceToVoice::GetSource(void)
{
	return(m_pSource);
}



ALuint SourceToVoice::GetSourceID(void)
{
	return(m_sourceID);
}



PlatformVoice *SourceToVoice::GetVoice(void)
{
	return(m_pVoice);
}



// Method 'ResetVoiceBuffer()' fills the voice buffer received in parameter with zeroes.
// When all voice buffers connected to a source have been resetted, it stops or pauses
// playback of the correponding voices.

void SourceToVoice::ResetVoiceBuffer(void *voiceBuffer)
{	
	ALuint nbVoiceBytesNeeded = m_pVoice->GetNbSamplesNeeded() << 1;
	
	// Reset 'SOURCE_STOP_RESET_LIMIT' buffers for each channel.
	if(m_pSource->GetNbVoiceBufferResets(m_sourceChannel) < SOURCE_STOP_RESET_LIMIT)
	{						
		std::memset(voiceBuffer, 0, nbVoiceBytesNeeded);
		m_pSource->AddVoiceBufferReset(m_sourceChannel);		
	}
	else // Resets are done.
	{
		ALenum playbackState = m_pSource->GetPlaybackState();
		ALuint sourcePostResetState = m_pSource->GetPostResetState();
		
		if(playbackState == AL_STOPPED)
		{							
			// Set the volume of the current voice to zero so that it can ramp up correctly
			// to the desired volume when it will be connected to another source and played.
			m_pVoice->SetVolume(0.0f);

			// Stop the voice.								
			m_pVoice->Stop();		
						
			// Inform the source one of its channel is now unused.
			m_pSource->SetChannelStatus(m_sourceChannel, SOURCE_CHANNEL_UNUSED);			
			
			if(m_pSource->AreChannelsUnused())
			{	
				ALsource *source = m_pSource;			// To access the source after disconnection.
				source->FinalizeVoiceBufferReset();
										
				if(sourcePostResetState != AL_PLAYING)
				{					
					SourceVoiceLinks::GetInstance()->DisconnectSourceFromVoices(source->GetID());
				}
			
				source->SetPlaybackState(sourcePostResetState);			
			}											
		}
		else if(playbackState == AL_PAUSED)
		{			
			// Pause the voice.				
			m_pVoice->Pause();			

			// Inform the source one of its channel is now unused.			
			m_pSource->SetChannelStatus(m_sourceChannel, SOURCE_CHANNEL_UNUSED);
			
			if(m_pSource->AreChannelsUnused())
			{				
				m_pSource->FinalizeVoiceBufferReset();						
				m_pSource->SetPlaybackState(sourcePostResetState);				
			}			
		}		
	}	
}


#ifdef PLATFORM_WII

void SourceToVoice::UpdateVoiceOutputState(void)
{
	// Set voice outputs states (including wiimotes speakers)	
	for(ALshort k = 0; k < AL_NB_OUTPUTS; k++)
	{				
		m_pVoice->SetOutputState(k, m_pSource->GetOutputState(k));
	}	
}

#endif


void SourceToVoice::UpdateVoiceParameters()
{	
	if(m_pSource)
	{
		UpdateVoicePitch();
		#ifdef PLATFORM_WII
			UpdateVoiceOutputState(); // Must be done before UpdateVoicePosition().
		#endif
		UpdateVoicePosition();
		UpdateVoiceVolume();
		
		if(m_pSource->GetPlaybackState() == AL_PLAYING)
		{
			if(m_pVoice->GetPlaybackState() != PLAYBACK_STATE_PLAYING)
			{
				m_pVoice->Play();
				m_pSource->SetChannelStatus(m_sourceChannel, SOURCE_CHANNEL_IN_USE);
			}
		}
		// NOTE : Stop and Pause updates are done by method SourceToVoice::ResetVoiceBuffer().
	}																					
}



void SourceToVoice::UpdateVoicePitch(void)
{
	ALCcontext *currentContext = ContextList::GetCurrentContext();
	m_pVoice->SetPitch(currentContext->GetSourcePitch(m_pSource));	
}



void SourceToVoice::UpdateVoicePosition(void)
{
	// If source is mono, set position according to application settings.
	if(m_nbSourceChannels == 1)
	{			
		ALCcontext *currentContext = ContextList::GetCurrentContext();		
		ALposition monoPosition = currentContext->GetSourcePanPosition(m_pSource);		
		m_pVoice->SetPosition(&monoPosition);
	}
	else if(m_nbSourceChannels == 2) // For stereo source pan left-right channels as usual.
	{				
		ALposition stereoPosition;
		stereoPosition.m_y = 0.0f;
		stereoPosition.m_z = 0.0f;

		if(m_sourceChannel == 0) // Left channel.
		{
			stereoPosition.m_x = -1.0f;					
		}
		else // Right channel
		{
			stereoPosition.m_x = 1.0f;					
		}	
		m_pVoice->SetPosition(&stereoPosition);
	}
}



// Method 'UpdateVoiceVolume()' updates the volume of the voice associated with the
// current SourceToVoice object. The volume is calculated according to the following
// steps:
//
// 1) A gain related to the source to listener distance is calculated according to
//	  the current distance model.
// 2) A gain related to the position of the listener relative to the source's inner
//	  and outer cones is calculated.
// 3) The previous gains are multiplied together along with the source's gain.
// 4) The gain calculated in (3) is contained within the source's min and max gain.
// 5) The gain calculated in (4) is multiplied by the listener's gain.
// 6) If the source is stereo, the gain calculated in (5) is multiplied by 0.707
//	  so that a stereo source (transmitted on two mono voices) plays with the same
//	  power as a mono source (transmitted on one mono voice).
// 7) The resulting gain is limited to 1.0f.

void SourceToVoice::UpdateVoiceVolume(void)
{																
	ALfloat totalGain;
	ALfloat directionalGain = 1.0f;
	ALfloat distanceGain = 1.0f;
	
	ALCcontext *currentContext = ContextList::GetCurrentContext();
		
	// If source is mono, get volume gain from distance and direction of propagation.
	if(m_nbSourceChannels == 1)
	{
		distanceGain = currentContext->GetSourceDistanceGain(m_pSource);	
		directionalGain = currentContext->GetSourceDirectionalGain(m_pSource);
	}
	totalGain = distanceGain * directionalGain * m_pSource->GetGain();
		
	ALfloat sourceMinGain = m_pSource->GetMinGain();
	ALfloat sourceMaxGain = m_pSource->GetMaxGain();
	
	// Limit gain contribution from source.
	if(totalGain < sourceMinGain)
	{
		totalGain = sourceMinGain;
	}
	else if(totalGain > sourceMaxGain)
	{
		totalGain = sourceMaxGain;
	}	
		
	ALfloat listenerGain = currentContext->GetListener()->GetGain();
	
	if(m_nbSourceChannels == 1)
	{																	
		totalGain *= listenerGain;									
	}
	else if(m_nbSourceChannels == 2)
	{															
		// Apply a SQRT_2_INVERSE = 0.707 attenuation to compensate the
		// fact that stereo sources are transmitted in two mono voices.
		totalGain *= (listenerGain * SQRT_2_INVERSE);									
	}			

	// Limit total gain to 1.0f
	if(totalGain >= 1.0f)
	{
		totalGain = 1.0f;
	}	
	
	m_pVoice->SetVolume(totalGain);
}



// **************************************************************************************** //
// ******************************** SourceVoiceLinks class ******************************** //
// **************************************************************************************** //


SourceVoiceLinks* SourceVoiceLinks::s_pInstance = NULL;


SourceVoiceLinks::SourceVoiceLinks(ALshort nbLinks, ALCcontext *context, Buffers *sourceBuffers)
{	
	if(!s_pInstance)
	{
		s_pInstance = this;
		m_pSourceBuffers = sourceBuffers;	
		m_nbLinks = nbLinks;
		m_firstFreeLink = 0;
	
		// Create array of SourceToVoice objects.
		m_pSourceVoiceLinks = alnew SourceToVoice* [nbLinks];
		for (ALshort i = 0 ; i < nbLinks ; i++)
		{			
			m_pSourceVoiceLinks[i] = NULL;
		}		

		m_lastUsedLink = NO_SOURCE_VOICE_LINK;	
		m_nbFreeLinks = MAX_VOICES;	
	}
}



SourceVoiceLinks::~SourceVoiceLinks(void)
{
	// Delete array of SourceToVoice objects.
	for(ALshort i = 0; i < m_nbLinks; i++)
	{
		aldelete m_pSourceVoiceLinks[i];
	}
	aldelete [] m_pSourceVoiceLinks;
	m_pSourceVoiceLinks = NULL;
	s_pInstance = NULL;
}



// Method 'ConnectSourceToVoices()' connects the source received in parameter to
// a number of voices equivalent to the number of source's channels if there are
// enough voices available (if not, no connection is done). The connection is
// performed through the use of a SourceToVoice object.

ALboolean SourceVoiceLinks::ConnectSourceToVoices(ALsource *source)
{
	ALshort nbChannels = source->GetNbChannels();
	
	if(nbChannels > 0 && nbChannels <= m_nbFreeLinks)
	{				
		// Connect each source channel to a voice.
		for(ALint i = 0; i < nbChannels; i++)
		{
			if(m_firstFreeLink < m_nbLinks)
			{
				m_nbFreeLinks--;
		
				// If no SourceToVoice for that link, create a new one and put it in 'm_pSourceVoiceLinks'.
				if(m_pSourceVoiceLinks[m_firstFreeLink] == NULL)
				{
					m_pSourceVoiceLinks[m_firstFreeLink] = (SourceToVoice *) alnew SourceToVoice(m_firstFreeLink);
				}
		
				// Update the sourceToVoice object with the new connection parameters.		
				m_pSourceVoiceLinks[m_firstFreeLink]->Connect(source, i);		
			
				// Update the indexes of the first free and last used links.
				if(m_firstFreeLink > m_lastUsedLink)
				{
					// This case only happens when m_firstFreeLink = m_lastUsedLink + 1
					m_lastUsedLink = m_firstFreeLink;
					m_firstFreeLink++;						
				}
				else // Search for the next free link.
				{					
					ALshort	k = m_firstFreeLink + 1;
					m_firstFreeLink = m_lastUsedLink + 1; 

					// Search to see if there is a free link before the last used link.
					while(k < m_lastUsedLink)
					{						
						if(m_pSourceVoiceLinks[k]->GetSourceID() == 0)
						{				
							m_firstFreeLink = k;
							break;
						}
						k++;
					}					
				}
			}
		}
		// Inform the source that it is now linked to voices.
		source->SetSourceVoiceLink(AL_TRUE);
		return(AL_TRUE);
	}
	return(AL_FALSE);
}



void SourceVoiceLinks::DisconnectSourceFromVoices(ALuint sourceID)
{
	ALshort nbVoicesFound = 0;	
	ALshort nbSourceChannels = 1;
	PlatformVoice *voice;
	ALsource *source = NULL;
	SourceToVoice *sourceToVoice;

	for(ALshort i = 0; i <= m_lastUsedLink; i++)
	{		
		sourceToVoice = m_pSourceVoiceLinks[i];

		if(sourceToVoice->GetSourceID() == sourceID)
		{			
			nbVoicesFound++;

			// Find the number of channels of the source.
			if(nbVoicesFound == 1)
			{				
				source = sourceToVoice->GetSource();				
				nbSourceChannels = source->GetNbChannels();				
			}

			// Reset voice parameters since it is gonna be used again.			
			voice = sourceToVoice->GetVoice();
			voice->Reset();															
			
			// Disconnect current voice from source.
			sourceToVoice->Disconnect();

			// If all voices are disconnected, indicate it to the source.
			if(nbVoicesFound == nbSourceChannels)
			{				
				source->SetSourceVoiceLink(AL_FALSE);				
			}

			// If current link was the last in use, change 'm_lastUsedLink'
			if(i == m_lastUsedLink)
			{
				ALshort k = m_lastUsedLink - 1;				
				m_lastUsedLink = NO_SOURCE_VOICE_LINK; // In case no used link is found.
			
				while(k >= 0)
				{					
					if(m_pSourceVoiceLinks[k]->GetSourceID() > 0)
					{						
						m_lastUsedLink = k;
						break;
					}
					k--;
				}				
			}

			// Update the first free link if necessary.
			if(i < m_firstFreeLink)
			{
				m_firstFreeLink = i;
			}
			m_nbFreeLinks++;
		}		
	}
}


SourceVoiceLinks* SourceVoiceLinks::GetInstance()
{	
	return s_pInstance;
}



// Method 'UpdateVoices()' runs over all source to voice connections and is responsible
// for calling methods to either fill voice buffers (from source buffers), reset voice
// buffers or disconnect a source from voices (in the special case where a source has
// been stopped after being paused). This method is called via a 3ms callback mechanism.

void SourceVoiceLinks::UpdateVoices(void)
{
	SourceToVoice *sourceToVoice;
	PlatformVoice *currentVoice;
	void *voiceBuffer;	
	ALsource *source;
	ALint sourceType;
	ALenum buffersFormat;
	ALsizei	buffersFrequency;
	ALenum playbackState;	
	ALuint sourceID;		
			
	for(ALshort i = 0; i <= m_lastUsedLink; i++)
	{		
		sourceToVoice = m_pSourceVoiceLinks[i];

		if(sourceToVoice)
		{
			source = sourceToVoice->GetSource();
			
			// Fill voice buffers only for voices connected to a source.			
			if(source)
			{			
				sourceID = source->GetID();
				currentVoice = sourceToVoice->GetVoice();
				playbackState = source->GetPlaybackState();						
				sourceToVoice->UpdateVoiceParameters();																							
				voiceBuffer = currentVoice->GetBufferToFill();
		
				if(voiceBuffer)
				{					
					sourceType = source->GetType();
					buffersFormat = source->GetBuffersFormat();
					buffersFrequency = source->GetBuffersFrequency();

					if(playbackState == AL_PLAYING)				   
					{					
						if(sourceType == AL_STREAMING)
						{	
							if((buffersFormat == AL_FORMAT_MONO16) || (buffersFormat == AL_FORMAT_STEREO16))
							{
								sourceToVoice->FillVoiceBufferStreaming(m_pSourceBuffers, (ALshort *) voiceBuffer);
								#ifdef PLATFORM_PS3
									if(buffersFrequency == PLATFORM_SAMPLING_RATE)
									{
										currentVoice->UpdateNoInterpolation((ALshort *) voiceBuffer);
									}
									else
									{
										currentVoice->Update((ALshort *) voiceBuffer);
									}
								#else
									currentVoice->Update((ALshort *) voiceBuffer);
								#endif
							}
							#ifdef PLATFORM_PS3
								else if((buffersFormat == AL_FORMAT_MONO32F) || (buffersFormat == AL_FORMAT_STEREO32F))
								{
									sourceToVoice->FillVoiceBufferStreaming(m_pSourceBuffers, (ALfloat *) voiceBuffer);
									if(buffersFrequency == PLATFORM_SAMPLING_RATE)
									{
										currentVoice->UpdateNoInterpolation((ALfloat *) voiceBuffer);
									}
									else
									{
										currentVoice->Update((ALfloat *) voiceBuffer);
									}
								}
							#endif
						}
						else if(sourceType == AL_STATIC)
						{
							if((buffersFormat == AL_FORMAT_MONO16) || (buffersFormat == AL_FORMAT_STEREO16))
							{
								sourceToVoice->FillVoiceBufferStatic(m_pSourceBuffers, (ALshort *) voiceBuffer);
								#ifdef PLATFORM_PS3
									if(buffersFrequency == PLATFORM_SAMPLING_RATE)
									{
										currentVoice->UpdateNoInterpolation((ALshort *) voiceBuffer);
									}
									else
									{
										currentVoice->Update((ALshort *) voiceBuffer);
									}
								#else
									currentVoice->Update((ALshort *) voiceBuffer);
								#endif
							}
							#ifdef PLATFORM_PS3
								else if((buffersFormat == AL_FORMAT_MONO32F) || (buffersFormat == AL_FORMAT_STEREO32F))
								{
									sourceToVoice->FillVoiceBufferStatic(m_pSourceBuffers, (ALfloat *) voiceBuffer);
									if(buffersFrequency == PLATFORM_SAMPLING_RATE)
									{
										currentVoice->UpdateNoInterpolation((ALfloat *) voiceBuffer);
									}
									else
									{
										currentVoice->Update((ALfloat *) voiceBuffer);
									}
								}
							#endif
						}					
					}
					else if((playbackState == AL_STOPPED) || (playbackState == AL_PAUSED))
					{				
						sourceToVoice->ResetVoiceBuffer(voiceBuffer);

						if((buffersFormat == AL_FORMAT_MONO16) || (buffersFormat == AL_FORMAT_STEREO16))
						{
							#ifdef PLATFORM_PS3
								if(buffersFrequency == PLATFORM_SAMPLING_RATE)
								{
									currentVoice->UpdateNoInterpolation((ALshort *) voiceBuffer);
								}
								else
								{
									currentVoice->Update((ALshort *) voiceBuffer);
								}
							#else
								currentVoice->Update((ALshort *) voiceBuffer);
							#endif
						}
						#ifdef PLATFORM_PS3
							else if((buffersFormat == AL_FORMAT_MONO32F) || (buffersFormat == AL_FORMAT_STEREO32F))
							{
								if(buffersFrequency == PLATFORM_SAMPLING_RATE)
								{
									currentVoice->UpdateNoInterpolation((ALfloat *) voiceBuffer);
								}
								else
								{
									currentVoice->Update((ALfloat *) voiceBuffer);
								}
							}
						#endif
					}
				}
				else if(playbackState == AL_STOPPED) // Case when a paused source was called to stop.				
				{				
					if(source->AreChannelsUnused())
					{					
						DisconnectSourceFromVoices(sourceID);				
					}
				}
			}
		}										
	}
}