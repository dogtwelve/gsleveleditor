#include "PS3_Interface.h"
#include <sysutil/sysutil_bgmplayback.h>


// **************************************************************************************** //
// ********************************* PlatformVoice class ********************************** //
// **************************************************************************************** //

CellAANHandle PlatformVoice::s_pMixerHandle;
CellSurMixerConfig PlatformVoice::s_pMixerConfiguration;

PlatformVoice::PlatformVoice(ALshort voiceID)
{	
	m_channelStripIndex = voiceID;
	m_playbackState = PLAYBACK_STATE_NONE;

	// Playback buffer parameters.
	m_bufferSize = VOICE_BUFFER_SIZE;
	m_bufferSizeBytes = VOICE_BUFFER_SIZE * sizeof(ALfloat);
	m_pPlaybackBuffer = NULL;
	m_nbInputSamples = VOICE_BUFFER_SIZE;
			
	// Set pitch parameters.
	m_startTimeOffset = 0.0f;
	m_outputTimeStep = 1.0f;	// Corresponds to pitch = 1.0f
	m_edgeInputSample = 0;
	m_edgeInputSampleF = 0.0f;
	m_extraOutputSamplesSize = ALint(1.0f / VOICE_PITCH_LOWER_LIMIT) + 1;
	m_pExtraOutputSamples = alnew ALfloat[m_extraOutputSamplesSize];
	m_nbExtraOutputSamples = 0;

	// Set volume parameters
	m_currentVolume = 0.0f;	

	// Set position parameters
	m_pPosition = alnew CellSurMixerPosition();

	// Create input buffer and fill it with zeroes.
	m_inputBufferSize = m_bufferSize * (ALuint) VOICE_PITCH_UPPER_LIMIT;	
	m_pInputBuffer = alnew ALchar[m_inputBufferSize << 2];				// Large enough to fill with floats.

	// Create voice playback buffer and fill it with zeroes.
	m_pPlaybackBuffer = alnew ALfloat[m_bufferSize];	
	std::memset(m_pPlaybackBuffer, 0, m_bufferSizeBytes);	
	
	// Acquire a voice.
	Acquire();
}



PlatformVoice::~PlatformVoice(void)
{
	aldelete m_pPosition;
	aldelete [] m_pExtraOutputSamples;
	aldelete [] m_pInputBuffer;
	aldelete [] m_pPlaybackBuffer;
}



void PlatformVoice::Clean(void)
{	
	cellSurMixerFinalize();
}



// 'GetBufferToFill()' returns the buffer in which uninterpolated samples are received. The
// actual interpolation is done from 'm_pInputBuffer' to 'm_playbackBuffer'.

void *PlatformVoice::GetBufferToFill(void)
{	 		
	if(m_playbackState == PLAYBACK_STATE_PLAYING)
 	{
		return((void *) m_pInputBuffer);
	}
	return(NULL);
}



ALuint PlatformVoice::GetNbSamplesNeeded(void)
{	
	return(m_nbInputSamples);
}



ALshort	PlatformVoice::GetPlaybackState(void)
{	
 	return(m_playbackState);
}



void PlatformVoice::Init(void)
{
	cellAudioInit();						// Initialize audio library

	// Configure mixer settings	
	s_pMixerConfiguration.priority = 400;
	s_pMixerConfiguration.chStrips1 = MAX_VOICES;
	s_pMixerConfiguration.chStrips2 = 0;
	s_pMixerConfiguration.chStrips6 = 0;
	s_pMixerConfiguration.chStrips8 = 0;

	cellSurMixerCreate(&s_pMixerConfiguration);

	// Set master volume. As noticed from recordings, signal is clipped when total
	// level is over -1 dB and pan is totally left or right in a 2 channel setting.
	cellSurMixerSetParameter(CELL_SURMIXER_PARAM_TOTALLEVEL_DB, -3);

	
	cellSurMixerGetAANHandle(&s_pMixerHandle);	
}



void PlatformVoice::Pause(void)
{	
	if(m_playbackState != PLAYBACK_STATE_STOPPED)
	{
		m_playbackState = PLAYBACK_STATE_PAUSED;
	}
}



void PlatformVoice::Play(void)
{
	if(m_playbackState != PLAYBACK_STATE_PLAYING)
	{		
		m_playbackState = PLAYBACK_STATE_PLAYING;
	}
}



void PlatformVoice::Reset(void)
{						
	// Set playback parameters.
	m_playbackState = PLAYBACK_STATE_NONE;
	std::memset(m_pPlaybackBuffer, 0, m_bufferSizeBytes);
	m_nbInputSamples = VOICE_BUFFER_SIZE;
		
	// Set pitch parameters.
	m_startTimeOffset = 0.0f;
	m_outputTimeStep = 1.0f;	// Corresponds to pitch = 1.0f
	m_edgeInputSample = 0;
	m_edgeInputSampleF = 0.0f;
	m_nbExtraOutputSamples = 0;
	std::memset(m_pExtraOutputSamples, 0, m_extraOutputSamplesSize << 1);	
	std::memset(m_pInputBuffer, 0, m_inputBufferSize << 2);

	// Set volume parameters
	m_currentVolume = 0.0f;
}



// Method 'SetPitch()' is indirectly called every 5ms via a callback mechanism.

void PlatformVoice::SetPitch(ALfloat pitch)
{								
	// Pitch cannot be changed when a voice is paused or stopped. It is however automatically
	// changed by a call from SourceVoiceLinks::PlaySource() when playback starts.
	if(m_playbackState == PLAYBACK_STATE_PLAYING)
	{
		// Limit pitch within acceptable bounds.
		if(pitch > VOICE_PITCH_UPPER_LIMIT)
		{
			pitch = VOICE_PITCH_UPPER_LIMIT;		
		}	
		else if(pitch < VOICE_PITCH_LOWER_LIMIT)
		{
			pitch = VOICE_PITCH_LOWER_LIMIT;	
		}		
		
		m_outputTimeStep = pitch; // Because time is normalized to 'outputRate / pitch'.		

		// Calculate nb of samples needed for the first interpolation pass at new pitch.
		m_nbInputSamples = (ALint) (m_startTimeOffset + 
								   (m_bufferSize - m_nbExtraOutputSamples - 1) * m_outputTimeStep) + 1;		
	}	
}



// Method 'SetPosition()' sets voice panning according to the position received in parameter.
// The method is called each 5ms by a callback mechanism.

void PlatformVoice::SetPosition(ALposition *position)
{	
	// Position cannot be changed when a voice is paused or stopped. It is however automatically
	// changed by a call from SourceVoiceLinks::PlaySource() when playback starts.
	if(m_playbackState == PLAYBACK_STATE_PLAYING)
	{		
		m_pPosition->x = position->m_x;
		m_pPosition->y = position->m_y;
		m_pPosition->z = position->m_z;

		CellSurMixerChStripParam channelStripPosition;
		channelStripPosition.param = CELL_SURMIXER_CH1PARAM_POSITION;
		channelStripPosition.attribute = (void *) m_pPosition;
		
		cellSurMixerChStripSetParameter(CELL_SURMIXER_CHSTRIP_TYPE1A, m_channelStripIndex,
										&channelStripPosition);		
	}
}



// Method 'SetVolume()' is (indirectly) called every 5 ms through a callback function.
// See NOTE 1 for details about fading volume.

void PlatformVoice::SetVolume(ALfloat gain)
{	
	// Volume cannot be changed when a voice is paused or stopped. It is however automatically
	// changed by a call from SourceVoiceLinks::PlaySource() when playback starts.
	if(m_playbackState == PLAYBACK_STATE_PLAYING)
	{				
		// Put limits on total gain.
		if(gain > 1.0f)
		{
			gain = 1.0f;
		}
		else if(gain < 0.0f)
		{
			gain = 0.0f;
		}						
		
		m_currentVolume = gain;
		CellSurMixerChStripParam channelStripVolume;
		channelStripVolume.param = CELL_SURMIXER_CH1PARAM_LEVEL;
		channelStripVolume.dBSwitch = CELL_SURMIXER_CONT_DBSWITCHOFF;
		channelStripVolume.floatVal = m_currentVolume;

		cellSurMixerChStripSetParameter(CELL_SURMIXER_CHSTRIP_TYPE1A, m_channelStripIndex,
										&channelStripVolume);		
	}
}



// To my knowledge, there is no way to stop the PS3 engine from reading in a channel strip.
// Therefore, voices are never really stopped but when a source is stopping, the playbackBuffer
// is filled twice with zeroes.

void PlatformVoice::Stop(void)
{
	m_playbackState = PLAYBACK_STATE_STOPPED;	
}


// Method 'Update(ALshort *)' interpolates samples from 'buffer' into 'm_playbackBuffer'
// according to the 'pitch' value updated by 'UpdatePitch()'. Values from buffer are
// in 16-bits fixed point format while interpolated values are in 32-bits floating point.

void PlatformVoice::Update(ALshort *buffer)
{				
	ALfloat interpolationTime;			// Interpolation time (relative to start of buffer (= 0.0f)).
	ALint secondIndex;					// Buffer index of second interpolating sample.
	ALint outerSamplesDifference;		// Difference between samples used for interpolation.
	ALfloat timeExcess;					// Interpolation time (relative to first interpolating sample).
	ALfloat interpolatedSample;			// Value of current interpolated sample.
	ALint nbExtraOutputSamples = 0;		// Calculated for the current pass.

	// If volume is zero, force playback buffer to be filled with zeroes (see NOTE 2).
	if(m_currentVolume == 0.0f)
	{
		std::memset(m_pPlaybackBuffer, 0, m_bufferSizeBytes);
	}
	else // Interpolate samples
	{		
		ALshort *inputBufferCursor = buffer;
		ALfloat* pPlaybackBufferCursor = m_pPlaybackBuffer;
		ALfloat* pPlaybackBufferEnd = m_pPlaybackBuffer + m_bufferSize;
		ALfloat* pExtraSamplesCursor = m_pExtraOutputSamples;

		// Write the extra output samples from the last interpolation pass.
		for(ALint k = m_nbExtraOutputSamples; k; k--)
		{
			*pPlaybackBufferCursor++ = *pExtraSamplesCursor++;
		}

		pExtraSamplesCursor = m_pExtraOutputSamples;	// Put cursor back at initial array position.

		// Interpolate samples between the 'edge input sample' and the first newly gotten input sample.	
		interpolationTime = m_startTimeOffset;		
		outerSamplesDifference = *inputBufferCursor - m_edgeInputSample;
	
		while(interpolationTime < 1.0f)
		{			
			*pPlaybackBufferCursor = (ALfloat) (m_edgeInputSample + 
									 interpolationTime * outerSamplesDifference) / MAX_FIXED_POINT_16;

			interpolationTime += m_outputTimeStep;			
			pPlaybackBufferCursor++;
		}
		
		// Interpolate all samples until 'interpolation time' is smaller than time of last input sample.		
		ALfloat inputTimeSpan = (ALfloat) m_nbInputSamples;
		while(interpolationTime < inputTimeSpan)
		{				
			// Calculate the index of the latest input sample used for interpolation.
			secondIndex = (ALint) interpolationTime;			
			
			// Calculate value of the interpolated sample.			
			inputBufferCursor = buffer + secondIndex;
			outerSamplesDifference = *inputBufferCursor;
			inputBufferCursor--;			 	
			outerSamplesDifference -= *inputBufferCursor;
			timeExcess = interpolationTime - (ALfloat) secondIndex;
			interpolatedSample = (ALfloat) (*inputBufferCursor +
								 timeExcess * outerSamplesDifference) / MAX_FIXED_POINT_16;			

			// If interpolated sample fits in voice buffer, put it in.			
			if(pPlaybackBufferCursor < pPlaybackBufferEnd)
			{
				*pPlaybackBufferCursor++ = interpolatedSample;
			}
			else // Too many interpolated samples for voice buffer, put them in extra samples array.
			{				
				*(pExtraSamplesCursor++) = interpolatedSample;
				nbExtraOutputSamples++;
			}	
			interpolationTime += m_outputTimeStep;			
		}	// End of while(interpolationTime < inputTimeSpan)

		// Calculate 'm_startTimeOffset' for next interpolation pass.		
		m_startTimeOffset += ((m_bufferSize + nbExtraOutputSamples - m_nbExtraOutputSamples) *
							  m_outputTimeStep) - inputTimeSpan;		

		// Keep the last sample from the input buffer.
		inputBufferCursor++;
		m_edgeInputSample = *inputBufferCursor;		

		// Calculate expected nb of input samples needed for next interpolation pass.
		m_nbExtraOutputSamples = nbExtraOutputSamples;	
		m_nbInputSamples = (ALint) (m_startTimeOffset + 
							(m_bufferSize - m_nbExtraOutputSamples - 1) * m_outputTimeStep) + 1;		 
	}	// End of else associated with if(m_currentVolume == 0.0f)

	// Provide interpolated buffer to the PS3 audio interface.
	cellAANAddData(s_pMixerHandle, m_channelStripPortNo, 0, m_pPlaybackBuffer, m_bufferSize);
}



// Method 'Update(ALfloat *)' interpolates samples from 'buffer' into 'm_playbackBuffer'
// according to the 'pitch' value updated by 'UpdatePitch()'. Values from buffer and
// interpolated values are both in 32-bits floating point.

void PlatformVoice::Update(ALfloat *buffer)
{				
	ALfloat interpolationTime;			// Interpolation time (relative to start of buffer (= 0.0f)).
	ALint secondIndex;					// Buffer index of second interpolating sample.	
	ALfloat outerSamplesDifference;		// Difference between sample used for interpolation.// Remove
	ALfloat timeExcess;					// Interpolation time (relative to first interpolating sample).
	ALfloat interpolatedSample;			// Value of current interpolated sample.
	ALint nbExtraOutputSamples = 0;		// Calculated for the current pass.

	// If volume is zero, force playback buffer to be filled with zeroes (see NOTE 2).
	if(m_currentVolume == 0.0f)
	{
		std::memset(m_pPlaybackBuffer, 0, m_bufferSizeBytes);
	}
	else // Interpolate samples
	{		
		ALfloat *inputBufferCursor = buffer;
		ALfloat* pPlaybackBufferCursor = m_pPlaybackBuffer;
		ALfloat* pPlaybackBufferEnd = m_pPlaybackBuffer + m_bufferSize;
		ALfloat* pExtraSamplesCursor = m_pExtraOutputSamples;

		// Write the extra output samples from the last interpolation pass.
		for(ALint k = m_nbExtraOutputSamples; k; k--)
		{
			*pPlaybackBufferCursor++ = *pExtraSamplesCursor++;
		}

		pExtraSamplesCursor = m_pExtraOutputSamples;	// Put cursor back at initial array position.

		// Interpolate samples between the 'edge input sample' and the first newly gotten input sample.	
		interpolationTime = m_startTimeOffset;		
		outerSamplesDifference = *inputBufferCursor - m_edgeInputSampleF;
	
		while(interpolationTime < 1.0f)
		{		
			*pPlaybackBufferCursor = m_edgeInputSampleF + interpolationTime * outerSamplesDifference;
			interpolationTime += m_outputTimeStep;			
			pPlaybackBufferCursor++;
		}
		
		// Interpolate all samples until 'interpolation time' is smaller than time of last input sample.		
		ALfloat inputTimeSpan = (ALfloat) m_nbInputSamples;
		while(interpolationTime < inputTimeSpan)
		{				
			// Calculate the index of the latest input sample used for interpolation.			
			secondIndex = (ALint) interpolationTime;			
			
			// Calculate value of the interpolated sample.			
			inputBufferCursor = buffer + secondIndex;
			outerSamplesDifference = *inputBufferCursor;
			inputBufferCursor--;			 	
			outerSamplesDifference -= *inputBufferCursor;
			timeExcess = interpolationTime - (ALfloat) secondIndex;
			interpolatedSample = *inputBufferCursor + timeExcess * outerSamplesDifference;			

			// If interpolated sample fits in voice buffer, put it in.			
			if(pPlaybackBufferCursor < pPlaybackBufferEnd)
			{
				*pPlaybackBufferCursor++ = interpolatedSample;
			}
			else // Too many interpolated samples for voice buffer, put them in extra samples array.
			{				
				*(pExtraSamplesCursor++) = interpolatedSample;
				nbExtraOutputSamples++;
			}	
			interpolationTime += m_outputTimeStep;			
		}	// End of while(interpolationTime < inputTimeSpan)

		// Calculate 'm_startTimeOffset' for next interpolation pass.		
		m_startTimeOffset += ((m_bufferSize + nbExtraOutputSamples - m_nbExtraOutputSamples) *
							  m_outputTimeStep) - inputTimeSpan;		

		// Keep the last sample from the input buffer.
		inputBufferCursor++;
		m_edgeInputSampleF = *inputBufferCursor;		

		// Calculate expected nb of input samples needed for next interpolation pass.
		m_nbExtraOutputSamples = nbExtraOutputSamples;	
		m_nbInputSamples = (ALint) (m_startTimeOffset + 
							(m_bufferSize - m_nbExtraOutputSamples - 1) * m_outputTimeStep) + 1;		 
	}	// End of else associated with if(m_currentVolume == 0.0f)

	// Provide interpolated buffer to the PS3 audio interface.
	cellAANAddData(s_pMixerHandle, m_channelStripPortNo, 0, m_pPlaybackBuffer, m_bufferSize);
}



void PlatformVoice::UpdateNoInterpolation(ALshort *buffer)
{
	// If volume is zero, force playback buffer to be filled with zeroes (see NOTE 2).
	if(m_currentVolume == 0.0f)
	{
		std::memset(m_pPlaybackBuffer, 0, m_bufferSizeBytes);
	}
	else
	{		
		for(int i = 0; i < m_bufferSize; i++)
		{
			m_pPlaybackBuffer[i] = (ALfloat) buffer[i]  / MAX_FIXED_POINT_16;
		}
	}

	// Provide interpolated buffer to the PS3 audio interface.
	cellAANAddData(s_pMixerHandle, m_channelStripPortNo, 0, m_pPlaybackBuffer, m_bufferSize);
}



void PlatformVoice::UpdateNoInterpolation(ALfloat *buffer)
{
	// If volume is zero, force playback buffer to be filled with zeroes (see NOTE 2).
	if(m_currentVolume == 0.0f)
	{
		std::memset(buffer, 0, m_bufferSizeBytes);
	}

	// Provide interpolated buffer to the PS3 audio interface.
	cellAANAddData(s_pMixerHandle, m_channelStripPortNo, 0, buffer, m_bufferSize);
}



// ----------------------------------- //
// ---------- PRIVATE FUNCTIONS ------ //
// ----------------------------------- //


void PlatformVoice::Acquire(void)
{				
	cellSurMixerChStripGetAANPortNo(&m_channelStripPortNo, CELL_SURMIXER_CHSTRIP_TYPE1A,
									 m_channelStripIndex);		
	// Set initial volume to 0.0f.
	CellSurMixerChStripParam channelStripVolume;
	channelStripVolume.param = CELL_SURMIXER_CH1PARAM_LEVEL;
	channelStripVolume.dBSwitch = CELL_SURMIXER_CONT_DBSWITCHOFF;
	channelStripVolume.floatVal = 0.0f;
	cellSurMixerChStripSetParameter(CELL_SURMIXER_CHSTRIP_TYPE1A, m_channelStripIndex,
									&channelStripVolume);	
}


// **************************************************************************************** //
// **************************************** NOTES ***************************************** //
// **************************************************************************************** //


// NOTE 1 : PS3 automatically provides ramping (fade IN and OUT) when the volume
//			is changed by method 'cellSurMixerChStripSetParameter()'. However, it
//			is not possible to set the volume to 0.0f prior to the first volume change.
//			The initial volume is set to 1.0f and when user application sets its
//			initial volume (e.g. to 0.5f), the volume will start at 1.0f and fade out
//			to the desired value (e.g. to 0.5f), causing a click in initial sound.
//			This is true as for SDK 2.5.3 and should be corrected by Sony's engineers
//			in future SDKs.

// NOTE 2 : Because of PS3 bug mentioned in NOTE 1, the samples (in m_playbackBuffer)
//			provided to the PS3 through	method cellAANAddData() are forced to zero when
//			volume is zero. We have indeed encountered situations where the beginning of
//			files was audible when volume was set to 0 prior to buffer filling.