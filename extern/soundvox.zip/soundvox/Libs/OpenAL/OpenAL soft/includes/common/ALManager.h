#ifndef AL_MANAGER_H
#define AL_MANAGER_H

#include "GeneralSettings.h"
#include "Errors.h"
#include "SourceVoiceLinks.h"
#include "OpenALMutex.h"



// **************************************************************************************** //
// ****************************** PlatformVoicesCallback class **************************** //
// **************************************************************************************** //


class PlatformVoicesCallback
{ 
 private:
	static ALint				s_nbInstances;
	static ALMutex				*s_pALMutex;
	static SourceVoiceLinks		*s_pSourceVoiceLinks;

	#ifdef PLATFORM_WII
 		OSAlarm m_wiimoteAlarm;
 	#endif
 public:
 	PlatformVoicesCallback(ALMutex *alMutex, SourceVoiceLinks *sourceVoiceLinks);
 	~PlatformVoicesCallback(void);
	
	#ifdef PLATFORM_WII
		static void VoicesUpdate(void);
		static void WiimoteAudioCallback(OSAlarm *alarm, OSContext *context);
	#elif PLATFORM_PS3
		static int VoicesUpdate(void *arg, uint32_t counter, uint32_t samples);
	#endif
};



// **************************************************************************************** //
// ************************************ ALManager class *********************************** //
// **************************************************************************************** //

class ALManager
{ 
 private:
 	static ALManager		*s_pInstance;
	ALMutex					*m_pALMutex;
 	Devices					*m_pDevices;
 	ALCdevice				*m_pPreferredDevice;
 	ALCdevice				*m_pOpenedDevice;
 	ContextList				*m_pContexts;
 	ALCcontext				*m_pCurrentContext;
 	Buffers					*m_pBuffers;
 	Errors					*m_pError;
 	SourceVoiceLinks		*m_pSourceVoiceLinks; 	
 	PlatformVoicesCallback	*m_pVoicesCallback;
 	ALboolean				m_isVoicesCallbackStarted; 	
 	
 	ALCboolean AreSourcesValid(ALsizei nbSources, const ALuint *sourceIDs);
 	ALCboolean IsAudioFormatValid(ALenum format);
 	ALCboolean IsBufferSizeValid(ALenum format, ALsizei size); 	
 public:
	ALManager(void);
	~ALManager(void);
	static ALManager *GetInstance(void);	
	
	void BufferData(ALuint bufferID, ALenum format, const ALvoid* data, ALsizei size, ALsizei freq);
	ALboolean BufferDataNoCopy(ALuint bufferID, ALenum format, const ALvoid* data,
							   ALsizei size, ALsizei freq, ALboolean deleteOldBuffer);
	ALCboolean CloseDevice(ALCdevice *device);
	ALCcontext *CreateContext(ALCdevice *device, const ALCint* attributesList);
	void DeleteBuffers(ALsizei nbBuffers, const ALuint* buffers);
	void DeleteSources(ALsizei nbSources, const ALuint* sources);
	void DestroyContext(ALCcontext *context);
	void DistanceModel(ALenum model);
	void DopplerFactor(ALfloat value);
	void EnableOutputUpdates(ALboolean enable);
	void GenBuffers(ALsizei nbBuffers, ALuint* buffers);
	void GenSources(ALsizei nbSources, ALuint* sources);
	ALCenum GetALCEnumValue(ALCdevice *device, const ALCchar *enumname);
	ALCenum GetALCError(ALCdevice *device);
	void GetALCIntegerv(ALCdevice *device, ALCenum parameter, ALCsizei size, ALCint *data);
	const ALCchar *GetALCString(ALCdevice *device, ALCenum parameter);
	ALenum GetALError(ALvoid);
	ALint GetALInteger(ALenum parameter);
	const ALchar *GetALString(ALenum parameter);
	void GetBufferi(ALuint bufferID, ALenum parameter, ALint* value);
	ALCdevice* GetContextsDevice(ALCcontext *context);
	ALCcontext *GetCurrentContext(void);
	ALfloat GetFloat(ALenum parameter);	
	void GetListener3f(ALenum parameter, ALfloat *value1, ALfloat *value2, ALfloat *value3);
	void GetListener3i(ALenum parameter, ALint *value1, ALint *value2, ALint *value3);
	void GetListenerf(ALenum parameter, ALfloat* value);
	void GetListenerfv(ALenum parameter, ALfloat* values);
	void GetListeneriv(ALenum parameter, ALint* values);
	void GetSource3f(ALuint sourceID, ALenum parameter, ALfloat* value1, ALfloat* value2, ALfloat* value3);
	void GetSource3i(ALuint sourceID, ALenum parameter, ALint* value1, ALint* value2, ALint* value3);
	void GetSourcef(ALuint sourceID, ALenum parameter, ALfloat* value);
	void GetSourcefv(ALuint sourceID, ALenum parameter, ALfloat* values);
	void GetSourcei(ALuint sourceID, ALenum parameter, ALint* value);
	void GetSourceiv(ALuint sourceID,  ALenum parameter, ALint* values);
	ALboolean IsBuffer(ALuint bufferID);
	ALboolean IsSource(ALuint sourceID);
	void Listener3f(ALenum parameter, ALfloat value1, ALfloat value2, ALfloat value3);
	void Listener3i(ALenum parameter, ALint value1, ALint value2, ALint value3);
	void Listenerf(ALenum parameter, ALfloat value);
	void Listenerfv(ALenum parameter, const ALfloat* values);
	void Listeneriv(ALenum parameter, const ALint* values);
	ALCboolean MakeContextCurrent(ALCcontext *context);
	ALCdevice *OpenDevice(const ALCchar *deviceName);
	void ProcessContext(ALCcontext *context);
	void Source3f(ALuint sourceID, ALenum parameter, ALfloat value1, ALfloat value2, ALfloat value3);
	void Source3i(ALuint sourceID, ALenum parameter, ALint value1, ALint value2, ALint value3);
	void Sourcef(ALuint sourceID, ALenum parameter, ALfloat value);
	void Sourcefv(ALuint sourceID, ALenum parameter, const ALfloat* values);
	void Sourcei(ALuint sourceID, ALenum parameter, ALint value);
	void Sourceiv(ALuint sourceID, ALenum parameter, const ALint* values);
	void SourcePausev(ALsizei nbSources, const ALuint *sourceIDs);
	void SourcePlayv(ALsizei nbSources, const ALuint *sourceIDs);
	void SourceQueueBuffers(ALuint sourceID, ALsizei nbBuffers, const ALuint *bufferIDs);
	void SourceRewindv(ALsizei nbSources, const ALuint *sourceIDs);
	void SourceStopv(ALsizei nbSources, const ALuint *sourceIDs);
	void SourceUnqueueBuffers(ALuint sourceID, ALsizei nbBuffers, ALuint *bufferIDs);
	void SpeedOfSound(ALfloat value);
	void SuspendContext(ALCcontext *context);

	#ifdef PLATFORM_WII
		ALboolean IsOutputOpen(ALshort outputID);
		ALint OutputClose(ALshort outputID);
		void OutputMasterVolume(ALshort outputID, ALfloat volume);
		ALint OutputOpen(ALshort outputID);
		void SourceOutputState(ALuint sourceID, ALshort outputID, ALshort state);
	#endif
};


#endif // AL_MANAGER_H
