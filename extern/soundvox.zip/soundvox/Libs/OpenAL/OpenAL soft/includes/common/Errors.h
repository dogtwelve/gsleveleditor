#ifndef ERRORS_H
#define ERRORS_H

#include "GeneralSettings.h"
#include "DeviceContext.h"

class Errors
{
 private:	
	ALCenum m_alcErrorCode;
	// Note : alErrorCodes are kept within each context.		
 public:
	Errors(void);
	~Errors(void);
	
	ALenum GetALErrorCode(void);
	ALCenum GetALCErrorCode(void);		
	void SetALErrorCode(ALenum errorState);				
	void SetALCErrorCode(ALCenum errorState);	
};


#endif // ERRORS_H