/*-------------------------------------------------------------------------------------------*
  Subject:  This file defines "Gameloft homemade" extension functions for Open AL.  
  Authors:	Robert Houde  
 *-------------------------------------------------------------------------------------------*/

#ifndef AL_GEXT_H
#define AL_GEXT_H

#include "../../../include/al.h"

#if defined(__cplusplus)
extern "C" {
#endif

#ifdef _PS3
	#include "../ps3/CurrentAudioPlatform.h"	
#elif defined (RVL)
	#include "../wii/CurrentAudioPlatform.h"
#endif

#ifdef PLATFORM_WII
	#include <wpad.h>
	#include <revolution/mem.h>	// Used for 'size_t' definition.
	
	// Define output IDs for Wii primary speakers an wiimote speakers.
	#define AL_OUTPUT_PRIMARY		WPAD_MAX_CONTROLLERS
	#define AL_OUTPUT_SECONDARY_0	WPAD_CHAN0
	#define AL_OUTPUT_SECONDARY_1	WPAD_CHAN1
	#define AL_OUTPUT_SECONDARY_2	WPAD_CHAN2
	#define AL_OUTPUT_SECONDARY_3	WPAD_CHAN3	
	#define AL_NB_OUTPUTS			(WPAD_MAX_CONTROLLERS + 1)
	
	// Define output states.
	#define AL_OUTPUT_OFF	0
	#define AL_OUTPUT_ON	1
	
	// Define OpenAL alarm tag for rvl
	#define AL_ALARM_TAG 'opal'
#endif

// Define formats for 32 bits floating point samples.	
#define AL_FORMAT_MONO32F	0x1104
#define AL_FORMAT_STEREO32F	0x1105



// ************* Declarations of Gameloft (home made) OpenAL extension functions ************* //

AL_API ALboolean AL_APIENTRY alBufferDataNoCopy(ALuint bufferID, ALenum format, const ALvoid* data,
												ALsizei size, ALsizei frequency,
												ALboolean deleteOldBuffer = false);
		
#ifdef PLATFORM_WII

AL_API void	AL_APIENTRY alEnableOutputUpdates(ALboolean enable);

AL_API ALboolean AL_APIENTRY alIsOutputOpen(ALshort outputID);

AL_API ALint AL_APIENTRY alOutputClose(ALshort outputID);

AL_API void AL_APIENTRY alOutputMasterVolume(ALshort outputID, ALfloat volume);

AL_API ALint AL_APIENTRY alOutputOpen(ALshort outputID);									
											
AL_API void AL_APIENTRY alSourceOutputState(ALuint sourceID, ALshort outputID, ALshort state);

#endif

#if defined(__cplusplus)
}  /* extern "C" */
#endif

// **************** Declarations of memory allocation operators and functions **************** //


#define AL_ENUM_FLAG(name) \
	static name operator|(name a, name b) \
	{ \
		return (name)((int)a | (int)b); \
	} \
	static name operator&(name a, name b) \
	{ \
		return (name)((int)a & (int)b); \
	} \
	static name operator~(name a) \
	{ \
		return (name)(~(int)a); \
	}\
	static name& operator|=(name& a, name b) \
	{ \
		a = a | b; \
		return a; \
	} \
	static name& operator&=(name& a, name b) \
	{ \
		a = a & b; \
		return a; \
	} \

enum AlMemHint
{
	ALMEMHINT_NONE	= 0x0000,
	ALMEMHINT_FAST	= 0x0001,
	ALMEMHINT_ZERO	= 0x0002,
	ALMEMHINT_BACK	= 0x0004,
	ALMEMHINT_BEST	= 0x0008,
};

AL_ENUM_FLAG(AlMemHint) // Definition of bitwise logical operators for type AlMemHint

// Methods AlAlloc() and AlFree() are to be defined by the user application.
extern void* AlAlloc(size_t size, AlMemHint alHint);
extern void* AlAlloc(size_t size, AlMemHint alHint, const char* filename, int line);
extern void AlFree(void* ptr);
	
void* operator new(size_t size, AlMemHint hint);
void operator delete(void* ptr, AlMemHint hint);
void* operator new[](size_t size, AlMemHint hint);
void operator delete[](void* ptr, AlMemHint hint);

void* operator new(size_t size, AlMemHint hint, const char* filename, int line);
void operator delete(void* ptr, AlMemHint hint, const char* filename, int line);
void* operator new[](size_t size, AlMemHint hint, const char* filename, int line);
void operator delete[](void* ptr, AlMemHint hint, const char* filename, int line);

#define alnewh(hint)	new(hint, __FILE__, __LINE__)
#define alnew			new(ALMEMHINT_NONE, __FILE__, __LINE__)
#define alnewz			alnewh(ALMEMHINT_ZERO)
#define alnewzh(hint)	alnewh(hint|ALMEMHINT_ZERO)
#define aldelete		delete

#endif // AL_GEXT_H