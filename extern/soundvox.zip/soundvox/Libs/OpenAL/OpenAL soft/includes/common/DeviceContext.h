#ifndef DEVICE_CONTEXT_H
#define DEVICE_CONTEXT_H

#include "GeneralSettings.h"
#include "SourceListener.h"


// **************************************************************************************** //
// ****************************** ALCdevice_struct structure ****************************** //
// **************************************************************************************** //


struct ALCdevice_struct
{
 private:
    ALCdevice	*m_pNext;
    ALCchar		m_pName[25];        
 public:
	ALCdevice_struct(const char *deviceName);
	~ALCdevice_struct(void);
	ALCchar *GetDeviceName(void);
	ALCdevice_struct *GetNext(void);
	void SetNext(ALCdevice_struct *device);	
};



// **************************************************************************************** //
// ************************************ Devices class ************************************* //
// **************************************************************************************** //



class Devices
{ 
 private:
 	ALCdevice	*m_pFirst; 		// First element of the linked list of devices.
 	ALint		m_nbDevices;
 public:
	Devices(void);
	~Devices(void);
	
	ALCdevice *CreateDevice(const ALCchar *deviceName);	
	ALCdevice *GetDevice(const ALCchar *deviceName);
};


// **************************************************************************************** //
// ***************************** ALCcontext_struct structure ****************************** //
// **************************************************************************************** //


typedef struct ALCcontext_struct
{
 private:
 	static ALuint	s_IDGenerator;
 	ALuint			m_ID;
 	ALlistener		*m_pListener;
 	ALsource		**m_pSources;		// Hash table of sources.
    ALCdevice  		*m_pDevice;			// Device to which context is attached.
    ALenum			m_errorCode;
    
    // 3D positioning and doppler parameters.
    ALenum			m_distanceModel; 			// See NOTE 1 for possible values.
    ALfloat     	m_dopplerFactor;
    ALfloat     	m_speedOfSound;
    ALfloat			m_alteredSpeedOfSound;		// = m_speedOfSound * m_dopplerFactor.
    
 	ALCcontext 		*m_pNext; 	

 	ALenum ValidateSources(ALsizei nbSources, const ALuint* sources); 	
 public:
	ALCcontext_struct(ALCdevice *device, const ALCint* attributesList);
	~ALCcontext_struct(void);
	ALenum DeleteSources(ALsizei nbSources, const ALuint* sources);
	ALenum GenerateSources(ALsizei nbSources, ALuint* sources);
	ALCdevice *GetDevice(void);
	ALenum GetDistanceModel(void);
	ALfloat GetDopplerFactor(void);
	ALenum GetErrorCode(void);
	ALuint GetID(void);
	ALlistener *GetListener(void);	
	ALCcontext *GetNext(void);
	ALsource *GetSource(ALuint sourceID);
	ALfloat GetSourceDirectionalGain(ALsource *source);
	ALfloat GetSourceDistanceGain(ALsource *source);
	ALposition GetSourcePanPosition(ALsource *source);
	ALfloat GetSourcePitch(ALsource *source);	
	ALfloat GetSpeedOfSound(void);
	void SetDistanceModel(ALenum model);
	void SetDopplerFactor(ALfloat dopplerFactor);
	void SetErrorCode(ALenum error);
	void SetNext(ALCcontext	*context);
	void SetSpeedOfSound(ALfloat speed);
}ALCcontext;



// **************************************************************************************** //
// ************************************* ContextList ************************************** //
// **************************************************************************************** //


class ContextList
{ 
 private:
	ALCcontext 			*m_pContexts;
	static ALCcontext	*s_pCurrentContext;
 public:
	ContextList(void);
	~ContextList(void);
	static ALCcontext *GetCurrentContext(void);
	static void SetCurrentContext(ALCcontext *context);
	
	ALCboolean AreContextsMappedToDevice(ALCdevice_struct *device);
	ALCcontext *CreateContext(ALCdevice *device, const ALCint* attributesList);
	ALCboolean IsContextValid(ALCcontext *context);
	void DestroyContext(ALCcontext *context);
	
};


// **************************************************************************************** //
// **************************************** NOTES ***************************************** //
// **************************************************************************************** //

// NOTE 1 : Possible values for the context's distance model (m_distanceModel) are:
//
// 1) AL_NONE
// 2) AL_INVERSE_DISTANCE
// 3) AL_INVERSE_DISTANCE_CLAMPED
// 4) AL_LINEAR_DISTANCE
// 5) AL_LINEAR_DISTANCE_CLAMPED
// 6) AL_EXPONENT_DISTANCE
// 7) AL_EXPONENT_DISTANCE_CLAMPED

#endif	// DEVICE_CONTEXT_H


