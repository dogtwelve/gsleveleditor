#ifndef SOURCE_LISTENER_H
#define SOURCE_LISTENER_H

#include "GeneralSettings.h"
#include "Buffers.h"


// One element of the source buffer queue.
struct ALbufferlistitem
{
    ALuint                  m_bufferID;
    ALuint                  m_bufferState;    
    ALbufferlistitem		*m_pNext;
};


// **************************************************************************************** //
// *********************************** Listener class ************************************* //
// **************************************************************************************** //


class ALlistener
{
 private:
 	ALposition	m_position;
    ALvelocity	m_velocity;
	ALfloat		m_gain;
    ALdirection m_atOrientation;		// Front direction of listener's orientation.
    ALdirection m_upOrientation;		// Up direction of listener's orientation.
 public:
	ALlistener(void);
	~ALlistener(void);
	ALdirection *GetAtOrientation(void);
	ALfloat GetGain(void); 
	ALposition *GetPosition(void);
	ALdirection *GetUpOrientation(void);
	ALvelocity *GetVelocity(void);
	void SetAtOrientation(ALfloat x, ALfloat y, ALfloat z);
	void SetGain(ALfloat gain);
	void SetPosition(ALfloat x, ALfloat y, ALfloat z);
	void SetUpOrientation(ALfloat x, ALfloat y, ALfloat z);
	void SetVelocity(ALfloat vx, ALfloat vy, ALfloat vz);
};



// **************************************************************************************** //
// *********************************** ALsource class ************************************* //
// **************************************************************************************** //


typedef struct ALsource
{
 private:
 	static ALuint		s_IDGenerator;
 	ALuint				m_sourceID;
    ALint  				m_type;					// AL_UNDETERMINED, AL_STREAMING or AL_STATIC.
    
    // Pitch parameters
	ALfloat				m_pitch;			// Pitch change asked by application (without sample rate).
    ALfloat      		m_effectivePitch;	// 1.0f = normal play (sample rate conversion included).    
    
    // Volume parameters
    ALfloat				m_gain;
    ALfloat				m_minGain;
    ALfloat				m_maxGain;
    
    // 3D positioning parameters
    ALboolean			m_isRelativeToListener;	// AL_TRUE : position relative to listener.
	ALposition			m_position;
	ALfloat				m_referenceDistance;
	ALfloat				m_maxDistance;
	ALfloat				m_rollOffFactor;
    ALvelocity			m_velocity;
    ALdirection			m_direction;
    ALfloat				m_coneInnerAngle;
    ALfloat				m_coneOuterAngle;
    ALfloat				m_coneOuterGain;

	// Playback parameters
    ALenum       		m_playbackState;		// AL_INITIAL, AL_PLAYING, AL_STOPPED or AL_PAUSED.
    ALenum				m_intraPlaybackState;	// SOURCE_WAITING, RESET_SOURCE.
    ALuint				m_nbExecutedChannels;	// During playback, current nb of channels executed.
    ALuint				m_pNbVoiceBufferResets[MAX_NB_SOURCE_CHANNELS];
	ALuint				m_pChannelsStatus[MAX_NB_SOURCE_CHANNELS];
    ALuint				m_existenceStatus;		// SOURCE_TO_DELETE, KEEP_SOURCE_ALIVE or SOURCE_BEING_DELETED.
    ALuint				m_postResetState;
	ALboolean			m_isSourceLooping;
	ALboolean			m_isSourceLinkedToVoices;
	
	// Buffer queue parameters
    ALbufferlistitem	*m_pBufferQueue; 		// Start of the linked list of buffers in queue.
    ALbufferlistitem	*m_pItemListStart;		// Start of buffer item in linked list.
    ALuint				m_nbListItems;			// Total number of list items containing the queue.  
    ALuint				m_nbQueuedBuffers;    	// Number of buffers in actual queue.
    ALbufferlistitem	*m_firstUnprocessedBuffer; 
    ALuint				m_nbProcessedBuffers;	// Number of buffers already processed (played)
    ALenum				m_buffersFormat;		// Audio format of queued buffers.
    ALsizei				m_buffersFrequency;		// Sampling frequency of queued buffers.
	ALuint				m_sampleWidth;			// Buffers sample width.
    ALuint				m_nbChannels;			// 1 : mono, 2 : stereo.
    ALuint 				m_cursorPosition;      	// Read position in current buffer (in samples).
    static Buffers		*s_pBuffers;			// Pointer to the hash table of all buffers.

	ALsource 			*m_pNext;
	
	#ifdef PLATFORM_WII
		ALshort			m_pOutputsStates[AL_NB_OUTPUTS]; // states : AL_OUTPUT_OFF, AL_OUTPUT_ON.
	#endif
   
    ALenum	VerifyBuffersIntegrity(ALsizei nbBuffers, const ALuint *bufferIDs);
    
 public:
	ALsource(void);
	~ALsource(void);
	static void SetBuffers(Buffers *buffers);
	
	void AddExecutedChannel(void);
	void AddVoiceBufferReset(ALshort channel);
	ALboolean AreChannelsUnused(void);
	void AttachStaticBuffer(ALuint bufferID);
	void DetachAllBuffers(void);
	void FinalizeVoiceBufferReset(void);	
	ALenum GetBuffersFormat(void);
	ALsizei	GetBuffersFrequency(void);
	ALint GetByteOffset(void);
	ALfloat GetConeInnerAngle(void);
	ALfloat GetConeOuterAngle(void);
	ALfloat GetConeOuterGain(void);
	ALuint GetCursorPosition(void);
	ALdirection *GetDirection(void);
	ALfloat GetEffectivePitch(void);
	ALuint GetExistenceStatus(void);
	ALuint GetFirstBufferID(void);
	ALfloat GetGain(void);
	ALuint GetID(void);
	ALfloat GetMaxDistance(void);
	ALfloat GetMaxGain(void);
	ALfloat GetMinGain(void);
	ALuint GetNbChannels(void);
	ALuint GetNbExecutedChannels(void);
	ALuint GetNbProcessedBuffers(void);
	ALuint GetNbQueuedBuffers(void);
	ALuint GetNbVoiceBufferResets(ALshort channel);
	ALsource *GetNext(void);
	Buffer *GetNextBuffer(void);
	ALfloat GetPitch(void);
	ALenum GetPlaybackState(void);
	ALposition *GetPosition(void);
	ALuint GetPostResetState(void);
	ALfloat GetReferenceDistance(void);
	ALfloat GetRollOffFactor(void);
	ALint GetSampleOffset(void);
	ALfloat GetSecOffset(void);	
	ALint GetType(void);
	ALuint GetUnprocessedBufferID(ALuint bufferIndex);
	ALvelocity *GetVelocity(void);
	ALboolean IsRelativeToListener(void);
	ALboolean IsSourceLinkedToVoices(void);
	ALboolean IsSourceLooping(void);
	ALenum QueueBuffers(ALsizei nbBuffers, const ALuint *bufferIDs);
	void ResetNbExecutedChannels(void);
	void Rewind(void);
	void SetAllBuffersAsProcessed(void);
	ALenum SetBuffer(ALint bufferID);
	void SetBufferAsProcessed(void);
	void SetBuffersFormat(ALenum format);
	void SetBuffersFrequency(ALsizei frequency);
	void SetChannelStatus(ALshort channel, ALuint status);
	void SetConeInnerAngle(ALfloat angle);
	void SetConeOuterAngle(ALfloat angle);
	void SetConeOuterGain(ALfloat gain);
	void SetCursorPosition(ALuint cursorPosition);
	void SetDirection(ALfloat x_direction, ALfloat y_direction, ALfloat z_direction);
	void SetExistenceStatus(ALuint status);
	void SetGain(ALfloat gain);
	void SetLoopState(ALboolean state);
	void SetMaxDistance(ALfloat maxDistance);
	void SetMaxGain(ALfloat maxGain);
	void SetMinGain(ALfloat minGain);
	void SetNext(ALsource *source);
	void SetPitch(ALfloat pitch);
	void SetPlaybackState(ALenum state);
	void SetPosition(ALfloat x, ALfloat y, ALfloat z);
	void SetRelativeToListener(ALboolean isRelativeToListener);
	void SetPostResetState(ALuint state);
	void SetReferenceDistance(ALfloat distance);
	void SetRollOffFactor(ALfloat rollOffFactor);
	void SetSourceVoiceLink(ALboolean isSourceLinkedToVoices);	
	void SetType(ALint type);
	void SetVelocity(ALfloat vx, ALfloat vy, ALfloat vz);
	void UpdateIntraPlaybackState(void);
	void UpdatePlaybackState(void);
	ALenum UnqueueBuffers(ALsizei nbBuffers, ALuint *bufferIDs);
	
	#ifdef PLATFORM_WII
		ALshort GetOutputState(ALshort outputID);	
		void SetOutputState(ALshort outputID, ALshort state);
	#endif	
}ALsource;

#endif // SOURCE_LISTENER_H
