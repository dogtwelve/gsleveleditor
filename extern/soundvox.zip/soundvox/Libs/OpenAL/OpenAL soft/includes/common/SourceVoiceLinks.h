#ifndef SOURCE_VOICE_LINKS_H
#define SOURCE_VOICE_LINKS_H

#include "CurrentAudioPlatform.h"

#ifdef PLATFORM_WII
	#include "Wii_Interface.h"
#elif defined PLATFORM_PS3
	#include "PS3_Interface.h"
#endif

#include "GeneralSettings.h"
#include "SourceListener.h"
#include "DeviceContext.h"
#include "Buffers.h"


// **************************************************************************************** //
// ********************************** SourceToVoice class ********************************* //
// **************************************************************************************** //


class SourceToVoice
{ 
 private:
 	
 	PlatformVoice	*m_pVoice;				// Voice connected to source.
 	ALsource		*m_pSource;				// Source connected to voice.
	ALuint			m_sourceID;				// = 0 when no source connected to voice.
	ALuint			m_nbSourceChannels;		// 1 : mono, 2 : stereo.
	ALshort 		m_sourceChannel; 		// Index of source's channel (starts at 0).
 public:
	SourceToVoice(ALshort voiceID);
	~SourceToVoice(void);
	void Connect(ALsource *source, ALshort sourceChannel);
	void Disconnect(void);
	void FillVoiceBufferStatic(Buffers *sourceBuffers, short *voiceBuffer);
	void FillVoiceBufferStatic(Buffers *sourceBuffers, float *voiceBuffer);
	void FillVoiceBufferStreaming(Buffers *sourceBuffers, short *voiceBuffer);
	void FillVoiceBufferStreaming(Buffers *sourceBuffers, float *voiceBuffer);
	ALsource *GetSource(void);
	ALuint GetSourceID(void);
	PlatformVoice *GetVoice(void);
	void ResetVoiceBuffer(void *voiceBuffer);
	#ifdef PLATFORM_WII
		void UpdateVoiceOutputState(void);
	#endif
	void UpdateVoiceParameters(void);
	void UpdateVoicePitch(void);	
	void UpdateVoicePosition(void);
	void UpdateVoiceVolume(void);
};



// **************************************************************************************** //
// ********************************* SourceVoiceLinks class ******************************* //
// **************************************************************************************** //


struct SourceVoiceLink
{
	ALuint m_sourceID;    
    ALint m_sourceChannel;
};


class SourceVoiceLinks
{ 
 private: 
 	static SourceVoiceLinks *s_pInstance; 	
  
	SourceToVoice		**m_pSourceVoiceLinks;	// Array of SourceToVoice objects.
	Buffers				*m_pSourceBuffers;		// List of all source buffers
	ALshort				m_nbLinks;				// Size of table m_pSourceVoiceLinks.
	ALshort				m_lastUsedLink;			// Index of the last link currently in use.
	ALshort				m_firstFreeLink;		// First free entry in table m_pSourceVoiceLinks.
	ALshort				m_nbFreeLinks;			// Nb of free entries in table m_pSourceVoiceLinks.
 public:
	SourceVoiceLinks(ALshort nbLinks, ALCcontext *context, Buffers *sourceBuffers);
	~SourceVoiceLinks(void);	
	static SourceVoiceLinks* GetInstance();
	
	ALboolean ConnectSourceToVoices(ALsource *source);
	void DisconnectSourceFromVoices(ALuint sourceID);
	void UpdateVoices(void);
};

#endif // SOURCE_VOICE_LINKS_H