#ifndef OPEN_AL_MUTEX_H
#define OPEN_AL_MUTEX_H

#include "CurrentAudioPlatform.h"
#include "GeneralSettings.h"

#ifdef PLATFORM_PS3
	#include <sys/synchronization.h>
	typedef sys_lwmutex_t mutexType;
#elif PLATFORM_WII
	typedef OSMutex mutexType;
#elif _WIN32
	#include <windows.h>
	typedef HANDLE mutexType;
#else // Dummy impl
	typedef int mutexType;
#endif

#define USE_OPENAL_MUTEX 1


// **************************************************************************************** //
// ************************************** ALMutex class *********************************** //
// **************************************************************************************** //


class ALMutex
{
 public:
	ALMutex();
	~ALMutex();

	void Lock();
	void Unlock();

 private:
	mutexType m_mutex;
	#ifdef PLATFORM_WII
		ALboolean	m_wereInterruptsEnabled;
	#endif
};



// **************************************************************************************** //
// ******************************** ScopedALMutexLock class ******************************* //
// **************************************************************************************** //


class ScopedALMutexLock
{
 public:
	ScopedALMutexLock(ALMutex* mutex);
	~ScopedALMutexLock(void);
 private:
	ALMutex* m_mutex;
};

#endif // OPEN_AL_MUTEX_H