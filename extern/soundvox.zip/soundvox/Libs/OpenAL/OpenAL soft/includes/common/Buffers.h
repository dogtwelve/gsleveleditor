#ifndef BUFFERS_H
#define BUFFERS_H

#include "GeneralSettings.h"

// **************************************************************************************** //
// ************************************* Buffer class ************************************* //
// **************************************************************************************** //

// Define buffer states.
#define UNUSED    0
#define PENDING   1
#define PROCESSED 2


class Buffer
{
 private:
	ALuint		m_bufferID;
	ALboolean	m_deleteOldMemory;
	ALenum		m_state;			// UNUSED, PENDING or PROCESSED.
	ALenum		m_format;
	ALsizei		m_frequency;	
	ALchar		*m_pMemory;			// Actual memory (potentially containing header of file).
	ALchar		*m_pDataMemory;		// Part of memory containing data.
	ALsizei		m_memorySize;		// Size of buffer m_pDataMemory.
	ALint		m_nbChannels;		// Number of channels.
	ALsizei		m_dataSize;			// Size of the data portion of buffer (in bytes).
	ALuint		m_nbSamples;		// Nb of samples per channel.
	Buffer		*m_pNext;			// Next buffer in the linked list of the hash table entry.
	ALuint		m_referenceCount;	// Nb of sources using this buffer (deletion can only occur when 0)	
 public:
	Buffer(ALuint bufferID);
	~Buffer(void);
	void DecreaseReferenceCount(void);
	ALuint GetSampleWidth(void);	
	ALenum GetFormat(void);
	ALsizei GetFrequency(void);
	ALuint GetID(void);
	ALchar *GetMemory(void);
	ALint GetNbChannels(void);
	ALuint GetNbSamples(void);
	Buffer *GetNext(void);
	ALuint GetReferenceCount(void);
	ALsizei GetSize(void);
	ALenum GetState(void);
	void IncreaseReferenceCount(void);
	void SetData(ALenum format, const ALvoid* data, ALsizei size, ALsizei frequency);
	ALboolean SetDataNoCopy(ALenum format, const ALvoid* data, ALsizei size, 
							ALsizei frequency, ALboolean deleteOldBuffer);
	void SetFormat(ALenum format);
	void SetFrequency(ALenum frequency);
	void SetNext(Buffer *buffer);
	void SetState(ALenum state);
};



// **************************************************************************************** //
// ************************************ Buffers class ************************************* //
// **************************************************************************************** //


class Buffers
{
 private:
 	static ALuint	s_IDGenerator;	// Generator of buffer ID. For OpenAL, buffer 0 is NULL.
	Buffer			**m_pBuffers;	// Hash table (array of linked list) of buffers.
	
	ALenum VerifyBuffersUnusedState(ALsizei nbBuffers, const ALuint* buffers);
 public:
	Buffers(void);
	~Buffers(void);

	ALCboolean AreAllBuffersDeleted(void);
	ALenum DeleteBuffers(ALsizei nbBuffers, const ALuint* buffers);
	ALenum GenerateBuffers(ALsizei nbBuffers, ALuint* buffers);
	Buffer *GetBuffer(ALuint bufferID);
};


#endif // BUFFERS_H

