#ifndef GENERAL_SETTINGS_H
#define GENERAL_SETTINGS_H			

#include "CurrentAudioPlatform.h"

#ifdef PLATFORM_WII
	#include "Wii_Settings.h"
	#include <cstring>				// memset, memcpy
#elif defined PLATFORM_PS3
	#include "string.h"				// memset, memcpy
	#include "PS3/PS3_Settings.h"
#endif

#include "float.h"	// Used to get the FLT_MAX constant.

// Open AL includes
#include "al.h"
#include "alc.h"
#include "al_gext.h" // Gameloft's homemade extensions for OpenAL (Wii and PS3) implementations.


// Define PlatformVoice playback states
#define		PLAYBACK_STATE_NONE			0
#define		PLAYBACK_STATE_PLAYING		1
#define		PLAYBACK_STATE_PAUSED		2
#define		PLAYBACK_STATE_STOPPED		3

// Define source maximum number of channels
#define	MAX_NB_SOURCE_CHANNELS	2

// Define the number of voice buffer resets to make when a source is stopping.
#define	SOURCE_STOP_RESET_LIMIT	2

// Define minimum pitch for a source.
#define SOURCE_MIN_PITCH		0.001f

// Define intra playback states for source objects
#define SOURCE_WAITING			0
#define RESET_SOURCE			1

// Define source existence states
#define DELETE_SOURCE			0
#define KEEP_SOURCE_ALIVE		1	// Don't delete source.

// Define source post reset state when no change is needed. 
#define NO_STATE_CHANGE			0

// Define use status of source channels
#define SOURCE_CHANNEL_UNUSED	0
#define SOURCE_CHANNEL_IN_USE	1

// Define the size of the ALbuffers hash table.
#define AL_BUFFERS_TABLE_SIZE	128

// Define the size of the ALsources hash table.
#define AL_SOURCES_TABLE_SIZE	32

// Define sampling rate settings
#define	MAX_SAMPLING_RATE	48000

// Define float <-> fixed-point conversion factors
#define	FLOAT_FIXED_1_15_FACTOR		32767.0f

// Define 1 / sqrt(2)
#define	SQRT_2_INVERSE	0.7071067811865475f

// Define PI
#define AL_PI 3.141592653589793f

// Define 180 degrees
#define ANGLE_180_DEGREES	180

// Define of value for an unknown audio format
#define UNKNOWN_FORMAT		0

// Define sample width
#define SAMPLE_WIDTH_8_BITS		8
#define SAMPLE_WIDTH_16_BITS	16
#define SAMPLE_WIDTH_32_BITS	32

// Define the buffer format for streaming.
#define SINGLE_BUFFER 1
#define DOUBLE_BUFFER 2

// Define names for first and second buffer in a double buffer scheme.
#define FIRST_BUFFER	0
#define	SECOND_BUFFER	1

// Define IDs representing the absence of resource, player, voice and SourceVoiceLink.
#define NO_SOURCE_VOICE_LINK	-1

// Define the availability of a source to voice link.
#define SOURCE_VOICE_LINK_AVAILABLE		-1

// Structure defining a 3D vector.
struct ALvector
{
	ALfloat m_x;
	ALfloat m_y;
	ALfloat m_z;
};

// Structure containing position coordinates of source or listener.
typedef ALvector ALposition;

// Structure containing velocity values of source or listener.
typedef ALvector ALvelocity;

// Structure containing direction values of source.
typedef ALvector ALdirection;

#endif // GENERAL_SETTINGS_H