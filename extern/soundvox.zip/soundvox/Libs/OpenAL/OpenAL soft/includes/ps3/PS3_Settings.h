#ifndef PS3_SETTINGS_H
#define PS3_SETTINGS_H

#include "cell/mixer/define.h"
#include "cell/audio.h"
#include "sys/ppu_thread.h"
#include "cell/sysmodule.h"
// TODO : Get rid of "stdio.h" when done.
#include "stdio.h"
#include <time.h> // For clock_t

#define	PLATFORM_SAMPLING_RATE	48000

// Define PS3 nominal number of samples gotten from voice buffer.
#define	NOMINAL_DSP_SAMPLE_TRANSFER		256

// Define pitch upper limit
#define VOICE_PITCH_LOWER_LIMIT		0.0625f
#define VOICE_PITCH_UPPER_LIMIT		8.0f

// Define the number of voices that can be created.
#define MAX_VOICES 60

// Define the voice buffer size.
#define VOICE_BUFFER_SIZE 256

// Define the write status of the voice playback buffers.
#define VOICE_BUFFER_UNAVAILABLE	0
#define VOICE_BUFFER_AVAILABLE		1

// Define Cell surround mixer status
#define SURROUND_MIXER_OFF	0
#define SURROUND_MIXER_ON	1

// Define maximum value for 16 bits fixed-point values.
#define MAX_FIXED_POINT_16		32767.0f

// Define the number of stopping fade outs (also valid for pause)
#define NB_STOP_FADE_OUTS		3

#endif // PS3_SETTINGS_H