#ifndef PS3_INTERFACE_H
#define PS3_INTERFACE_H

#include "GeneralSettings.h"

class PlatformVoice
{ 
 private:
	// SurMixer parameters.
	static CellSurMixerConfig	s_pMixerConfiguration;		// Surround mixer parameters.
	static CellAANHandle		s_pMixerHandle;				// Handle to surround mixer.

	// Buffers and playback parameters
	ALuint			m_inputBufferSize;	// Size of input buffer (in samples).	
	ALchar			*m_pInputBuffer;	// Buffer containing samples to interpolate.
	ALuint			m_bufferSize;		// Size of the playback buffer (in samples).
	ALuint			m_bufferSizeBytes;	// Size of the playback buffer (in bytes).
	ALfloat			*m_pPlaybackBuffer;	// Buffer of interpolated samples provided to PS3 audio engine.
	ALuint			m_playbackState;

	// Pitch parameters (time is normalized to 'outputRate / pitch').
	ALuint			m_nbInputSamples;		// Nb of interpolating samples needed (without edge sample).
	ALshort			m_edgeInputSample;		// Input sample used in previous and current pass (short).
	ALfloat			m_edgeInputSampleF;		// Input sample used in previous and current pass (float).
	ALfloat			m_outputTimeStep;		// Interpolation time step (= current pitch).
	ALfloat			m_startTimeOffset;		// Time of the first interpolated sample.
	ALfloat			*m_pExtraOutputSamples;	// Extra samples interpolated in last pass.
	ALint			m_extraOutputSamplesSize;// Maximum nb of samples in array m_extraOutputSamples.
	ALint			m_nbExtraOutputSamples;	// Nb of extra output samples from the last pass.

	// Position parameters
	CellSurMixerPosition	*m_pPosition;

	// Volume parameters
	ALfloat			m_currentVolume;		// Volume value once volume is updated.

	// Channel strip parameters.
	ALuint			m_channelStripPortNo;	// Channel strip port number (needed to provide data).
	ALuint			m_channelStripIndex;	// Channel strip index (from 0 to MAX_VOICES - 1).	

	void Acquire(void);
 public: 	
	PlatformVoice(ALshort voiceID);
	~PlatformVoice();
	static void Clean(void);
	static void Init(void);

 	void		*GetBufferToFill(void);
 	ALuint		GetNbSamplesNeeded(void);
 	ALshort		GetPlaybackState(void);
	void		Pause(void);
 	void		Play(void);
	void		Reset(void);
 	void		SetPitch(ALfloat pitch);
	void		SetPosition(ALposition *position);
	void		SetVolume(ALfloat gain);
	void		Stop(void);
	void		Update(ALshort *buffer);
	void		Update(ALfloat *buffer);
	void		UpdateNoInterpolation(ALshort *buffer);
	void		UpdateNoInterpolation(ALfloat *buffer);
};

#endif // PS3_INTERFACE_H