#ifndef WII_INTERFACE_H
#define WII_INTERFACE_H

#include "GeneralSettings.h"
#include "Wii_Settings.h"


class PlatformVoice
{
 public: 	
 	PlatformVoice(ALshort voiceID);
	~PlatformVoice();
	
	static void Clean(void);
	static ALint CloseOutput(ALshort outputID);
	static void EnableOutputUpdates(ALboolean enable);
	static void Init(void);
 	static ALboolean IsOutputOpen(ALshort outputID);
 	static ALint OpenOutput(ALshort outputID);
	static void SetOutputMasterVolume(ALshort outputID, ALfloat volume);
 	static void UpdateWiimoteSounds(void);

 	void		*GetBufferToFill(void);
 	ALuint		GetNbSamplesNeeded(void);
 	ALuint		GetPlaybackState(void);
 	void		Pause(void);
 	void		Play(void);
 	void		Reset(void);
 	void		SetOutputState(ALshort outputID, ALshort state);
 	void		SetPitch(ALfloat pitch);
 	void		SetPosition(ALposition *position);
	void		SetVolume(ALfloat gain);
 	void		Stop(void);	
	void		Update(ALshort *buffer);		
 private:
 	// General speaker parameters (including wiimotes)
 	static ALfloat		s_pOutputVolumes[];			// Outputs master volumes.
 	static ALshort		s_totalWiimoteConnections;	// Total of connections on all wiimotes.
	static ALshort		s_pNbWiimotePlayingVoices[];// Nb voices playing on each wiimote.	
	static ALshort		s_pWiimoteBuffer[];
	static ALubyte		s_pWiimoteEncodedData[];
	static ALuint		s_wiimoteEncodeFlag[];
	static WENCInfo		s_pWiimoteEncodeInfos[];
	static ALboolean	s_isWiimoteUpdated;

 	// General parameters
 	ALshort			m_voiceID;
	AXVPB           *m_pVoiceBlock;

	// Buffer parameters
	ALuint			m_bufferSize;		// Size of each of the two buffers (in samples).
	ALuint			m_bufferSizeBytes;	// Size of each of the two buffers (in bytes).
	ALchar*			m_pPlaybackBuffer;	
	
	// Buffer addresses (in the AX sample adressing mode, see NOTE 1).
	ALuint			m_startAddress;		// Start of the first of double buffer.
	ALuint			m_endAddress;		// End of the second of double buffer.
	ALuint			m_halfAddress;		// Start of the second of double buffer.
	ALuint			m_cursorStart;		// Cursor's starting address.
	ALshort			m_bufferToFillIndex;
	
	// Playback state parameters
	ALuint			m_playbackState;
	
	// Pitch parameters
	ALfloat			m_currentPitch;
	ALfloat			m_pitchUpperLimit;
	ALfloat			m_pitchLowerLimit;
    AXPBSRC			m_voiceSrc;
		
	// Position parameters
	ALposition		m_position;
	
	// Volume parameters
	ALfloat			m_currentGain;			// Gain value once volume is updated.
	ALushort		m_currentVolume;		// Volume value once volume is updated.
	
	// Voice specific speakers parameters (including wiimotes)
	ALint			m_pOutputsStates[AL_NB_OUTPUTS];	// states = AL_OUTPUT_ON, AL_OUTPUT_OFF
    AXPBMIX			*m_wiiMixing;						// Mixing for principal speakers.
	
	// Wiimote speaker (voice specific) parameters
   	ALshort			m_nbActiveWiimoteChannels;	// Nb of channels on which voice outputs.
	AXPBRMTMIX		*m_wiimoteMixing;			// Mixing for wiimote speakers.
	
 	static void WiimoteOnCallback(s32 outputID, s32 result);
 	static void WiimotePlayCallback(s32 outputID, s32 result);	
		
	void Acquire(void);
	void UpdateWiimoteVolumes(void);		
};


// **************************************************************************************** //
// ****************************************** NOTES *************************************** //
// **************************************************************************************** //


// NOTE 1 : When providing buffer addresses to the AX interface, addresses must be
//			divided by 2 for 16 bits samples.


#endif // WII_INTERFACE_H



