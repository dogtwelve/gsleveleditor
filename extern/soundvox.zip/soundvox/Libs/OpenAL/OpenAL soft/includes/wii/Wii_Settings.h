#ifndef WII_SETTINGS_H
#define WII_SETTINGS_H

#include <revolution.h>
#include <revolution/mix.h>
#include <revolution/mem.h>

// Includes necessary for wiimote playback
#include <wpad.h>
#include <wenc.h>

// Includes necessary to create threads
#include <os.h>
#include <OSThread.h>
// Definitions : 	typedef s64	OSTime; // In "os.h"
//					typedef u32	OSTick; // In "os.h"

#define	PLATFORM_SAMPLING_RATE	32000
#define MAX_VOICES				96
#define VOICE_BUFFER_SIZE		512 	// Should be at least 2 * 96 * maxWiiPitch (= 4).
										// If not, limit the AX pitch consequently.

// Define voice priorities
#define	VOICE_PRIORITY_HIGH		31
#define	VOICE_PRIORITY_MEDIUM	15
#define	VOICE_PRIORITY_LOW		1

// Even if AX envelope 'currentVolume' parameter is defined as a u16, it is limited
// in value to 0x8000, which in AX's fixed-point representation corresponds to 1.0f.
#define	MAX_VOLUME 1.0f

// Define the (left or right) pan limit. See NOTE 1
#define SIDE_PAN_LIMIT		30500 //32767

// Define center volume value (= 0.707 * 32767). See NOTE 1
#define CENTER_PAN_VALUE	21566 //23170		

// Define voice pan factor as (1.0 - 0.707)
#define VOICE_PAN_FACTOR	0.29289321881345f

// Define the nominal number of samples gotten from voice buffer.
#define	NOMINAL_DSP_SAMPLE_TRANSFER		96

// Define number of samples per wiimote output buffer.
#define WIIMOTE_NB_SAMPLES_BUFFER		40
#define	WIIMOTE_PACKET_MAX_LENGTH		20

// Define the size of wiimote encoded data
#define	WIIMOTE_ENCODED_DATA_SIZE		24

// Define array index for Wii normal speakers
#define WII_PRIMARY_OUTPUT	WPAD_MAX_CONTROLLERS // = 4

// Define Wii maximal pitch
#define MAXIMAL_PITCH	4.0f

	
#endif // WII_SETTINGS_H


// **************************************************************************************** //
// **************************************** NOTES ***************************************** //
// **************************************************************************************** //

// NOTE 1 : When a full-scale mono sine wave transmitted on a single voice is panned on the left
//			(or right) channel, sound is clipped if SIDE_PAN_LIMIT is larger than approximately
//			31000. Sound is correct at SIDE_PAN_LIMIT = 30500. For this reason, SIDE_PAN_LIMIT
//			has been limited to 30500 and CENTER_PAN_VALUE to 0.707 * 30500.			