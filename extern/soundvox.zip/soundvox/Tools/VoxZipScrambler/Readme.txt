////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         Vox Audio Engine Tools                             //
//                                                                            //
//                              Zip scrambler                                 //
//                                                                            //
//                               Robert Houde                                 //
//                             (c)2010 Gameloft                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

This tool allows the scrambling of uncompressed zip archives. This is done by
overwriting the signatures of all headers in the following way:

1) Local file headers : Signature is replaced by magic number
2) Central directory file headers : The signature is XORed with the magic number.
3) End of central directory header : The signature is XORed with the magic number.

The magic number can be provided as argument. If not, constant VOX_ZIP_MAGIC_NUMBER
is taken as magic number.

Usage : 
    VoxZipScrambler [-m magicNumber] [-o outputFile] <inputFile>
    VoxZipScrambler [-o outputFile] [-m magicNumber] <inputFile>
    
Note : If only the input file is specified the scrambler will overwrite it with 
       the new data, without any warning.(Drag and drop mode will use this mode).