////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         Vox Audio Engine Tools                             //
//                                                                            //
//                              ADPCM Encoder                                 //
//                                                                            //
//                            Alexandre B�langer                              //
//                             (c)2009 Gameloft                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

This tool allow the encoding of PCM (uncompressed) in Wave container (.wav) to 
IMA/DVI-ADPCM conpression scheme.  This encoder also extend the algorithm by
allowing to encode file with from 1 to 8 channels.  This encoder also fix 
looping problem cause by wrongly encoded last block, miscounted sample in fact 
chunk and compression error at the begging of the file.

Usage : 
    ADPCMEncoder <inputfile>
    ADPCMEncoder <inputfile> <outputfile> [block size=1024]
    
Note : If only the input file is specified the encoder will overwrite it with 
       the new data, without any warning.(Drag and drop mode will use this mode)
       Block size parameter is optional. For smoother decoding at runtime this
       parameter can tweaker to get block of data near frame duration.