////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         Vox Audio Engine Tools                             //
//                                                                            //
//                             Wave Properties                                //
//                                                                            //
//                            Alexandre B�langer                              //
//                             (c)2011 Gameloft                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

This tool print the properties of wave files

Usage : 
  Start the GUI with WaveProperties.exe
  
  Click "File..." button to add a file with the file dialog or directly drag 
  files inside the interface.
      
Note : This tool is only for wave file (*.wav).  File with compression code 
       other than 1 (PCM), 2 (MSADPCM) or 17 (IMA-ADPCM), may show incomplete or
       incorrect information.