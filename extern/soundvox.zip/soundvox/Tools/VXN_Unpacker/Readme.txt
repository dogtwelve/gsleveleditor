////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         Vox Audio Engine Tools                             //
//                                                                            //
//                              VXN Unpacker                                  //
//                                                                            //
//                                Robert Houde                                //
//                             (c)2009 Gameloft                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

This tool allows the recovery of the xml and wav files used to construct a vxn
file. Since a vxn file does not contain the names of the original wav files used
to create its segments, the recovered wav files are given names constructed from
the vxn file name. For example, a (3 segments) vxn file named test.vxn will
produce wav files denoted test_segment_0.wav, test_segment_1.wav and 
test_segment_2.wav. These names will also be used with the 'filename' attribute
of the xml 'segment' element.

Usage : 
    VXN_Unpacker <vxnfilename>
    VXN_Unpacker <vxnfilename> <xmlfilename>
    
Note : If only the vxn file name is specified, the xml file will get the same
       name as the vxn file (except for the xml extension). Drag and drop uses
       this mode.