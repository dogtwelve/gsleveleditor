////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         Vox Audio Engine Tools                             //
//                                                                            //
//                            Vox Player Remote                               //
//                                                                            //
//                               Robert Houde                                 //
//                             (c)2011 Gameloft                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

This player allows upload and playback of multiples files on a remote device.
All files having a format supported by the Vox base implementation (i.e. Wav PCM,
IMA-ADPCM, MS-ADPCM, MPC, Ogg-Vorbis and vxn) can be played (vxn state transitions
are not supported at the moment). The client side (located on your computer)
presents the player user interface through a tab named 'Vox Player' in the glf
debugger. The server side (on the remote device) uses Vox to control playback. 

Usage
=====

1) Install the server on the remote device. Server executables are located in
   vox/Tools/VoxPlayerRemote/dist/platform (where platform is either android,
   iPhone, ...).
   
2) Start the server on the remote device.

3) Start the glf debugger (glf/tools/debugger/glfDebugger.exe) and connect to
   the remote device. If using an Android phone connected with USB, use the
   run_glfdebugger_android.bat instead (it starts the glf debugger and connects
   to the device). When you are connected, you should see a tab named 'Vox Player'
   within the glf debugger window.
   
4) In the 'Player' tab (within the 'Vox Player' tab), browse for a file and
   click the 'Send' button.

5) Select the newly created emitter in the 'Emitters' list and use the buttons
   below to control its playback. A volume slider is also available.


Present status of the player
============================

1) Remote devices include iPhone and Android phones (AudioTrack is used on
   Android phones).
   
2) Only one file at a time can be uploaded to the remote device.

3) Uploaded files are decoded in RAM on the remote device (no disk save). 
   Therefore, we recommend deleting the emitters you no longer use.
   
4) Vxn can be played but state transitions are not supported.

