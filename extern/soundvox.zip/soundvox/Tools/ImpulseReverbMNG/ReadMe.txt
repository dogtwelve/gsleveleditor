////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         Vox Audio Engine Tools                             //
//                                                                            //
//                            Impulse Reverb MNG                              //
//                                                                            //
//                            Alexandre Bélanger                              //
//                             (c)2009 Gameloft                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

This tool allows the creation of a mng file for PS3 multistream driver.  The 
current version only allows 1 channel impulse and will show a warning if
sampling rate is not 48 kHz.  This tool only accept PCM (uncompressed) wav file.

Usage
=====

1- Load impulse wav file
2- Export MNG

