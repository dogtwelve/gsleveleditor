////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         Vox Audio Engine Tools                             //
//                                                                            //
//                             MS-ADPCM Encoder                               //
//                                                                            //
//                               Robert Houde                                 //
//                             (c)2011 Gameloft                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

This tool allow the encoding of PCM (uncompressed) in Wave container (.wav) to 
MS-ADPCM conpression scheme.

Usage : 
    ADPCMEncoder <inputfile>
    ADPCMEncoder <inputfile> <outputfile> [block size=1024]
    
Note : If only the input file is specified the encoder will overwrite it with 
       the new data, without any warning.(Drag and drop mode will use this mode)
       Block size parameter is optional (default value is 1024 bytes). For smoother
       decoding at runtime this parameter can tweaker to get block of data near
       frame duration.