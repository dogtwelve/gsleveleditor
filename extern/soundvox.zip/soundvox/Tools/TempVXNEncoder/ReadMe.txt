////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         Vox Audio Engine Tools                             //
//                                                                            //
//                          VXN Temporary Encoder                             //
//                                                                            //
//                            Alexandre B�langer                              //
//                             (c)2010 Gameloft                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

This tool will allow specific patterns of interactive music to be encoded into
VXN files.  This tool is temporary and will be replaced with the VXN Editor as
soon as it's available and fully supported in Vox Audio Engine.

=== Important Limitations ===

- No resampling will be done, the file in input need to be 16 bits PCM already
	resample to the desired value.  The "Sample Rate" value in the GUI is only to
	specify the current sample rate of the input file.
	
- All input must have mathing properties : bit per sample, channels, sample rate

- For the crossfading music, both track MUST have the exact same amount of 
	samples or a crash might occurs
	
- The project file (XML) must be save on the same drive the input wav file are 
	on, however it can be save in a different folder.
	
- If the input files are rename or move to another folder, the project must	be 
	recreated.  If only the content of the input file has changed, the project is 
	still valid.
	
== How To Use The Tool ==

- Open the GUI (TempVXNProjectCreator.exe)

- Select the tab corresponding to the type of pattern you need

- Fill all the field (be sure to check the comments at the base of the form)

- Click CreateXML and save the project file

- Drag and drop the project file on the encoder "NativeEncoder.exe"

After theses step you should find a vxn file in you folder project with the same
name.


Other patterns may be added if needed, however this is a temporary tool, so 
development will be kept as minimal as possible