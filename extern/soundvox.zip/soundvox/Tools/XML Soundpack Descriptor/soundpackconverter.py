
#
# Utility to convert soundpacks from xls to xml.
#
# C.D. March 2010
# A.B. April 2010
#

import xml.dom.minidom
from pyExcelerator import *

def parseSoundPackXLS( inputfile, toLowerFilenames=False):
  soundEntries = []
  bankEntries = []
  groupEntries = []
  actionEntries = []
  sheets = []
  sections = {}
    # Todo: get columns from their respective labels?
  soundscolumns = { 'label':0, 'filename':2, 'group':3 , 'bank':4, 'priority':5, 'loop':6, 'format':10, 'loadingflags':12, 'refdistance':14 , 'maxdistance':15, 'rolloff':16, 'basegain':17, 'mingainmod':18, 'maxgainmod':19, 'basepitch':20, 'minpitchmod':21, 'maxpitchmod':22, 'customparam':23}
  groupscolumns = { 'name':0, 'bus':2, 'pos3d':5 , 'volumeslider':7}
  bankscolumns = { 'name':0, 'maxplaybacks':1, 'behaviour':2, 'threshold':3 }
  actionscolumns = { 'label':0, 'type':1, 'value':2, 'params':3, 'customparam':5 }
    
  valid3D = [ 'no', 'yes', 'relative' ]
  validFormat = [ 'pcm', 'adpcm', 'mpc8', 'mpc', 'ogg', 'vxn', 'bcwav' ]
  validBehaviour = [ 'steal oldest', 'steal lowest priority', 'do nothing', 'steal low. prio. or old. same prio', '' ]
  validActionType = [ 'random', 'playlist', 'pl_random']
  validLoadingFlags = [ 'none', 'load to ram', 'load & decode', '']
    
  sounduid = 0
  bankuid = 1
  groupuid = 1
  actionuid = 0
    
  soundDict = {}
  bankDict = {}
  groupDict = {}
  volumeSliderDict = {}
    
  # Parsing of xls file provides a list of pairs (worksheetName, worksheetData)
  sheets = parse_xls( inputfile )
  
  # For each worsheet, get name and data (a dictionary with keys being pairs (row, col) and values being cell data)
  for sheet in sheets :
    sectionName,vals = sheet 

    # find table extents
    maxRow = 0
    maxCol = 0
    for v in vals :
      if v[0] > maxRow : maxRow = v[0]
      if v[1] > maxCol : maxCol = v[1]  
    maxCol = maxCol + 1
    maxRow = maxRow + 1

    if sectionName == 'SFX_DESIGN' or sectionName == 'VFX_DESIGN' or sectionName == 'MUSIC_DESIGN' :
      qtyCustomParamPrev = -1
      for line in range(2,maxRow) :
        qtyCustomParam = 0
        col = soundscolumns['label']
        if vals.has_key((line, col)) :
          entry = {}
          for (attribute,col) in soundscolumns.items() :
            pos = (line,col)
            if vals.has_key(pos) :
              v = vals[pos]
              txt = str(v)                            
              if attribute == 'loadingflags' :
                txt = txt.lower()
                if validLoadingFlags.count(txt) == 0 :
                  print 'Loading flags not recognized : ' + txt + ' => ' + str(validLoadingFlags)
                if txt == 'load & decode' :
                  txt = 'load and decode'
              if attribute == 'loop' :
                txt = txt.lower()
              if attribute == 'format' :
                txt = txt.lower()
                if validFormat.count(txt) == 0 :
                  print 'Format not recognized : ' + txt + ' => ' + str(validFormat)
                if txt == 'mpc8' :
                  print 'mpc8 deprecated, please use mpc for format'
              if attribute == 'label' :
                soundDict[txt] = str(sounduid)
              if attribute == 'filename' :
                if toLowerFilenames == True :
                  txt = txt.lower()
              if attribute == 'refdistance' :
                txt = txt.lower()
                txt = txt.replace(",", ".")
              if attribute == 'maxdistance' :
                txt = txt.lower()
                txt = txt.replace(",", ".")
              if attribute == 'rolloff' :
                txt = txt.lower()
                txt = txt.replace(",", ".")
              if attribute == 'mingainmod' :
                txt = txt.lower()
                txt = txt.replace(",", ".")
              if attribute == 'maxgainmod' :
                txt = txt.lower()
                txt = txt.replace(",", ".")
              if attribute == 'minpitchmod' :
                txt = txt.lower()
                txt = txt.replace(",", ".")
              if attribute == 'maxpitchmod' :
                txt = txt.lower()
                txt = txt.replace(",", ".")
              if attribute == 'basegain' :
                txt = txt.lower()
                txt = txt.replace(",", ".")
              if attribute == 'basepitch' :
                txt = txt.lower()
                txt = txt.replace(",", ".")
              # Get user custom parameters (ending up as one xml attribute with values separated by semicolon)
              if attribute == 'customparam' :
                qtyCustomParam = qtyCustomParam + 1
                customparamcol = col + 1
                customparampos = (line, customparamcol)
                while (vals.has_key(customparampos)) :
                  txt = txt + ';' + str(vals[customparampos])
                  customparamcol = customparamcol + 1
                  customparampos = (line, customparamcol)
                  qtyCustomParam = qtyCustomParam + 1
                entry['customparamqty'] = str(qtyCustomParam)
              entry[attribute] = txt
          entry['uid'] = str(sounduid)
          sounduid = sounduid + 1
          soundEntries.append( ('sound',entry,[]) )
          if qtyCustomParamPrev != -1 and qtyCustomParamPrev != qtyCustomParam :
             print "["+ entry['label'] + "]" + " : Sound doesn't have the same quantity of custom param than previous row"
          qtyCustomParamPrev = qtyCustomParam

    if sectionName == 'BANK_PRIORITY' :
      for line in range(2,maxRow) :
        col = bankscolumns['name']
        if vals.has_key((line, col)) :
          entry = {}
          for (attribute,col) in bankscolumns.items() :
            pos = (line,col)
            if vals.has_key(pos) :
              v = vals[pos]
              txt = str(v)
              if attribute == 'behaviour' :
                txt = txt.lower()
                if validBehaviour.count(txt) == 0 :                                    
                  print 'Bank behaviour not recognized : ' + txt + ' => ' + str(validBehaviour)
              if attribute == 'name' :
                bankDict[txt] = str(bankuid)
              entry[attribute] = txt
          entry['uid'] = str(bankuid)        
          bankuid = bankuid + 1 
          bankEntries.append( ('bank',entry,[]) )

    if sectionName == 'GROUP_ROUTING' :        
      for line in range(2,maxRow) :
        col = groupscolumns['name']
        if vals.has_key((line, col)) :
          entry = {}
          for (attribute,col) in groupscolumns.items() :
            pos = (line,col)
            if vals.has_key(pos) :
              v = vals[pos]
              txt = str(v)
              if attribute == 'pos3d' :
                txt = txt.lower()
                if valid3D.count(txt) == 0 :
                  print '3D type not recognized : ' + txt + ' => ' + str(valid3D)
              entry[attribute] = txt
              if attribute == 'name' :
                groupDict[txt] = str(groupuid)
              if attribute == 'volumeslider' :
                if txt not in volumeSliderDict :
                  volumeSliderDict[txt] = 0
          entry['uid'] = str(groupuid)
          groupuid = groupuid + 1            
          groupEntries.append( ('group',entry,[]) )            

    if sectionName == 'EVENT' :  
      qtyCustomParamPrev = -1      
      for line in range(2,maxRow) :
        qtyCustomParam = 0    
        col = actionscolumns['label']
        if vals.has_key((line, col)) :
          entry = {}
          entry['uid'] = str(actionuid)
          actionuid = actionuid + 1
          for (attribute,col) in actionscolumns.items() :
            pos = (line,col)
            if vals.has_key(pos) :
              v = vals[pos]
              txt = str(v)
              if attribute == 'type' :
                txt = txt.lower()
                if validActionType.count(txt) == 0 :
                  print 'Event type not recognized : ' + txt + ' => ' + str(validActionType)
              # Get user custom parameters (ending up as one xml attribute with values separated by semicolon)
              if attribute == 'customparam' :
                qtyCustomParam = qtyCustomParam + 1
                customparamcol = col + 1
                customparampos = (line, customparamcol)
                while (vals.has_key(customparampos)) :
                  txt = txt + ';' + str(vals[customparampos])
                  customparamcol = customparamcol + 1
                  customparampos = (line, customparamcol)
                  qtyCustomParam = qtyCustomParam + 1
                entry['customparamqty'] = str(qtyCustomParam)
              entry[attribute] = txt
          actionEntries.append( ('event',entry,[]) )   
          if qtyCustomParamPrev != -1 and qtyCustomParamPrev != qtyCustomParam :
             print "["+ entry['label'] + "]" + " : Event doesn't have the same quantity of custom param than previous row"
          qtyCustomParamPrev = qtyCustomParam

  tempList = []
  for (key, elements, empty) in soundEntries :
    if 'bank' not in elements :
      print "["+ elements['label'] + "]" + " : No bank specified for sound " + elements['label']
      elements['bank'] = '0';
    
    if  elements['bank'] in bankDict :
      elements['bank'] = bankDict[elements['bank']]
    else :
      print "["+ elements['label'] + "]" + " : Bank " + elements['bank'] + " not found for sound " +  elements['label'] + " setting default bank (0)"
      elements['bank'] = '0';
        
    if 'group' not in elements :
      print "["+ elements['label'] + "]" + " : No group specified for sound " + elements['label']
      elements['group'] = '0';
                
    if  elements['group'] in groupDict :         
      elements['group'] = groupDict[elements['group']]
    else :
      print "["+ elements['label'] + "]" + " : Group " + elements['group'] + " not found for sound " +  elements['label'] + " setting default group (0)"
      elements['bank'] = '0';   
    tempList.append( ( key, elements, empty) )
  soundEntries = tempList
    
    
  tempList = []
  for (key, elements, empty) in actionEntries :
    if 'type' not in elements :
      print "["+ elements['label'] + "]" + " : No type specified for event " + elements['label']
      continue
    if elements['type'] == 'random' or elements['type'] == 'playlist' or elements['type'] == 'pl_random' :
      value = elements['value']
      strList = value.split(',')
      value = ''
      for string in strList :
        string = string.strip()
        if value != '' :
          value = value + ','
        if string in soundDict :
          value = value + soundDict[string]
        else :
          print "["+ elements['label'] + "]" + " : Could not find " + string + " for event " +  elements['label']
      elements['value'] = value;
    else :
      print "["+ elements['label'] + "]" + " : Type " + elements['type'] + " not recognized for event " + elements['label']
    tempList.append( ( key, elements, empty) )
    actionEntries = tempList

  for (key, elements, empty) in groupEntries :
    if 'volumeslider' in elements :
      uid = int(elements['uid'])
      volumeSliderDict[elements['volumeslider']] = volumeSliderDict[elements['volumeslider']] + (1 << uid)     
    
  groupMaskEntries = []  
      
  vsditer = volumeSliderDict.iteritems()
  for (key, value) in vsditer :
    tempDict = {}
    tempDict['label'] = key
    tempDict['mask'] = str(value)
    groupMaskEntries.append( ( 'groupmask', tempDict, []))
    
    
  soundParam = {}
  soundParam['size'] = str(len(soundEntries))
  bankParam = {}
  bankParam['size'] = str(len(bankEntries))
  groupParam = {}
  groupParam['size'] = str(len(groupEntries))
  actionParam = {}
  actionParam['size'] = str(len(actionEntries))  
  groupMaskParam = {}
  groupMaskParam['size'] = str(len(groupMaskEntries))

  return [('sounds', soundParam, soundEntries),('groups',groupParam,groupEntries),('groupmasks',groupMaskParam,groupMaskEntries),('banks',bankParam,bankEntries),('events',actionParam,actionEntries)]

#
# XML helper functions
#

def pynativeToDomElement( dom, data ):
    (elemName,attributes,children) = data
    elem = dom.createElement(elemName)
    for (attr,val) in attributes.items() :
        elem.setAttribute(attr,val)
    for child in children :
        elem.appendChild( pynativeToDomElement(dom,child) )
    return elem

#
#


def exportSoundPackXML( filename, soundData ) : 
    dom = xml.dom.minidom.parseString( "<soundpack/>" )
    doc = dom.documentElement
    for section in soundData :
        doc.appendChild(pynativeToDomElement(dom,section))  
    #print dom.toprettyxml()
    f = open(filename,'wb')
    f.write( dom.toprettyxml() )
        

if __name__ == '__main__':
  if len(sys.argv) < 3:
    print "Usage: soundpackconverter.py input.xls output.xml toLowerFilenames"
  else:
    infile = sys.argv[1]
    outfile = sys.argv[2]
    
    toLowerFilenames = False;
    if len(sys.argv) > 3:
      toLowerFilenames = sys.argv[3]
      
    exportSoundPackXML( outfile, parseSoundPackXLS( infile, toLowerFilenames ) )

#End