////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                         Vox Audio Engine Tools                             //
//                                                                            //
//                               Vox Player                                   //
//                                                                            //
//                            Alexandre Bélanger                              //
//                             (c)2009 Gameloft                               //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

This player allows the playback of any file directly supported by Vox base
implementation.

Usage
=====

VoxPlayer soundfilename

