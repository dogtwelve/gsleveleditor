#include "EngineStdAfx.h"
#include "SoundMgr.h"


using namespace pig;
using namespace core;


SoundMgr::GroupHandleMask SoundMgr::k_musicGroupMask(1 << SoundMgr::k_musicGroup);
SoundMgr::GroupHandleMask SoundMgr::k_soundGroupMask(0xFFFFFFF &  (~(1 << SoundMgr::k_musicGroup)));

#if defined (_PIG_ANDROID_)
extern "C" void VoxSetAndroidAPILevel(vox::s32 level); //Only required if using OpenSL
#endif
//////////////////////////////////////////////////////////////////////////

SoundMgr::SoundMgr()
{
#if defined(PIG_WINDOWS)
	m_vox = &vox::VoxEngine::GetVoxEngine();
#elif defined (PIG_IOS_DEVICE)
	m_vox = &vox::VoxIphone::GetVoxEngine();
#elif defined (_PIG_ANDROID_)
    //there is no separate "engine" (cmp ios), vox::DriverAndroid gets used automagically
	m_vox = &vox::VoxEngine::GetVoxEngine();

    //apiLevel from Java: Integer.parseInt(Build.VERSION.SDK))
    //see http://developer.android.com/reference/android/os/Build.VERSION_CODES.html#FROYO
    //Android 2.2 -> 8
    //Android 2.3 -> 9
    //Android 2.3.3 -> 10

    int apiLevel = 8;
    VoxSetAndroidAPILevel(apiLevel);
#endif

	PASSERT2(m_vox, "Cannot initialize the sound engine");


	m_lastSoundHandle = 0;
	m_lastGroupHandle = k_soundGroup;
	m_lastBankId = 0;

	m_groupNames.resize(32);
	m_maxGroupSounds.resize(32, 999);
	m_groupSoundCount.resize(32);
}

//////////////////////////////////////////////////////////////////////////

SoundMgr::~SoundMgr()
{
	m_vox->DestroyVoxEngine();
    m_vox = 0;
}

//////////////////////////////////////////////////////////////////////////

void SoundMgr::Initialize()
{
	m_vox->Initialize();
}

//////////////////////////////////////////////////////////////////////////

void SoundMgr::Serialize(pig::stream::IStreamW& s)
{
	if (m_musicQueue.empty() || m_musicQueue.back().stopping)
	{
		s << (u8)0;
	}
	else
	{
		s << (u8)1;
		MusicInfo& info = m_musicQueue.back();
		s << info.name;
		s << info.stateName;
		s << m_vox->GetPlayCursor(info.handle);
		//s << m_vox->GetGain(info.handle);
		s << info.loop;
	}

	//serialize sounds
	SoundHandleMap::iterator it = m_soundHandleMap.begin();
	for (; it != m_soundHandleMap.end();)
	{
		SoundHandleMap::iterator crt = it++;
		SoundInfo& info = crt->second;
		vox::EmitterHandle& eh = (vox::EmitterHandle&)info.handle;
		if (!m_vox->IsDone(eh) && !info.stopping)
		{
			s << (u8)1;

			s << crt->first;
			s << info.name;
			s << info.loop;
			s << info.priority;
			s << info.group;

			int relativeToListener;
			m_vox->Get3DEmitterParameteri(info.handle, vox::Vox3DEmitterParameter::k_nRelativeToListener, relativeToListener);
			s << relativeToListener;

			Vector3D pos;
			m_vox->Get3DEmitterPosition(info.handle, pos.m_x, pos.m_y, pos.m_z);
			s << pos;
			
			s << m_vox->GetPlayCursor(info.handle);
			s << info.volume;
		}
	}
	s << (u8)0;
}

//////////////////////////////////////////////////////////////////////////

void SoundMgr::Deserialize(pig::stream::IStream& s)
{
	//////////////////////////////////////////////////////////////////////////
	//clean up
	StopAllSounds(0);

	//we serialize the SoundHandles as well so we have to clear this map to avoid duplicates
	m_soundHandleMap.clear();
	for (u32 i = 0; i < m_groupSoundCount.size(); i++)
		m_groupSoundCount[i] = 0;

	//////////////////////////////////////////////////////////////////////////
	//deserialization follows

	//this will be the max id loaded + 1
	m_lastSoundHandle = 0;

	u8 status;
	s >> status;
	if (status != 0)
	{
		String name;
		String stateName;
		s >> name;
		s >> stateName;
		if (!IsMusicPlaying(name))
			PlayMusic(name);

		SetMusicState(stateName);

		MusicInfo& info = m_musicQueue.back();

		float f;
		s >> f;
		m_vox->SetPlayCursor(info.handle, f);
// 		s >> f;
// 		m_vox->SetGain(info.handle, f);
		bool l;
		s >> l;
		m_vox->SetLoop(info.handle, l);
		info.loop = l;
	}

	s >> status;
	while (status != 0)
	{
		SoundHandle sh;
		String name;
		bool loop;
		GroupHandle group;
		u32 priority;
		Vector3D pos;
		int relativeToListener;
		float cursor, volume;

		s >> sh;
		s >> name;
		s >> loop;
		s >> priority;
		s >> group;
		s >> relativeToListener;
		s >> pos;
		s >> cursor;
		s >> volume;

		m_lastSoundHandle = Max((int)m_lastSoundHandle, sh);

		sh = _PlaySound(sh, name, loop, volume, 0, priority, group);
		if (sh >= 0)
		{
			vox::EmitterHandle eh = FindEmitterHandleBySoundHandle(sh);
			m_vox->SetPlayCursor(eh, cursor);
			m_vox->Set3DEmitterParameteri(eh, vox::Vox3DEmitterParameter::k_nRelativeToListener, relativeToListener);
			m_vox->Set3DEmitterPosition(eh, pos.m_x, pos.m_y, pos.m_z);
		}

		s >> status;
	}

	m_lastSoundHandle++;
}

//////////////////////////////////////////////////////////////////////////

u32 SoundMgr::PlayMusic(const pig::String& name, bool loop /* = false */, pig::u32 fadeDuration /* = 0 */, bool stopOthers /*= true*/)
{
	if (!m_musicStreamFactory.get())
		return 0;

	vox::DataHandle& dh = (vox::DataHandle&)FindDataHandleByMusicName(name);
	if (dh == m_emptyDataHandle)
		return 0;

	vox::EmitterHandle e = m_vox->CreateEmitter(dh, 0);
	m_vox->Play(e, loop, (float)fadeDuration * 0.001f);
	m_vox->SetPlayCursor(e, 0.f);
	m_vox->SetGroup(e, k_musicGroup);

    if (stopOthers)
	    StopMusic(fadeDuration);

	MusicInfo info;
	info.stopping = false;
	info.name = name;
	info.handle = e;
	info.stateName.clear();
	info.loop = loop;
	m_musicQueue.push_back(info);
	return (pig::u32)(m_vox->GetDuration(dh) * 1000.f);
}

//////////////////////////////////////////////////////////////////////////

void SoundMgr::StopMusic(pig::u32 fadeDuration /* = 0 */)
{
	if (!m_musicQueue.empty())
	{
		for (u32 i = 0; i < m_musicQueue.size(); i++)
		{
			m_musicQueue[i].stopping = true;
			vox::EmitterHandle& eh = (vox::EmitterHandle&)m_musicQueue[i].handle;
			m_vox->Stop(eh, (float)fadeDuration * 0.001f);
		}
	}
}

//////////////////////////////////////////////////////////////////////////

void SoundMgr::StopMusic(const pig::String& name, pig::u32 fadeDuration /* = 0 */)
{
	if (!m_musicQueue.empty())
	{
		for (u32 i = 0; i < m_musicQueue.size(); i++)
		{
			if (m_musicQueue[i].name == name)
			{
				m_musicQueue[i].stopping = true;
				vox::EmitterHandle& eh = (vox::EmitterHandle&)m_musicQueue[i].handle;
				m_vox->Stop(eh, (float)fadeDuration * 0.001f);
			}
		}
	}
}

//////////////////////////////////////////////////////////////////////////

SoundMgr::SoundHandle SoundMgr::PlaySound(const pig::String& name, bool loop /* = false */, float volume /* = 1 */, pig::u32 fadeDuration /* = 0 */, pig::u32 priority /* = 0 */, GroupHandle group /* = -1 */)
{
	SoundHandle sh = _PlaySound(m_lastSoundHandle++, name, loop, volume, fadeDuration, priority, group);
	return sh;
}

SoundMgr::SoundHandle SoundMgr::_PlaySound(SoundMgr::SoundHandle sh, const pig::String& name, bool loop /* = false */, float volume /* = 1 */, pig::u32 fadeDuration /* = 0 */, pig::u32 priority /* = 0 */, GroupHandle group /* = -1 */)
{
	if (!m_soundStreamFactory.get())
		return -1;

	group = group < 0 ? k_soundGroup : group;
	if (m_groupSoundCount[group] >= m_maxGroupSounds[group])
	{
		PDBG("SOUND: Cannot play '%s'. Too many sounds playing", name.c_str());
		return -1;
	}

	vox::DataHandle& dh = (vox::DataHandle&)FindDataHandleBySoundName(name);
	if (dh == m_emptyDataHandle)
	{
		PDBG("SOUND: Cannot load '%s'.", name.c_str());
		return -1;
	}

	vox::EmitterHandle e = m_vox->CreateEmitter(dh, priority);
	m_vox->SetGroup(e, group);
	m_vox->Play(e, loop, (float)fadeDuration * 0.001f);
	m_vox->SetGain(e, core::Clamp(volume, 0.f, 10.f));
	m_vox->Set3DEmitterParameteri(e, vox::Vox3DEmitterParameter::k_nRelativeToListener, -1);
	m_groupSoundCount[group]++;

	SoundInfo si;
	si.name = name;
	si.loop = loop;
	si.handle = e;
	si.priority = priority;
	si.group = group;
	si.volume = volume;

	m_soundHandleMap.insert(std::make_pair(sh, si));
	return sh;
}

//////////////////////////////////////////////////////////////////////////

SoundMgr::SoundHandle SoundMgr::PlaySound(const pig::String& name, const pig::core::Vector3D& pos, bool loop /* = false */, float volume /* = 1 */, pig::u32 fadeDuration /* = 0 */, pig::u32 priority /* = 0 */, GroupHandle group /* = -1 */)
{
	SoundHandle sh = PlaySound(name, loop, volume, fadeDuration, priority, group);
	if (sh >= 0)
	{
		vox::EmitterHandle& eh = (vox::EmitterHandle&)FindEmitterHandleBySoundHandle(sh);
		PASSERT(!(eh == vox::EmitterHandle()));
		m_vox->Set3DEmitterParameteri(eh, vox::Vox3DEmitterParameter::k_nRelativeToListener, 0);
		m_vox->Set3DEmitterPosition(eh, pos.m_x, pos.m_y, pos.m_z);
	}
	return sh;
}

//////////////////////////////////////////////////////////////////////////

extern int xxxDecoTime;

void SoundMgr::Update()
{
#if defined(VOX_THREADING_MODE_NONE)
	m_vox->Update(System::GetApplication()->GetUpdateTimeSeconds());
#endif

	m_cleanupTimer -= System::GetApplication()->GetUpdateTime();
	if (m_cleanupTimer <= 0)
	{
		m_cleanupTimer = 200;

		//cleanup sounds
		SoundHandleMap::iterator it = m_soundHandleMap.begin();
		for (; it != m_soundHandleMap.end();)
		{
			SoundHandleMap::iterator crt = it++;
			vox::EmitterHandle& eh = (vox::EmitterHandle&)crt->second.handle;
			if (m_vox->IsDone(eh))
			{
                //printf("deleting sound - %d\n", m_soundHandleToEmitter.size());
				m_soundHandleMap.erase(crt);
				int g = m_vox->GetGroup(eh);
				PASSERT(g >= 0  &&  g < 32);
				PASSERT(m_groupSoundCount[g] > 0);
				if (m_groupSoundCount[g] > 0)
					m_groupSoundCount[g]--;
			}
		}

		//clean up music
		for (u32 i = 0; i < m_musicQueue.size();)
		{
			vox::EmitterHandle& eh = (vox::EmitterHandle&)m_musicQueue[i].handle;
			if (m_vox->IsDone(eh))
				m_musicQueue.erase(m_musicQueue.begin() + i);
			else
				i++;
		}
	}
}

//////////////////////////////////////////////////////////////////////////

void SoundMgr::SetSoundVolume(float volume, pig::u32 fadeDuration)
{
    //INFO: 32 slots preallocated, 27 is the grouphandle limit!
    //printf("last group handle: %d\n", m_lastGroupHandle);
    //printf("#groupname:%d  #groupmap:%d\n", m_groupNames.size(), m_groupMap.size());

    //INFO: approach taken - iterate through groupnames and find handles in map
    //but could also iteratate through GroupHandleMap m_groupMap; ?

    //set predefined sound group
    SetGroupVolume(volume, fadeDuration, k_soundGroupMask);

    int i = 0;
    PArray<pig::String>::iterator groupNamesIt;
    for (groupNamesIt = m_groupNames.begin(); groupNamesIt != m_groupNames.end(); ++groupNamesIt)
    {
        //need to check because strings preallocated in array
        if (!(*groupNamesIt).empty())
        {
            //printf("groupName %d: %s", i, (*groupNamesIt).c_str());
            //i++;

            GroupHandle gh = FindGroupHandleByName(*groupNamesIt);
            if (gh >= 0)
            {
                //successfully found in grouphandlemap
                if (gh != k_musicGroup)
                {
                    GroupHandleMask currentGroupMask(gh);
                    SetGroupVolume(volume, fadeDuration, currentGroupMask);
                }
            }
        }
    }

    //TODO: actually this loop might be better to use
    i = 0;
    PArray<pig::u32>::iterator groupSoundCountIt;
    for (groupSoundCountIt  = m_groupSoundCount.begin();
         groupSoundCountIt != m_groupSoundCount.end();
         ++groupSoundCountIt)
    {
        //printf("sound group %d has %d sounds\n", i, (*groupSoundCountIt));
        ++i;
        if ((*groupSoundCountIt) > 0)
        {
            //change volume
        }
    }
}

