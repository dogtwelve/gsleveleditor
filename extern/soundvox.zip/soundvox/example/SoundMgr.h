#ifndef _SOUND_MGR_H_
#define _SOUND_MGR_H_


#include "PIG.h"
#include "Singleton.h"

#if defined(PIG_WINDOWS)
#include "vox.h"
#elif defined (PIG_IOS_DEVICE)
#include "iPhone/vox_iphone.h"
#elif defined (_PIG_ANDROID_)
#include "vox.h"
#endif
#include "vox_utils.h"


namespace pig
{
namespace stream
{
class IStreamFactory;
class IStreamW;
}
}


class SoundMgr : public Singleton<SoundMgr>
{
public:
	typedef int SoundHandle;
	typedef int GroupHandle;

	class GroupHandleMask
	{
		friend class SoundMgr;

	public:
		GroupHandleMask() : m_mask(0) { }
		GroupHandleMask(GroupHandle gh) : m_mask(gh >= 0 ? gh : 0) { }
		GroupHandleMask(const GroupHandleMask& other) : m_mask(other.m_mask) {}
		~GroupHandleMask() {}
		GroupHandleMask& operator=(const GroupHandleMask& other) { m_mask = other.m_mask; return *this; }

		GroupHandleMask& Add(GroupHandle gh) { m_mask = gh >= 0 ? (m_mask | (1 << gh)) : m_mask; return *this; }
		GroupHandleMask& Remove(GroupHandle gh) { m_mask = gh >= 0 ? (m_mask & (~(1 << gh))) : m_mask; return *this; }

	protected:
		pig::u32		GetMask() const { return m_mask; }

	private:
		pig::u32		m_mask;
	};

	SoundMgr();
	~SoundMgr();

	void				Initialize();

	void				Serialize(pig::stream::IStreamW& s);
	void				Deserialize(pig::stream::IStream& s);

	void				Update();

	static const GroupHandle	k_musicGroup = 0;
	static const GroupHandle	k_soundGroup = 1;
	static GroupHandleMask		k_musicGroupMask;
	static GroupHandleMask		k_soundGroupMask;


	pig::stream::IStreamFactory* SetSoundStreamPath(const pig::String& path, const pig::String& filter);
	pig::stream::IStreamFactory* GetSoundStreamFactory();

	pig::stream::IStreamFactory* SetMusicStreamPath(const pig::String& path, const pig::String& filter);
	pig::stream::IStreamFactory* GetMusicStreamFactory();

	void				SetMusicState(const pig::String& stateName);
	const pig::String&	GetMusicState() const;

	void				SetListenerPosition(const pig::core::Vector3D& pos);
	void				SetListenerOrientation(const pig::core::Vector3D& front, const pig::core::Vector3D& up);

	void				SetMasterVolume(float volume, pig::u32 fadeDuration = 0);
	float				GetMasterVolume() const;

	void				SetMusicVolume(float volume, pig::u32 fadeDuration = 0);
	float				GetMusicVolume() const;

	void				SetGroupVolume(float volume, pig::u32 fadeDuration = 0, GroupHandleMask mask = k_soundGroupMask);
	float				GetGroupVolume(GroupHandle gh = k_soundGroup) const;

	void				SetSoundVolume(SoundHandle handle, float volume, pig::u32 fadeDuration = 0);
	float				GetSoundVolume(SoundHandle handle) const;

    void                SetSoundVolume(float volume, pig::u32 fadeDuration = 0);

	void				SetSoundPitch(SoundHandle handle, float pitch, pig::u32 fadeDuration = 0);
	float				GetSoundPitch(SoundHandle handle) const;

	float				GetSoundCursor(SoundHandle handle) const;
	void				SetSoundCursor(SoundHandle handle, float cursor);

	void				Pause(pig::u32 fadeDuration = 0);
	void				Resume(pig::u32 fadeDuration = 0);

	void				PauseMusic(pig::u32 fadeDuration = 0);
	void				ResumeMusic(pig::u32 fadeDuration = 0);

	void				PauseSoundGroups(GroupHandleMask mask = k_soundGroupMask, pig::u32 fadeDuration = 0);
	void				StopSoundGroups(GroupHandleMask mask = k_soundGroupMask, pig::u32 fadeDuration = 0);
	void				ResumeSoundGroups(GroupHandleMask mask = k_soundGroupMask, pig::u32 fadeDuration = 0);

	void				SetMaxSounds(const pig::String& name, pig::u32 max);
	void				SetMaxSounds(GroupHandle handle, pig::u32 max);

	pig::u32			PlayMusic(const pig::String& name, bool loop = false, pig::u32 fadeDuration = 0, bool stopOthers = true);
	void				StopMusic(const pig::String& name, pig::u32 fadeDuration = 0);
	void				StopMusic(pig::u32 fadeDuration = 0);
	pig::String			GetMusicName() const;
	bool				IsMusicPlaying() const;
	bool				IsMusicPlaying(const pig::String& name) const;

	GroupHandle			CreateNewGroup(const pig::String& name);
	GroupHandle			FindGroupHandleByName(const pig::String& name) const;
	const pig::String&	GetGroupName(GroupHandle gh) const;

	bool				IsValid(SoundHandle sh) const;

	SoundHandle			PlaySound(const pig::String& name, bool loop = false, float volume = 1.f, pig::u32 fadeDuration = 0, pig::u32 priority = 0, GroupHandle group = -1);
	SoundHandle			PlaySound(const pig::String& name, const pig::core::Vector3D& pos, bool loop = false, float volume = 1.f, pig::u32 fadeDuration = 0, pig::u32 priority = 0, GroupHandle group = -1);

	void				StopAllSounds(pig::u32 fadeDuration = 0);
	void				StopSound(SoundHandle handle, pig::u32 fadeDuration = 0);

	void				SetRange(SoundHandle handle, float range);
	void				SetPosition(SoundHandle handle, const pig::core::Vector3D& pos);
	void				SetLooped(SoundHandle handle, bool looped);

	pig::u32			GetMusicDuration(const pig::String& name) const;
	pig::u32			GetSoundDuration(const pig::String& name) const;
	pig::u32			GetDuration(SoundHandle handle) const;

	bool				IsSoundPlaying(SoundHandle handle) const;
	bool				IsUniqueSoundPlaying(const pig::String& name) const;


protected:
	struct MusicInfo
	{
		pig::String         name;
		pig::String			stateName;
		bool                loop;
		bool				stopping;
		vox::EmitterHandle  handle;
	};

	struct SoundInfo
	{
		SoundInfo() : loop(false), group(0), priority(0), volume(0), stopping(false) {}
		pig::String         name;
		bool                loop;
		vox::EmitterHandle  handle;
		GroupHandle			group;
		pig::u32			priority;
		float				volume;
		bool				stopping;
	};

	SoundInfo*				   FindSoundInfoBySoundHandle(SoundHandle sh) const;
	const vox::EmitterHandle&  FindEmitterHandleBySoundHandle(SoundHandle sh) const;
	const vox::DataHandle&     FindDataHandleBySoundName(const pig::String& name) const;
	const vox::DataHandle&     FindDataHandleByMusicName(const pig::String& name) const;
	pig::s32                   FindBankIdBySoundName(const pig::String& name) const;

	SoundHandle				  _PlaySound(SoundHandle sh, const pig::String& name, bool loop = false, float volume = 1.f, pig::u32 fadeDuration = 0, pig::u32 priority = 0, GroupHandle group = -1);

private:
	typedef PUMap<pig::String, GroupHandle, PHashF<pig::String>, PEqualF<pig::String>, FPoolAlloc<GroupHandle> >          GroupHandleMap;
	typedef PMap<SoundHandle, SoundInfo, PLessF<SoundHandle>, FPoolAlloc<SoundInfo> >									  SoundHandleMap;
	typedef PUMap<pig::String, vox::DataHandle, PHashF<pig::String>, PEqualF<pig::String>, FPoolAlloc<vox::DataHandle> >  SoundNameToDataHandleMap;
	typedef PUMap<pig::String, pig::s32, PHashF<pig::String>, PEqualF<pig::String>, FPoolAlloc<pig::s32> >                SoundNameToBankIdMap;

	vox::VoxEngine*					m_vox;

	SharedPtr<pig::stream::IStreamFactory>	m_soundStreamFactory;
	SharedPtr<pig::stream::IStreamFactory>	m_musicStreamFactory;

	mutable SoundNameToDataHandleMap		m_soundNameToDataHandle;
	mutable SoundNameToDataHandleMap		m_musicNameToDataHandle;

	PArray<MusicInfo>			m_musicQueue;

	pig::u32					m_lastSoundHandle;
	mutable SoundHandleMap		m_soundHandleMap;

	vox::EmitterHandle			m_emptyEmitterHandle;
	vox::DataHandle				m_emptyDataHandle;

	PArray<pig::u32>			m_maxGroupSounds;
	PArray<pig::u32>			m_groupSoundCount;

	int							m_cleanupTimer;

	PArray<pig::String>			m_groupNames;
	GroupHandleMap				m_groupMap;
	int							m_lastGroupHandle;

	SoundNameToBankIdMap		m_soundNameToBankId;
	int							m_lastBankId;
};

//////////////////////////////////////////////////////////////////////////

inline pig::stream::IStreamFactory* SoundMgr::SetMusicStreamPath(const pig::String& path, const pig::String& filter)
{
	PASSERT2(m_musicNameToDataHandle.empty(), "Cannot change the folder after loading music");
	m_musicStreamFactory = pig::stream::CreateStreamFactoryFromPath(path, filter);
	return m_musicStreamFactory.get();
}

//////////////////////////////////////////////////////////////////////////

inline pig::stream::IStreamFactory* SoundMgr::GetMusicStreamFactory()
{
	return m_musicStreamFactory.get();
}

//////////////////////////////////////////////////////////////////////////

inline pig::stream::IStreamFactory* SoundMgr::SetSoundStreamPath(const pig::String& path, const pig::String& filter)
{
	PASSERT2(m_soundNameToDataHandle.empty(), "Cannot change the folder after loading sounds");
	m_soundStreamFactory = pig::stream::CreateStreamFactoryFromPath(path, filter);
	return m_soundStreamFactory.get();
}

//////////////////////////////////////////////////////////////////////////

inline pig::stream::IStreamFactory* SoundMgr::GetSoundStreamFactory()
{
	return m_soundStreamFactory.get();
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::SetListenerPosition(const pig::core::Vector3D& pos)
{
	m_vox->Set3DListenerPosition(pos.m_x, pos.m_y, pos.m_z);
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::SetListenerOrientation(const pig::core::Vector3D& front, const pig::core::Vector3D& up)
{
	m_vox->Set3DListenerOrientation(front.m_x, front.m_y, front.m_z, up.m_x, up.m_y, up.m_z);
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::SetMasterVolume(float volume, pig::u32 fadeDuration /* = 0 */)
{
	m_vox->SetMasterGain(pig::core::Clamp(volume, 0.f, 2.f), (float)fadeDuration * 0.001f);
}

//////////////////////////////////////////////////////////////////////////

inline float SoundMgr::GetMasterVolume() const
{
	return m_vox->GetMasterGain();
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::SetMusicVolume(float volume, pig::u32 fadeDuration /* = 0 */)
{
	m_vox->SetGroupGain(1 << k_musicGroup, pig::core::Clamp(volume, 0.f, 2.f), (float)fadeDuration * 0.001f);
}

//////////////////////////////////////////////////////////////////////////

inline float SoundMgr::GetMusicVolume() const
{
	return m_vox->GetGroupGain(1 << k_musicGroup);
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::SetMusicState(const pig::String& stateName)
{
	if (!m_musicQueue.empty())
	{
		MusicInfo& p = m_musicQueue.back();
		p.stateName = stateName;
		m_vox->SetInteractiveMusicState(p.handle, stateName.c_str());
	}
}

//////////////////////////////////////////////////////////////////////////

inline const pig::String& SoundMgr::GetMusicState() const
{
	if (!m_musicQueue.empty())
	{
		const MusicInfo& p = m_musicQueue.back();
		return p.stateName;
	}
	else
		return pig::String::null;
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::SetGroupVolume(float volume, pig::u32 fadeDuration /* = 0 */, GroupHandleMask mask)
{
	m_vox->SetGroupGain(mask.GetMask(), pig::core::Clamp(volume, 0.f, 2.f), (float)fadeDuration * 0.001f);
}

//////////////////////////////////////////////////////////////////////////

inline float SoundMgr::GetGroupVolume(GroupHandle group) const
{
	return m_vox->GetGroupGain(1 << (group < 0 ? k_soundGroup : group));
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::SetSoundVolume(SoundHandle handle, float volume, pig::u32 fadeDuration /* = 0 */)
{
	SoundHandleMap::iterator it = m_soundHandleMap.find(handle);
	if (it != m_soundHandleMap.end())
	{
		volume = pig::core::Clamp(volume, 0.f, 10.f);
		m_vox->SetGain(it->second.handle, volume, (float)fadeDuration * 0.001f);
		it->second.volume = volume;
	}
}

//////////////////////////////////////////////////////////////////////////

inline float SoundMgr::GetSoundVolume(SoundHandle handle) const
{
	SoundHandleMap::const_iterator it = m_soundHandleMap.find(handle);
	if (it != m_soundHandleMap.end())
		return it->second.volume;
	else
		return 0.f;
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::SetSoundPitch(SoundHandle handle, float pitch, pig::u32 fadeDuration /* = 0 */)
{
	vox::EmitterHandle& eh = (vox::EmitterHandle&)FindEmitterHandleBySoundHandle(handle);
	if (!(eh == m_emptyEmitterHandle))
		m_vox->SetPitch(eh, pitch, (float)fadeDuration * 0.001f);
}

//////////////////////////////////////////////////////////////////////////

inline float SoundMgr::GetSoundPitch(SoundHandle handle) const
{
	vox::EmitterHandle& eh = (vox::EmitterHandle&)FindEmitterHandleBySoundHandle(handle);
	if (!(eh == m_emptyEmitterHandle))
		return m_vox->GetPitch(eh);
	else
		return 1.f;
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::Pause(pig::u32 fadeDuration)
{
	PauseMusic(fadeDuration);
	PauseSoundGroups(k_soundGroupMask, fadeDuration);
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::Resume(pig::u32 fadeDuration)
{
	ResumeMusic(fadeDuration);
	ResumeSoundGroups(k_soundGroupMask, fadeDuration);
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::PauseMusic(pig::u32 fadeDuration)
{
	m_vox->PauseAllEmitters(k_musicGroupMask.GetMask(), (float)fadeDuration * 0.001f);
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::ResumeMusic(pig::u32 fadeDuration)
{
	m_vox->ResumeAllEmitters(k_musicGroupMask.GetMask(), (float)fadeDuration * 0.001f);
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::PauseSoundGroups(GroupHandleMask mask, pig::u32 fadeDuration)
{
	m_vox->PauseAllEmitters(mask.GetMask(), (float)fadeDuration * 0.001f);
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::StopSoundGroups(GroupHandleMask mask, pig::u32 fadeDuration)
{
	m_vox->StopAllEmitters(mask.GetMask(), (float)fadeDuration * 0.001f);
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::ResumeSoundGroups(GroupHandleMask mask, pig::u32 fadeDuration)
{
	m_vox->ResumeAllEmitters(mask.GetMask(), (float)fadeDuration * 0.001f);
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::SetMaxSounds(const pig::String& name, pig::u32 max)
{
	pig::s32 bankId = FindBankIdBySoundName(name);
	if (bankId < 0)
	{
		bankId = m_lastBankId++;
		m_soundNameToBankId[name] = bankId;
		bool done = m_vox->SetPriorityBank(bankId, 0, max, vox::k_nStealOldest);
		done = done;
		PASSERT2(done, "Could not create priority bank - probably limit reached. Using %s banks right now", m_lastBankId);
	}

	vox::DataHandle& dh = (vox::DataHandle&)FindDataHandleBySoundName(name);
	if (!(dh == m_emptyDataHandle))
		m_vox->SetPriorityBankId(dh, bankId);
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::SetMaxSounds(GroupHandle handle, pig::u32 max)
{
	handle = handle < 0 ? k_soundGroup : handle;
	m_maxGroupSounds[handle] = max;
}

//////////////////////////////////////////////////////////////////////////

inline pig::String SoundMgr::GetMusicName() const
{
	return m_musicQueue.empty() ? pig::String::null : m_musicQueue.back().name;
}

//////////////////////////////////////////////////////////////////////////

inline bool SoundMgr::IsMusicPlaying() const
{
	for (pig::u32 i = 0, sz = m_musicQueue.size(); i < sz; i++)
		if (!m_musicQueue[i].stopping)
			return true;
	return false;
}

//////////////////////////////////////////////////////////////////////////

inline bool SoundMgr::IsMusicPlaying(const pig::String& name) const
{
	for (pig::u32 i = 0, sz = m_musicQueue.size(); i < sz; i++)
		if (m_musicQueue[i].name == name && !m_musicQueue[i].stopping)
			return true;
	return false;
}

//////////////////////////////////////////////////////////////////////////

inline SoundMgr::GroupHandle SoundMgr::CreateNewGroup(const pig::String& name)
{
	PASSERT2(m_lastGroupHandle < 28, "Too many group handles created. Limit is 28");
	GroupHandle gh = FindGroupHandleByName(name);
	if (gh < 0)
	{
		gh = ++m_lastGroupHandle;
		m_groupMap[name] = gh;
	}
	return gh;
}

//////////////////////////////////////////////////////////////////////////

inline SoundMgr::GroupHandle SoundMgr::FindGroupHandleByName(const pig::String& name) const
{
	GroupHandleMap::const_iterator it = m_groupMap.find(name);
	return it == m_groupMap.end() ? -1 : it->second;
}

//////////////////////////////////////////////////////////////////////////

inline const pig::String& SoundMgr::GetGroupName(GroupHandle gh) const
{
	return (gh >= 0 && gh < 32) ? m_groupNames[gh] : pig::String::null;
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::StopAllSounds(pig::u32 fadeDuration)
{
	SoundHandleMap::iterator it = m_soundHandleMap.begin();
	for (; it != m_soundHandleMap.end();)
	{
		SoundHandleMap::iterator crt = it++;
		vox::EmitterHandle& eh = (vox::EmitterHandle&)crt->second.handle;
		if (!m_vox->IsDone(eh))
		{
			crt->second.stopping = true;
			m_vox->Stop(eh, (float)fadeDuration * 0.001f);
		}
	}
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::StopSound(SoundHandle handle, pig::u32 fadeDuration)
{
	SoundInfo* si = FindSoundInfoBySoundHandle(handle);
	if (si)
	{
		si->stopping = true;
		m_vox->Stop(si->handle, (float)fadeDuration * 0.001f);
	}
}

//////////////////////////////////////////////////////////////////////////

inline bool SoundMgr::IsSoundPlaying(SoundHandle handle) const
{
	vox::EmitterHandle& eh = (vox::EmitterHandle&)FindEmitterHandleBySoundHandle(handle);
	return !(eh == m_emptyEmitterHandle) ? m_vox->IsPlaying(eh) : false;
}

//////////////////////////////////////////////////////////////////////////

inline pig::u32 SoundMgr::GetDuration(SoundHandle handle) const
{
	vox::EmitterHandle& eh = (vox::EmitterHandle&)FindEmitterHandleBySoundHandle(handle);
	if (!(eh == m_emptyEmitterHandle))
	{
		vox::DataHandle dh = m_vox->GetData(eh);
		if (!(dh == m_emptyDataHandle))
			return (pig::u32)(m_vox->GetDuration(dh) * 1000.f);
	}
	return 0;
}

//////////////////////////////////////////////////////////////////////////

inline pig::u32 SoundMgr::GetSoundDuration(const pig::String& name) const
{
	vox::DataHandle& dh = (vox::DataHandle&)FindDataHandleBySoundName(name);
	if (!(dh == m_emptyDataHandle))
		return (pig::u32)(m_vox->GetDuration(dh) * 1000.f);
	return 0;
}

//////////////////////////////////////////////////////////////////////////

inline pig::u32 SoundMgr::GetMusicDuration(const pig::String& name) const
{
	vox::DataHandle& dh = (vox ::DataHandle&)FindDataHandleByMusicName(name);
	if (!(dh == m_emptyDataHandle))
		return (pig::u32)(m_vox->GetDuration(dh) * 1000.f);
	return 0;
}

//////////////////////////////////////////////////////////////////////////

inline bool SoundMgr::IsValid(SoundHandle handle) const
{
	const vox::EmitterHandle& eh = FindEmitterHandleBySoundHandle(handle);
	return (!(eh == m_emptyEmitterHandle));
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::SetPosition(SoundHandle handle, const pig::core::Vector3D& pos)
{
	vox::EmitterHandle& eh = (vox::EmitterHandle&)FindEmitterHandleBySoundHandle(handle);
	if (!(eh == m_emptyEmitterHandle))
	{
		m_vox->Set3DEmitterPosition(eh, pos.m_x, pos.m_y, pos.m_z);
		m_vox->Set3DEmitterParameteri(eh, vox::Vox3DEmitterParameter::k_nRelativeToListener, 0);
	}
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::SetRange(SoundHandle handle, float range)
{
	vox::EmitterHandle& eh = (vox::EmitterHandle&)FindEmitterHandleBySoundHandle(handle);
	if (!(eh == m_emptyEmitterHandle))
	{
		//m_vox->Set3DEmitterPosition(eh, pos.m_x, pos.m_y, pos.m_z);
		//m_vox->Set3DEmitterParameteri(eh, vox::Vox3DEmitterParameter::k_nRelativeToListener, 0);
	}
}

//////////////////////////////////////////////////////////////////////////

inline float SoundMgr::GetSoundCursor(SoundHandle handle) const
{
	vox::EmitterHandle& eh = (vox::EmitterHandle&)FindEmitterHandleBySoundHandle(handle);
	if (!(eh == m_emptyEmitterHandle))
	{
		return m_vox->GetPlayCursor(eh);
	}
	return 0.f;
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::SetSoundCursor(SoundHandle handle, float cursor)
{
	vox::EmitterHandle& eh = (vox::EmitterHandle&)FindEmitterHandleBySoundHandle(handle);
	if (!(eh == m_emptyEmitterHandle))
	{
		m_vox->SetPlayCursor(eh, pig::core::Clamp(cursor, 0.f, 1.f));
	}
}

//////////////////////////////////////////////////////////////////////////

inline void SoundMgr::SetLooped(SoundHandle handle, bool looped)
{
	vox::EmitterHandle& eh = (vox::EmitterHandle&)FindEmitterHandleBySoundHandle(handle);
	if (!(eh == m_emptyEmitterHandle))
		m_vox->SetLoop(eh, looped);
}

//////////////////////////////////////////////////////////////////////////

inline SoundMgr::SoundInfo* SoundMgr::FindSoundInfoBySoundHandle(SoundHandle sh) const
{
	SoundHandleMap::iterator it = m_soundHandleMap.find(sh);
	return it != m_soundHandleMap.end() ? &it->second : 0;
}

//////////////////////////////////////////////////////////////////////////

inline const vox::EmitterHandle& SoundMgr::FindEmitterHandleBySoundHandle(SoundHandle sh) const
{
	SoundHandleMap::const_iterator it = m_soundHandleMap.find(sh);
	return it != m_soundHandleMap.end() ? it->second.handle : m_emptyEmitterHandle;
}

//////////////////////////////////////////////////////////////////////////

inline int lower(int c)
{
	return std::tolower((unsigned char)c);
}

inline const vox::DataHandle& SoundMgr::FindDataHandleBySoundName(const pig::String& name) const
{
	SoundNameToDataHandleMap::const_iterator it = m_soundNameToDataHandle.find(name);
	if (it == m_soundNameToDataHandle.end())
	{
        //PASSERT(m_soundStreamFactory->HasName(name));
        /*if (!m_soundStreamFactory->HasName(name))
        {
            PDBG("WARNING: could not find audio file %s", name.c_str());
        }*/

		std::string fullName(m_soundStreamFactory->GetPath().c_str());
		fullName.push_back('/');
		fullName.append(name.c_str());

		std::transform(fullName.begin(), fullName.end(), fullName.begin(), lower);

		const vox::DataHandle& data = vox::VoxUtils::LoadDataSourceFromFileAutoDetectDecoder(fullName.c_str(), k_soundGroup);
		if (data == vox::DataHandle())
			return m_emptyDataHandle;

		std::pair<SoundNameToDataHandleMap::iterator, bool> p = m_soundNameToDataHandle.insert(std::make_pair(name, data));
		return p.first->second;
	}
	else
		return it->second;

	//return m_emptyDataHandle;
}

//////////////////////////////////////////////////////////////////////////

inline pig::s32 SoundMgr::FindBankIdBySoundName(const pig::String& name) const
{
	SoundNameToBankIdMap::const_iterator it = m_soundNameToBankId.find(name);
	return (it != m_soundNameToBankId.end()) ? it->second : -1;
}

//////////////////////////////////////////////////////////////////////////

inline const vox::DataHandle& SoundMgr::FindDataHandleByMusicName(const pig::String& name) const
{
	SoundNameToDataHandleMap::const_iterator it = m_musicNameToDataHandle.find(name);
	if (it == m_musicNameToDataHandle.end())
	{
        PASSERT(m_musicStreamFactory->HasName(name));
        if (!m_musicStreamFactory->HasName(name))
        {
            PDBG("WARNING: could not find audio file %s", name.c_str());
        }

        std::string fullName(m_musicStreamFactory->GetPath().c_str());
		fullName.push_back('/');
        fullName.append(name.c_str());

		std::transform(fullName.begin(), fullName.end(), fullName.begin(), lower);

		const vox::DataHandle& data = vox::VoxUtils::LoadDataSourceFromFileAutoDetectDecoder(fullName.c_str(), k_musicGroup);
		if (data == vox::DataHandle())
			return m_emptyDataHandle;

		std::pair<SoundNameToDataHandleMap::iterator, bool> p = m_musicNameToDataHandle.insert(std::make_pair(name, data));
		return p.first->second;
	}
	else
		return it->second;

	//return m_emptyDataHandle;
}


#endif

