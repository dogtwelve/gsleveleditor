#include "StdAfx.h"
#include "vox_default_config.h"

#if VOX_DRIVER_USE_MMSYSTEM && VOX_MMSYSTEM_DRIVER_PLATFORM

#include "vox_driver_mmsystem.h"
#include "vox_macro.h"

#define VOX_MMSYSTEM_MIN_NB_BUFFERS		2
#define VOX_MMSYSTEM_MIN_BUFFER_SIZE	2048	// In bytes (= 512 samples * 2 channels * 2 bytes/sample)
#define VOX_MMSYSTEM_V5_MIN_LATENCY		10240	// In bytes (= 5 * 512 samples). For versions 5 and earlier.
#define VOX_MMSYSTEM_V6_MIN_LATENCY		14336	// In bytes (= 7 * 512 samples). For versions 6 and later.

namespace vox 
{

DriverMMSystemSource::DriverMMSystemSource(void * trackParam, void* driverParam, u32 sourceId):
DriverCallbackSourceInterface(trackParam, driverParam, sourceId)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverMMSystemSource::DriverMMSystemSource", vox::VoxThread::GetCurThreadId());
	Init();
}

DriverMMSystemSource::~DriverMMSystemSource()//**-**
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverMMSystemSource::DriverMMSystemSource", vox::VoxThread::GetCurThreadId());
}

void DriverMMSystemSource::PrintDebug()
{
}

//*** DriverMMSystem ***//

DriverInterface* CreateDriver()
{
	return VOX_NEW DriverMMSystem();
}

DriverMMSystem::DriverMMSystem()
:m_nbBuffers(0)
,m_bufferSize(0)
,m_currentBuffer(0)
,m_pOutBuffers(0)
,m_pWaveBlocks(0)
,m_updateThread(0)
,m_isThreadRunning(false)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverMMSystem::DriverMMSystem", vox::VoxThread::GetCurThreadId());
	Init(0);
}

DriverMMSystem::~DriverMMSystem()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverMMSystem::~DriverMMSystem", vox::VoxThread::GetCurThreadId());
	Shutdown();
}

DriverSourceInterface* DriverMMSystem::CreateDriverSource(void * trackParam, void* driverParam, s32 priority)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverMMSystem::CreateDriverSource", vox::VoxThread::GetCurThreadId());
	m_mutex.Lock();
	
	DriverMMSystemSource* driverSource = 0;

	if(m_audioUnitActive)
	{
		driverSource = VOX_NEW DriverMMSystemSource(trackParam, driverParam, m_nextSourceId);
		if(driverSource)
		{
			m_activeSources.push_back(driverSource);
			m_nextSourceId++;
		}
	}

	m_mutex.Unlock();
	return driverSource;
}

void DriverMMSystem::DestroyDriverSource(DriverSourceInterface* driverSource)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverMMSystem::DestroyDriverSource", vox::VoxThread::GetCurThreadId());
	m_mutex.Lock();
	if(driverSource)
	{
		VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> >::iterator it = m_activeSources.begin();
		VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> >::iterator end = m_activeSources.end();

		for(; it != end; it++)
		{
			if(*it == driverSource)
			{
				m_activeSources.erase(it);
				break;
			}
		}

		VOX_DELETE((DriverMMSystemSource*) driverSource);
	}
	m_mutex.Unlock();
}

void DriverMMSystem::Init(void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverMMSystem::Init", vox::VoxThread::GetCurThreadId());

	DriverCallbackInterface::Init(param);
	DriverCallbackSourceInterface::SetDriverSampleRate(VOX_MMSYSTEM_DRIVER_PREFERRED_RATE);

	// Set a lower limit to buffer size
	if(m_bufferSize < VOX_MMSYSTEM_MIN_BUFFER_SIZE)
	{
		m_bufferSize = VOX_MMSYSTEM_MIN_BUFFER_SIZE;
	}

	// Set a lower limit to nb of buffers
	if(m_nbBuffers < VOX_MMSYSTEM_MIN_NB_BUFFERS)
	{
		m_nbBuffers = VOX_MMSYSTEM_MIN_NB_BUFFERS;
	}

	// Get major version of mmsystem
    DWORD dwMajorVersion = 0;
    dwMajorVersion = (DWORD)(LOBYTE(LOWORD(GetVersion())));

	if(dwMajorVersion >= 6)
	{
		// Total buffer size must be higher or equal to 7 x 512 samples
		if(m_nbBuffers * m_bufferSize < VOX_MMSYSTEM_V6_MIN_LATENCY)
		{
			s32 nbExtraBytesNeeded = VOX_MMSYSTEM_V6_MIN_LATENCY - (m_nbBuffers * m_bufferSize);
			s32 nbExtraBuffersFloor = nbExtraBytesNeeded / m_bufferSize;
			m_nbBuffers += nbExtraBuffersFloor + ((nbExtraBytesNeeded % m_bufferSize) > 0);
		}
	}
	else // dwMajorVersion <= 5
	{
		// Total buffer size must be higher or equal to 5 x 512 samples
		if(m_nbBuffers * m_bufferSize < VOX_MMSYSTEM_V5_MIN_LATENCY)
		{
			s32 nbExtraBytesNeeded = VOX_MMSYSTEM_V5_MIN_LATENCY - (m_nbBuffers * m_bufferSize);
			s32 nbExtraBuffersFloor = nbExtraBytesNeeded / m_bufferSize;
			m_nbBuffers += nbExtraBuffersFloor + ((nbExtraBytesNeeded % m_bufferSize) > 0);
		}
	}

	// Create buffers
	m_pOutBuffers = static_cast<u8**> (VOX_ALLOC(m_nbBuffers * sizeof(u8*)));

	if(!m_pOutBuffers)
	{
		m_bufferSize = 0;
		VOX_WARNING_LEVEL_1("[%s:%d] Could not create MMSystem buffers.", __FUNCTION__, __LINE__);
		return;
	}

	for(u32 i = 0; i < m_nbBuffers; i++)
	{
		m_pOutBuffers[i] = static_cast<u8*> (VOX_ALLOC(m_bufferSize));
		if(!m_pOutBuffers[i])
		{
			m_bufferSize = 0;
			VOX_WARNING_LEVEL_1("[%s:%d] Could not create MMSystem buffers.", __FUNCTION__, __LINE__);
			for(u32 j = 0; j < i; j++)
			{
				VOX_FREE(m_pOutBuffers[j]);
			}
			VOX_FREE(m_pOutBuffers);
			m_pOutBuffers = 0;
			return;
		}
		memset(m_pOutBuffers[i], 0, m_bufferSize);
	}
	m_pWaveBlocks = static_cast<WAVEHDR*> (VOX_ALLOC(m_nbBuffers * sizeof(WAVEHDR)));

	if(!m_pWaveBlocks)
	{
		m_bufferSize = 0;
		VOX_WARNING_LEVEL_1("[%s:%d] Could not create MMSystem wave blocks.", __FUNCTION__, __LINE__);
		for(u32 i = 0; i < m_nbBuffers; i++)
		{
			VOX_FREE(m_pOutBuffers[i]);
		}
		VOX_FREE(m_pOutBuffers);
		m_pOutBuffers = 0;
		return;
	}

	// Set up the WAVEFORMATEX structure.
	memset(&m_waveformat, 0, sizeof(m_waveformat));
	m_waveformat.wFormatTag = WAVE_FORMAT_PCM;
	m_waveformat.wBitsPerSample = 16;
	m_waveformat.nChannels = 2;
	m_waveformat.nSamplesPerSec = VOX_MMSYSTEM_DRIVER_PREFERRED_RATE;
	m_waveformat.nBlockAlign = m_waveformat.nChannels * (m_waveformat.wBitsPerSample >> 3);
	m_waveformat.nAvgBytesPerSec = m_waveformat.nSamplesPerSec * m_waveformat.nBlockAlign;

	if(waveOutOpen(&m_waveOut, WAVE_MAPPER, &m_waveformat, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR)
	{
		m_bufferSize = 0;
		VOX_WARNING_LEVEL_1("[%s:%d] Could not open MMSystem wave out.", __FUNCTION__, __LINE__);
		
		for(u32 i = 0; i < m_nbBuffers; i++)
		{
			VOX_FREE(m_pOutBuffers[i]);
		}
		VOX_FREE(m_pOutBuffers);
		m_pOutBuffers = 0;

		VOX_FREE(m_pWaveBlocks);
		m_pWaveBlocks = 0;
		return;
	}

	// Initialize buffers with silence
	for(u32 i = 0; i < m_nbBuffers; i++)
	{
		memset(&m_pWaveBlocks[i], 0, sizeof(WAVEHDR));
		waveOutPrepareHeader(m_waveOut, &m_pWaveBlocks[i], sizeof(WAVEHDR));
		m_pWaveBlocks[i].dwBufferLength = m_bufferSize;
		m_pWaveBlocks[i].lpData = (LPSTR) m_pOutBuffers[i];
		waveOutWrite(m_waveOut, &m_pWaveBlocks[i], sizeof(WAVEHDR));
	}

	// Inform parent class about driver's callback period (used for pitch ramping)
	DriverCallbackSourceInterface::SetDriverCallbackPeriod(static_cast<float> (m_bufferSize / m_waveformat.nBlockAlign) / static_cast<float> (VOX_MMSYSTEM_DRIVER_PREFERRED_RATE));

	// Start thread used to provide data to mmsystem.
	m_updateThread = VOX_NEW VoxThread(&vox::DriverMMSystem::UpdateThreaded, this, 0, "DriverMMSystem::Update");
	if(!m_updateThread)
	{
		m_bufferSize = 0;
		VOX_WARNING_LEVEL_1("[%s:%d] Could not start MMSystem update thread.", __FUNCTION__, __LINE__);
		
		for(u32 i = 0; i < m_nbBuffers; i++)
		{
			VOX_FREE(m_pOutBuffers[i]);
		}
		VOX_FREE(m_pOutBuffers);
		m_pOutBuffers = 0;

		VOX_FREE(m_pWaveBlocks);
		m_pWaveBlocks = 0;
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return;
	}
	m_isThreadRunning = true;

	m_audioUnitActive = true;
}

void DriverMMSystem::Shutdown()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverMMSystem::Shutdown", vox::VoxThread::GetCurThreadId());

	if(m_audioUnitActive)
	{
		// Terminate update thread
		m_isThreadRunning = false;
		if(m_updateThread)
		{
			VOX_DELETE(m_updateThread);
			m_updateThread = 0;
		}

		waveOutReset(m_waveOut);

		// Close mmsystem output device
		waveOutClose(m_waveOut);

		// Free allocated memory
		if(m_pWaveBlocks)
		{
			VOX_FREE(m_pWaveBlocks);
			m_pWaveBlocks = 0;
		}

		if(m_pOutBuffers)
		{
			for(u32 i = 0; i < m_nbBuffers; i++)
			{
				VOX_FREE(m_pOutBuffers[i]);
			}
			VOX_FREE(m_pOutBuffers);
			m_pOutBuffers = 0;
		}

		m_audioUnitActive = false;
	}
}

void DriverMMSystem::Suspend()
{
	// TODO : See if thread should be stopped
}

void DriverMMSystem::Resume()
{
	// TODO : Resume thread if it has been stopped by Suspend().
}

void DriverMMSystem::UpdateData(void)
{
	// Sleep 80% of buffer size
	u32 sleepTime = static_cast<DWORD> (static_cast<f32> (m_bufferSize >> 2) / static_cast<f32> (VOX_MMSYSTEM_DRIVER_PREFERRED_RATE) * 800.0f);

	while(m_isThreadRunning)
	{	
		while((m_pWaveBlocks[m_currentBuffer].dwFlags & WHDR_DONE) && m_isThreadRunning)
		{
			if(m_pWaveBlocks[m_currentBuffer].dwFlags & WHDR_PREPARED)
				waveOutUnprepareHeader(m_waveOut, &m_pWaveBlocks[m_currentBuffer], sizeof(WAVEHDR));

			// Get a buffer of samples
			FillBuffer(reinterpret_cast<s16*> (m_pOutBuffers[m_currentBuffer]), m_bufferSize >> 2);
			
			waveOutPrepareHeader(m_waveOut, &m_pWaveBlocks[m_currentBuffer], sizeof(WAVEHDR));

			m_pWaveBlocks[m_currentBuffer].dwBufferLength = m_bufferSize;
			m_pWaveBlocks[m_currentBuffer].lpData = (LPSTR) m_pOutBuffers[m_currentBuffer];

			waveOutWrite(m_waveOut, &m_pWaveBlocks[m_currentBuffer], sizeof(WAVEHDR));

			m_currentBuffer = (m_currentBuffer + 1) % m_nbBuffers;

			Sleep(sleepTime);
		}
	}
}

void DriverMMSystem::UpdateThreaded(void* caller, void* param)
{
	VOX_PROFILING_START_FRAME_LAZY;
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverMMSystem::Run", 0);

	((DriverMMSystem*)caller)->UpdateData();
}

}//namespace vox

#endif // VOX_DRIVER_USE_MMSYSTEM && VOX_MMSYSTEM_DRIVER_PLATFORM
