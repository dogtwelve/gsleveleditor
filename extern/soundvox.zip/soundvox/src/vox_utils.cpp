#include "StdAfx.h"
#include "vox_utils.h"
#include "vox_macro.h"
#include "vox_stream_memorybuffer.h"

#include <cstring>
#include <string.h>

namespace vox
{

DataHandle VoxUtils::LoadDataSourceFromFile( const c8* fileName, s32 decoderType, s32 groupFlags )
{
	VoxEngine& vox = VoxEngine::GetVoxEngine();
	return vox.LoadDataSource( k_nStreamTypeCFile, (void*)fileName, decoderType, 0, groupFlags );
}

DataHandle VoxUtils::LoadDataSourceFromFileAutoDetectDecoder( const c8* fileName, s32 groupFlags)
{
	if(fileName)
	{
		const c8* ext = strrchr(fileName, '.');
		if(ext == 0)
			return DataHandle();
		
		ext++;//skip '.'
		VOX_STRING fileext(ext);

		for(u32 i = 0; i < strlen(ext); i++)
		{
			fileext[i] = fileext[i] < 97 ? fileext[i] + 32 : fileext[i];
		}

		if(fileext == "wav")
		{
			return LoadDataSourceFromFile(fileName, k_nDecoderTypeMSWav, groupFlags);
		}
		else if(fileext == "ogg")
		{
			return LoadDataSourceFromFile(fileName, k_nDecoderTypeStbVorbis, groupFlags);
		}
		else if(fileext == "mpc")
		{
			return LoadDataSourceFromFile(fileName, k_nDecoderTypeMPC8, groupFlags);
		}
		else if(fileext == "vxn")
		{
			return LoadDataSourceFromFile(fileName, k_nDecoderTypeInteractiveMusic, groupFlags);
		}
#ifdef _NN_CTR
		else if(fileext == "bcwav")
		{
			return LoadDataSourceFromFile(fileName, k_nDecoderTypeBCWav, groupFlags);
		}
#endif
	}
	return DataHandle();
}

DataHandle VoxUtils::LoadDataSourceFromFileAsRAW( const c8* fileName, s32 decoderType, s32 groupFlags)
{
	VoxEngine& vox = VoxEngine::GetVoxEngine();
#if VOX_AUTORELEASE_DATA_SOURCE
	DataHandle dh = LoadDataSourceFromFile(fileName, decoderType, groupFlags);
	return vox.ConvertToRawSource(dh);

#else
	DataHandle dh = LoadDataSourceFromFile(fileName, decoderType, groupFlags);
	DataHandle cdh = vox.ConvertToRawSource(dh);
	vox.ReleaseDatasource(dh);
	return cdh;
#endif
}

DataHandle VoxUtils::LoadDataSourceFromFileToRAM( const c8* fileName, s32 decoderType, s32 groupFlags)
{
	VoxEngine& vox = VoxEngine::GetVoxEngine();

#if VOX_AUTORELEASE_DATA_SOURCE
	//DataHandle dh = LoadDataSourceFromFile(fileName, decoderType, groupFlags);
	//return vox.ConvertToRamBufferSource(dh);
	vox::FileSystemInterface* pFs = vox::FileSystemInterface::GetInstance();
	if(pFs)
	{
		vox::FileInterface* file = pFs->OpenFile((c8*)fileName);
		if(file)
		{
			file->Seek(0, vox::k_nSeekEnd);
			s32 size = file->Tell();
			if(size > 0)
			{
				file->Seek(0, vox::k_nSeekSet);
				s32 readSize = 0;
				
#if defined(_NN_CTR)
				u8* buf = (u8*)VOX_ALLOC_ALIGN(size, (vox::VoxMemHint)(vox::k_nVoxMemHint_Align32 | vox::k_nVoxMemHint_RamBuffer));
#else
				u8* buf = (u8*)VOX_ALLOC(size);
#endif
				if(buf)
				{
					s32 idx = 0;
					do
					{
						if(size - idx < 64 * 1024)
							readSize = file->Read(buf + idx, 1, size - idx);
						else
							readSize = file->Read(buf + idx, 1, 64 * 1024);
						idx += readSize;
					}
					while(readSize > 0);

					pFs->CloseFile(file);					

					VOX_ASSERT_MSG(idx <= size, "Read more data from file then size");

					vox::StreamMemoryBufferParams streamParams;
					streamParams.buffer = (u8*)buf;
					streamParams.size = size;
					streamParams.doCopy = false;
					streamParams.takeOwnership = true;
					
					// Loading the source
					return vox.LoadDataSource( vox::k_nStreamTypeMemoryBuffer, &streamParams, decoderType, 0, groupFlags );
				}
				pFs->CloseFile(file);
			}
			else
			{
				pFs->CloseFile(file);
			}
		}
	}
	return vox::DataHandle();
#else
	DataHandle dh = LoadDataSourceFromFile(fileName, decoderType, groupFlags);
	DataHandle cdh = vox.ConvertToRamBufferSource(dh);
	vox.ReleaseDatasource(dh);
	return cdh;
#endif
}

DataHandle VoxUtils::LoadDataSourceFromFileAutoDetectDecoderEx( const c8* fileName, s32 groupFlags, VoxSourceLoadingFlags loadingFlags, DataHandleUserData* pDataSourceUserData)
{
	if(fileName)
	{
		const c8* ext = strrchr(fileName, '.');
		if(ext == 0)
			return DataHandle();
		
		ext++;//skip '.'
		VOX_STRING fileext(ext);

		for(u32 i = 0; i < strlen(ext); i++)
		{
			fileext[i] = fileext[i] < 97 ? fileext[i] + 32 : fileext[i];
		}

		if(fileext == "wav")
		{
			return LoadDataSourceFromFileEx(fileName, k_nDecoderTypeMSWav, loadingFlags, groupFlags);
		}
		else if(fileext == "ogg")
		{
			return LoadDataSourceFromFileEx(fileName, k_nDecoderTypeStbVorbis, loadingFlags, groupFlags);
		}
		else if(fileext == "mpc")
		{
			return LoadDataSourceFromFileEx(fileName, k_nDecoderTypeMPC8, loadingFlags, groupFlags);
		}
		else if(fileext == "vxn")
		{
			return LoadDataSourceFromFileEx(fileName, k_nDecoderTypeInteractiveMusic, loadingFlags, groupFlags);
		}
#ifdef _NN_CTR
		else if(fileext == "bcwav")
		{
			return LoadDataSourceFromFileEx(fileName, k_nDecoderTypeBCWav, loadingFlags, groupFlags);
		}
#endif
	}
	return DataHandle();
}

DataHandle VoxUtils::LoadDataSourceFromFileEx( const c8* fileName, s32 decoderType, VoxSourceLoadingFlags loadingFlags, s32 groupFlags)
{
	VoxEngine& vox = VoxEngine::GetVoxEngine();
	if(loadingFlags & k_nAsync)
	{
		return vox.LoadDataSourceAsync( k_nStreamTypeCFile, (void*)fileName, decoderType, 0, groupFlags, (VoxSourceLoadingFlags)(loadingFlags & k_mLoadFlagMask));
	}
	else if(loadingFlags & k_nLoadToRam)
	{
		return LoadDataSourceFromFileToRAM(fileName, decoderType, groupFlags);
	}
	else if(loadingFlags == k_nLoadToRamAndDecode)
	{
		return LoadDataSourceFromFileAsRAW(fileName, decoderType, groupFlags);
	}
	else
	{
		return LoadDataSourceFromFile(fileName, decoderType, groupFlags);
	}
}

}
