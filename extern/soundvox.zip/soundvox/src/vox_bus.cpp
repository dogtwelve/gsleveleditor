#include "StdAfx.h"
#include "vox_default_config.h"
#if VOX_DRIVER_USE_PS3_MULTISTREAM && VOX_PS3_MULTISTREAM_DRIVER_PLATFORM
#include "vox_bus.h"
#include "vox_macro.h"
#include "vox_memory.h"
#include "vox_filesystem.h"
#include "vox_internal.h"
#include <cell/mstream.h>
#include <stdlib.h>
//#include <stdio.h>

//*** BusRoutingChange ***//
namespace vox
{
BusRoutingChange::BusRoutingChange(c8* busFromName, c8* busToName, VoxDSPGeneralParameter::BusRoutingType routingType, f32 dryVolume, f32 wetVolume, f32 fadeTime)
:BusFrom(0)
,BusTo(0)
,RoutingType(routingType)
,DryVolume(dryVolume)
,WetVolume(wetVolume)
,FadeTime(fadeTime)
{
	s32 size;
	if(busFromName && busToName)
	{
		size = strlen(busFromName);
		if(size >0)
		{
			BusFrom = (c8*)VOX_ALLOC(size+1);
			if(BusFrom)
				strcpy(BusFrom, busFromName);
		}

		size = strlen(busToName);
		if(size >0)
		{
			BusTo = (c8*)VOX_ALLOC(size+1);
			if(BusTo)
				strcpy(BusTo, busToName);
		}
	}
}

BusRoutingChange::~BusRoutingChange()
{
	if(BusFrom)
	{
		VOX_FREE(BusFrom);
	}

	if(BusTo)
	{
		VOX_FREE(BusTo);
	}
}

}

/* BusOutput */
namespace vox
{

BusOutput::BusOutput(c8* name, f32 volumeDry, f32 volumeWet)
:m_name(0)
,m_volumeDry(volumeDry)
,m_volumeWet(volumeWet)
{
	s32 length = strlen(name);

	if(length <= 0)
	{
		VOX_WARNING_LEVEL_2("Cannot retrieve bus output name%s", "");
	}
	else
	{
		m_name = (c8*)VOX_ALLOC(sizeof(c8) * length + 1);
		if(m_name)
			strcpy(m_name, name);
	}
}

BusOutput::~BusOutput()
{
	if(m_name)
	{
		VOX_DELETE(m_name);
	}
}

}

/* BusManager */
namespace vox
{
#define VOX_PS3_FIRST_FREQUENCY_BUS 0
//#define VOX_PS3_FIRST_TIME_BUS 16 //Replaced by m_timeDomainBusStart to allow dynamic changed
#define VOX_PS3_MAX_BUS 32

BusManager* BusManager::m_instance = 0;
BusManager* BusManager::GetInstance()
{
	if(m_instance == 0)
	{
		m_instance = VOX_NEW BusManager();
	}
	return m_instance;
}

void BusManager::Destroy()
{
	if(m_instance)
	{
		VOX_DELETE(m_instance);
		m_instance = 0;
	}
}

BusManager::BusManager()
:m_pDSPMgr(0),
m_timeDomainBusStart(VOX_PS3_MAX_BUS)
{
	Init();
}

BusManager::~BusManager()
{
	Bus* bus;
	while(m_fixedBuses.size() > 0)
	{
		bus = m_fixedBuses.back();
		m_fixedBuses.pop_back();
		VOX_DELETE(bus);
	}
	while(m_staticBuses.size() > 0)
	{
		bus = m_staticBuses.back();
		m_staticBuses.pop_back();
		VOX_DELETE(bus);
	}
	while(m_dynamicBuses.size() > 0)
	{
		bus = m_dynamicBuses.back();
		m_dynamicBuses.pop_back();
		VOX_DELETE(bus);
	}

	if(m_pDSPMgr)
		VOX_DELETE(m_pDSPMgr);
}

void BusManager::Init()
{
	m_pDSPMgr = VOX_NEW DSPManager();
	if(m_pDSPMgr)
		m_pDSPMgr->Init();

	for(int i = 0; i < VOX_PS3_MAX_BUS; i++)
	{
		m_revervedBuses[i] = false;
	}

	u32 busmask = ~VOX_DRIVER_PS3_MS_BUS_MASK;
	s32 timeBusCount = 0;
	for(s32 i = 0; i < 32; i++)
	{
		if(busmask & 0x00000001)
		{
			++timeBusCount;
			busmask = busmask >> 1;
		}
		else
		{
			break;
		}
	}

	VOX_ASSERT_MSG((timeBusCount >= 3) && (timeBusCount <= 28) && (busmask == 0), "VOX_DRIVER_PS3_MS_BUS_MASK invalid, please refer to vox_default_config.h");
	m_timeDomainBusStart = VOX_PS3_MAX_BUS - timeBusCount;

	//Set Fixed bus
	m_revervedBuses[BUS_MASTER		& 0x3F] = true;
	m_revervedBuses[BUS_COMP_APPLY	& 0x3F] = true;
	m_revervedBuses[BUS_COMP_CALC	& 0x3F] = true;
	m_revervedBuses[BUS_FILTER_LFE	& 0x3F] = true;

	m_revervedBuses[BUS_SFX1	& 0x3F] = true;
	m_revervedBuses[BUS_SFX2	& 0x3F] = true;
	m_revervedBuses[BUS_SFX3	& 0x3F] = true;
}

s32 BusManager::ReserveBusId(s32 domain)
{
	s32 busId = k_nBusIdInvalid;
	if(domain == VoxBusDomain::k_nFrequencyDomain)
	{
		for(s32 i = VOX_PS3_FIRST_FREQUENCY_BUS; i < m_timeDomainBusStart; i++)
		{
			if(m_revervedBuses[i] == false)
			{
				m_revervedBuses[i] = true;
				return i | CELL_MS_BUS_FLAG;
			}
		}
	}
	else if(domain == VoxBusDomain::k_nTimeDomain)
	{
		for(s32 i = m_timeDomainBusStart; i < VOX_PS3_MAX_BUS; i++)
		{
			if(m_revervedBuses[i] == false)
			{
				m_revervedBuses[i] = true; 
				return i | CELL_MS_BUS_FLAG;
			}
		}
	}
	else
	{
		VOX_WARNING_LEVEL_2("Domain type %d isn't valid", domain);
		return busId;
	}

	VOX_WARNING_LEVEL_2("Could not assign bus of domain type %d, no more bus available for that domain.", domain);

	return busId;
}

void BusManager::ReleaseBusId(s32 busId)
{
	busId = busId & 0x3F;

	if(busId >= 0 && busId < VOX_PS3_MAX_BUS)
	{
		if(!m_revervedBuses[busId])
			VOX_WARNING_LEVEL_2("Releasing an unreserved bus(%d)", busId);
		m_revervedBuses[busId] = false;
	}
}

s32 BusManager::GetBusId(char* busName)
{
	if(busName)
	{
		VOX_LIST<Bus*, SAllocator<Bus*> >::iterator iter = m_dynamicBuses.begin();
		VOX_LIST<Bus*, SAllocator<Bus*> >::iterator last = m_dynamicBuses.end();

		Bus* b;
		for(;iter != last; iter++)
		{
			b = (Bus*)*iter;
			if(strcasecmp(busName, b->GetName()) == 0)
				return b->GetBusId();
		}

		iter = m_staticBuses.begin();
		last = m_staticBuses.end();
		for(;iter != last; iter++)
		{
			b = (Bus*)*iter;
			if(strcasecmp(busName, b->GetName()) == 0)
				return b->GetBusId();
		}

		iter = m_fixedBuses.begin();
		last = m_fixedBuses.end();
		for(;iter != last; iter++)
		{
			b = (Bus*)*iter;
			if(strcasecmp(busName, b->GetName()) == 0)
				return b->GetBusId();
		}
	}

	return k_nBusIdInvalid;
}

s32 BusManager::LoadFixedBuses()
{
	Bus* pMasterBus = VOX_NEW BusMaster();
	if(pMasterBus)
	{
		pMasterBus->Load(0, m_pDSPMgr, this);
		m_fixedBuses.push_back(pMasterBus);
	}

	Bus* pFilterLFEBus = VOX_NEW BusFilterLFE();
	if(pFilterLFEBus)
	{
		pFilterLFEBus->Load(0, m_pDSPMgr, this);
		m_fixedBuses.push_back(pFilterLFEBus);
	}

	Bus* pCompApplyBus = VOX_NEW BusCompressorApply();
	if(pCompApplyBus)
	{
		pCompApplyBus->Load(0, m_pDSPMgr, this);
		m_fixedBuses.push_back(pCompApplyBus);
	}

	Bus* pCompCalcBus = VOX_NEW BusCompressorCalc();
	if(pCompCalcBus)
	{
		pCompCalcBus->Load(0, m_pDSPMgr, this);
		m_fixedBuses.push_back(pCompCalcBus);
	}

	return 0;
}

s32 BusManager::LoadVRT(char* vrtfile)
{
	FileSystemInterface* pFS = FileSystemInterface::GetInstance();
	if(!pFS)
		return -1;

	FileInterface* file = pFS->OpenFile(vrtfile);
	if(!file)
	{
		VOX_WARNING_LEVEL_2("Cannot open file %s", vrtfile);
		return -1;
	}

	//Unload all dynamic buses
	UnloadVRT();

	// 4 byte id
	// 1 byte version
	// 1 byte nb bus
	c8 header[8];
	file->Read(header, 8, 1);

	if(!((header[0] == 'V') && (header[1] == 'R') && (header[2] == 'T') && (header[3] == ' ')))
	{
		VOX_WARNING_LEVEL_2("Cannot load file, not a VRT", header[4]);
	}

	if(header[4] !=  VRT_VERSION)
	{
		VOX_WARNING_LEVEL_2("VRT version %d not supported", header[4]);
		pFS->CloseFile(file);
		return -1;
	}

	u8 busQty = header[5];

	c8 path[512];
	FileSystemInterface::GetDirectory(path, 512, vrtfile);
	pFS->PushDirectory(path);

	u16 busSize = 0;

	c8* data = 0;
	u16 lastBusSize = 0;
	//for each bus ...
	for(int i = 0; i < busQty; i++)
	{
		file->Read((void*)&busSize, 2, 1);
		busSize -=2;
		if(lastBusSize < busSize)
		{
			VOX_FREE(data);
			data = (c8*) VOX_ALLOC(busSize);
			lastBusSize = busSize;
		}

		if(data)
		{
			file->Read(data, busSize, 1);

			Bus* b = VOX_NEW Bus();
			if(b)
			{
				b->Load(data, m_pDSPMgr, this);
				m_staticBuses.push_back(b);
			}
		}
		else
		{
			//skip to next, hope next bus is smaller
			file->Seek(busSize, k_nSeekCur);
			lastBusSize = 0;
		}
	}

	VOX_FREE(data);

	AttachBusOutputs(m_staticBuses);

	pFS->PopDirectory();
	pFS->CloseFile(file);

	return 0;
}

s32 BusManager::LoadVRF(char* vrffile)
{
	FileSystemInterface* pFS = FileSystemInterface::GetInstance();
	if(!pFS)
		return -1;

	FileInterface* file = pFS->OpenFile(vrffile);
	if(!file)
	{
		VOX_WARNING_LEVEL_2("Cannot open file %s", vrffile);
		return -1;
	}

	//Unload all dynamic buses
	UnloadVRF();

	// 4 byte id
	// 1 byte version
	// 1 byte nb bus
	c8 header[6];
	file->Read(header, 6, 1);

	if(!((header[0] == 'V') && (header[1] == 'R') && (header[2] == 'F') && (header[3] == ' ')))
	{
		VOX_WARNING_LEVEL_2("Cannot load file, not a VRF : %c%c%c%c", header[0], header[1], header[2], header[3]);
		return -1;
	}

	if(header[4] !=  VRF_VERSION)
	{
		VOX_WARNING_LEVEL_2("VRF version %d not supported", header[4]);
		pFS->CloseFile(file);
		return -1;
	}

	u8 busQty = header[5];

	//skip template name
	u16 templateSize;
	file->Read(&templateSize, 2, 1);
	file->Seek(templateSize, k_nSeekCur);

	c8 path[512];
	FileSystemInterface::GetDirectory(path, 512, vrffile);
	pFS->PushDirectory(path);

	u16 busSize = 0;

	c8* data = 0;
	u16 lastBusSize = 0;
	//for each bus ...
	for(int i = 0; i < busQty; i++)
	{
		file->Read((void*)&busSize, 2, 1);
		busSize -=2;
		if(lastBusSize < busSize)
		{
			VOX_FREE(data);
			data = (c8*) VOX_ALLOC(busSize);
			lastBusSize = busSize;
		}

		if(data)
		{
			file->Read(data, busSize, 1);

			Bus* b = VOX_NEW Bus();
			if(b)
			{
				b->Load(data, m_pDSPMgr, this);
				m_dynamicBuses.push_back(b);
			}
		}
		else
		{
			//skip to next, hope next bus is smaller
			file->Seek(busSize, k_nSeekCur);
			lastBusSize = 0;
		}
	}

	VOX_FREE(data);

	AttachBusOutputs(m_dynamicBuses);

	pFS->PopDirectory();
	pFS->CloseFile(file);

	return 0;
}

s32 BusManager::UnloadVRF()
{
	Bus* bus;
	while(m_dynamicBuses.size() > 0)
	{
		bus = m_dynamicBuses.back();
		m_dynamicBuses.pop_back();
		VOX_DELETE(bus);
	}
	return 0;
}

s32 BusManager::UnloadVRT()
{
	Bus* bus;
	while(m_staticBuses.size() > 0)
	{
		bus = m_staticBuses.back();
		m_staticBuses.pop_back();
		VOX_DELETE(bus);
	}
	return 0;
}

void BusManager::AttachBusOutputs(VOX_LIST<Bus*, SAllocator<Bus*> > busesList)
{
	VOX_LIST<Bus*, SAllocator<Bus*> >::iterator iter = busesList.begin();
	VOX_LIST<Bus*, SAllocator<Bus*> >::iterator last = busesList.end();

	Bus* b;
	for(;iter != last; iter++)
	{
		b = (Bus*)*iter;
		b->AttachBusOutput(this);
	}
}

void BusManager::SetBusRoutingVolumeChange(BusRoutingChange* busRoutingChange)
{
	c8* busName = busRoutingChange->BusFrom;
	if(busName)
	{
		VOX_LIST<Bus*, SAllocator<Bus*> >::iterator iter = m_dynamicBuses.begin();
		VOX_LIST<Bus*, SAllocator<Bus*> >::iterator last = m_dynamicBuses.end();

		Bus* b;
		for(;iter != last; iter++)
		{
			b = (Bus*)*iter;
			if(strcasecmp(busName, b->GetName()) == 0)
			{
				b->SetBusRoutingVolumeChange(busRoutingChange);
				return;
			}
		}

		iter = m_staticBuses.begin();
		last = m_staticBuses.end();
		for(;iter != last; iter++)
		{
			b = (Bus*)*iter;
			if(strcasecmp(busName, b->GetName()) == 0)
			{
				b->SetBusRoutingVolumeChange(busRoutingChange);
				return;
			}
		}

		iter = m_fixedBuses.begin();
		last = m_fixedBuses.end();
		for(;iter != last; iter++)
		{
			b = (Bus*)*iter;
			if(strcasecmp(busName, b->GetName()) == 0)
			{
				b->SetBusRoutingVolumeChange(busRoutingChange);
				return;
			}
		}
	}
}

void BusManager::Update(f32 dt)
{
	//Do something
	VOX_LIST<Bus*, SAllocator<Bus*> >::iterator iter = m_dynamicBuses.begin();
	VOX_LIST<Bus*, SAllocator<Bus*> >::iterator last = m_dynamicBuses.end();

	Bus* b;
	for(;iter != last; iter++)
	{
		b = (Bus*)*iter;
		b->Update(dt);
	}

	iter = m_staticBuses.begin();
	last = m_staticBuses.end();
	for(;iter != last; iter++)
	{
		b = (Bus*)*iter;
		b->Update(dt);
	}

	iter = m_fixedBuses.begin();
	last = m_fixedBuses.end();
	for(;iter != last; iter++)
	{
		b = (Bus*)*iter;
		b->Update(dt);
	}
}

}

/* Bus */
namespace vox
{

// volumes. (Maximum volume for each speaker)
f32 fVols51[64] = {	1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
					0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
					0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
					0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f,
					0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f,
					0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f,
					0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
					0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};

f32 fVolsLFE[64] = {1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
					0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
					0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
					0.0f, 0.0f, 0.0f, 0.2f, 0.0f, 0.0f, 0.0f, 0.0f,
					0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f,
					0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f,
					0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
					0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};

f32 fVolsRev[64] = {0.2f,   0.0f,	0.0f,	0.0f, 	0.0f, 	0.0f, 	0.0f, 0.0f,
					0.0f,	0.2f,   0.0f,	0.0f, 	0.0f, 	0.0f, 	0.0f, 0.0f,
					0.0f,	0.0f, 	0.0f,   0.0f, 	0.0f, 	0.0f, 	0.0f, 0.0f,
					0.0f,	0.0f, 	0.0f, 	0.0f, 	0.0f,   0.0f, 	0.0f, 0.0f,
					0.0f,	0.0f, 	0.0f, 	0.0f, 	0.2f,   0.0f, 	0.0f, 0.0f,
					0.0f,	0.0f, 	0.0f, 	0.0f, 	0.0f, 	0.2f,   0.0f, 0.0f,
					0.0f,	0.0f, 	0.0f, 	0.0f, 	0.0f, 	0.0f, 	0.0f, 0.0f,
					0.0f,	0.0f, 	0.0f, 	0.0f, 	0.0f, 	0.0f, 	0.0f, 0.0f};

f32 fVols0[64] = {  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
					0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
					0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
					0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
					0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
					0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
					0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
					0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};


Bus::Bus()
:m_name(0)
,m_busId(k_nBusIdInvalid)
,m_domain(VoxBusDomain::k_nUnknown)
,m_type(VoxBusType::k_nDynamic)
{
	for(int i = 0; i < 8; i++)
	{
		m_dsp[i] = 0;
	}

	memcpy(m_volumeDry, fVols51, sizeof(f32) * 64);
	memcpy(m_volumeWet, fVols51, sizeof(f32) * 64);
}

Bus::~Bus()
{
	Unload();
}

s32 Bus::Load(void *data, DSPManager* pDSPMgr, BusManager* pBusMgr)
{
	const u8* _data = (const u8*) data;
	u16 dataCursor = 0;
	u8 nameSize = (u8)_data[dataCursor++];
	
	m_name = (c8*)VOX_ALLOC(nameSize + 1);
	memcpy(m_name, &_data[dataCursor], nameSize);
	m_name[nameSize] = 0;
	dataCursor += nameSize;

	m_domain = _data[dataCursor++];

	if(strcmp(m_name, "SFX1") == 0)
	{
		m_busId = BUS_SFX1;
	}
	else if(strcmp(m_name, "SFX2") == 0)
	{
		m_busId = BUS_SFX2;
	}
	else if(strcmp(m_name, "SFX3") == 0)
	{
		m_busId = BUS_SFX3;
	}
	else
	{
		m_busId = pBusMgr->ReserveBusId(m_domain);
	}

	memcpy(m_volumeDry, &_data[dataCursor], sizeof(f32)*64);
	dataCursor += sizeof(f32)*64;
	s32	ret = cellMSCoreSetVolume64(m_busId, CELL_MS_DRY, m_volumeDry);
	CELLMS_ERROR(ret);

	memcpy(m_volumeWet, &_data[dataCursor], sizeof(f32)*64);
	dataCursor += sizeof(f32)*64;
	ret = cellMSCoreSetVolume64(m_busId, CELL_MS_WET, m_volumeWet);
	CELLMS_ERROR(ret);

	s32 dspQty = _data[dataCursor++];

	c8 dspName[256];
	c8 tempName[256];
	for(int i = 0; i < dspQty; i++)
	{
		nameSize = _data[dataCursor++];
		if(nameSize < 255)
		{
			memcpy(dspName, &_data[dataCursor], nameSize);
			dspName[nameSize] = 0;
			strcpy(tempName, "/mng/");
			strcat(tempName, dspName);
			if(pDSPMgr)
				m_dsp[i] = pDSPMgr->CreateDSP(tempName , m_busId, (CELL_MS_DSPSLOTS)(CELL_MS_DSP_SLOT_0 + i));
		}
		dataCursor += nameSize + 2;
	}

	s32 busOutputQty = _data[dataCursor++];
	f32 vdry, vwet;
	c8 name[256];
	memset(name, 0, 256);
	BusOutput *pBusOutput;
	for(int i = 0; i < busOutputQty; i++)
	{
		nameSize = _data[dataCursor++];
		//skip
		memcpy(name, &_data[dataCursor], nameSize);
		name[nameSize] = 0;
		dataCursor += nameSize;
		memcpy(&vdry, &_data[dataCursor], sizeof(f32));
		dataCursor += 4;
		memcpy(&vwet, &_data[dataCursor], sizeof(f32));
		dataCursor += 4;

		pBusOutput = VOX_NEW BusOutput(name, vdry, vwet);
		if(pBusOutput)
			m_busOutputs.push_back(pBusOutput);
		else
			VOX_WARNING_LEVEL_2("Could not attach output %d of bus %s", i, m_name);
	}

	return -1;
}

void Bus::Unload()
{
	s32	ret = cellMSCoreSetVolume64(m_busId, CELL_MS_WET_AND_DRY, fVols51);
	CELLMS_ERROR(ret);
	//restore default routing
	ret = cellMSCoreSetRouting( m_busId, BUS_MASTER, CELL_MS_WET_AND_DRY, CELL_MS_ROUTE_ALL_OFF, 1.0f, 1.0f);
	CELLMS_ERROR(ret);
	ret = cellMSCoreSetRouting( m_busId, BUS_MASTER, CELL_MS_WET_AND_DRY, CELL_MS_ROUTE_ON, 1.0f, 1.0f);
	CELLMS_ERROR(ret);

	cellMSCoreSetBypass(m_busId, CELL_MS_WET_AND_DRY, CELL_MS_NOTBYPASSED);

	for(int i = 0; i < 8; i++)
	{
		if(m_dsp[i])
			VOX_DELETE(m_dsp[i]);
	}

	if(m_name)
		VOX_FREE(m_name);

	BusManager* pBusMgr = BusManager::GetInstance();
	if(!(m_busId == BUS_SFX1 || m_busId == BUS_SFX2 || m_busId == BUS_SFX3) && pBusMgr)
		pBusMgr->ReleaseBusId(m_busId);
	m_busId = k_nBusIdInvalid;

	//Should be empty at this point, but just to be sure ...
	BusOutput* bo;
	while(m_busOutputs.size() > 0)
	{
		bo = m_busOutputs.back();
		m_busOutputs.pop_back();
		VOX_DELETE(bo);
	}
}

s32 Bus::AttachBusOutput(BusManager* pBusMgr)
{
	if(m_busOutputs.size() <= 0)
		return 0; //Nothing to do

	//remove all routing
	s32 ret = cellMSCoreSetRouting( m_busId, BUS_MASTER, CELL_MS_WET_AND_DRY, CELL_MS_ROUTE_ALL_OFF, 1.0f, 1.0f);
	CELLMS_ERROR(ret);
	//s32 ret = cellMSCoreSetRouting( m_busId, BUS_MASTER, CELL_MS_WET_AND_DRY, CELL_MS_ROUTE_OFF, 1.0f, 1.0f);
	//CELLMS_ERROR(ret);

	BusOutput* bo;
	s32 busId;
	while(m_busOutputs.size() > 0)
	{
		bo = m_busOutputs.back();
		m_busOutputs.pop_back();

		busId = pBusMgr->GetBusId(bo->GetName());
		if(busId != -1)
		{
			s32 ret = cellMSCoreSetRouting( m_busId, busId, CELL_MS_WET_AND_DRY, CELL_MS_ROUTE_ON, bo->GetVolumeDry(), bo->GetVolumeWet());
			CELLMS_ERROR(ret);
		}

		VOX_DELETE(bo);
	}

	return 0;
}

void Bus::SetBusRoutingVolumeChange(BusRoutingChange* busRoutingChange)
{
	BusManager* pBusMgr = BusManager::GetInstance();
	if(pBusMgr && busRoutingChange)
	{
		f32 curDryV, curWetV;
		s32 dryRoute, wetRoute;
		s32 toBusId = pBusMgr->GetBusId(busRoutingChange->BusTo);

		//Get current Volume
		s32 ret = cellMSCoreGetRouting(m_busId, toBusId, &dryRoute, &wetRoute, &curDryV, &curWetV);
		CELLMS_ERROR(ret);

		// Set fader on current Volume
		Fader dryFader = Fader(curDryV, curDryV, busRoutingChange->FadeTime);
		Fader wetFader = Fader(curWetV, curWetV, busRoutingChange->FadeTime);

		//Check if was already fading
		VOX_LIST<BusRoutingChangeInternal*, SAllocator<BusRoutingChangeInternal*> >::iterator iter = m_volumeFader.begin();
		VOX_LIST<BusRoutingChangeInternal*, SAllocator<BusRoutingChangeInternal*> >::iterator last = m_volumeFader.end();

		BusRoutingChangeInternal* brci = 0;
		for(;iter != last; iter++)
		{
			brci = (BusRoutingChangeInternal*)*iter;
			if(brci==0)
				continue;
			if(brci->BusTo == toBusId)
			{			
				//Route volume is currently fading, get current fader
				m_volumeFader.erase(iter);
				dryFader = brci->DryVolume;
				wetFader = brci->WetVolume;
				VOX_DELETE(brci);
				break;//cannot have more than one volume change per route
			}
		}

		//If fading is same type, new fader override, if not old fader continue
		brci = 0;
		if(busRoutingChange->RoutingType == VoxDSPGeneralParameter::k_nDry && dryRoute)
		{
			brci = VOX_NEW BusRoutingChangeInternal(toBusId, busRoutingChange->RoutingType, Fader(curDryV, busRoutingChange->DryVolume, busRoutingChange->FadeTime), wetFader);
		}
		else if(busRoutingChange->RoutingType == VoxDSPGeneralParameter::k_nWet && wetRoute)
		{
			brci = VOX_NEW BusRoutingChangeInternal(toBusId, busRoutingChange->RoutingType, dryFader, Fader(curWetV, busRoutingChange->WetVolume, busRoutingChange->FadeTime));
		}
		else if(busRoutingChange->RoutingType == VoxDSPGeneralParameter::k_nWetAndDry && (dryRoute || wetRoute))
		{
			brci = VOX_NEW BusRoutingChangeInternal(toBusId, busRoutingChange->RoutingType, Fader(curDryV, busRoutingChange->DryVolume, busRoutingChange->FadeTime), Fader(curWetV, busRoutingChange->WetVolume, busRoutingChange->FadeTime));
		}

		if(brci)
		{
			m_volumeFader.push_back(brci);
		}
	}
}

void Bus::Update(f32 dt)
{
	VOX_LIST<BusRoutingChangeInternal*, SAllocator<BusRoutingChangeInternal*> >::iterator iter = m_volumeFader.begin();
	VOX_LIST<BusRoutingChangeInternal*, SAllocator<BusRoutingChangeInternal*> >::iterator last = m_volumeFader.end();

	BusRoutingChangeInternal* brci;
	for(;iter != last; iter++)
	{
		brci = (BusRoutingChangeInternal*)*iter;
		if(brci==0)
			continue;
		if(brci->DryVolume.IsFinished() && brci->WetVolume.IsFinished())
		{			
			iter = m_volumeFader.erase(iter);
			VOX_DELETE(brci);
			iter--;//erase go to next item, if we don't go back one it will be skipped
		}
		else
		{
			brci->DryVolume.Update(dt);
			brci->WetVolume.Update(dt);
			//if(brci->RoutingType == VoxDSPGeneralParameter::k_nDry)
			//{
			//	s32 ret = cellMSCoreSetRouting(m_busId & 0xFF, brci->BusTo & 0xFF, CELL_MS_DRY, CELL_MS_ROUTE_VOLUME_ONLY, brci->DryVolume.GetCurrentValue(), brci->WetVolume.GetCurrentValue());
			//	CELLMS_ERROR(ret);
			//}
			//else if(brci->RoutingType == VoxDSPGeneralParameter::k_nWet)
			//{
			//	s32 ret = cellMSCoreSetRouting(m_busId & 0xFF, brci->BusTo & 0xFF, CELL_MS_WET, CELL_MS_ROUTE_VOLUME_ONLY, brci->DryVolume.GetCurrentValue(), brci->WetVolume.GetCurrentValue());
			//	CELLMS_ERROR(ret);
			//}
			//else if(brci->RoutingType == VoxDSPGeneralParameter::k_nWetAndDry)
			{
				s32 ret = cellMSCoreSetRouting(m_busId & 0xFF, brci->BusTo & 0xFF, CELL_MS_WET_AND_DRY, CELL_MS_ROUTE_VOLUME_ONLY, brci->DryVolume.GetCurrentValue(), brci->WetVolume.GetCurrentValue());
				CELLMS_ERROR(ret);
			}
		}
	}

	for(int i = 0; i < 8; i++)
	{
		if(m_dsp[i])
		{
			m_dsp[i]->Update(dt);
		}
	}
}

}

/* BusMaster */
namespace vox
{
BusMaster::BusMaster()
{
	m_type = VoxBusType::k_nMandatory;
}

BusMaster::~BusMaster()
{
}

s32 BusMaster::Load(void *data, DSPManager* pDSPMgr, BusManager* pBusMgr)
{
	m_busId = BUS_MASTER;
	m_name = (c8*)VOX_ALLOC(strlen("Master") + 1);
	if(m_name)
		strcpy(m_name, "Master");

	// Setup the volumes on the master bus
	s32 ret = cellMSCoreSetVolume64(BUS_MASTER, CELL_MS_DRY, fVols51);
	CELLMS_ERROR(ret);
	cellMSCoreSetBypass(BUS_MASTER, CELL_MS_WET, CELL_MS_BYPASSED);

	return ret;
}

}

/* BusFilterLFE */
namespace vox
{
BusFilterLFE::BusFilterLFE()
{
	m_type = VoxBusType::k_nMandatory;
}

BusFilterLFE::~BusFilterLFE()
{
}

s32 BusFilterLFE::Load(void *data, DSPManager* pDSPMgr, BusManager* pBusMgr)
{
	m_busId = BUS_FILTER_LFE;
	m_name = (c8*)VOX_ALLOC(strlen("FilterLFE") + 1);
	if(m_name)
		strcpy(m_name, "FilterLFE");

	// Setup the volumes on the dsp bus
	s32 ret = cellMSCoreSetVolume64(BUS_FILTER_LFE, CELL_MS_WET, fVolsLFE);
	CELLMS_ERROR(ret);

	ret = cellMSCoreSetRouting( BUS_FILTER_LFE, BUS_MASTER, CELL_MS_WET, CELL_MS_ROUTE_ON, 0.0f, 1.0f);
	CELLMS_ERROR(ret);
	ret = cellMSCoreSetRouting( BUS_FILTER_LFE, BUS_MASTER, CELL_MS_DRY, CELL_MS_ROUTE_OFF, 0.0f, 1.0f);
	CELLMS_ERROR(ret);
	cellMSCoreSetBypass(BUS_FILTER_LFE, CELL_MS_DRY, CELL_MS_BYPASSED);
	
	if(pDSPMgr)
		m_dsp[0] = pDSPMgr->CreateFilterLFE();
	else
		ret = -1;

	return ret;
}

}

/* BusCompressorApply */
namespace vox
{
BusCompressorApply::BusCompressorApply()
{
	m_type = VoxBusType::k_nMandatory;
}

BusCompressorApply::~BusCompressorApply()
{
}

s32 BusCompressorApply::Load(void *data, DSPManager* pDSPMgr, BusManager* pBusMgr)
{
	m_busId = BUS_COMP_APPLY;
	m_name = (c8*)VOX_ALLOC(strlen("CompressorApply") + 1);
	if(m_name)
		strcpy(m_name, "CompressorApply");

	s32	ret = cellMSCoreSetVolume64(BUS_COMP_APPLY, CELL_MS_WET, fVols51);
	CELLMS_ERROR(ret);
	cellMSCoreSetBypass(BUS_COMP_APPLY, CELL_MS_DRY, CELL_MS_BYPASSED);

	ret = cellMSCoreSetRouting( BUS_COMP_APPLY, BUS_MASTER, CELL_MS_WET_AND_DRY, CELL_MS_ROUTE_OFF, 0.0f, 0.0f);
	CELLMS_ERROR(ret);
	ret = cellMSCoreSetRouting( BUS_COMP_APPLY, BUS_FILTER_LFE, CELL_MS_WET, CELL_MS_ROUTE_ON, 0.0f, 1.0f);
	CELLMS_ERROR(ret);
	ret = cellMSCoreSetRouting( BUS_COMP_APPLY, BUS_FILTER_LFE, CELL_MS_DRY, CELL_MS_ROUTE_OFF, 0.0f, 1.0f);
	CELLMS_ERROR(ret);

	//Apply bus own the DPS
	//if(pDSPMgr)
	//	m_dsp[0] = pDSPMgr->CreateSideChainDSP("/app_home/data/mng/CompressorSC.mng");
	//else
		ret = -1;

	return ret;
}

}

/* BusCompressorCalc */
namespace vox
{
BusCompressorCalc::BusCompressorCalc()
{
	m_type = VoxBusType::k_nMandatory;
}

BusCompressorCalc::~BusCompressorCalc()
{
}

s32 BusCompressorCalc::Load(void *data, DSPManager* pDSPMgr, BusManager* pBusMgr)
{
	m_busId = BUS_COMP_CALC;
	m_name = (c8*)VOX_ALLOC(strlen("CompressorCalc") + 1);
	if(m_name)
		strcpy(m_name, "CompressorCalc");

	s32 ret = cellMSCoreSetVolume64(BUS_COMP_CALC, CELL_MS_DRY, fVols51);
	CELLMS_ERROR(ret);
	cellMSCoreSetBypass(BUS_COMP_CALC, CELL_MS_WET, CELL_MS_BYPASSED);
	
	ret = cellMSCoreSetRouting( BUS_COMP_CALC, BUS_MASTER, CELL_MS_WET_AND_DRY, CELL_MS_ROUTE_OFF, 0.0f, 0.0f);
	CELLMS_ERROR(ret);
	ret = cellMSCoreSetRouting( BUS_COMP_CALC, BUS_FILTER_LFE, CELL_MS_DRY, CELL_MS_ROUTE_ON, 1.0f, 0.0f);
	CELLMS_ERROR(ret);
	ret = cellMSCoreSetRouting( BUS_COMP_CALC, BUS_FILTER_LFE, CELL_MS_WET, CELL_MS_ROUTE_OFF, 1.0f, 0.0f);
	CELLMS_ERROR(ret);
	
	//Calc stage own the dsp
	//m_dsp[0] = pDSPMgr->CreateSideChainDSP("/app_home/data/CompressorSC.mng");

	return ret;
}

}

#endif //VOX_DRIVER_USE_PS3_MULTISTREAM
