#include "StdAfx.h"
#include "vox_default_config.h"

#if VOX_DRIVER_USE_PS3_MULTISTREAM && VOX_PS3_MULTISTREAM_DRIVER_PLATFORM 

#include "vox_dsp_ps3.h"
#include "vox_bus.h"

#include "vox.h"
#include "vox_macro.h"
#include "vox_memory.h"
#include "vox_filesystem.h"

#include <stdlib.h>

#if VOX_DSP_ENABLE_COMPRESSOR
//Addresses of embedded (linked) .pic file SPU program 
extern char _binary_mstream_dsp_compressor_pic_start[];
extern char _binary_mstream_dsp_compressor_pic_end[];
extern char _binary_mstream_dsp_compressor_pic_size[];
#endif
#if VOX_DSP_ENABLE_TDREVERB
//Addresses of embedded (linked) .pic file SPU program 
extern char _binary_mstream_dsp_reverb_pic_start[];
extern char _binary_mstream_dsp_reverb_pic_end[];
extern char _binary_mstream_dsp_reverb_pic_size[];
#endif
#if VOX_DSP_ENABLE_FILTER
//Addresses of embedded (linked) .pic file SPU program 
extern char _binary_mstream_dsp_filter_pic_start[];
extern char _binary_mstream_dsp_filter_pic_end[];
extern char _binary_mstream_dsp_filter_pic_size[];
#endif
#if VOX_DSP_ENABLE_PITCHSHIFT
//Addresses of embedded (linked) .pic file SPU program 
extern char _binary_mstream_dsp_pitchshift_pic_start[];
extern char _binary_mstream_dsp_pitchshift_pic_end[];
extern char _binary_mstream_dsp_pitchshift_pic_size[];
#endif
#if VOX_DSP_ENABLE_IMPULSEREVERB
//Addresses of embedded (linked) .pic file SPU program 
extern char _binary_mstream_dsp_IR_pic_start[];
extern char _binary_mstream_dsp_IR_pic_end[];
extern char _binary_mstream_dsp_IR_pic_size[];
#endif
#if VOX_DSP_ENABLE_PARAMETRIC_EQ
//Addresses of embedded (linked) .pic file SPU program 
extern char _binary_mstream_dsp_para_eq_pic_start[];
extern char _binary_mstream_dsp_para_eq_pic_end[];
extern char _binary_mstream_dsp_para_eq_pic_size[];
#endif
#if VOX_DSP_ENABLE_DELAY
//Addresses of embedded (linked) .pic file SPU program 
extern char _binary_mstream_dsp_delay_pic_start[];
extern char _binary_mstream_dsp_delay_pic_end[];
extern char _binary_mstream_dsp_delay_pic_size[];
#endif
#if VOX_DSP_ENABLE_DISTORTION
//Addresses of embedded (linked) .pic file SPU program 
extern char _binary_mstream_dsp_distortion_pic_start[];
extern char _binary_mstream_dsp_distortion_pic_end[];
extern char _binary_mstream_dsp_distortion_pic_size[];
#endif

/* DSPManager */
namespace vox
{
DSPManager::DSPManager()
{
	m_pDSPHandles = (s32*)VOX_ALLOC(sizeof(s32) * (VoxDSP::k_nDSPMax));

	if(m_pDSPHandles)
	{
		for(int i = 0; i < VoxDSP::k_nDSPMax; i++)
		{
			m_pDSPHandles[i] = -1;
		}
	}
	else
	{
		VOX_WARNING_LEVEL_2("Unable to allocate dsp handles buffer", 0);
	}
}

DSPManager::~DSPManager()
{
	VOX_FREE(m_pDSPHandles);
}

void DSPManager::Init()
{
	if(!m_pDSPHandles || VoxDSP::k_nDSPMax == 0)
	{
		//No dsp enabled
		return;
	}

	CellMSDSP DSPInfo;
#if VOX_DSP_ENABLE_COMPRESSOR
	m_pDSPHandles[VoxDSP::k_nCompressor]= cellMSDSPLoadDSPFromMemory((void*)_binary_mstream_dsp_compressor_pic_start, &DSPInfo, VoxDSP::k_nCompressor,CELL_MS_ALLOC_PAGE);
	VOX_ASSERT_MSG(m_pDSPHandles[VoxDSP::k_nCompressor]!=-1,"Compressor cellMSDSPLoadDSPFromMemory Failed\n");
#endif
#if VOX_DSP_ENABLE_TDREVERB
	m_pDSPHandles[VoxDSP::k_nTDReverb]= cellMSDSPLoadDSPFromMemory((void*)_binary_mstream_dsp_reverb_pic_start, &DSPInfo, VoxDSP::k_nTDReverb,CELL_MS_ALLOC_PAGE);
	VOX_ASSERT_MSG(m_pDSPHandles[VoxDSP::k_nTDReverb]!=-1,"TD Reverb cellMSDSPLoadDSPFromMemory Failed\n");
#endif
#if VOX_DSP_ENABLE_FILTER
	m_pDSPHandles[VoxDSP::k_nFilter]= cellMSDSPLoadDSPFromMemory((void*)_binary_mstream_dsp_filter_pic_start, &DSPInfo, VoxDSP::k_nFilter,CELL_MS_ALLOC_PAGE);
	VOX_ASSERT_MSG(m_pDSPHandles[VoxDSP::k_nFilter]!=-1,"Filter cellMSDSPLoadDSPFromMemory Failed\n");
#endif
#if VOX_DSP_ENABLE_PITCHSHIFT
	m_pDSPHandles[VoxDSP::k_nPitchShift]= cellMSDSPLoadDSPFromMemory((void*)_binary_mstream_dsp_pitchshift_pic_start, &DSPInfo, VoxDSP::k_nPitchShift,CELL_MS_ALLOC_PAGE);
	VOX_ASSERT_MSG(m_pDSPHandles[VoxDSP::k_nPitchShift]!=-1,"Pitch Shift cellMSDSPLoadDSPFromMemory Failed\n");	
#endif
#if VOX_DSP_ENABLE_IMPULSEREVERB
	m_pDSPHandles[VoxDSP::k_nImpulseReverb]= cellMSDSPLoadDSPFromMemory((void*)_binary_mstream_dsp_IR_pic_start, &DSPInfo, VoxDSP::k_nImpulseReverb,CELL_MS_ALLOC_PAGE);
	VOX_ASSERT_MSG(m_pDSPHandles[VoxDSP::k_nImpulseReverb]!=-1,"Impulse Reverb cellMSDSPLoadDSPFromMemory Failed\n");	
#endif	
#if VOX_DSP_ENABLE_PARAMETRIC_EQ
	m_pDSPHandles[VoxDSP::k_nParametricEQ]= cellMSDSPLoadDSPFromMemory((void*)_binary_mstream_dsp_para_eq_pic_start, &DSPInfo, VoxDSP::k_nParametricEQ,CELL_MS_ALLOC_PAGE);
	VOX_ASSERT_MSG(m_pDSPHandles[VoxDSP::k_nParametricEQ]!=-1,"Parametric EQ cellMSDSPLoadDSPFromMemory Failed\n");	
#endif	
#if VOX_DSP_ENABLE_DELAY
	m_pDSPHandles[VoxDSP::k_nDelay]= cellMSDSPLoadDSPFromMemory((void*)_binary_mstream_dsp_delay_pic_start, &DSPInfo, VoxDSP::k_nDelay,CELL_MS_ALLOC_PAGE);
	VOX_ASSERT_MSG(m_pDSPHandles[VoxDSP::k_nDelay]!=-1,"Delay cellMSDSPLoadDSPFromMemory Failed\n");
	CELLMS_ERROR(m_pDSPHandles[VoxDSP::k_nDelay]);
#endif	
#if VOX_DSP_ENABLE_DISTORTION
	m_pDSPHandles[VoxDSP::k_nDistortion]= cellMSDSPLoadDSPFromMemory((void*)_binary_mstream_dsp_distortion_pic_start, &DSPInfo, VoxDSP::k_nDistortion,CELL_MS_ALLOC_PAGE);
	VOX_ASSERT_MSG(m_pDSPHandles[VoxDSP::k_nDistortion]!=-1,"Distortion cellMSDSPLoadDSPFromMemory Failed\n");	
#endif	
}

DSP* DSPManager::CreateDSP(char* mngFile, s32 busNo, CELL_MS_DSPSLOTS dspSlot)
{
	c8* data = 0;
	DSP* dsp = 0;

	FileSystemInterface* pFS = FileSystemInterface::GetInstance();
	FileInterface* file = 0;
	if(pFS && mngFile)
		file = pFS->OpenFile(mngFile);
	
	if(file)
	{
		CellMSSection1 MNGHeader;
		file->Read((void*)&MNGHeader, sizeof(CellMSSection1), 1);
		
		if(MNGHeader.Header[0] == 'M' && MNGHeader.Header[1] == 'U' && MNGHeader.Header[2] == 'L' && MNGHeader.Header[3] == 'T')
		{
			c8 dspid[9];
			memcpy(dspid, MNGHeader.ID, 8);
			dspid[8] = 0;
#if VOX_DSP_ENABLE_TDREVERB
			if(strcmp(dspid,"TD_RVERB") == 0)
			{
				data = (c8*)VOX_ALLOC(sizeof(CellMSFXReverbParams));
				if(data)
				{
					file->Read((void*)data, sizeof(CellMSFXReverbParams), 1);
					dsp = VOX_NEW DSPTDReverb();
					if(dsp)
					{
						if(dsp->Load(data, busNo, dspSlot, GetDSPHandle(VoxDSP::k_nTDReverb)) < 0)
						{
							VOX_DELETE (dsp);
							dsp = 0;
							VOX_WARNING_LEVEL_2("Error while loading DSP from %s", mngFile);
						}
					}
					else
					{
						VOX_WARNING_LEVEL_2("Error while loading DSPTDReverb from %s, object creation failed", mngFile);
					}
					VOX_FREE(data);
				}
				else
				{
					VOX_WARNING_LEVEL_2("Error while loading DSP from %s, buffer creation failed", mngFile);
				}
			}
			else
#endif
#if VOX_DSP_ENABLE_COMPRESSOR
			if(strcmp(dspid,"FD_COMP") == 0)
			{
				data = (c8*)VOX_ALLOC(sizeof(CellMSFXCompressorInfo));
				if(data)
				{
					file->Read((void*)data, sizeof(CellMSFXCompressorInfo), 1);
					dsp = VOX_NEW DSPCompressor();
					if(dsp)
					{
						if(dsp->Load(data, busNo, dspSlot, GetDSPHandle(VoxDSP::k_nCompressor)) < 0)
						{
							VOX_DELETE (dsp);
							dsp = 0;
							VOX_WARNING_LEVEL_2("Error while loading DSP from %s", mngFile);
						}
					}
					else
					{
						VOX_WARNING_LEVEL_2("Error while loading DSPCompressor from %s, object creation failed", mngFile);
					}
					VOX_FREE(data);
				}
				else
				{
					VOX_WARNING_LEVEL_2("Error while loading DSP from %s, buffer creation failed", mngFile);
				}
			}
			else
#endif
#if VOX_DSP_ENABLE_PITCHSHIFT
			if(strcmp(dspid,"PITCH") == 0)
			{
				data = (c8*)VOX_ALLOC(sizeof(f32));
				if(data)
				{
					file->Read((void*)data, sizeof(f32), 1);
					dsp = VOX_NEW DSPPitchShift();
					if(dsp)
					{
						if(dsp->Load(data, busNo, dspSlot, GetDSPHandle(VoxDSP::k_nPitchShift)) < 0)
						{
							VOX_DELETE (dsp);
							dsp = 0;
							VOX_WARNING_LEVEL_2("Error while loading DSP from %s", mngFile);
						}
					}
					else
					{
						VOX_WARNING_LEVEL_2("Error while loading DSPPitchShift from %s, object creation failed", mngFile);
					}
					VOX_FREE(data);
				}
				else
				{
					VOX_WARNING_LEVEL_2("Error while loading DSP from %s, buffer creation failed", mngFile);
				}
			}
			else
#endif
#if VOX_DSP_ENABLE_IMPULSEREVERB
			if(strcmp(dspid,"IP_RVERB") == 0)
			{
				file->Seek(0, k_nSeekEnd);
				s32 size = file->Tell() - sizeof(CellMSSection1);
				file->Seek(sizeof(CellMSSection1), k_nSeekSet);
				data = (c8*)VOX_ALLOC(size);
				if(data)
				{
					file->Read((void*)data, size, 1);
					dsp = VOX_NEW DSPImpulseReverb();
					if(dsp)
					{
						if(dsp->Load(data, busNo, dspSlot, GetDSPHandle(VoxDSP::k_nImpulseReverb)) < 0)
						{
							VOX_DELETE (dsp);
							dsp = 0;
							VOX_WARNING_LEVEL_2("Error while loading DSP from %s", mngFile);
						}
					}
					else
					{
						VOX_WARNING_LEVEL_2("Error while loading DSPImpulseReverb from %s, object creation failed", mngFile);
					}
					VOX_FREE(data);
				}
				else
				{
					VOX_WARNING_LEVEL_2("Error while loading DSP from %s, buffer creation failed", mngFile);
				}
			}
			else
#endif
#if VOX_DSP_ENABLE_PARAMETRIC_EQ
			if(strcmp(dspid,"PARA_EQ") == 0)
			{
				file->Seek(0, k_nSeekEnd);
				s32 size = file->Tell() - sizeof(CellMSSection1);
				file->Seek(sizeof(CellMSSection1), k_nSeekSet);
				data = (c8*)VOX_ALLOC(size);
				if(data)
				{
					file->Read((void*)data, size, 1);
					dsp = VOX_NEW DSPParametricEQ();
					if(dsp)
					{
						if(dsp->Load(data, busNo, dspSlot, GetDSPHandle(VoxDSP::k_nParametricEQ)) < 0)
						{
							VOX_DELETE (dsp);
							dsp = 0;
							VOX_WARNING_LEVEL_2("Error while loading DSP from %s", mngFile);
						}
					}
					else
					{
						VOX_WARNING_LEVEL_2("Error while loading DSPParametricEQ from %s, object creation failed", mngFile);
					}
					VOX_FREE(data);
				}
				else
				{
					VOX_WARNING_LEVEL_2("Error while loading DSP from %s, buffer creation failed", mngFile);
				}
			}
			else
#endif	
#if VOX_DSP_ENABLE_FILTER
			if(strcmp(dspid,"FILT") == 0)
			{
				file->Seek(0, k_nSeekEnd);
				s32 size = file->Tell() - sizeof(CellMSSection1);
				file->Seek(sizeof(CellMSSection1), k_nSeekSet);
				data = (c8*)VOX_ALLOC(size);
				if(data)
				{
					file->Read((void*)data, size, 1);
					dsp = VOX_NEW DSPFilter();
					if(dsp)
					{
						if(dsp->Load(data, busNo, dspSlot, GetDSPHandle(VoxDSP::k_nFilter)) < 0)
						{
							VOX_DELETE (dsp);
							dsp = 0;
							VOX_WARNING_LEVEL_2("Error while loading DSP from %s", mngFile);
						}
					}
					else
					{
						VOX_WARNING_LEVEL_2("Error while loading DSPFilter from %s, object creation failed", mngFile);
					}
					VOX_FREE(data);
				}
				else
				{
					VOX_WARNING_LEVEL_2("Error while loading DSP from %s, buffer creation failed", mngFile);
				}
			}
			else
#endif	
#if VOX_DSP_ENABLE_DELAY
			if(strcmp(dspid,"TD_DELAY") == 0)
			{
				file->Seek(0, k_nSeekEnd);
				s32 size = file->Tell() - sizeof(CellMSSection1);
				data = (c8*)VOX_ALLOC(size);
				file->Seek(sizeof(CellMSSection1), k_nSeekSet);
				if(data)
				{
					file->Read((void*)data, size, 1);
					dsp = VOX_NEW DSPDelay();
					if(dsp)
					{
						if(dsp->Load(data, busNo, dspSlot, GetDSPHandle(VoxDSP::k_nDelay)) < 0)
						{
							VOX_DELETE (dsp);
							dsp = 0;
							VOX_WARNING_LEVEL_2("Error while loading DSP from %s", mngFile);
						}
					}
					else
					{
						VOX_WARNING_LEVEL_2("Error while loading DSPDelay from %s, object creation failed", mngFile);
					}
					VOX_FREE(data);
				}
				else
				{
					VOX_WARNING_LEVEL_2("Error while loading DSP from %s, buffer creation failed", mngFile);
				}
			}
			else
#endif	
#if VOX_DSP_ENABLE_DISTORTION
			if(strcmp(dspid,"PDST") == 0)
			{
				file->Seek(0, k_nSeekEnd);
				s32 size = file->Tell() - sizeof(CellMSSection1);
				data = (c8*)VOX_ALLOC(size);
				file->Seek(sizeof(CellMSSection1), k_nSeekSet);
				if(data)
				{
					file->Read((void*)data, size, 1);
					dsp = VOX_NEW DSPDistortion();
					if(dsp)
					{
						if(dsp->Load(data, busNo, dspSlot, GetDSPHandle(VoxDSP::k_nDistortion)) < 0)
						{
							VOX_DELETE (dsp);
							dsp = 0;
							VOX_WARNING_LEVEL_2("Error while loading DSP from %s", mngFile);
						}
					}
					else
					{
						VOX_WARNING_LEVEL_2("Error while loading DSPDistortion from %s, object creation failed", mngFile);
					}
					VOX_FREE(data);
				}
				else
				{
					VOX_WARNING_LEVEL_2("Error while loading DSP from %s, buffer creation failed", mngFile);
				}
			}
			else
#endif
			{
				VOX_WARNING_LEVEL_2("Could not load dsp from %s, %s is not supported by driver", mngFile, MNGHeader.ID);
			}
		}
		else
		{
			VOX_WARNING_LEVEL_2("%s is not a valid dsp definition file", mngFile);
		}

		pFS->CloseFile(file);
	}
	else
	{
		VOX_WARNING_LEVEL_2("Could not open dsp definition file %s", mngFile);
	}

	return dsp;
}

DSP* DSPManager::CreateSideChainDSP(char* mngFile)
{
	c8* data = 0;
	DSP* dsp = 0;

	FileSystemInterface* pFS = FileSystemInterface::GetInstance();
	FileInterface* file = 0;
	if(pFS && mngFile)
		file = pFS->OpenFile(mngFile);
	
	if(file)
	{
		CellMSSection1 MNGHeader;
		file->Read((void*)&MNGHeader, sizeof(CellMSSection1), 1);
		
		if(MNGHeader.Header[0] == 'M' && MNGHeader.Header[1] == 'U' && MNGHeader.Header[2] == 'L' && MNGHeader.Header[3] == 'T')
		{
			char dspid[9];
			memcpy(dspid, MNGHeader.ID, 8);
			dspid[8] = 0;
#if VOX_DSP_ENABLE_COMPRESSOR
			if(strcmp(dspid,"FD_COMP") == 0)
			{
				data = (c8*)VOX_ALLOC(sizeof(CellMSFXCompressorInfo));
				if(data)
				{
					file->Read((void*)data, sizeof(CellMSFXCompressorInfo), 1);
					dsp = VOX_NEW DSPSCCompressor();
					if(dsp)
					{
						if(dsp->Load(data, BUS_COMP_APPLY, CELL_MS_DSP_SLOT_0, GetDSPHandle(VoxDSP::k_nCompressor)) < 0)
						{
							VOX_DELETE (dsp);
							dsp = 0;
							VOX_WARNING_LEVEL_2("Error while loading DSP from %s", mngFile);
						}
					}
					else
					{
						VOX_WARNING_LEVEL_2("Error while loading DSPSCCompressor from %s, object creation failed", mngFile);
					}
					VOX_FREE(data);
				}
				else
				{
					VOX_WARNING_LEVEL_2("Error while loading DSP from %s, buffer creation failed", mngFile);
				}
			}
			else
#endif
			{
				VOX_WARNING_LEVEL_2("Could not load dsp from %s, %s is not supported by driver", mngFile, MNGHeader.ID);
			}
		}
		else
		{
			VOX_WARNING_LEVEL_2("%s is not a valid dsp definition file", mngFile);
		}

		pFS->CloseFile(file);
	}
	else
	{
		VOX_WARNING_LEVEL_2("Could not open dsp definition file %s", mngFile);
	}

	return dsp;
}

DSP* DSPManager::CreateFilterLFE()
{
	DSP* dsp = 0;

#if VOX_DSP_ENABLE_PARAMETRIC_EQ
	dsp = VOX_NEW DSPFilterLFE();
	if(dsp)
	{
		if(dsp->Load(0, BUS_FILTER_LFE, CELL_MS_DSP_SLOT_0, GetDSPHandle(VoxDSP::k_nParametricEQ)) < 0)
		{
			VOX_DELETE (dsp);
			dsp = 0;
			VOX_WARNING_LEVEL_2("Error while loading Filter LFE", 0);
		}
	}
	else
	{
		VOX_WARNING_LEVEL_2("Error creating Filter LFE, object creation failed", 0);
	}
#endif

	return dsp;
}

s32	 DSPManager::GetDSPHandle(VoxDSP::DSPID dspId)
{
	if(m_pDSPHandles && dspId < VoxDSP::k_nDSPMax)
		return m_pDSPHandles[dspId];

	return -1;
}

}

/* DSP */
namespace vox
{
DSP::DSP()
:m_busNo(-1)
,m_dspSlot(CELL_MS_DSP_SLOT_0)
{
}

void DSP::SetDSPSlotRoute()
{
	// Standard routing for 5.0 dsp

	// setup active channels to process in the DSP
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 0, 1 );
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 0, 1 );
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 1, 2 );
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 1, 2 );
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 2, 4 );
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 2, 4 );
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 3, 16 );
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 3, 16 );
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 4, 32 );
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 4, 32 );

	// switch inactive channels to bypass the DSP
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 5, 0);
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 5, 0);
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 6, 0);
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 6, 0);
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 7, 0);
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 7, 0);
}
}

/* DSPTDReverb */
#if VOX_DSP_ENABLE_TDREVERB
namespace vox
{
DSPTDReverb::DSPTDReverb()
:m_pReverbBuffer(0)
{
}

DSPTDReverb::~DSPTDReverb()
{
	Unload();
}

s32 DSPTDReverb::Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle)
{
	s32 result = -1;
	s32 nbRev = 4;

	if(m_busNo != -1)
		Unload();

	if(dspHandle != -1)
	{
		m_busNo = busNo;
		m_dspSlot = dspSlot;
		cellMSCoreSetDSP( m_busNo, m_dspSlot, dspHandle);
		void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );

		//Get size required for 1 active reverb for a required slot.
		s32 size = cellMSFXReverbGetNeededMemorySize(nbRev);

		m_pReverbBuffer = VOX_ALLOC_ALIGN(size, k_nVoxMemHint_Align128);
		VOX_ASSERT_MSG(m_pReverbBuffer, "Failed to allocate time domain reverberation buffer");

		VOX_WARNING_LEVEL_5("Allocated TDReverb buffer size: %d to address 0x%x\n",size,(int)m_pReverbBuffer);

		memcpy(&m_params, mngData, sizeof(CellMSFXReverbParams));

		result = cellMSFXReverbInit(pParamAddr, m_pReverbBuffer, &m_params, nbRev );
		VOX_ASSERT_MSG(result != -1, "Init TDReverb return failed\n");

		SetDSPSlotRoute();
		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_NOTBYPASSED );
	}

	return result;
}

void DSPTDReverb::Unload()
{
	if(m_busNo != -1)
	{
		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_BYPASSED );
		cellMSCoreSetDSP( m_busNo, m_dspSlot, CELL_MS_DSPOFF);
		m_busNo = -1;
	}

	if(m_pReverbBuffer)
	{
		VoxFree(m_pReverbBuffer);
		m_pReverbBuffer = 0;
	}
}

void DSPTDReverb::SetParameter(s32 paramId, void* param)
{

}

void DSPTDReverb::SetDSPSlotRoute()
{
	// Reverb sums all channel then process the reverberation and redistribute on all channel
	// Bus output needs to take this in consideration

	//// setup active channels to process in the DSP
	//cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 0, 1+2+4+16+32 );
	//cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 0, 1+2+4+16+32 );

	//// switch inactive channels to bypass the DSP
	//cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 1, 0 );
	//cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 1, 0 );
	//cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 2, 0 );
	//cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 2, 0 );
	//cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 3, 0 );
	//cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 3, 0 );
	//cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 4, 0 );
	//cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 4, 0 );
	//cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 5, 0);
	//cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 5, 0);
	//cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 6, 0);
	//cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 6, 0);
	//cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 7, 0);
	//cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 7, 0);
		// setup active channels to process in the DSP
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 0, 1 );
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 0, 1 );

	// switch inactive channels to bypass the DSP
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 1, 2 );
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 1, 2 );
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 2, 16 );
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 2, 16 );
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 3, 32 );
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 3, 32 );
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 4, 0 );
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 4, 0 );
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 5, 0);
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 5, 0);
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 6, 0);
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 6, 0);
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 7, 0);
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 7, 0);
}
}
#endif

/* DSPCompressor */
#if VOX_DSP_ENABLE_COMPRESSOR
namespace vox
{
DSPCompressor::~DSPCompressor()
{
	Unload();
}

s32 DSPCompressor::Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle)
{
	s32 result = -1;

	if(m_busNo != -1)
		Unload();

	if(dspHandle != -1)
	{
		m_busNo = busNo;
		m_dspSlot = dspSlot;
		cellMSCoreSetDSP( m_busNo, m_dspSlot, dspHandle);
		void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );

		memcpy(&m_params, mngData, sizeof(CellMSFXCompressorInfo));

		result = cellMSFXCompressorInitApply(pParamAddr, &m_params);
		VOX_ASSERT_MSG(result != -1, "Init Reverb return failed\n");

		SetDSPSlotRoute();
		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_NOTBYPASSED );
	}

	return result;
}

void DSPCompressor::Unload()
{
	if(m_busNo != -1)
	{
		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_BYPASSED );
		cellMSCoreSetDSP( m_busNo, m_dspSlot, CELL_MS_DSPOFF);
		m_busNo = -1;
	}
}

void DSPCompressor::SetParameter(s32 paramId, void* param)
{

}
}
#endif

/* DSPSCCompressor */
#if VOX_DSP_ENABLE_COMPRESSOR
namespace vox
{
s32 DSPSCCompressor::Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle)
{
	s32 result = -1;

	if(m_busNo != -1)
		Unload();

	if(dspHandle != -1)
	{
		memcpy(&m_params, mngData, sizeof(CellMSFXCompressorInfo));

		//Set Apply compressor
		m_busNo = BUS_COMP_APPLY;
		m_dspSlot = CELL_MS_DSP_SLOT_0;
		
		cellMSCoreSetDSP( m_busNo, m_dspSlot, dspHandle);
		void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );

		result = cellMSFXCompressorInitApply(pParamAddr, &m_params);
		VOX_ASSERT_MSG(result != -1, "Init Reverb return failed\n");

		SetDSPSlotRoute();

		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_NOTBYPASSED );

		//Set Calc compressor
		m_busNo = BUS_COMP_CALC;
		m_dspSlot = CELL_MS_DSP_SLOT_0;
		
		cellMSCoreSetDSP( m_busNo, m_dspSlot, result);
		pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );

		result = cellMSFXCompressorInitCalc(pParamAddr, &m_params);
		VOX_ASSERT_MSG(result != -1, "Init Reverb return failed\n");

		SetDSPSlotRoute();

		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_NOTBYPASSED );
	}

	return result;
}

void DSPSCCompressor::Unload()
{
	if(m_busNo != -1)
	{
		cellMSCoreBypassDSP( BUS_COMP_APPLY, CELL_MS_DSP_SLOT_0, CELL_MS_BYPASSED );
		cellMSCoreSetDSP( BUS_COMP_APPLY, CELL_MS_DSP_SLOT_0, CELL_MS_DSPOFF);
		cellMSCoreBypassDSP( BUS_COMP_CALC, CELL_MS_DSP_SLOT_0, CELL_MS_BYPASSED );
		cellMSCoreSetDSP( BUS_COMP_CALC, CELL_MS_DSP_SLOT_0, CELL_MS_DSPOFF);
		m_busNo = -1;
	}
}

void DSPSCCompressor::SetParameter(s32 paramId, void* param)
{

}
}
#endif

/* DSPPitchShift */
#if VOX_DSP_ENABLE_PITCHSHIFT
namespace vox
{
DSPPitchShift::DSPPitchShift()
:m_pPitchShiftBuffer(0)
{
}

DSPPitchShift::~DSPPitchShift()
{
	Unload();
}

s32 DSPPitchShift::Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle)
{
	s32 result = -1;

	if(m_busNo != -1)
		Unload();

	if(dspHandle != -1)
	{
		m_busNo = busNo;
		m_dspSlot = dspSlot;
		cellMSCoreSetDSP( m_busNo, m_dspSlot, dspHandle);
		void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );

		//Get size required for 5 active pitch shift for a required slot.
		s32 size = cellMSFXPitchShiftGetNeededMemorySize(5);

		m_pPitchShiftBuffer = VOX_ALLOC_ALIGN(size, k_nVoxMemHint_Align128);
		VOX_ASSERT_MSG(m_pPitchShiftBuffer, "Failed to allocate pitch shift buffer");

		VOX_WARNING_LEVEL_5("Allocated pitch shift buffer size: %d to address 0x%x\n",size,(int)m_pPitchShiftBuffer);

		memcpy(&m_params, mngData, sizeof(f32));

		result = cellMSFXPitchShiftInit( pParamAddr, m_pPitchShiftBuffer, m_params, 5);
		VOX_ASSERT_MSG(result != -1, "Init Pitch Shift return failed\n");

		SetDSPSlotRoute();
		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_NOTBYPASSED );
	}

	return result;
}

void DSPPitchShift::Unload()
{
	if(m_busNo != -1)
	{
		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_BYPASSED );
		cellMSCoreSetDSP( m_busNo, m_dspSlot, CELL_MS_DSPOFF);
		m_busNo = -1;
	}

	if(m_pPitchShiftBuffer)
	{
		VoxFree(m_pPitchShiftBuffer);
		m_pPitchShiftBuffer = 0;
	}
}

void DSPPitchShift::SetParameter(s32 paramId, void* param)
{

}
}
#endif

/* DSPImpulseReverb */
#if VOX_DSP_ENABLE_IMPULSEREVERB
namespace vox
{
DSPImpulseReverb::DSPImpulseReverb()
:m_impulseFFTInfo(0)
{
	for(int i = 0; i < 8; i++)
	{
		m_impulseArray[i] = 0;
	}
}

DSPImpulseReverb::~DSPImpulseReverb()
{
	Unload();
}

s32 DSPImpulseReverb::Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle)
{
	s32 result = -1;

	if(m_busNo != -1)
		Unload();

	if(dspHandle != -1)
	{
		m_busNo = busNo;
		m_dspSlot = dspSlot;

		memcpy(&m_impulseInfo, mngData, sizeof(CellImpulseInfo));

		//Only support single impulse at the moment
		if(m_impulseInfo.Channel == 1/* && m_impulseInfo.Interleaved == 0*/)
		{
			s32 size = cellMSFXIRDSPImpulseGetNeededMemorySize(m_impulseInfo.Sample << 1);
			VOX_WARNING_LEVEL_5("allocating 0x%x bytes for impulse FFT data\n",size);

			m_impulseArray[0] = VOX_ALLOC_ALIGN(size, k_nVoxMemHint_Align128);
			VOX_ASSERT_MSG(m_impulseArray[0], "Fail to get fft memblock");
			VOX_WARNING_LEVEL_5("allocated at addr: 0x%x\n",(int)m_impulseArray[0]);
			cellMSFXIRDSPCreateImpulse(m_impulseArray[0], m_impulseInfo.Sample << 1, (char *)mngData + sizeof(CellImpulseInfo), CELL_MS_16BIT_BIG);
			VOX_WARNING_LEVEL_5("FFT Impulse data created\n",0);
			m_impulseArray[3] = m_impulseArray[2] = m_impulseArray[1] = m_impulseArray[0];

			//size = cellMSFXIRDSPInfoGetNeededMemorySize(4, m_impulseArray);
			size = cellMSFXIRDSPInfoGetNeededMemorySize(1, m_impulseArray);
			m_impulseFFTInfo = VOX_ALLOC_ALIGN(size, k_nVoxMemHint_Align128);
			VOX_ASSERT_MSG(m_impulseFFTInfo, "Failed to allocate impulse FFT buffer");
			VOX_WARNING_LEVEL_5("allocated 0x%x at addr: 0x%x for impulse info buffer\n",size,(int)m_impulseFFTInfo);

			// Note that the info stored in impulseInfoAddr can now be used for multiple streams / busses if required
			// You do not need to create Info for each occurance (unless you require different impulse information)

			//result = cellMSFXIRDSPInitInfo(m_impulseFFTInfo, 4, m_impulseArray);
			result = cellMSFXIRDSPInitInfo(m_impulseFFTInfo, 1, m_impulseArray);
			VOX_ASSERT_MSG(m_impulseArray[0], "cellMSFXIRDSPInitInfo failed");

			// Now we can attach the Impulse DSP to the sub bus as usual...

			cellMSCoreBypassDSP( busNo, dspSlot , CELL_MS_BYPASSED );

			cellMSCoreSetDSP( busNo, dspSlot, dspHandle);
			void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( busNo, dspSlot );
			
			result = cellMSFXIRDSPInit(pParamAddr, m_impulseFFTInfo);

			VOX_ASSERT_MSG(result != -1, "Init Reverb return failed\n");

			SetDSPSlotRoute();
			cellMSCoreBypassDSP( busNo, dspSlot, CELL_MS_NOTBYPASSED );
		}
	}

	return result;
}

void DSPImpulseReverb::Unload()
{
	if(m_busNo != -1)
	{
		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_BYPASSED );
		cellMSCoreSetDSP( m_busNo, m_dspSlot, CELL_MS_DSPOFF);
		m_busNo = -1;
	}

	if(m_impulseFFTInfo)
	{
		VoxFree(m_impulseFFTInfo);
		m_impulseFFTInfo= 0;
	}

	//for(int i = 0; i < 8; i++)
	//{
	//	if(m_impulseArray[i])
	//	{
	//		VoxFree(m_impulseArray[i]);
	//		m_impulseArray[i]= 0;
	//	}
	//}
	if(m_impulseArray[0])
	{
		VoxFree(m_impulseArray[0]);
		m_impulseArray[0]= 0;
	}
}

void DSPImpulseReverb::SetParameter(s32 paramId, void* param)
{

}

void DSPImpulseReverb::SetDSPSlotRoute()
{
	// Reverb sums all channel then process the reverberation and redistribute on all channel
	// Bus output needs to take this in consideration

	// setup active channels to process in the DSP
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 0, 1+2+16+32 );
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 0, 1+2+16+32 );

	// switch inactive channels to bypass the DSP
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 1, 0 );
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 1, 0 );
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 2, 0 );
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 2, 0 );
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 3, 0 );
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 3, 0 );
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 4, 0 );
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 4, 0 );
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 5, 0);
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 5, 0);
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 6, 0);
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 6, 0);
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 7, 0);
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 7, 0);
}
}
#endif

/* DSPParametricEQ */
#if VOX_DSP_ENABLE_PARAMETRIC_EQ
namespace vox
{
DSPParametricEQ::DSPParametricEQ()
:m_pParaEqMemBlock(0)
{
}

DSPParametricEQ::~DSPParametricEQ()
{
	Unload();
}

s32 DSPParametricEQ::Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle)
{
	s32 result = -1;

	if(m_busNo != -1)
		Unload();

	if(dspHandle != -1)
	{
		m_busNo = busNo;
		m_dspSlot = dspSlot;
		cellMSCoreSetDSP( m_busNo, m_dspSlot, dspHandle);
		void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );

		//Get size required for 5 active parametric EQ for a required slot.
		s32 size = cellMSFXParaEQGetNeededMemorySize(5);

		m_pParaEqMemBlock = VOX_ALLOC_ALIGN(size, k_nVoxMemHint_Align128);
		VOX_ASSERT_MSG(m_pParaEqMemBlock, "Failed to allocate parametric eq buffer");

		VOX_WARNING_LEVEL_5("Allocated parametric EQ buffer size: %d to address 0x%x\n",size,(int)m_pParaEqMemBlock);

		memcpy(&m_ParaEqParams, mngData, sizeof(CellMSFXParaEQ));
		result = cellMSFXParaEQInit( pParamAddr, m_pParaEqMemBlock, &m_ParaEqParams, 5);
		VOX_ASSERT_MSG(result != -1, "Init Parametric EQ return failed\n");

		SetDSPSlotRoute();
		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_NOTBYPASSED );
	}

	return result;
}

void DSPParametricEQ::Unload()
{
	if(m_busNo != -1)
	{
		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_BYPASSED );
		cellMSCoreSetDSP( m_busNo, m_dspSlot, CELL_MS_DSPOFF);
		m_busNo = -1;
	}

	if(m_pParaEqMemBlock)
	{
		VoxFree(m_pParaEqMemBlock);
		m_pParaEqMemBlock = 0;
	}
}

void DSPParametricEQ::SetParameter(s32 paramId, void* param)
{
	//TODO
	//switch(paramId)
	//{
	//	case 0: //all param
	//	{
	//		m_ParaEqParams = *((CellMSFXParaEQ*)param);
	//		void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );
	//		if(pParamAddr)
	//		{
	//			cellMSFXParaEQSet(pParamAddr, &m_ParaEqParams, 0);
	//		}
	//		break;
	//	}
	//	case 1: // filter 1
	//	{
	//		m_ParaEqParams.Filters[0] = *((CellMSFXFilter*)param);
	//		void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );
	//		if(pParamAddr)
	//		{
	//			cellMSFXParaEQSet(pParamAddr, &m_ParaEqParams, 0);
	//		}
	//		break;
	//	}
	//	case 2: // filter 2
	//	{
	//		m_ParaEqParams.Filters[1] = *((CellMSFXFilter*)param);
	//		void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );
	//		if(pParamAddr)
	//		{
	//			cellMSFXParaEQSet(pParamAddr, &m_ParaEqParams, 0);
	//		}
	//		break;
	//	}
	//	case 3: // filter 3
	//	{
	//		m_ParaEqParams.Filters[2] = *((CellMSFXFilter*)param);
	//		void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );
	//		if(pParamAddr)
	//		{
	//			cellMSFXParaEQSet(pParamAddr, &m_ParaEqParams, 0);
	//		}
	//		break;
	//	}
	//	case 4: // filter 4
	//	{
	//		m_ParaEqParams.Filters[3] = *((CellMSFXFilter*)param);
	//		void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );
	//		if(pParamAddr)
	//		{
	//			cellMSFXParaEQSet(pParamAddr, &m_ParaEqParams, 0);
	//		}
	//		break;
	//	}
	//}
}
}
#endif

/* DSPOcclusion */
#if VOX_DSP_ENABLE_OCCLUSION
namespace vox
{
DSPOcclusion::DSPOcclusion()
:m_pFilterMemBlock(0)
,m_currentMaterial(VoxDSPEmitterParameter::k_nNone)
,m_cutoffFrequency(5000.0f)
{
}

DSPOcclusion::~DSPOcclusion()
{
	Unload();
}

s32 DSPOcclusion::Load(s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle)
{
	s32 result = -1;

	if(m_busNo != -1)
		Unload();

	if(dspHandle != -1)
	{
		m_busNo = busNo;
		m_dspSlot = dspSlot;
		cellMSCoreSetDSP( m_busNo, m_dspSlot, dspHandle);
		void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );

		//Get size required for 5 active filters for a required slot.
		// TODO : See if 5 is really required or only 1 should be used
		s32 size = cellMSFXFilterGetNeededMemorySize(5);

		m_pFilterMemBlock = VOX_ALLOC_ALIGN(size, k_nVoxMemHint_Align128);
		VOX_ASSERT_MSG(m_pFilterMemBlock, "Failed to allocate filter buffer");

		VOX_WARNING_LEVEL_5("Allocated occlusion buffer size: %d to address 0x%x\n",size,(int)m_pFilterMemBlock);

		// High-shelf settings
		m_filterParams.fFrequency = 5000.0f;
		m_filterParams.fGain = -8.0f;
		m_filterParams.FilterMode = CELL_MSFX_FILTERMODE_HIGHSHELF;

		result = cellMSFXFilterInit( pParamAddr, m_pFilterMemBlock, &m_filterParams);
		VOX_ASSERT_MSG(result != -1, "Init occlusion return failed\n");

		// TODO : Verify if dspmask should be used or SetDSPSlotRoute (also should SetDSPSlotRoute
		// be redefined for this class.
		//SetDSPSlotRoute();
		const char dspmask[] = {1, 0, 0, 0, 0, 0, 0, 0};
		cellMSCoreSetMasks( m_busNo, CELL_MS_INMASK,  m_dspSlot, dspmask );
		cellMSCoreSetMasks( m_busNo, CELL_MS_OUTMASK,  m_dspSlot, dspmask );
		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_NOTBYPASSED );
	}

	return result;
}

void DSPOcclusion::SetDistanceAttenuation(f32 attenuation)
{
	if(m_attDistance != attenuation)
	{
		m_attDistance = attenuation;
		attenuation = attenuation < 0.3f ? 0.0f : (attenuation - 0.3f) / 0.7f;//**-** max occlusion on last 30%
		m_cutoffFrequency = 5000.0f * (1.0f - attenuation) + 24000.0f * attenuation;
		m_filterParams.fFrequency = m_cutoffFrequency;

		void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );
		s32 result = cellMSFXFilterSet( pParamAddr, &m_filterParams, -1);
		VOX_ASSERT_MSG(result != -1, "Occlusion update failed\n");
	}
}


void DSPOcclusion::Unload()
{
	if(m_busNo != -1)
	{
		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_BYPASSED );
		cellMSCoreSetDSP( m_busNo, m_dspSlot, CELL_MS_DSPOFF);
		m_busNo = -1;
	}

	if(m_pFilterMemBlock)
	{
		VoxFree(m_pFilterMemBlock);
		m_pFilterMemBlock = 0;
	}
}

void DSPOcclusion::SetParameter(s32 paramId, void* param)
{
	void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );
	if(!pParamAddr)
		return;

	switch(paramId)
	{
		case 0:
		{
			f32* value = (f32*)param;
			if(m_filterParams.fFrequency != *value)
			{
				m_filterParams.fFrequency = *value;
				s32 ret = cellMSFXFilterSet( pParamAddr, &m_filterParams, 0);
				CELLMS_ERROR(ret);
			}
			break;
		}
		default:
		{
			break;
		}
	}
}

//f32 materialPreset[7][2] = 
//{ //attLF, attHF
	//{0.f,0.f}, //none 
	//{-12.f, -6.f},//thin door
	//{-28.16f, -15.84f},//thick door
	//{-20.f, -20.f},//wood wall
	//{-30.f, -20.f},//brick wall
	//{-40.8f,-19.2f},//stone wall
	//{-1.8f, -10.2f}//curtain
//};

void DSPOcclusion::SetMaterialPreset(VoxDSPEmitterParameter::OcclusionMaterialPreset preset, f32 fadeTime)
{
	//if(preset == m_currentMaterial)
	//	return; //don't set the same material twice

//	if(preset < VoxDSPEmitterParameter::k_nNone || preset > VoxDSPEmitterParameter::k_nCurtain)
//		return; //not a valid preset

//	m_currentMaterial = preset;
//	m_attLF = Fader(m_attLF.GetCurrentValue(), materialPreset[m_currentMaterial][0], fadeTime);
//	m_attHF = Fader(m_attHF.GetCurrentValue(), materialPreset[m_currentMaterial][1], fadeTime);

//	if(m_currentMaterial != VoxDSPEmitterParameter::k_nNone)
//	{
//		m_ParaEqParams.Filters[0].FilterMode = CELL_MSFX_FILTERMODE_LOWSHELF;
//		m_ParaEqParams.Filters[1].FilterMode = CELL_MSFX_FILTERMODE_HIGHSHELF;
//		m_ParaEqParams.Filters[2].FilterMode = CELL_MSFX_FILTERMODE_HIGHSHELF;
//	}
}

void DSPOcclusion::Update(f32 dt)
{

}

}
#endif


/* DSPFilterLFE */
#if VOX_DSP_ENABLE_PARAMETRIC_EQ
namespace vox
{
DSPFilterLFE::DSPFilterLFE()
:m_pParaEqMemBlock(0)
{
}

DSPFilterLFE::~DSPFilterLFE()
{
	Unload();
}

s32 DSPFilterLFE::Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle)
{
	s32 result = -1;

	if(m_busNo != -1)
		Unload();

	if(dspHandle != -1)
	{
		m_busNo = busNo;
		m_dspSlot = dspSlot;
		cellMSCoreSetDSP( m_busNo, m_dspSlot, dspHandle);
		void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );

		//Get size required for 5 active parametric EQ (used as filter LFE) for a required slot.
		s32 size = cellMSFXParaEQGetNeededMemorySize(6);

		m_pParaEqMemBlock = VOX_ALLOC_ALIGN(size, k_nVoxMemHint_Align128);
		VOX_ASSERT_MSG(m_pParaEqMemBlock, "Failed to allocate filter LFE buffer");

		VOX_WARNING_LEVEL_5("Allocated filter LFE buffer size: %d to address 0x%x\n",size,(int)m_pParaEqMemBlock);

		m_ParaEqParams.Filters[0].FilterMode = CELL_MSFX_FILTERMODE_OFF;
		m_ParaEqParams.Filters[1].FilterMode = CELL_MSFX_FILTERMODE_OFF;
		m_ParaEqParams.Filters[2].FilterMode = CELL_MSFX_FILTERMODE_OFF;
		m_ParaEqParams.Filters[3].FilterMode = CELL_MSFX_FILTERMODE_OFF;

		result = cellMSFXParaEQInit( pParamAddr, m_pParaEqMemBlock, &m_ParaEqParams, 6);
		VOX_ASSERT_MSG(result != -1, "Init filter LFE return failed\n");

		result = cellMSFXParaEQSetLFE(pParamAddr, 5, CELL_MSFX_FILTERMODE_LFE_8_POLE);

		SetDSPSlotRoute();
		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_NOTBYPASSED );
	}

	return result;
}

void DSPFilterLFE::Unload()
{
	if(m_busNo != -1)
	{
		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_BYPASSED );
		cellMSCoreSetDSP( m_busNo, m_dspSlot, CELL_MS_DSPOFF);
		m_busNo = -1;
	}

	if(m_pParaEqMemBlock)
	{
		VoxFree(m_pParaEqMemBlock);
		m_pParaEqMemBlock = 0;
	}
}

void DSPFilterLFE::SetParameter(s32 paramId, void* param)
{

}

void DSPFilterLFE::SetDSPSlotRoute()
{
	// Standard routing for 5.1 dsp

	// setup active channels to process in the DSP
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 0, 1 );
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 0, 1 );
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 1, 2 );
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 1, 2 );
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 2, 4 );
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 2, 4 );
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 3, 16 );
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 3, 16 );
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 4, 32 );
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 4, 32 );

	// Setup LFE STAGE
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 5, 8);
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 5, 8);

	// switch inactive channels to bypass the DSP
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 6, 0);
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 6, 0);
	cellMSCoreSetMask( m_busNo, CELL_MS_INMASK,  m_dspSlot, 7, 0);
	cellMSCoreSetMask( m_busNo, CELL_MS_OUTMASK, m_dspSlot, 7, 0);
}
}
#endif

/* DSPFilter */
#if VOX_DSP_ENABLE_FILTER
namespace vox
{
DSPFilter::DSPFilter()
:m_pFilterMemBlock(0)
{
}

DSPFilter::~DSPFilter()
{
	Unload();
}

s32 DSPFilter::Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle)
{
	s32 result = -1;

	if(m_busNo != -1)
		Unload();

	if(dspHandle != -1)
	{
		m_busNo = busNo;
		m_dspSlot = dspSlot;
		cellMSCoreSetDSP( m_busNo, m_dspSlot, dspHandle);
		void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );

		//Get size required for 5 active filters for a required slot.
		s32 size = cellMSFXFilterGetNeededMemorySize(5);

		m_pFilterMemBlock = VOX_ALLOC_ALIGN(size, k_nVoxMemHint_Align128);
		VOX_ASSERT_MSG(m_pFilterMemBlock, "Failed to allocate filter buffer");

		VOX_WARNING_LEVEL_5("Allocated filter buffer size: %d to address 0x%x\n",size,(int)m_pFilterMemBlock);

		memcpy(&m_filterParams, mngData, sizeof(CellMSFXFilter));
		result = cellMSFXFilterInit( pParamAddr, m_pFilterMemBlock, &m_filterParams);
		VOX_ASSERT_MSG(result != -1, "Init filter return failed\n");

		SetDSPSlotRoute();
		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_NOTBYPASSED );
	}

	return result;
}

s32 DSPFilter::Load(s32 streamNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle)
{
	s32 result = -1;

	if(m_busNo != -1)
		Unload();

	if(dspHandle != -1)
	{
		m_busNo = streamNo;
		m_dspSlot = dspSlot;
		cellMSCoreSetDSP( m_busNo, m_dspSlot, dspHandle);
		void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );

		//Get size required for 5 active filters for a required slot.
		s32 size = cellMSFXFilterGetNeededMemorySize(5);

		m_pFilterMemBlock = VOX_ALLOC_ALIGN(size, k_nVoxMemHint_Align128);
		VOX_ASSERT_MSG(m_pFilterMemBlock, "Failed to allocate filter buffer");

		VOX_WARNING_LEVEL_5("Allocated filter buffer size: %d to address 0x%x\n",size,(int)m_pFilterMemBlock);

		//memcpy(&m_filterParams, mngData, sizeof(CellMSFXFilter));
		m_filterParams.fFrequency = 24000.f;
		m_filterParams.fGain = 1.0f;
		m_filterParams.fResonance = 1.0f;
		m_filterParams.FilterMode = CELL_MSFX_FILTERMODE_LOWPASS_RESONANT;//CELL_MSFX_FILTERMODE_LOWPASS_ONEPOLE;
		result = cellMSFXFilterInit( pParamAddr, m_pFilterMemBlock, &m_filterParams);
		VOX_ASSERT_MSG(result != -1, "Init Filter return failed\n");

		//SetDSPSlotRoute();
		const char dspmask[] = {1, 0, 0, 0, 0, 0, 0, 0};
		cellMSCoreSetMasks( m_busNo, CELL_MS_INMASK,  m_dspSlot, dspmask );
		cellMSCoreSetMasks( m_busNo, CELL_MS_OUTMASK,  m_dspSlot, dspmask );
		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_NOTBYPASSED );
	}

	return result;
}

void DSPFilter::Unload()
{
	if(m_busNo != -1)
	{
		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_BYPASSED );
		cellMSCoreSetDSP( m_busNo, m_dspSlot, CELL_MS_DSPOFF);
		m_busNo = -1;
	}

	if(m_pFilterMemBlock)
	{
		VoxFree(m_pFilterMemBlock);
		m_pFilterMemBlock = 0;
	}
}

void DSPFilter::SetParameter(s32 paramId, void* param)
{
	void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );
	if(!pParamAddr)
		return;

	switch(paramId)
	{
		case 0:
		{
			f32* value = (f32*)param;
			if(m_filterParams.fFrequency != *value)
			{
				m_filterParams.fFrequency = *value;
				s32 ret = cellMSFXFilterSet( pParamAddr, &m_filterParams, 0);
				CELLMS_ERROR(ret);
			}
			break;
		}
		default:
		{
			break;
		}
	}
}

void DSPFilter::Update(f32 dt)
{
	//m_filterParams.fFrequency = m_fader.GetCurrentValue();
	//void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );
	//s32 result = cellMSFXFilterSet( pParamAddr, &m_filterParams, -1);
	//VOX_ASSERT_MSG(result != -1, "Init Parametric EQ return failed\n");

	//m_fader.Update(dt);

	//if(m_fader.IsFinished())
	//{
	//	m_fader = Fader(m_fader.GetEndValue(), m_fader.GetStartValue(), 5.0f);
	//}
}

}
#endif

/* DSPDelay */
#if VOX_DSP_ENABLE_DELAY
namespace vox
{
DSPDelay::DSPDelay()
:m_pDelayMemBlock(0)
{
}

DSPDelay::~DSPDelay()
{
	Unload();
}

s32 DSPDelay::Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle)
{
	s32 result = -1;

	if(m_busNo != -1)
		Unload();

	if(dspHandle != -1)
	{
		m_busNo = busNo;
		m_dspSlot = dspSlot;
		cellMSCoreSetDSP( m_busNo, m_dspSlot, dspHandle);
		void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );

		//Get size required for 5 active delays for a required slot.
		s32 size = cellMSFXDelayGetNeededMemorySize(5);

		m_pDelayMemBlock = VOX_ALLOC_ALIGN(size, k_nVoxMemHint_Align128);
		VOX_ASSERT_MSG(m_pDelayMemBlock, "Failed to allocate delay buffer");

		VOX_WARNING_LEVEL_5("Allocated delay buffer size: %d to address 0x%x\n",size,(int)m_pDelayMemBlock);

		memcpy(&m_delayParams, mngData, sizeof(CellMSFXDelay));

		result = cellMSFXDelayInit( pParamAddr, m_pDelayMemBlock, &m_delayParams,5);
		if(result == -1)
		{
			VOX_WARNING_LEVEL_1("ERROR : %d\n",cellMSSystemGetLastError());
		}
		VOX_ASSERT_MSG(result != -1, "Init delay return failed\n");

		SetDSPSlotRoute();
		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_NOTBYPASSED );
	}

	return result;
}

void DSPDelay::Unload()
{
	if(m_busNo != -1)
	{
		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_BYPASSED );
		cellMSCoreSetDSP( m_busNo, m_dspSlot, CELL_MS_DSPOFF);
		m_busNo = -1;
	}

	if(m_pDelayMemBlock)
	{
		VoxFree(m_pDelayMemBlock);
		m_pDelayMemBlock = 0;
	}
}

void DSPDelay::SetParameter(s32 paramId, void* param)
{

}
}
#endif

/* DSPDistortion */
#if VOX_DSP_ENABLE_DISTORTION
namespace vox
{
DSPDistortion::~DSPDistortion()
{
	Unload();
}

s32 DSPDistortion::Load(void* mngData, s32 busNo, CELL_MS_DSPSLOTS dspSlot, s32 dspHandle)
{
	s32 result = -1;

	if(dspHandle != -1)
	{
		m_busNo = busNo;
		m_dspSlot = dspSlot;
		cellMSCoreSetDSP( m_busNo, m_dspSlot, dspHandle);
		void* pParamAddr = (char *)cellMSCoreGetDSPParamAddr( m_busNo, m_dspSlot );

		memcpy(&m_params, mngData, sizeof(CellMSFXDistortion));

		result = cellMSFXDistortionInit(pParamAddr, &m_params);
		VOX_ASSERT_MSG(result != -1, "Init Distortion return failed\n");

		SetDSPSlotRoute();
		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_NOTBYPASSED );
	}

	return result;
}

void DSPDistortion::Unload()
{
	if(m_busNo != -1)
	{
		cellMSCoreBypassDSP( m_busNo, m_dspSlot, CELL_MS_BYPASSED );
		cellMSCoreSetDSP( m_busNo, m_dspSlot, CELL_MS_DSPOFF);
		m_busNo = -1;
	}
}

void DSPDistortion::SetParameter(s32 paramId, void* param)
{

}
}
#endif

#endif //VOX_DRIVER_USE_PS3_MULTISTREAM
