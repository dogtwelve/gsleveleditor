#include "StdAfx.h"
#include "vox_default_config.h"

#if VOX_DRIVER_USE_VITA_SW && VOX_VITA_SW_DRIVER_PLATFORM

#include "vox_driver_vita_sw.h"
#include "vox_macro.h"
#include <audioout.h>
#include <kernel.h>
namespace vox
{

#define VOX_VITA_SW_DRIVER_PREFERRED_RATE 48000 // Hz Check Vita documentation for valid output rate for MAIN channel, only 48 kHz atm

//*** DriverVitaSWSource ***//

s32* DriverVitaSWSource::m_filterBuffer = 0;

DriverVitaSWSource::DriverVitaSWSource(void * trackParam, void* driverParam, u32 sourceId):
DriverCallbackSourceInterface(trackParam, driverParam, sourceId)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverVitaSWSource::DriverVitaSWSource", vox::VoxThread::GetCurThreadId());
	Init();
}

DriverVitaSWSource::~DriverVitaSWSource()//**-**
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverVitaSWSource::~DriverVitaSWSource", vox::VoxThread::GetCurThreadId());
}

#ifndef M_PI
	#define M_PI	3.14159265358979323846264f
#endif

void DriverVitaSWSource::FillBuffer(s32* buffer, s32 nbSample)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverVitaSWSource::FillBuffer", vox::VoxThread::GetCurThreadId());
#if VOX_VITA_SW_DRIVER_ENABLE_OCCLUSION
	//if(m_trackParams.numChannels == 1 && m_filterBuffer)
	//{
	//	f32 attenuation = GetDistanceGain();
	//	attenuation /= VOX_FX1814_ONE;

	//	static f32 maxCutoff = 23000.f;
	//	static f32 shelfGain = 8.0f;

	//	if(attenuation > 0.97) //don't process near no attenuation
	//	{
	//		DriverCallbackSourceInterface::FillBuffer(buffer, nbSample);
	//	}
	//	else
	//	{
	//		memset(m_filterBuffer, 0, nbSample * 2 * sizeof(s32));
	//		DriverCallbackSourceInterface::FillBuffer(m_filterBuffer, nbSample);

	//		{
	//			VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverVitaSWSource::FillBuffer::BiquadFilter", vox::VoxThread::GetCurThreadId());
	//			attenuation = attenuation < 0.3f ? 0.0f : (attenuation - 0.3f)/ 0.7f;
	//			f32 cutoff = 5000.0f * (1.0f - attenuation) + maxCutoff * attenuation;

	//			f32  V = pow(10, (shelfGain) / 20);
	//			f32  K = tan(M_PI * cutoff / 48000);

	//			f32 norm = 1 / (V + (sqrt(2*V) + K) * K);
	//			f32 a0 = (1 + (1.414f + K) * K) * norm;
	//			f32 a1 = 2 * (K * K - 1) * norm;
	//			f32 a2 = (1 - (1.414f + K) * K) * norm;
	//			norm = 1 / (1 + sqrt(2/V) * K + K * K / V);
	//			f32 b1 = 2 * (K * K / V - 1) * norm;
	//			f32 b2 = (1 - sqrt(2/V) * K + K * K / V) * norm;

	//			s32 tempV;

	//			s32 histL0X = m_historyL[0].x;
	//			s32 histL1X = m_historyL[1].x;
	//			s32 histR0X = m_historyR[0].x;
	//			s32 histR1X = m_historyR[1].x;

	//			s32 histL0Y = m_historyL[0].y;
	//			s32 histL1Y = m_historyL[1].y;
	//			s32 histR0Y = m_historyR[0].y;
	//			s32 histR1Y = m_historyR[1].y;

	//			for(s32 i = 0; i < (nbSample << 1); i+=2)
	//			{
	//				tempV = (s32)(a0*m_filterBuffer[i] + a1*histL0X + a2*histL1X - b1*histL0Y - b2*histL1Y);
	//				histL1Y = histL0Y;
	//				histL0Y = tempV;
	//				histL1X = histL0X;
	//				histL0X = m_filterBuffer[i];
	//				buffer[i] += tempV;

	//				tempV = (s32)(a0*m_filterBuffer[i+1] + a1*histR0X + a2*histR1X - b1*histR0Y - b2*histR1Y);
	//				histR1Y = histR0Y;
	//				histR0Y = tempV;
	//				histR1X = histR0X;
	//				histR0X = m_filterBuffer[i+1];
	//				buffer[i+1] += tempV;					
	//			}

	//			m_historyL[0].x = histL0X;
	//			m_historyL[1].x = histL1X;
	//			m_historyR[0].x = histR0X;
	//			m_historyR[1].x = histR1X;

	//			m_historyL[0].y = histL0Y;
	//			m_historyL[1].y = histL1Y;
	//			m_historyR[0].y = histR0Y;
	//			m_historyR[1].y = histR1Y;
	//		}
	//	}
	//}
	if(m_trackParams.numChannels == 1 && m_filterBuffer)
	{
		f32 attenuation = GetDistanceGain();
		attenuation /= VOX_FX1814_ONE;

		static f32 maxCutoff = 23000.f;
		static f32 shelfGain = 8.0f;

		if(attenuation > 0.97) //don't process near no attenuation
		{
			DriverCallbackSourceInterface::FillBuffer(buffer, nbSample);
		}
		else
		{
			memset(m_filterBuffer, 0, nbSample * 2 * sizeof(s32));
			DriverCallbackSourceInterface::FillBuffer(m_filterBuffer, nbSample);

			{
				VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverVitaSWSource::FillBuffer::BiquadFilter", vox::VoxThread::GetCurThreadId());
				attenuation = attenuation < 0.3f ? 0.0f : (attenuation - 0.3f)/ 0.7f;
				f32 cutoff = 5000.0f * (1.0f - attenuation) + maxCutoff * attenuation;

				f32  V = pow(10, (shelfGain) / 20);
				f32  K = tan(M_PI * cutoff / 48000);

				f32 norm = 1 / (V + (sqrt(2*V) + K) * K);
				f32 a0 = (1 + (1.414f + K) * K) * norm;
				f32 a1 = 2 * (K * K - 1) * norm;
				f32 a2 = (1 - (1.414f + K) * K) * norm;
				norm = 1 / (1 + sqrt(2/V) * K + K * K / V);
				f32 b1 = 2 * (K * K / V - 1) * norm;
				f32 b2 = (1 - sqrt(2/V) * K + K * K / V) * norm;

				fx1814 a0fp = (a0 * VOX_FX1814_ONE);// >> VOX_FX1814_FRACT_SHIFT)
				fx1814 a1fp = (a1 * VOX_FX1814_ONE);
				fx1814 a2fp = (a2 * VOX_FX1814_ONE);
				fx1814 b1fp = (b1 * VOX_FX1814_ONE);
				fx1814 b2fp = (b2 * VOX_FX1814_ONE);

				s32 tempV;

				s32 histL0X = m_historyL[0].x;
				s32 histL1X = m_historyL[1].x;
				s32 histR0X = m_historyR[0].x;
				s32 histR1X = m_historyR[1].x;

				s32 histL0Y = m_historyL[0].y;
				s32 histL1Y = m_historyL[1].y;
				s32 histR0Y = m_historyR[0].y;
				s32 histR1Y = m_historyR[1].y;

				int i = 0;
				for(s32 j = 0; j < nbSample/64; j++)
					for(s32 k = 0; k < 64; k++,i+=2)
				//for(s32 i = 0; i < (nbSample << 1); i+=2)
				{
					tempV = (s32)(((a0fp*m_filterBuffer[i]) >> VOX_FX1814_FRACT_SHIFT) + ((a1fp*histL0X) >> VOX_FX1814_FRACT_SHIFT) + ((a2fp*histL1X) >> VOX_FX1814_FRACT_SHIFT) - ((b1fp*histL0Y) >> VOX_FX1814_FRACT_SHIFT) - ((b2fp*histL1Y) >> VOX_FX1814_FRACT_SHIFT));
					histL1Y = histL0Y;
					histL0Y = tempV;
					histL1X = histL0X;
					histL0X = m_filterBuffer[i];
					buffer[i] += tempV;

					tempV = (s32)(((a0fp*m_filterBuffer[i+1]) >> VOX_FX1814_FRACT_SHIFT) + ((a1fp*histR0X) >> VOX_FX1814_FRACT_SHIFT) + ((a2fp*histR1X) >> VOX_FX1814_FRACT_SHIFT) - ((b1fp*histR0Y) >> VOX_FX1814_FRACT_SHIFT) - ((b2fp*histR1Y) >> VOX_FX1814_FRACT_SHIFT));
					histR1Y = histR0Y;
					histR0Y = tempV;
					histR1X = histR0X;
					histR0X = m_filterBuffer[i+1];
					buffer[i+1] += tempV;					
				}

				m_historyL[0].x = histL0X;
				m_historyL[1].x = histL1X;
				m_historyR[0].x = histR0X;
				m_historyR[1].x = histR1X;

				m_historyL[0].y = histL0Y;
				m_historyL[1].y = histL1Y;
				m_historyR[0].y = histR0Y;
				m_historyR[1].y = histR1Y;
			}
		}
	}
	else
#endif
	{
		DriverCallbackSourceInterface::FillBuffer(buffer, nbSample);
	}
}

void DriverVitaSWSource::PrintDebug()
{
}

//*** DriverVitaSW ***//

DriverInterface* CreateDriver()
{
	return VOX_NEW DriverVitaSW();
}

	
DriverVitaSW::DriverVitaSW()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverVitaSW::DriverVitaSW", vox::VoxThread::GetCurThreadId());
	m_outBuffer[0] = 0;
	m_outBuffer[1] = 0;
	m_doUpdate = false;

	Init(0);
}

DriverVitaSW::~DriverVitaSW()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverVitaSW::~DriverVitaSW", vox::VoxThread::GetCurThreadId());
	Shutdown();
	if(m_outBuffer[0])
		VOX_FREE(m_outBuffer[0]);
	if(m_outBuffer[1])
		VOX_FREE(m_outBuffer[1]);

#if VOX_VITA_SW_DRIVER_ENABLE_OCCLUSION
	if(DriverVitaSWSource::m_filterBuffer)
	{
		VOX_FREE(DriverVitaSWSource::m_filterBuffer);
	}
#endif
}

DriverSourceInterface* DriverVitaSW::CreateDriverSource(void * trackParam, void* driverParam, s32 priority)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverVitaSW::CreateDriverSource", vox::VoxThread::GetCurThreadId());
	m_mutex.Lock();
	
	DriverVitaSWSource* driverSource = 0;

	if(m_audioUnitActive)
	{
		driverSource = VOX_NEW DriverVitaSWSource(trackParam, driverParam, m_nextSourceId);
		if(driverSource)
		{
			m_activeSources.push_back(driverSource);
			m_nextSourceId++;
		}
	}

	m_mutex.Unlock();
	return driverSource;
}

void DriverVitaSW::DestroyDriverSource(DriverSourceInterface* driverSource)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverVitaSW::DestroyDriverSource", vox::VoxThread::GetCurThreadId());
	m_mutex.Lock();
	if(driverSource)
	{
		VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> >::iterator it = m_activeSources.begin();
		VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> >::iterator end = m_activeSources.end();

		for(; it != end; it++)
		{
			if(*it == driverSource)
			{
				m_activeSources.erase(it);
				break;
			}
		}

		VOX_DELETE((DriverVitaSWSource*) driverSource);
	}
	m_mutex.Unlock();
}

void DriverVitaSW::Init(void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverVitaSW::Init", vox::VoxThread::GetCurThreadId());
	
	ScopeMutex _sm(&m_mutex);

	DriverCallbackInterface::Init(param);
	DriverCallbackSourceInterface::SetDriverSampleRate(VOX_VITA_SW_DRIVER_PREFERRED_RATE);

	u32 samplePerBuffer = VOX_VITA_SW_DRIVER_BUFFER_LENGTH;
	//Verify that samplePerBuffer is a multiple of 64
	if(samplePerBuffer & (63))
	{
		samplePerBuffer = (samplePerBuffer & (0xffffffe0)) + 64;
	}

#if VOX_VITA_SW_DRIVER_ENABLE_OCCLUSION
	if(!DriverVitaSWSource::m_filterBuffer)
	{
		DriverVitaSWSource::m_filterBuffer = (s32*)VOX_ALLOC(sizeof(s32) * 2 * samplePerBuffer);
	}
#endif

	m_outBuffer[0] = static_cast<s16*>(VOX_ALLOC(2*samplePerBuffer*sizeof(s16)));
	m_outBuffer[1] = static_cast<s16*>(VOX_ALLOC(2*samplePerBuffer*sizeof(s16)));
	m_currentOutBuffer = 0;

	if(!m_outBuffer[0] || !m_outBuffer[1])
	{
		VOX_WARNING_LEVEL_1("Vita Audio Output could not allocate internal buffer of size : %d", 2*samplePerBuffer*sizeof(s16));
		return;
	}

	VOX_WARNING_LEVEL_5("Initializing Vita software driver with rate %d Hz and %d samples per callback", VOX_VITA_SW_DRIVER_PREFERRED_RATE, samplePerBuffer);
	m_portId = sceAudioOutOpenPort(SCE_AUDIO_OUT_PORT_TYPE_MAIN, samplePerBuffer, VOX_VITA_SW_DRIVER_PREFERRED_RATE, SCE_AUDIO_OUT_PARAM_FORMAT_S16_STEREO);

	if(m_portId >= 0)
	{
		s32 vol[2];
		vol[0] = vol[1] = SCE_AUDIO_VOLUME_0dB;
		sceAudioOutSetVolume(m_portId, (SCE_AUDIO_VOLUME_FLAG_L_CH | SCE_AUDIO_VOLUME_FLAG_R_CH), vol);

		SceInt32 threadPriority = VOX_VITA_SW_DRIVER_THREAD_PRIORITY;
		SceInt32 cpuAffinityMask = VOX_VITA_SW_DRIVER_THREAD_CPU_AFFINITY;

		// Determine on how many cpus the AudioOutput callback thread is set to run.
		int nbCpusUsed = 0;
		if(cpuAffinityMask & SCE_KERNEL_CPU_MASK_USER_0)
		{
			nbCpusUsed++;
		}
		if(cpuAffinityMask & SCE_KERNEL_CPU_MASK_USER_1)
		{
			nbCpusUsed++;
		}
		if(cpuAffinityMask & SCE_KERNEL_CPU_MASK_USER_2)
		{
			nbCpusUsed++;
		}

		if(nbCpusUsed > 1)
		{
			// Combination of multiple cpus other than SCE_KERNEL_CPU_MASK_USER_ALL is invalid
			cpuAffinityMask = SCE_KERNEL_CPU_MASK_USER_ALL;
			if(nbCpusUsed == 2)
			{
				VOX_WARNING_LEVEL_1("%s", "Vita Audio Output thread affinity has been forced to SCE_KERNEL_CPU_MASK_USER_ALL. All user available cpus will be used.");
			}

			// If more than one cpu is used, thread priority cannot be higher than 128
			if(threadPriority < 128)
			{
				threadPriority = SCE_KERNEL_DEFAULT_PRIORITY - 32;
				VOX_WARNING_LEVEL_1("%s", "Vita Audio Output thread priority has been forced to SCE_KERNEL_DEFAULT_PRIORITY - 32 (max priority when using more than one CPU).");
				VOX_WARNING_LEVEL_1("%s", "Vita Audio Output thread will use the 'Common Ready Queue', which could lead to driver malfunction !");
			}
		}

		m_threadId = sceKernelCreateThread(
							"Vox Audio Output",
							&DriverVitaSW::soundThread,
							threadPriority,
							16 * 1024,
							0,
							cpuAffinityMask,
							SCE_NULL);

		if(m_threadId < 0)
		{
			VOX_WARNING_LEVEL_1("Vita Audio Output fail to create thread : %d", m_threadId);
			return;
		}

		m_doUpdate = true;
		
		void* arg = this;
		s32 errCode = sceKernelStartThread(m_threadId, sizeof(this), &arg);

		if(errCode < 0)
		{
			VOX_WARNING_LEVEL_1("Vita Audio Output fail to start thread : %d", m_threadId);
			sceKernelDeleteThread(m_threadId);
			m_threadId = -1;
			return;
		}

		SetDefaultParameter();
		m_audioUnitActive = true;
	}
	else
	{
		VOX_WARNING_LEVEL_1("Vita Audio Output fail to open : %d", m_portId);
	}
}

void DriverVitaSW::Shutdown()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverVitaSW::Shutdown", vox::VoxThread::GetCurThreadId());
	m_mutex.Lock();

	if(m_audioUnitActive)
	{
		m_audioUnitActive = false;
		//stop thread
		m_doUpdate = false;
		s32 exitCode;
		if(m_threadId >= 0)
		{
			sceKernelWaitThreadEnd(m_threadId, &exitCode, NULL);
			sceKernelDeleteThread(m_threadId);
		}
	}

	if(m_portId >= 0)
	{
		s32 ret = sceAudioOutReleasePort(m_portId);
		if(ret < 0)
		{
			VOX_WARNING_LEVEL_1("Vita Audio Output fail to close : %d", m_portId);
		}
	}

	m_mutex.Unlock();
}

void DriverVitaSW::Suspend()
{
	// TODO : See if callback should be stopped 
}

void DriverVitaSW::Resume()
{
	// TODO : Resume callback
}


void DriverVitaSW::PrintDebug()
{
}

s32 DriverVitaSW::soundThread(u32 args, void *argc )
{
	if(argc)
	{
		(*((DriverVitaSW**)argc))->playbackCallback();
	}

	return 0;
}

void DriverVitaSW::playbackCallback()
{
	u32 samplePerBuffer = VOX_VITA_SW_DRIVER_BUFFER_LENGTH;
	//Verify that samplePerBuffer is a multiple of 64
	if(samplePerBuffer & (63))
	{
		samplePerBuffer = (samplePerBuffer & (0xffffffe0)) + 64;
	}

	VOX_PROFILING_REGISTER_THREAD( "AudioOutput", vox::VoxThread::GetCurThreadId());

	while(m_doUpdate)
	{
		VOX_PROFILING_START_FRAME_LAZY;
		{
			VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverVitaSW::playbackCallback", vox::VoxThread::GetCurThreadId());
			FillBuffer(m_outBuffer[m_currentOutBuffer], samplePerBuffer);
		}

		sceAudioOutOutput(m_portId, m_outBuffer[m_currentOutBuffer]); //blocking
		m_currentOutBuffer ^= 1;
	}
}



}


#endif //#if VOX_DRIVER_USE_VITA_SW && VOX_VITA_SW_DRIVER_PLATFORM