#include "StdAfx.h"

#if VOX_DRIVER_USE_QSA && VOX_QSA_DRIVER_PLATFORM

#include "vox_driver_qsa.h"
#include "vox_macro.h"
#include "vox_memory.h"

#define VOX_QSA_DRIVER_THREAD_PRIORITY 24

namespace vox {

DriverInterface* CreateDriver()
{
	return VOX_NEW DriverQSA();
}

DriverQSASource::DriverQSASource(void * trackParam, void* driverParam, u32 sourceId):
		DriverCallbackSourceInterface(trackParam, driverParam, sourceId)
{
	Init();
}

DriverQSASource::~DriverQSASource(){
}

void  DriverQSASource::PrintDebug(){
}


//*** DriverQSA ***//

bool DriverQSA::s_isThreadRunning = false;

DriverQSA::DriverQSA():
	m_pcm_handle(0),
	m_outBuffer(0),
	m_nbFragments(0),
	m_frag_size(0),
	m_card(-1),
	m_device(-1),
	m_suspended(false),
	m_needResampling(false),
	m_resampleBuffer(0),
	m_resampleBufferSize(0),
	m_resamplePos(0),
	m_prevLeft(0),
	m_prevRight(0),
	m_needRampIn(false)
{
	Init(0);
}

DriverQSA::~DriverQSA()
{
	Shutdown();
}

#define QSA_CHECK_STATUS(X) if(X < 0){VOX_WARNING_LEVEL_1("%s:%d : Error in driver : %d : %s", __FUNCTION__, __LINE__, X, snd_strerror(X));}

void DriverQSA::Init(void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverQSA::Init", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));
	
	VOX_WARNING_LEVEL_5("Starting QSA init",0);

	DriverCallbackInterface::Init(param);

	int error = 0;

	error = snd_pcm_open_preferred(&m_pcm_handle, &m_card, &m_device, SND_PCM_OPEN_PLAYBACK);
	QSA_CHECK_STATUS(error);

	snd_pcm_channel_info_t pi;
	memset(&pi, 0, sizeof (pi));
	pi.channel = SND_PCM_CHANNEL_PLAYBACK;

	error = snd_pcm_plugin_info(m_pcm_handle, &pi);
	QSA_CHECK_STATUS(error);

	// Inspect possible hardware sample rates and select one.
	s32 sampleRate = GetChannelRate(&pi);

	snd_pcm_channel_params_t pp;
	memset (&pp, 0, sizeof (pp));
	pp.mode = SND_PCM_MODE_BLOCK;
	pp.channel = SND_PCM_CHANNEL_PLAYBACK;
	pp.start_mode = SND_PCM_START_FULL;		// Start stream when all fragments are filled.
	pp.stop_mode = SND_PCM_STOP_STOP;
	pp.buf.block.frag_size = pi.min_fragment_size;
	pp.buf.block.frags_max = VOX_QSA_DRIVER_MAX_FRAGMENTS;
	pp.buf.block.frags_min = VOX_QSA_DRIVER_MIN_FRAGMENTS;
	pp.format.interleave = 1;
	pp.format.rate = sampleRate;
	pp.format.voices = pi.max_voices;
	pp.format.format = SND_PCM_SFMT_S16_LE;
	strcpy (pp.sw_mixer_subchn_name, "Wave playback channel");

	// Set channel parameters
	error = snd_pcm_plugin_params(m_pcm_handle, &pp);
	QSA_CHECK_STATUS(error);

	// Prepare channel
	error = snd_pcm_plugin_prepare(m_pcm_handle, SND_PCM_CHANNEL_PLAYBACK);
	QSA_CHECK_STATUS(error);

	// Get the actual setup (not necessarily the one that we have set)
	snd_pcm_channel_setup_t setup;
	memset(&setup, 0, sizeof(setup));
	setup.channel = SND_PCM_CHANNEL_PLAYBACK;
	error = snd_pcm_plugin_setup(m_pcm_handle, &setup);
	QSA_CHECK_STATUS(error);

	// Set member variables according to setup parameters
	m_nbFragments = setup.buf.block.frags;
	m_frag_size = setup.buf.block.frag_size;
	m_hwSampleRate = setup.format.rate;

	// If channel sample rate is different from driver sample rate, resampling is needed.
	m_needResampling = (m_hwSampleRate != VOX_QSA_DRIVER_PREFERRED_RATE);

	m_outBuffer = (c8*)VOX_ALLOC(m_frag_size);
	if(!m_outBuffer)
	{
		QSA_CHECK_STATUS(-1);
		return;
	}

	f32 callbackPeriod = static_cast<f32> (m_frag_size >> 2) / static_cast<f32> (m_hwSampleRate);

	// When resampling, driver sources buffer filling is not at the same rate as API writes.
	if(m_needResampling)
	{
		callbackPeriod *= static_cast<f32> (m_hwSampleRate) / static_cast<f32> (VOX_QSA_DRIVER_PREFERRED_RATE);
	}

	// Inform parent class about driver sources callback period (used for pitch ramping)
	DriverCallbackSourceInterface::SetDriverCallbackPeriod(callbackPeriod);

	// Inform parent class about driver's sample rate
	DriverCallbackSourceInterface::SetDriverSampleRate((s32) VOX_QSA_DRIVER_PREFERRED_RATE);

	SetDefaultParameter();

	// Fill all buffer fragments
	for(int i = 0; i < m_nbFragments; i++)
	{
		if(m_needResampling)
		{
			FillBuffer((s16*)m_outBuffer, m_frag_size >> 2);
		}
		else
		{
			_FillBuffer((s16*)m_outBuffer, m_frag_size >> 2);
		}
		int nbBytesWritten = snd_pcm_plugin_write(m_pcm_handle, m_outBuffer, m_frag_size);
		if(nbBytesWritten != m_frag_size)
		{
			QSA_CHECK_STATUS(nbBytesWritten);
			VOX_FREE(m_outBuffer);
			return;
		}
	}

	// Start update thread
	s_isThreadRunning = true;
	s32 result = pthread_create(&m_internThread, 0, UpdateThreaded, this);

	if(result != 0)
	{
		QSA_CHECK_STATUS(result);
		VOX_FREE(m_outBuffer);
		m_outBuffer = 0;
		return;
	}

	// Set thread priority
	sched_param thread_params;
	int sched_mode;
	pthread_getschedparam(m_internThread, &sched_mode, &thread_params);

	s32 minprio = sched_get_priority_min(sched_mode);
	s32 maxprio = sched_get_priority_max(sched_mode);

	s32 threadprio = (VOX_QSA_DRIVER_THREAD_PRIORITY <= maxprio) ? (VOX_QSA_DRIVER_THREAD_PRIORITY >= minprio ? VOX_QSA_DRIVER_THREAD_PRIORITY : minprio) : maxprio;

	thread_params.sched_priority = threadprio;
	pthread_setschedparam(m_internThread, sched_mode, &thread_params);

	// Activate driver (starts actual buffer writes)
	if(error == 0)
	{
		m_audioUnitActive = true;
	}

	VOX_WARNING_LEVEL_5("End of QSA init",0);
}

void DriverQSA::DoCallback()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverQSA::DoCallback", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));

	if(!m_suspended && m_outBuffer && m_audioUnitActive)
	{
		// Get the channel status
		snd_pcm_channel_status_t status;
		memset(&status, 0, sizeof (status));
        status.channel = SND_PCM_CHANNEL_PLAYBACK;

        int errorCode = snd_pcm_plugin_status(m_pcm_handle, &status);

		if(errorCode == 0 && status.status == SND_PCM_STATUS_RUNNING)
		{
			if(m_needResampling)
			{
				FillBuffer((s16*)m_outBuffer, m_frag_size >> 2);
			}
			else
			{
				_FillBuffer((s16*)m_outBuffer, m_frag_size >> 2);
			}

			s32 written = snd_pcm_plugin_write(m_pcm_handle, m_outBuffer, m_frag_size);
			if(written != m_frag_size)
			{
				Recover();
			}
		}
		else // Channel is not running, recover.
		{
			Recover();
		}
	}
}

void DriverQSA::Shutdown()
{
	VOX_WARNING_LEVEL_5("****entering DriverQSA Shutdown",0);
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_pcm_handle)
	{
		s_isThreadRunning = false;
		pthread_join(m_internThread, 0);

		m_audioUnitActive =	false;
		int status = 0;

		status = snd_pcm_close(m_pcm_handle);
		QSA_CHECK_STATUS(status);

		m_pcm_handle = 0;

		if(m_outBuffer)
		{
			VOX_FREE(m_outBuffer);
			m_outBuffer = 0;
		}

		if(m_resampleBuffer)
		{
			VOX_FREE(m_resampleBuffer);
			m_resampleBuffer = 0;
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverQSA::Suspend()
{
	VOX_WARNING_LEVEL_5("****entering DriverQSA Suspend",0);
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_audioUnitActive)
	{
		int status = snd_pcm_playback_pause(m_pcm_handle);
		QSA_CHECK_STATUS(status);
		m_suspended = true;
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverQSA::Resume()
{
	VOX_WARNING_LEVEL_5("****entering DriverQSA Resume",0);

	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
 	if(m_audioUnitActive)
 	{
 		int status = snd_pcm_playback_resume(m_pcm_handle);
 		QSA_CHECK_STATUS(status);
		m_suspended = false;
		m_needRampIn = true;
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

DriverSourceInterface* DriverQSA::CreateDriverSource(void * trackParam, void* driverParam, s32 priority)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());

	DriverQSASource* driverSource = 0;

	if(m_audioUnitActive)
	{
		driverSource = VOX_NEW DriverQSASource(trackParam, driverParam, m_nextSourceId);
		if(driverSource)
		{
			m_activeSources.push_back(driverSource);
			m_nextSourceId++;
		}
	}

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return driverSource;
}


void DriverQSA::DestroyDriverSource(DriverSourceInterface* driverSource)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(driverSource)
	{
		VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> >::iterator it = m_activeSources.begin();
		VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> >::iterator end = m_activeSources.end();

		for(; it != end; it++)
		{
			if(*it == driverSource)
			{
				m_activeSources.erase(it);
				break;
			}
		}

		VOX_DELETE( (DriverQSASource*)driverSource);
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void* DriverQSA::UpdateThreaded(void* caller)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverQSA::UpdateThreaded", vox::VoxThread::GetCurThreadId());
	while(s_isThreadRunning)
	{
		((DriverQSA*)caller)->DoCallback();
		usleep(1000);
	}
	return 0;
}

void DriverQSA::Recover(void)
{
	snd_pcm_channel_status_t status;
	memset(&status, 0, sizeof (status));
	status.channel = SND_PCM_CHANNEL_PLAYBACK;

	if(snd_pcm_plugin_status(m_pcm_handle, &status) == 0)
	{
		if(status.status == SND_PCM_STATUS_UNDERRUN || status.status == SND_PCM_STATUS_READY)
		{
			VOX_WARNING_LEVEL_1("Trying to repair QSA channel", 0);
			if(snd_pcm_plugin_prepare(m_pcm_handle, SND_PCM_CHANNEL_PLAYBACK) < 0)
			{
				VOX_WARNING_LEVEL_1("Could not repair QSA channel", 0);
				return;
			}
		}

		// Fill buffer completely before starting stream
		for(int i = 0; i < m_nbFragments; i++)
		{
			if(m_needResampling)
			{
				FillBuffer((s16*)m_outBuffer, m_frag_size >> 2);
			}
			else
			{
				_FillBuffer((s16*)m_outBuffer, m_frag_size >> 2);
			}
			int nbBytesWritten = snd_pcm_plugin_write(m_pcm_handle, m_outBuffer, m_frag_size);
			if(nbBytesWritten != m_frag_size)
			{
				return;
			}
		}
	}
}

void DriverQSA::FillBuffer(s16* outBuffer, s32 nbSample)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverQSA::FillBuffer", vox::VoxThread::GetCurThreadId());

	if(m_needResampling)
	{
		ScopeMutex sm(&m_mutex);
		s32 previousResampleBufferSize = m_resampleBufferSize;
		if(m_resampleBufferSize == 0)
		{
			if(m_resampleBuffer)
			{
				VOX_FREE(m_resampleBuffer);
			}

			m_resampleBufferSize = nbSample << 2;

			m_resampleBuffer = (s16*)VOX_ALLOC(m_resampleBufferSize);
			m_resamplePos = 0;

			if(!m_resampleBuffer)
			{
				m_resampleBufferSize = -1; //error
				if(m_resampleBufferSize != previousResampleBufferSize)
				{
					VOX_WARNING_LEVEL_2("Could not create QSA resample buffer", 0);
				}
			}
			else
			{
				DriverCallbackInterface::_FillBuffer(m_resampleBuffer, nbSample);
			}
		}

		if(m_resampleBufferSize > 0)
		{
			s32 realrate = (s32)VOX_QSA_DRIVER_PREFERRED_RATE;
			s32 hwRate = m_hwSampleRate;
			fx1814 idxiter = (realrate << VOX_FX1814_FRACT_SHIFT) / hwRate;

			s32 bufferSamples = m_resampleBufferSize >> 2;

			s32 outSampleIndex = 0;
			s32 bufferSampleIndex = 0;

			fx1814 idxratio;

			s16 nextLeft, nextRight;
			s32 tempSample;

			s32 stereoSample = nbSample * 2; //hack to avoid *2 every iter

			while(stereoSample > outSampleIndex)
			{
				while(((m_resamplePos) < ((bufferSamples) << VOX_FX1814_FRACT_SHIFT)) && (stereoSample > outSampleIndex))
				{
					idxratio = m_resamplePos & VOX_FX1814_FRACT_MASK;
					bufferSampleIndex = (m_resamplePos >> VOX_FX1814_FRACT_SHIFT) << 1;

					nextLeft = m_resampleBuffer[bufferSampleIndex];
					nextRight = m_resampleBuffer[bufferSampleIndex + 1];

					tempSample = m_prevLeft + (((nextLeft - m_prevLeft) * idxratio) >> VOX_FX1814_FRACT_SHIFT);
					outBuffer[outSampleIndex++] = (s16)tempSample;
					tempSample = m_prevRight + (((nextRight - m_prevRight) * idxratio) >> VOX_FX1814_FRACT_SHIFT);
					outBuffer[outSampleIndex++] = (s16)tempSample;
					m_resamplePos += idxiter;
					if(bufferSampleIndex != ((m_resamplePos >> VOX_FX1814_FRACT_SHIFT) << 1))
					{
						m_prevLeft = nextLeft;
						m_prevRight = nextRight;
					}
				}

				if(!(m_resamplePos < ((bufferSamples) << VOX_FX1814_FRACT_SHIFT)))
				{
					DriverCallbackInterface::_FillBuffer(m_resampleBuffer, bufferSamples);
					m_resamplePos &= VOX_FX1814_FRACT_MASK;
				}
			}
		}
		else
		{
			memset(outBuffer, 0, (nbSample << 1) * sizeof(s16));
			return;
		}
	}
	else
	{
		DriverCallbackInterface::FillBuffer(outBuffer, nbSample);
	}

	if(m_needRampIn)
	{
		m_needRampIn = false;

		for(s32 i = 0 ; i < (nbSample<<1) ; i+=2)
		{
			outBuffer[i] = (s32)outBuffer[i] * (i>>1) / nbSample;
			outBuffer[i+1] = (s32)outBuffer[i+1] * (i>>1) / nbSample;
		}
	}
}

s32 DriverQSA::GetChannelRate(snd_pcm_channel_info_t *infos)
{
	s32 sampleRate;

	// Since Playbook DAC is at 48kHz, set sample rate from vox to qsa to this value
	// so that resampling from 32kHz driver sources to 48kHz is done in vox.
	if(infos->rates & SND_PCM_RATE_48000)
	{
		sampleRate = 48000;
	}
	else if(infos->rates & SND_PCM_RATE_32000)
	{
		sampleRate = 32000;
	}
	else if(infos->rates & SND_PCM_RATE_44100)
	{
		sampleRate = 44100;
	}
	else
	{
		m_hwSampleRate = infos->min_rate;
	}

	return sampleRate;
}

}//namespace vox

#endif // VOX_DRIVER_USE_QSA && VOX_QSA_DRIVER_PLATFORM
