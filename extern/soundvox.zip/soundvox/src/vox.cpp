#include "StdAfx.h"
#include "vox_default_config.h"
#include "vox.h"
#include "vox_internal.h"

#include "vox_stream_memorybuffer.h"
#include "vox_stream_cfile.h"

#include "vox_decoder_raw.h"
#include "vox_decoder_mswav.h"
#if !defined(_NN_CTR)
#include "vox_decoder_stbvorbis.h"
#include "vox_decoder_mpc8.h"
#else
#include "vox_decoder_bcwav.h"
#endif
#include "vox_decoder_native.h"

#include "vox_macro.h"

#include "vox_thread.h"

#include "vox_mutex.h"


template <class T> const T& MAX ( const T& a, const T& b ) 
{
	return (b<a) ? a : b;
}

vox::f64 GetTimeDT(vox::f64 t1, vox::f64 t2)
{
	vox::f64 dt = t2 - t1;
	return MAX(0.0, dt);
}

#ifndef GetTime
#if defined(_PS3)
#include <time.h>
vox::f64 _GetTime()
{
	vox::f64 ticks = clock();
	vox::f64 time = ticks/((double)CLOCKS_PER_SEC);

	return time;
}
#elif defined(SN_TARGET_PSP2)
#include <rtc.h>
#pragma comment (lib, "SceRtc_stub")
vox::f64 _GetTime()
{
	static unsigned int TICK_PER_SEC = sceRtcGetTickResolution();
	SceRtcTick ticks;
    sceRtcGetCurrentTick(&ticks);

	vox::f64 time = ticks.tick/((double)TICK_PER_SEC);

	return time;
}
#elif defined(_WIN32)
#if VOX_DEBUG_SERVER_ENABLE
#define _WINSOCKAPI_
#endif
#include "windows.h"
vox::f64 _GetTime()
{
	LARGE_INTEGER freq, start;
	double ticks, f;

	QueryPerformanceFrequency(&freq);
	QueryPerformanceCounter(&start);
	f = (vox::f64)freq.QuadPart;
	ticks = (vox::f64)start.QuadPart;

	return (ticks)/f;
}
#elif defined(_IPHONE_OS) || defined(_MAC_OSX_INTEL)
#include <mach/mach_time.h>
vox::f64 _GetTime()
{	
	static mach_timebase_info_data_t info; // info.numer / info.denom = tick period in nanoseconds.
	static vox::f64 tickPeriodInSeconds;
	static bool isFirstTime = true;
	
	if(isFirstTime)
	{
		mach_timebase_info(&info);
		tickPeriodInSeconds = (vox::f64)info.numer / (vox::f64)info.denom * 0.000000001;
		isFirstTime = false;
	}
    
    return ((vox::f64) mach_absolute_time()) * tickPeriodInSeconds;
}
#elif defined (_LIMO) || defined(_LINUX) || defined(_PALMPRE) || defined(_ANDROID) || defined(__native_client__) || defined(__QNXNTO__)
#include <sys/time.h>
vox::f64 _GetTime()
{
	struct timeval	tp;
	vox::f64 sec, usec;
	gettimeofday(&tp, 0);
	sec = tp.tv_sec;
	usec = tp.tv_usec;
	return (sec + usec/1000000);
}
#elif defined(_NN_CTR)
#include <nn/os.h>
vox::f64 _GetTime()
{
	nn::fnd::TimeSpan time = nn::os::Tick::GetSystemCurrent().ToTimeSpan();
	return ((f64)time.GetMicroSeconds())/1000000.0;
}
#endif

#define GetTime _GetTime
#endif

namespace vox {

VoxEngine* VoxEngine::s_voxEngine = 0;
VoxEngineInternal* VoxEngine::m_internal=0;

VoxEngine& VoxEngine::GetVoxEngine()
{
	if ( ! s_voxEngine )
	{
		s_voxEngine = VOX_NEW VoxEngine();
	}

	VOX_ASSERT_MSG( s_voxEngine, "VoxEngine creation failed\n" );
	return *s_voxEngine;
}


void VoxEngine::DestroyVoxEngine()
{
	if ( s_voxEngine )
	{
		VOX_DELETE(s_voxEngine);
		s_voxEngine = 0;
	}
}	
	
///

VoxEngine::VoxEngine()
:m_isInitialized(false)
{
	//VOX_PROFILING_REGISTER_THREAD( "VoxMainThread", VoxThread::GetId());
#ifdef VOX_THREADING_MODE_SINGLE_THREAD
	m_updateThread = 0;
	m_lastUpdateTime = 0.0;
#elif defined(VOX_THREADING_MODE_DUAL_THREAD)
	m_updateThread[0] = 0;
	m_updateThread[1] = 0;
	m_lastUpdateTime = 0.0;
#endif
	VOX_MUTEX_LEVEL_1(m_mutex = VOX_NEW Mutex();)
	m_internal = VoxEngineInternal::GetVoxEngineInternal();
	VOX_ASSERT( m_internal );

	//s_voxEngine = this;
}

VoxEngine::~VoxEngine()
{
	Shutdown();
	if(m_internal)
	{
		VOX_DELETE(m_internal);
	}
	m_internal = 0;
	VOX_MUTEX_LEVEL_1(VOX_DELETE (m_mutex);)
#if VOX_USE_CONSOLE
	Console* console = Console::GetInstance();
	if(console)
		VOX_DELETE (console);
#endif
}

//

void VoxEngine::Initialize()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Initialize", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	
	if(!m_internal)
		return;
	
	VOX_ASSERT_MSG(!m_isInitialized, "Vox already initialized\n");
	if(m_isInitialized)
		return;

	m_isInitialized = true;
	m_internal->Initialize();
	s32 id;
	
	VOX_ASSERT( m_internal->m_decoderTypeCount == 0 );

	// Pre-register stream types
	id = RegisterStreamType( StreamMemoryBufferFactory ); VOX_ASSERT( id == k_nStreamTypeMemoryBuffer );
	id = RegisterStreamType( StreamCFileFactory ); VOX_ASSERT( id == k_nStreamTypeCFile );
	VOX_ASSERT( m_internal->m_streamTypeCount == k_nStreamTypeCount );

	// Pre-register decoder types
	id = RegisterDecoderType( DecoderRawFactory ); VOX_ASSERT( id == k_nDecoderTypeRAW );
	id = RegisterDecoderType( DecoderMSWavFactory ); VOX_ASSERT( id == k_nDecoderTypeMSWav );
#if !defined(_NN_CTR)
	id = RegisterDecoderType( DecoderStbVorbisFactory ); VOX_ASSERT( id == k_nDecoderTypeStbVorbis );
	id = RegisterDecoderType( DecoderMPC8Factory ); VOX_ASSERT( id == k_nDecoderTypeMPC8 );
#else
	id = RegisterDecoderType( 0 ); VOX_ASSERT( id == k_nDecoderTypeStbVorbis ); // To keep id in the same order than enum
	id = RegisterDecoderType( 0 ); VOX_ASSERT( id == k_nDecoderTypeMPC8 );// To keep id in the same order than enum
#endif
	id = RegisterDecoderType( DecoderNativeFactory ); VOX_ASSERT( id == k_nDecoderTypeInteractiveMusic );
#if defined(_NN_CTR)
	id = RegisterDecoderType( DecoderBCWavFactory ); VOX_ASSERT( id == k_nDecoderTypeBCWav );
#else
	id = RegisterDecoderType( 0 ); VOX_ASSERT( id == k_nDecoderTypeBCWav );// To keep id in the same order than enum
#endif

	VOX_ASSERT( m_internal->m_decoderTypeCount == k_nDecoderTypeCount );

#ifdef VOX_THREADING_MODE_SINGLE_THREAD
	m_updateThread = VOX_NEW VoxThread(&vox::VoxEngine::UpdateThreaded, this, 0, "VoxEngine::Update");
	m_lastUpdateTime = GetTime();
#elif defined(VOX_THREADING_MODE_DUAL_THREAD)
	m_updateThread[0] = VOX_NEW VoxThread(&vox::VoxEngine::UpdateEmittersThreaded, this, 0, "VoxEngine::UpdateEmitters");
	m_updateThread[1] = VOX_NEW VoxThread(&vox::VoxEngine::UpdateSourcesThreaded, this, 0, "VoxEngine::UpdateSources");
	m_lastUpdateTime = GetTime();
#endif

}

void VoxEngine::Shutdown()
{
#ifdef VOX_THREADING_MODE_SINGLE_THREAD
	if(m_updateThread)
	{
		VOX_DELETE( m_updateThread);
		m_updateThread = 0;
	}
#elif defined(VOX_THREADING_MODE_DUAL_THREAD)
	if(m_updateThread[0])
	{
		VOX_DELETE (m_updateThread[0]);
		m_updateThread[0] = 0;
	}
	if(m_updateThread[1])
	{
		VOX_DELETE (m_updateThread[1]);
		m_updateThread[1] = 0;
	}
#endif
}

s32 VoxEngine::RegisterStreamType( StreamTypeFactoryFnPtr fnPtr )
{
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->RegisterStreamType(fnPtr);

	return -1;
}
	
s32 VoxEngine::RegisterDecoderType( DecoderTypeFactoryFnPtr fnPtr )
{
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->RegisterDecoderType(fnPtr);

	return -1;
}

bool VoxEngine::SetPriorityBank(s32 bankId, s32 threshold, s32 maxplayback, PriorityBankBehavior behavior)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetPriorityBank", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->SetPriorityBank( bankId, threshold, maxplayback, behavior);

	return false;
}


//
	
void VoxEngine::SuspendEngine(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SuspendEngine", vox::VoxThread::GetCurThreadId());
	if(m_internal)
		m_internal->Suspend();
}

	
void VoxEngine::ResumeEngine(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::ResumeEngine", vox::VoxThread::GetCurThreadId());
	if(m_internal)
		m_internal->Resume();
}

bool VoxEngine::IsEngineSuspended(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::IsEngineSuspended", vox::VoxThread::GetCurThreadId());
	if(m_internal)
		return m_internal->IsSuspended();
	return true;
}

//

void VoxEngine::Update(f32 dt)
{ 
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Update", vox::VoxThread::GetCurThreadId());
#ifndef VOX_THREADING_MODE_NONE
	VOX_WARNING_LEVEL_1("%s cannot be call when threading is enabled", __FUNCTION__);
	return;
#endif
	UpdateSources(); 
	UpdateEmitters(dt);
}

void VoxEngine::UpdateSources()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::UpdateSources", vox::VoxThread::GetCurThreadId());
#ifndef VOX_THREADING_MODE_NONE
	VOX_WARNING_LEVEL_1("%s cannot be call when threading is enabled", __FUNCTION__);
	return;
#endif
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if ( m_internal )
	{
		m_internal->UpdateSources();
	}
}

void VoxEngine::UpdateEmitters(f32 dt)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::UpdateEmitters", vox::VoxThread::GetCurThreadId());
	
#ifndef VOX_THREADING_MODE_NONE
	VOX_WARNING_LEVEL_1("%s cannot be call when threading is enabled", __FUNCTION__);
	return;
#endif
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if ( m_internal )
	{
		m_internal->UpdateEmitters(dt);
	}
}

DataHandle VoxEngine::LoadDataSource( s32 streamType, void* streamParams, s32 decoderType, void* decoderParams, s32 groupId )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::LoadDataSource", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->LoadDataSource(streamType, streamParams, decoderType, decoderParams, groupId );

	return DataHandle(-1);
}

DataHandle VoxEngine::LoadDataSourceAsync( s32 streamType, void* streamParams, s32 decoderType, void* decoderParams, s32 groupId, VoxSourceLoadingFlags loadingFlags )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::LoadDataSourceAsync", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->LoadDataSourceAsync(streamType, streamParams, decoderType, decoderParams, groupId, loadingFlags );

	return DataHandle(-1);
}

DataHandle VoxEngine::ConvertToRawSource(DataHandle &handle )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::ConvertToRawSource", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->ConvertToRawSource(handle);

	return DataHandle(-1);
}

DataHandle VoxEngine::ConvertToRamBufferSource(DataHandle &handle )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::ConvertToRamBufferSource", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->ConvertToRamBufferSource(handle);

	return DataHandle(-1);
}

void VoxEngine::SetUserData( DataHandle &handle, DataHandleUserData &data)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetUserData", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->SetUserData(handle, data);
}

DataHandleUserData VoxEngine::GetUserData( DataHandle &handle)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::GetUserData", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->GetUserData(handle);

	return DataHandleUserData();
}

void VoxEngine::SetPriorityBankId( DataHandle &handle, s32 bankId)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetPriorityBankId", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->SetPriorityBankId(handle, bankId);
}

void VoxEngine::SetUid( DataHandle &handle, s32 Uid)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetUid", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->SetUid(handle, Uid);
}

s32 VoxEngine::GetUid( DataHandle &handle)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::GetUid", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->GetUid(handle);
	return -1;
}

void VoxEngine::ReleaseDatasource( DataHandle &handle )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::ReleaseDatasource", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal) 
		m_internal->ReleaseDatasource( handle );
}

void VoxEngine::ReleaseDatasource(u32 groupMask)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::ReleaseDatasource", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal) 
		m_internal->ReleaseDatasource( groupMask );
}

s32  VoxEngine::GetEmitterHandles( DataHandle &handle, EmitterHandle* handlesBuffer, s32 bufferCount )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::GetEmitterHandles", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->GetEmitterHandles( handle, handlesBuffer, bufferCount );

	return 0;
}

s32  VoxEngine::GetAllDataSources( DataHandle* handlesBuffer, s32 bufferCount )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::GetAllDataSources", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->GetAllDataSources( handlesBuffer, bufferCount );

	return 0;
}


bool  VoxEngine::IsReady( DataHandle &handle )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::IsReady", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->IsReady( handle );

	return false;
}

bool  VoxEngine::IsValid( DataHandle &handle )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::IsValid", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->IsValid( handle );

	return false;
}

f32 VoxEngine::GetDuration( DataHandle &handle )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::GetDuration", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->GetDuration( handle );

	return 0.0f;
}

EmitterHandle VoxEngine::CreateEmitter( DataHandle &handle, s32 priority, void* driverParam )
{ 
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::CreateEmitter", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal) 
		return m_internal->CreateEmitter( handle, priority, driverParam );

	return EmitterHandle(-1);
}

EmitterHandle VoxEngine::CreateEmitterAsync( DataHandle &handle, s32 priority, void* driverParam )
{ 
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::CreateEmitterAsync", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal) 
		return m_internal->CreateEmitterAsync( handle, priority, driverParam );

	return EmitterHandle(-1);
}

void VoxEngine::SetUserData( EmitterHandle &handle, EmitterHandleUserData &data)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetUserData", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->SetUserData(handle, data);
}

EmitterHandleUserData VoxEngine::GetUserData( EmitterHandle &handle)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::GetUserData", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->GetUserData(handle);

	return EmitterHandleUserData();
}

void VoxEngine::KillEmitter( EmitterHandle &handle )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::KillEmitter", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal) 
		m_internal->KillEmitter( handle );
}

DataHandle VoxEngine::GetData(EmitterHandle &handle)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::GetData", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->GetData(handle);
		
	return DataHandle(-1);
}

void VoxEngine::SetAutoKillAfterDone( EmitterHandle &handle, bool kill)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetAutoKillAfterDone", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->SetAutoKillAfterDone( handle, kill);
}

void VoxEngine::SetGain( EmitterHandle &handle, f32 gain, f32 fadeTime) 
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetGain", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->SetGain( handle, gain, fadeTime);
}

f32 VoxEngine::GetGain( EmitterHandle &handle )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::GetGain", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->GetGain( handle);
	return 0.f;
}

void VoxEngine::SetLoop( EmitterHandle &handle, bool loop)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetLoop", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->SetLoop( handle, loop);
}

void VoxEngine::SetPitch( EmitterHandle &handle, f32 pitch, f32 fadeTime)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetPitch", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->SetPitch( handle, pitch, fadeTime);
}

f32 VoxEngine::GetPitch( EmitterHandle &handle )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::GetPitch", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->GetPitch( handle);
	return 0.f;
}

void VoxEngine::SetPriority( EmitterHandle &handle, s32 priority)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetPitch", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->SetPriority( handle, priority);
}

s32  VoxEngine::GetPriority( EmitterHandle &handle)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::GetPitch", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->GetPriority( handle);
	return -(1<<30);
}

void VoxEngine::Play( EmitterHandle &handle, bool loop, f32 fadeTime )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Play", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Play( handle, loop, fadeTime );
}
void VoxEngine::Stop( EmitterHandle &handle, f32 fadeTime )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Stop", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Stop( handle, fadeTime );
}
void VoxEngine::Pause( EmitterHandle &handle, f32 fadeTime) 
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Pause", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Pause( handle, fadeTime);
}
void VoxEngine::Resume( EmitterHandle &handle, f32 fadeTime) 
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Resume", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Resume( handle, fadeTime);
}

s32  VoxEngine::GetAllEmitters( EmitterHandle* handlesBuffer, s32 bufferCount )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::GetAllEmitters", vox::VoxThread::GetCurThreadId());
	if(m_internal)
		return m_internal->GetAllEmitters( handlesBuffer, bufferCount );

	return 0;
}

void VoxEngine::PlayAllEmitters( u32 groupMask, f32 fadeTime)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::PlayAllEmitters", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->PlayAllEmitters( groupMask, fadeTime);
}
void VoxEngine::StopAllEmitters( u32 groupMask, f32 fadeTime)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::StopAllEmitters", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->StopAllEmitters( groupMask, fadeTime);
}
void VoxEngine::PauseAllEmitters( u32 groupMask, f32 fadeTime)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::PauseAllEmitters", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->PauseAllEmitters( groupMask, fadeTime);
}
void VoxEngine::ResumeAllEmitters( u32 groupMask, f32 fadeTime)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::ResumeAllEmitters", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->ResumeAllEmitters( groupMask, fadeTime);
}

void VoxEngine::SetGroup( EmitterHandle &handle, s32 groupId)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetGroup", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->SetGroup( handle, groupId);
}

s32  VoxEngine::GetGroup( EmitterHandle &handle )
{ 
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::GetGroup", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->GetGroup( handle );

	return 0;
}

f32 VoxEngine::GetPlayCursor( EmitterHandle &handle )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::GetPlayCursor", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->GetPlayCursor( handle );

	return 0.0f;
}

void  VoxEngine::SetPlayCursor( EmitterHandle &handle, f32 time)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetPlayCursor", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->SetPlayCursor( handle, time );
}

bool VoxEngine::IsReady( EmitterHandle &handle )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::IsReady", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->IsReady( handle );

	return false;
}

bool  VoxEngine::IsValid( EmitterHandle &handle )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::IsValid", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->IsValid( handle );

	return false;
}

bool VoxEngine::IsAlive( EmitterHandle &handle )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::IsAlive", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->IsAlive( handle );

	return false;
}

bool VoxEngine::IsPlaying( EmitterHandle &handle )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::IsPlaying", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->IsPlaying( handle );

	return false;
}

bool VoxEngine::IsDone( EmitterHandle &handle )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::IsDone", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->IsDone( handle );

	return true;
}

u32 VoxEngine::GetStatus( EmitterHandle &handle )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::GetStatus", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->GetStatus( handle );

	return k_nError;
}

void  VoxEngine::SetMasterGain( f32 gain, f32 fadeTime)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetMasterGain", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->SetMasterGain( gain, fadeTime );
}

f32 VoxEngine::GetMasterGain()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::GetMasterGain", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->GetMasterGain();

	return 0.0f;
}

void  VoxEngine::SetGroupGain( u32 groupMask, f32 gain, f32 fadeTime)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetGroupGain", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->SetGroupGain( groupMask, gain, fadeTime );
}

f32 VoxEngine::GetGroupGain( s32 groupId )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::GetGroupGain", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->GetGroupGain( groupId );

	return 0.0f;
}
	
void  VoxEngine::Set3DEmitterPosition( EmitterHandle &handle, f32 x, f32 y, f32 z )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Set3DEmitterPosition", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Set3DEmitterPosition( handle, x, y, z );
}

void  VoxEngine::Set3DEmitterVelocity( EmitterHandle &handle, f32 x, f32 y, f32 z )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Set3DEmitterVelocity", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Set3DEmitterVelocity( handle, x, y, z );
}

void  VoxEngine::Set3DEmitterDirection( EmitterHandle &handle, f32 x, f32 y, f32 z )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Set3DEmitterDirection", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Set3DEmitterDirection( handle, x, y, z );
}

void  VoxEngine::Set3DEmitterParameters( EmitterHandle &handle, const Vox3DEmitterParameters &param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Set3DEmitterParameters", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Set3DEmitterParameters( handle, param );
}

void  VoxEngine::Set3DEmitterParameterf( EmitterHandle &handle, s32 paramId, f32 floatValue )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Set3DEmitterParameterf", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Set3DEmitterParameterf( handle, paramId, floatValue );
}

void  VoxEngine::Set3DEmitterParameteri( EmitterHandle &handle, s32 paramId, s32 intValue )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Set3DEmitterParameteri", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Set3DEmitterParameteri( handle, paramId, intValue );
}

void  VoxEngine::Get3DEmitterPosition( EmitterHandle &handle, f32 &x, f32 &y, f32 &z )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Get3DEmitterPosition", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Get3DEmitterPosition( handle, x, y, z );
}

void  VoxEngine::Get3DEmitterVelocity( EmitterHandle &handle, f32 &x, f32 &y, f32 &z )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Get3DEmitterVelocity", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Get3DEmitterVelocity( handle, x, y, z );
}

void  VoxEngine::Get3DEmitterDirection( EmitterHandle &handle, f32 &x, f32 &y, f32 &z )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Get3DEmitterDirection", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Get3DEmitterDirection( handle, x, y, z );
}

void  VoxEngine::Get3DEmitterParameters( EmitterHandle &handle, Vox3DEmitterParameters &param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Get3DEmitterParameters", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Get3DEmitterParameters( handle, param );
}

void  VoxEngine::Get3DEmitterParameterf( EmitterHandle &handle, s32 paramId, f32 &floatValue )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Get3DEmitterParameterf", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Get3DEmitterParameterf( handle, paramId, floatValue );
}

void  VoxEngine::Get3DEmitterParameteri( EmitterHandle &handle, s32 paramId, s32 &intValue )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Get3DEmitterParameteri", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Get3DEmitterParameteri( handle, paramId, intValue );
}

void VoxEngine::Set3DListenerPosition(f32 x, f32 y, f32 z)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Set3DListenerPosition", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Set3DListenerPosition( x, y, z );
}

void VoxEngine::Set3DListenerVelocity(f32 x, f32 y, f32 z)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Set3DListenerVelocity", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Set3DListenerVelocity( x, y, z );
}

void VoxEngine::Set3DListenerOrientation(f32 x_at, f32 y_at, f32 z_at, f32 x_up, f32 y_up, f32 z_up)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Set3DListenerOrientation", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Set3DListenerOrientation( x_at, y_at, z_at, x_up, y_up, z_up );
}

void VoxEngine::Set3DGeneralParameter(const Vox3DGeneralParameters &param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Set3DGeneralParameter", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Set3DGeneralParameter( param );
}

void VoxEngine::Set3DGeneralParameterf( s32 paramId, f32 floatValue )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Set3DGeneralParameterf", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Set3DGeneralParameterf( paramId, floatValue );
}

void VoxEngine::Set3DGeneralParameteri( s32 paramId, s32 intValue )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Set3DGeneralParameteri", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Set3DGeneralParameteri( paramId, intValue );
}

void VoxEngine::Get3DListenerPosition(f32 &x, f32 &y, f32 &z)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Get3DListenerPosition", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Get3DListenerPosition( x, y, z );
}

void VoxEngine::Get3DListenerVelocity(f32 &x, f32 &y, f32 &z)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Get3DListenerVelocity", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Get3DListenerVelocity( x, y, z );
}

void VoxEngine::Get3DListenerOrientation(f32 &x_at, f32 &y_at, f32 &z_at, f32 &x_up, f32 &y_up, f32 &z_up)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Get3DListenerOrientation", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Get3DListenerOrientation( x_at, y_at, z_at, x_up, y_up, z_up );
}

void VoxEngine::Get3DGeneralParameter(Vox3DGeneralParameters &param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Get3DGeneralParameter", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Get3DGeneralParameter( param );
}

void VoxEngine::Get3DGeneralParameterf( s32 paramId, f32 &floatValue )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Get3DGeneralParameterf", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Get3DGeneralParameterf( paramId, floatValue );
}

void VoxEngine::Get3DGeneralParameteri( s32 paramId, s32 &intValue )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::Get3DGeneralParameteri", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->Get3DGeneralParameteri( paramId, intValue );
}

void VoxEngine::SetStaticBusRouting(c8* filename)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetStaticBusRouting", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->SetStaticBusRouting(filename);
}

void VoxEngine::SetDynamicBusRouting(c8* filename)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetDynamicBusRouting", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->SetDynamicBusRouting(filename);
}

void  VoxEngine::SetRoutingVolume(c8* busFromName, c8* busToName, VoxDSPGeneralParameter::BusRoutingType routingType, f32 dryVolume, f32 wetVolume, f32 fadeTime)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetRoutingVolume", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->SetRoutingVolume(busFromName, busToName, routingType, dryVolume, wetVolume, fadeTime);
}

void  VoxEngine::SetSFXPresetActive(s32 preset, bool active, f32 fadeTime)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetSFXPresetActive", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->SetSFXPresetActive(preset, active, fadeTime);
}

void  VoxEngine::SetDSPEmitterParameter( EmitterHandle &handle, s32 paramId, void* param )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetDSPEmitterParameter", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->SetDSPEmitterParameter(handle, paramId, param);
}

void  VoxEngine::SetInteractiveMusicState(EmitterHandle &handle, const char *stateLabel)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetInteractiveMusicState", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
	{
		m_internal->SetInteractiveMusicState(handle, stateLabel);
	}
}

void VoxEngine::RegisterForEmitterStateChangeNotification( EmitterHandle &handle, VoxEmitterStateChangedCallbackFunc callback, void* userData)
{
#if VOX_ENABLE_EMITTER_STATE_CHANGED_CALLBACK
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::RegisterForEmitterStateChangeNotification", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
	{
		m_internal->RegisterForEmitterStateChangeNotification(handle, callback, userData);
	}
#endif
}

void VoxEngine::UnregisterForEmitterStateChangeNotification( EmitterHandle &handle)
{
#if VOX_ENABLE_EMITTER_STATE_CHANGED_CALLBACK
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::UnregisterForEmitterStateChangeNotification", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
	{
		m_internal->UnregisterForEmitterStateChangeNotification(handle);
	}
#endif
}

VoxOutputMode VoxEngine::GetOutputMode()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::GetOutputMode", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->GetOutputMode();
	return k_nOutputModeUnknown;
}

bool VoxEngine::SetOutputMode(VoxOutputMode mode)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::SetOutputMode", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		return m_internal->SetOutputMode(mode);
	return false;
}

void VoxEngine::PrintDebug()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::PrintDebug", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->PrintDebug();
}

void VoxEngine::GetDebugInfo(DebugInfo &info)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::GetDebugInfo", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if(m_internal)
		m_internal->GetDebugInfo(info);
}

void VoxEngine::UpdateThreaded(void* caller, void* param)
{
	VOX_PROFILING_START_FRAME_LAZY;
	((VoxEngine*)caller)->UpdateThreaded();
}

void VoxEngine::UpdateSourcesThreaded(void* caller, void* param)
{
	VOX_PROFILING_START_FRAME_LAZY;
	((VoxEngine*)caller)->UpdateSourcesThreaded();
}

void VoxEngine::UpdateEmittersThreaded(void* caller, void* param)
{
	VOX_PROFILING_START_FRAME_LAZY;
	//get real dt
	((VoxEngine*)caller)->UpdateEmittersThreaded();
}

void VoxEngine::UpdateSourcesThreaded()
{
#ifndef VOX_THREADING_MODE_NONE
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::UpdateSourcesThreaded", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if ( m_internal )
	{
		m_internal->UpdateSources();
	}
#endif
}

void VoxEngine::UpdateEmittersThreaded()
{
#ifndef VOX_THREADING_MODE_NONE
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::UpdateEmittersThreaded", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_internal, "VoxInternal doesn't exist\n");
	if ( m_internal )
	{
		vox::f64 currentTime = GetTime();
		vox::f64 dt = GetTimeDT(m_lastUpdateTime, currentTime);
		m_lastUpdateTime = currentTime;
		m_internal->UpdateEmitters((f32)dt);
	}
#endif
}

void VoxEngine::UpdateThreaded()
{
#ifndef VOX_THREADING_MODE_NONE
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_GENERAL, "VoxEngine::UpdateThreaded", vox::VoxThread::GetCurThreadId());
	UpdateSourcesThreaded();
	UpdateEmittersThreaded();
#endif
}
}
