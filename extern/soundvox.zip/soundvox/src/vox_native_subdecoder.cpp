#include "StdAfx.h"
#include "vox_native_subdecoder.h"


namespace vox
{

s32* VoxNativeSubDecoder::s_pMixingBuffer = 0;
s32	VoxNativeSubDecoder::s_nbMixingBufferBytes = 0;

//*** NativeSubDecoderState ***//

#if VOX_NATIVE_REDUCE_LATENCY

NativeSubDecoderState::NativeSubDecoderState(NativePlaylistsManager *pPlaylists)
{
	m_pPlaylists = (NativePlaylistsManager *) VOX_NEW NativePlaylistsManager(*pPlaylists);
}

NativeSubDecoderState::~NativeSubDecoderState()
{
	if(m_pPlaylists)
	{
		VOX_DELETE(m_pPlaylists);
		m_pPlaylists = 0;
	}
}

#endif // VOX_NATIVE_REDUCE_LATENCY


//*** VoxNativeSubDecoder ***//

VoxNativeSubDecoder::VoxNativeSubDecoder(StreamCursorInterface* pStreamCursor, NativeChunks* pNativeChunks, States *pStates,
										 AudioSegments *pAudioSegments, DOUBLE_VECTOR(s32) *pSegmentsCues,
										 TransitionRules *pTransitionRules, DOUBLE_VECTOR(TransitionParams) *pTransitions,
										 STRING_MAP(s32, StringCompare) *pStateLabels,
										 NativePlaylistsManager *pPlaylists):
m_pStreamCursor(pStreamCursor),
m_pAudioSegments(pAudioSegments),
m_pTransitionRules(pTransitionRules),
m_pStates(pStates),
m_pTransitions(pTransitions),
m_pStateLabels(pStateLabels),
m_pSegmentsCues(pSegmentsCues),
m_pPlaylists(pPlaylists),
m_oldState(NATIVE_STATE_NONE),
m_currentState(NATIVE_STATE_NONE),
m_newState(NATIVE_STATE_NONE),
m_oldPlaylist(-1),
m_currentPlaylist(-1),
m_newPlaylist(-1),
m_resetPlaylist(true),
m_currentRule(NATIVE_RULE_NONE),
m_newRule(NATIVE_RULE_NONE),
m_nbSegmentsPlaying(0),
m_mixingStartPosition(-1),
m_currentSegmentOffset(0),
m_hasData(true)
{
	m_currentSegmentState.m_index = -1;
	m_currentSegmentState.m_lifeState = k_nSegmentCurrent;
	m_currentSegmentState.m_position = 0;
	m_oldSegmentState.m_index = -1;
	m_oldSegmentState.m_lifeState = k_nSegmentOld;
	m_oldSegmentState.m_position = 0;
	m_dyingSegmentState.m_index = -1;
	m_dyingSegmentState.m_lifeState = k_nSegmentDying;
	m_dyingSegmentState.m_position = 0;

	m_audioFormat = pNativeChunks->m_formatChunk.m_format;
	m_dataStart = pNativeChunks->m_idChunk.m_fileInfos.m_dataStart;
}


void VoxNativeSubDecoder::ApplyTransitionRule(TransitionRule *pRule)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoder::ApplyTransitionRule", vox::VoxThread::GetCurThreadId());

	PlaylistElement *pElement;
	s32 nextDyingSegment = GetNextDyingSegmentLifeState();

	// Get a new playlist element according to rule entryPointType
	if(pRule->m_entryPointType == k_nEntrySameTime)
	{
		if(nextDyingSegment == k_nSegmentOld)
		{
			m_pPlaylists->TransposePlaylistParameters(m_currentPlaylist, m_newPlaylist);
		}
		else // Current segment is going to die, transpose playlist that generated old segment
		{
			if(m_currentPlaylist == m_oldPlaylist)
			{
				m_pPlaylists->SetPlaylistToPreviousState(m_oldPlaylist);
			}
			m_pPlaylists->TransposePlaylistParameters(m_oldPlaylist, m_newPlaylist);
			SwapOldAndCurrentSegments();
		}
		pElement = m_pPlaylists->GetPlaylistElement(m_newPlaylist, k_nSelectionSamePosition);

		// If no fade out required by rule, only current segment must play
		if((s32) (pRule->m_fadeOutLength * m_audioFormat.m_sampleRate) <= 0)
		{
			if(m_oldSegmentState.m_playbackState >= NATIVE_STATE_PLAYING)
			{
				m_oldSegmentState.m_playbackState = NATIVE_STATE_FORCED_STOP;
				m_nbSegmentsPlaying--;
			}
			if(m_dyingSegmentState.m_playbackState >= NATIVE_STATE_PLAYING)
			{
				m_dyingSegmentState.m_playbackState = NATIVE_STATE_FORCED_STOP;
				m_nbSegmentsPlaying--;
			}
		}
	}
	// TODO : Also add a condition to get a transition segment
	//else if(pRule->m_transitionSegment >= 0)
	//{
	// TODO : See if playlist should be resetted if m_resetPlaylist = true
	//	pElement = m_pPlaylists->GetPlaylistElement(m_newPlaylist, k_nSelectionTransitionSegment);
	//}
	else
	{
		// Reset playlist if requested by state transition
		if(m_resetPlaylist)
		{
			m_pPlaylists->ResetPlaylist(m_newPlaylist);
			m_resetPlaylist = false;
		}
		pElement = m_pPlaylists->GetPlaylistElement(m_newPlaylist, k_nSelectionUnforced);
	}

	if(pElement)
	{
		m_newPlaylistElement = *pElement;

		// Bypass element parameters by rule parameters
		m_newPlaylistElement.m_entryPointType = pRule->m_entryPointType;
		m_newPlaylistElement.m_playPreEntry = pRule->m_playPreEntry;
		// NOTE : Rule sets 'playPostExit' value directly to 'old segment' in UpdateOldSegmentState()
	}
	else // No new element to play.
	{
		m_newPlaylistElement.m_segmentIndex = NATIVE_SEGMENT_NONE;
	}
}



void VoxNativeSubDecoder::Clean(void)
{
	if(s_pMixingBuffer)
	{
		VOX_FREE(s_pMixingBuffer);
		s_pMixingBuffer = 0;
		s_nbMixingBufferBytes = 0;
	}
}


s32 VoxNativeSubDecoder::Decode(void* outputBuffer, s32 nbBytes)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoder::Decode", vox::VoxThread::GetCurThreadId());

	s32 nbBytesDecoded;
	s32 nbFrames = m_audioFormat.m_nbChannels * (m_audioFormat.m_bitsPerSample >> 3);

	// Insure that the number of bytes decoded is a multiple of the number of bytes per frame
	nbBytes -= nbBytes % nbFrames;

	// If segment mixing is expected, verify if it should be done during current decode pass.
	if(m_mixingStartPosition >= 0)
	{
		s32 nbSamplesDesired = nbBytes / nbFrames;

		// If mixing position is contained in current decode pass, start mixing segments
		if(m_mixingStartPosition <= (s32) m_currentSegmentState.m_totalSamplesDecoded + nbSamplesDesired)
		{
			m_currentSegmentOffset = m_mixingStartPosition - m_currentSegmentState.m_totalSamplesDecoded;
			UpdateSegmentsStates();
		}
	}

	// Perform actual segments decoding
	if(m_nbSegmentsPlaying > 1)
	{
		nbBytesDecoded = MixMultipleSegments((s16 *) outputBuffer, nbBytes);
	}
	else if(m_nbSegmentsPlaying == 1)
	{
		if(m_currentSegmentState.m_fadeParameters.m_nbSamplesRemaining > 0)
		{
			nbBytesDecoded = MixMultipleSegments((s16 *) outputBuffer, nbBytes);
		}
		else
		{
			nbBytesDecoded = DecodeSegment(outputBuffer, nbBytes, &m_currentSegmentState);
		}
	}

	// Release segments that should be stopped (or have been prematuraly forced to stop)
	if(m_dyingSegmentState.m_playbackState <= NATIVE_STATE_STOPPED)
	{
		StopSegment(&m_dyingSegmentState);
	}
	if(m_oldSegmentState.m_playbackState <= NATIVE_STATE_STOPPED)
	{
		StopSegment(&m_oldSegmentState);
	}
	if(m_currentSegmentState.m_playbackState <= NATIVE_STATE_STOPPED)
	{
		StopSegment(&m_currentSegmentState);
	}

	return nbBytesDecoded;
}


#if VOX_NATIVE_REDUCE_LATENCY

// This method emulates a decode without file access, buffer creation of filling.
// However, it puts the subdecoder in the same state as if a decode has been done.

s32 VoxNativeSubDecoder::EmulateDecode(s32 nbBytes)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoder::EmulateDecode", vox::VoxThread::GetCurThreadId());

	s16 compressionCode = m_audioFormat.m_compressionCode;
	s32 nbBytesDecoded;
	s32 nbFrames = m_audioFormat.m_nbChannels * (m_audioFormat.m_bitsPerSample >> 3);

	// Insure that the number of bytes decoded is a multiple of the number of bytes per frame
	nbBytes -= nbBytes % nbFrames;

	// If segment mixing is expected, verify if it should be done during current decode pass.
	if(m_mixingStartPosition >= 0)
	{
		s32 nbSamplesDesired = nbBytes / nbFrames;

		// If mixing position is contained in current decode pass, start mixing segments
		if(m_mixingStartPosition <= (s32) m_currentSegmentState.m_totalSamplesDecoded + nbSamplesDesired)
		{
			m_currentSegmentOffset = m_mixingStartPosition - m_currentSegmentState.m_totalSamplesDecoded;
			UpdateSegmentsStates();
		}
	}

	// Perform actual segments decoding
	if(m_nbSegmentsPlaying == 1)
	{
		if(m_currentSegmentState.m_fadeParameters.m_nbSamplesRemaining > 0)
		{
			nbBytesDecoded = EmulateMixMultipleSegments(nbBytes);
		}
		else
		{
			nbBytesDecoded = EmulateDecodeSegment(nbBytes, &m_currentSegmentState);
		}
	}
	else if(m_nbSegmentsPlaying > 1)
	{
		nbBytesDecoded = EmulateMixMultipleSegments(nbBytes);
	}

	// Release segments that should be stopped (or have been prematuraly forced to stop)
	if(m_dyingSegmentState.m_playbackState <= NATIVE_STATE_STOPPED)
	{
		StopSegment(&m_dyingSegmentState);
	}

	if(m_oldSegmentState.m_playbackState <= NATIVE_STATE_STOPPED)
	{
		StopSegment(&m_oldSegmentState);
	}

	if(m_currentSegmentState.m_playbackState <= NATIVE_STATE_STOPPED)
	{
		StopSegment(&m_currentSegmentState);
	}

	// If adpcm, reset decode buffer cursors.
	if(compressionCode == k_ccIMAADPCM || compressionCode == k_ccMSADPCM)
	{
		if(m_dyingSegmentState.m_playbackState == NATIVE_STATE_PLAYING)
		{
			m_dyingSegmentState.m_setAdpcmBufferCursor = true;
		}
		if(m_oldSegmentState.m_playbackState == NATIVE_STATE_PLAYING)
		{
			m_oldSegmentState.m_setAdpcmBufferCursor = true;
		}
		if(m_currentSegmentState.m_playbackState == NATIVE_STATE_PLAYING)
		{
			m_currentSegmentState.m_setAdpcmBufferCursor = true;
		}
	}

	return nbBytesDecoded;
}


s32 VoxNativeSubDecoder::EmulateMixMultipleSegments(s32 nbBytes)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoder::EmulateMixMultipleSegments", vox::VoxThread::GetCurThreadId());

	s32 nbBytesDecoded;
	s32 maxBytesDecoded = 0;

	// Decode dying segment if any
	if(m_dyingSegmentState.m_playbackState >= NATIVE_STATE_PLAYING)
	{
		nbBytesDecoded = EmulateDecodeSegment(nbBytes, &m_dyingSegmentState);
		EmulateMixSegmentInBuffer(nbBytesDecoded, &m_dyingSegmentState);
		maxBytesDecoded = nbBytesDecoded;
	}

	// Decode old segment if any
	if(m_oldSegmentState.m_playbackState >= NATIVE_STATE_PLAYING)
	{
		nbBytesDecoded = EmulateDecodeSegment(nbBytes, &m_oldSegmentState);
		if(nbBytesDecoded > maxBytesDecoded)
		{
			maxBytesDecoded = nbBytesDecoded;
		}
		EmulateMixSegmentInBuffer(nbBytesDecoded, &m_oldSegmentState);
	}

	// Decode current segment
	nbBytesDecoded = EmulateDecodeCurrentSegmentWithOffset(nbBytes);
	if(nbBytesDecoded > maxBytesDecoded)
	{
		maxBytesDecoded = nbBytesDecoded;
	}
	EmulateMixSegmentInBuffer(nbBytesDecoded, &m_currentSegmentState);

	return maxBytesDecoded;
}


void VoxNativeSubDecoder::EmulateMixSegmentInBuffer(s32 nbBytesDecoded, SegmentState *pSegmentState)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoder::EmulateMixSegmentInBuffer", vox::VoxThread::GetCurThreadId());

	s16 nbChannels = m_audioFormat.m_nbChannels;

	FadeParameters fade = pSegmentState->m_fadeParameters;

	s32 nbSamplesDecoded = nbBytesDecoded / (nbChannels * (m_audioFormat.m_bitsPerSample >> 3));
	s32 fadeStartOffset = fade.m_startOffset;

	// Update the startOffset value for the next decode pass
	pSegmentState->m_fadeParameters.m_startOffset -= nbSamplesDecoded;
	if(pSegmentState->m_fadeParameters.m_startOffset < 0)
	{
		pSegmentState->m_fadeParameters.m_startOffset = 0;
	}

	// There are still samples before start of fade
	if(fadeStartOffset > 0)
	{
		nbSamplesDecoded -= (fadeStartOffset < nbSamplesDecoded ? fadeStartOffset: nbSamplesDecoded);
	}

	s32 nbSamplesFade = fade.m_nbSamplesRemaining;

	if(nbSamplesFade > 0)
	{
		if(nbSamplesFade > nbSamplesDecoded)
		{
			nbSamplesFade = nbSamplesDecoded;
			
			// If segment is dying, readjust gainChange according to nbSamplesFade readjustment.
			if(pSegmentState->m_lifeState == k_nSegmentDying)
			{
				fade.m_gainChange = -fade.m_gain / nbSamplesFade;
			}
		}

		fade.m_gain += fade.m_gainChange * nbSamplesFade;

		pSegmentState->m_fadeParameters.m_nbSamplesRemaining -= nbSamplesFade;
		if(pSegmentState->m_fadeParameters.m_nbSamplesRemaining < 0)
		{
			pSegmentState->m_fadeParameters.m_nbSamplesRemaining = 0;
		}

		pSegmentState->m_fadeParameters.m_gain = fade.m_gain;
	}

	// If segment has stopped fading, reset its fade parameters
	if(pSegmentState->m_fadeParameters.m_nbSamplesRemaining == 0)
	{
		pSegmentState->m_fadeParameters.Reset();

		// If segment was fading out, stop it.
		if(fade.m_gainChange < 0)
		{
			pSegmentState->m_playbackState = NATIVE_STATE_STOPPED;
		}
	}
	
	// If segment was dying, stop it.
	if(pSegmentState->m_lifeState == k_nSegmentDying)
	{
		pSegmentState->m_playbackState = NATIVE_STATE_STOPPED;
	}
}

#endif // VOX_NATIVE_REDUCE_LATENCY


// When multiple segments are playing at once and a transition occurs, this method
// determines whether the current or the old segment should die based upon the fade
// volume when transition entry point is same time or based upon cursor position
// when transition entry point is a cue.

s32 VoxNativeSubDecoder::GetNextDyingSegmentLifeState(void)
{
	s32 lifeState = k_nSegmentOld;
	
	if(m_nbSegmentsPlaying > 1)
	{
		if(m_currentPlaylistElement.m_entryPointType == k_nEntrySameTime)
		{
			// If new segment is triggered by state change, segment whose fade gain is the lowest goes dying
			if(m_newState != m_currentState && m_currentSegmentState.m_fadeParameters.m_gain < m_oldSegmentState.m_fadeParameters.m_gain)
			{
				lifeState = k_nSegmentCurrent;
			}
		}
		else // k_nEntryPreEntryCue : Segment whose cursor is not in body goes dying
		{				
			if(m_currentPlaylistElement.m_playPreEntry == 1)
			{
				if((s32) m_currentSegmentState.m_totalSamplesDecoded < (*m_pSegmentsCues)[m_currentSegmentState.m_index][NATIVE_CUE_PRE_ENTRY])
				{
					lifeState = k_nSegmentCurrent;
				}
			}
		}
	}

	return lifeState;
}


TrackParams VoxNativeSubDecoder::GetTrackParams(void)
{
	TrackParams parameters;

	parameters.numChannels = m_audioFormat.m_nbChannels;
	parameters.samplingRate = m_audioFormat.m_sampleRate;
	parameters.bitsPerSample = m_audioFormat.m_bitsPerSample;
	parameters.numSamples = 0;

	return parameters;
}



bool VoxNativeSubDecoder::HasData()
{
	return m_hasData;
}



void VoxNativeSubDecoder::InterpretTransitionRule(s32 ruleIndex)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoder::InterpretTransitionRule", vox::VoxThread::GetCurThreadId());

	TransitionRule *pRule = &m_pTransitionRules->m_pBuffer[ruleIndex];

	if(pRule->m_exitPointType == k_nExitImmediate)
	{
		UpdateSegmentsStates();
	}
	else // Rule is not immediate, get relevant parameters while waiting to apply rule
	{
		s32 playlistIndex = m_pStates->m_pPlaylistIndexes[m_newState];
		PlaylistElement *pNextElement = m_pPlaylists->PeekAtNextPlaylistElement(playlistIndex);
		if(pNextElement)
		{
			// Inspect next playlist element to get its starting position (relative to current segment).
			if(pNextElement->m_playPreEntry == 1)
			{
				m_mixingStartPosition = (*m_pSegmentsCues)[m_currentSegmentState.m_index][NATIVE_CUE_POST_EXIT] -
									    (*m_pSegmentsCues)[pNextElement->m_segmentIndex][NATIVE_CUE_PRE_ENTRY];
			}
			else
			{
				m_mixingStartPosition = (*m_pSegmentsCues)[m_currentSegmentState.m_index][NATIVE_CUE_POST_EXIT];
			}
		}
		else
		{
			UpdateSegmentsStates();
		}
	}
}


bool VoxNativeSubDecoder::IsExtraSegmentNeeded(TransitionRule *pRule)
{
	if(m_nbSegmentsPlaying > 0)
	{
		if(pRule)
		{
			if(pRule->m_exitPointType == k_nExitImmediate)
			{
				if(pRule->m_fadeOutLength > 0.0f)
				{
					return true;
				}
			}
			else
			{
				return true;
			}
		}
		else // Case when playlist is played with no interference from rule.
		{
			if(m_currentPlaylistElement.m_playPostExit == 1 || m_newPlaylistElement.m_playPreEntry == 1)
			{
				return true;
			}
		}
	}
	else if(m_nbSegmentsPlaying == 0)
	{
		return true;
	}

	return false;
}



s32 VoxNativeSubDecoder::MixMultipleSegments(s16* outputBuffer, s32 nbBytes)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoder::MixMultipleSegments", vox::VoxThread::GetCurThreadId());

	s32 nbBytesDecoded;
	s32 maxBytesDecoded = 0;

	s32 nbSamplesDesired = nbBytes / (m_audioFormat.m_nbChannels * (m_audioFormat.m_bitsPerSample >> 3));
	s32 nbMixingBufferBytesDesired = (nbBytes << 1); // << 1 to compensate for s16 -> s32

	// If current mixing buffer is not large enough, reallocate a larger one.
	if(nbMixingBufferBytesDesired > s_nbMixingBufferBytes)
	{
		if(s_pMixingBuffer)
		{
			VOX_FREE(s_pMixingBuffer);
		}
	
		s_pMixingBuffer = (s32*) VOX_ALLOC(nbMixingBufferBytesDesired);

		if(s_pMixingBuffer)
		{
			s_nbMixingBufferBytes = nbMixingBufferBytesDesired;
		}
		else // No mixing buffer, stop all segments.
		{
			s_nbMixingBufferBytes = 0;
			m_dyingSegmentState.m_playbackState = NATIVE_STATE_STOPPED;
			m_oldSegmentState.m_playbackState = NATIVE_STATE_STOPPED;
			m_currentSegmentState.m_playbackState = NATIVE_STATE_STOPPED;
			return 0;
		}
	}
	
	// Clear mixing buffer.
	memset(s_pMixingBuffer, 0, s_nbMixingBufferBytes);

	// Decode dying segment if any
	if(m_dyingSegmentState.m_playbackState >= NATIVE_STATE_PLAYING)
	{
		nbBytesDecoded = DecodeSegment(outputBuffer, nbBytes, &m_dyingSegmentState);
		MixSegmentInBuffer(outputBuffer, nbBytesDecoded, &m_dyingSegmentState);
		maxBytesDecoded = nbBytesDecoded;
	}

	// Decode old segment if any
	if(m_oldSegmentState.m_playbackState >= NATIVE_STATE_PLAYING)
	{
		nbBytesDecoded = DecodeSegment(outputBuffer, nbBytes, &m_oldSegmentState);
		if(nbBytesDecoded > maxBytesDecoded)
		{
			maxBytesDecoded = nbBytesDecoded;
		}
		MixSegmentInBuffer(outputBuffer, nbBytesDecoded, &m_oldSegmentState);
	}

	// Decode current segment
	nbBytesDecoded = DecodeCurrentSegmentWithOffset(outputBuffer, nbBytes);
	if(nbBytesDecoded > maxBytesDecoded)
	{
		maxBytesDecoded = nbBytesDecoded;
	}
	MixSegmentInBuffer(outputBuffer, nbBytesDecoded, &m_currentSegmentState);

	// Create cursors to transfer samples from decoding buffers into mixing buffer
	s32 *pMixingBufferCursor = s_pMixingBuffer;
	s16 *pOutputBufferCursor = (s16 *) outputBuffer;
	
	s32 totalSamples = nbSamplesDesired * m_audioFormat.m_nbChannels;

	// Put content of mixing buffer back into outputBuffer
	for(int i = 0; i < totalSamples; i++)
	{
		if ((u32) (*pMixingBufferCursor + 32768) > 65535)
			*pOutputBufferCursor = (s16)(*pMixingBufferCursor < 0 ? -32768 : 32767);
		else
			*pOutputBufferCursor = (s16) (*pMixingBufferCursor);
		pOutputBufferCursor++;
		pMixingBufferCursor++;
	}

	return maxBytesDecoded;
}


void VoxNativeSubDecoder::MixSegmentInBuffer(s16* outputBuffer, s32 nbBytesDecoded, SegmentState *pSegmentState)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoder::MixSegmentInBuffer", vox::VoxThread::GetCurThreadId());

	s32 fadeGain;
	s32 i;
	s32 *pMixingBufferCursor = s_pMixingBuffer;
	s16 *pOutputBufferCursor = outputBuffer; 
	s16 nbChannels = m_audioFormat.m_nbChannels;

	FadeParameters fade = pSegmentState->m_fadeParameters;

	s32 nbSamplesDecoded = nbBytesDecoded / (nbChannels * (m_audioFormat.m_bitsPerSample >> 3));
	s32 fadeStartOffset = fade.m_startOffset;

	// Update the startOffset value for the next decode pass
	pSegmentState->m_fadeParameters.m_startOffset -= nbSamplesDecoded;
	if(pSegmentState->m_fadeParameters.m_startOffset < 0)
	{
		pSegmentState->m_fadeParameters.m_startOffset = 0;
	}

	// There are still samples before start of fade
	if(fadeStartOffset > 0)
	{
		s32 nbSamplesWithoutFade = fadeStartOffset < nbSamplesDecoded ? fadeStartOffset: nbSamplesDecoded;
		s32 totalSamplesWithoutFade = nbSamplesWithoutFade * nbChannels;

		if(fade.m_gainChange < 0) // Fade out : Don't fade the first 'nbSamplesWithoutFade' samples
		{
			for(i = 0; i < totalSamplesWithoutFade; i++)
			{
				*pMixingBufferCursor += (s32) (*pOutputBufferCursor);
				pMixingBufferCursor++;
				pOutputBufferCursor++;
			}
		}
		else // Fade in : Skip the first 'nbSamplesWithoutFade' samples
		{
			pMixingBufferCursor = s_pMixingBuffer + totalSamplesWithoutFade;
			pOutputBufferCursor = outputBuffer + totalSamplesWithoutFade;
		}

		nbSamplesDecoded -= nbSamplesWithoutFade;
	}

	s32 totalSamplesDecoded = nbSamplesDecoded * nbChannels;
	s32 nbSamplesFade = fade.m_nbSamplesRemaining;
	s32 totalSamplesToFade = nbSamplesFade * nbChannels;

	if(nbSamplesFade > 0)
	{
		if(nbSamplesFade > nbSamplesDecoded)
		{
			nbSamplesFade = nbSamplesDecoded;
			totalSamplesToFade = nbSamplesFade * nbChannels;
			
			// If segment is dying, readjust gainChange according to nbSamplesFade readjustment.
			if(pSegmentState->m_lifeState == k_nSegmentDying)
			{
				fade.m_gainChange = -fade.m_gain / nbSamplesFade;
			}
		}

		for(i = 1; i <= totalSamplesToFade; i++)
		{
			fadeGain = fade.m_gain >> VOX_FX1715_FRACT_SHIFT;
			*pMixingBufferCursor += ((*pOutputBufferCursor) * fadeGain) >> VOX_FX1715_FRACT_SHIFT;
			pMixingBufferCursor++;
			pOutputBufferCursor++;
			if(i % nbChannels == 0)
			{
				fade.m_gain += fade.m_gainChange;
			}
		}

		pSegmentState->m_fadeParameters.m_nbSamplesRemaining -= nbSamplesFade;
		if(pSegmentState->m_fadeParameters.m_nbSamplesRemaining < 0)
		{
			pSegmentState->m_fadeParameters.m_nbSamplesRemaining = 0;
		}

		pSegmentState->m_fadeParameters.m_gain = fade.m_gain;
	}

	// If segment has stopped fading, reset its fade parameters
	if(pSegmentState->m_fadeParameters.m_nbSamplesRemaining == 0)
	{
		pSegmentState->m_fadeParameters.Reset();

		// If segment was fading out, stop it.
		if(fade.m_gainChange < 0)
		{
			pSegmentState->m_playbackState = NATIVE_STATE_STOPPED;
		}
		else // When fade-in is done, fill rest of buffer with unaltered samples
		{
			for(i = totalSamplesToFade + 1; i <= totalSamplesDecoded; i++)
			{
				*pMixingBufferCursor += (s32) (*pOutputBufferCursor);
				pMixingBufferCursor++;
				pOutputBufferCursor++;
			}
		}
	}
	
	// If segment was dying, stop it.
	if(pSegmentState->m_lifeState == k_nSegmentDying)
	{
		pSegmentState->m_playbackState = NATIVE_STATE_STOPPED;
	}
}


void VoxNativeSubDecoder::Reset(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoder::Reset", vox::VoxThread::GetCurThreadId());

	s32 nbPlaylists = m_pPlaylists->GetNbPlaylists();
	for(s32 i = 0; i < nbPlaylists; i++)
	{
		m_pPlaylists->ResetPlaylist(i);
	}

	m_hasData = true;
	m_nbSegmentsPlaying = 0;
	m_mixingStartPosition = -1;
	m_currentSegmentOffset = 0;
	m_currentRule = NATIVE_RULE_NONE;
	m_newRule = NATIVE_RULE_NONE;
	m_oldPlaylist = -1;
	m_currentPlaylist = -1;
	m_newPlaylist = -1;
	m_resetPlaylist = true;
	m_oldState = NATIVE_STATE_NONE;
	m_currentState = NATIVE_STATE_NONE;
	m_newState = NATIVE_STATE_NONE;

	m_currentSegmentState.m_index = -1;
	m_currentSegmentState.m_lifeState = k_nSegmentCurrent;
	m_currentSegmentState.m_position = 0;
	m_oldSegmentState.m_index = -1;
	m_oldSegmentState.m_lifeState = k_nSegmentOld;
	m_oldSegmentState.m_position = 0;
	m_dyingSegmentState.m_index = -1;
	m_dyingSegmentState.m_lifeState = k_nSegmentDying;
	m_dyingSegmentState.m_position = 0;

	m_oldPlaylistElement.Reset();
	m_currentPlaylistElement.Reset();
	m_newPlaylistElement.Reset();
}


#if VOX_NATIVE_REDUCE_LATENCY

void VoxNativeSubDecoder::GetState(NativeSubDecoderState *pState)
{
	pState->m_pPlaylists->SetState(*m_pPlaylists);

	pState->m_oldState = m_oldState;
	pState->m_currentState = m_currentState;
	pState->m_newState = m_newState;

	pState->m_oldPlaylist = m_oldPlaylist;
	pState->m_currentPlaylist = m_currentPlaylist;
	pState->m_newPlaylist = m_newPlaylist;
	pState->m_resetPlaylist = m_resetPlaylist;

	pState->m_oldPlaylistElement.m_segmentIndex = m_oldPlaylistElement.m_segmentIndex;
	pState->m_oldPlaylistElement.m_entryPointType = m_oldPlaylistElement.m_entryPointType;
	pState->m_oldPlaylistElement.m_playPreEntry = m_oldPlaylistElement.m_playPreEntry;
	pState->m_oldPlaylistElement.m_playPostExit = m_oldPlaylistElement.m_playPostExit;
	pState->m_oldPlaylistElement.m_nbLoops = m_oldPlaylistElement.m_nbLoops;

	pState->m_currentPlaylistElement.m_segmentIndex = m_currentPlaylistElement.m_segmentIndex;
	pState->m_currentPlaylistElement.m_entryPointType = m_currentPlaylistElement.m_entryPointType;
	pState->m_currentPlaylistElement.m_playPreEntry = m_currentPlaylistElement.m_playPreEntry;
	pState->m_currentPlaylistElement.m_playPostExit = m_currentPlaylistElement.m_playPostExit;
	pState->m_currentPlaylistElement.m_nbLoops = m_currentPlaylistElement.m_nbLoops;

	pState->m_newPlaylistElement.m_segmentIndex = m_newPlaylistElement.m_segmentIndex;
	pState->m_newPlaylistElement.m_entryPointType = m_newPlaylistElement.m_entryPointType;
	pState->m_newPlaylistElement.m_playPreEntry = m_newPlaylistElement.m_playPreEntry;
	pState->m_newPlaylistElement.m_playPostExit = m_newPlaylistElement.m_playPostExit;
	pState->m_newPlaylistElement.m_nbLoops = m_newPlaylistElement.m_nbLoops;

	pState->m_currentRule = m_currentRule;
	pState->m_newRule = m_newRule;
	
	pState->m_nbSegmentsPlaying = m_nbSegmentsPlaying;
	pState->m_dyingSegmentState = m_dyingSegmentState;
	pState->m_oldSegmentState = m_oldSegmentState;
	pState->m_currentSegmentState = m_currentSegmentState;
	pState->m_mixingStartPosition = m_mixingStartPosition;
	pState->m_currentSegmentOffset = m_currentSegmentOffset;
	pState->m_hasData = m_hasData;
}

void VoxNativeSubDecoder::SetState(NativeSubDecoderState *pState)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoder::SetState::NativeSubDecoderState", vox::VoxThread::GetCurThreadId());

	m_pPlaylists->SetState(*pState->m_pPlaylists);

	m_oldState = pState->m_oldState;
	m_currentState = pState->m_currentState;
	m_newState = pState->m_newState;

	m_oldPlaylist = pState->m_oldPlaylist;
	m_currentPlaylist = pState->m_currentPlaylist;
	m_newPlaylist = pState->m_newPlaylist;
	m_resetPlaylist = pState->m_resetPlaylist;

	m_oldPlaylistElement.m_segmentIndex = pState->m_oldPlaylistElement.m_segmentIndex;
	m_oldPlaylistElement.m_entryPointType = pState->m_oldPlaylistElement.m_entryPointType;
	m_oldPlaylistElement.m_playPreEntry = pState->m_oldPlaylistElement.m_playPreEntry;
	m_oldPlaylistElement.m_playPostExit = pState->m_oldPlaylistElement.m_playPostExit;
	m_oldPlaylistElement.m_nbLoops = pState->m_oldPlaylistElement.m_nbLoops;

	m_currentPlaylistElement.m_segmentIndex = pState->m_currentPlaylistElement.m_segmentIndex;
	m_currentPlaylistElement.m_entryPointType = pState->m_currentPlaylistElement.m_entryPointType;
	m_currentPlaylistElement.m_playPreEntry = pState->m_currentPlaylistElement.m_playPreEntry;
	m_currentPlaylistElement.m_playPostExit = pState->m_currentPlaylistElement.m_playPostExit;
	m_currentPlaylistElement.m_nbLoops = pState->m_currentPlaylistElement.m_nbLoops;

	m_newPlaylistElement.m_segmentIndex = pState->m_newPlaylistElement.m_segmentIndex;
	m_newPlaylistElement.m_entryPointType = pState->m_newPlaylistElement.m_entryPointType;
	m_newPlaylistElement.m_playPreEntry = pState->m_newPlaylistElement.m_playPreEntry;
	m_newPlaylistElement.m_playPostExit = pState->m_newPlaylistElement.m_playPostExit;
	m_newPlaylistElement.m_nbLoops = pState->m_newPlaylistElement.m_nbLoops;

	m_currentRule = pState->m_currentRule;
	m_newRule = pState->m_newRule;
	
	m_nbSegmentsPlaying = pState->m_nbSegmentsPlaying;
	m_dyingSegmentState = pState->m_dyingSegmentState;
	m_oldSegmentState = pState->m_oldSegmentState;
	m_currentSegmentState = pState->m_currentSegmentState;
	m_mixingStartPosition = pState->m_mixingStartPosition;
	m_currentSegmentOffset = pState->m_currentSegmentOffset;
	m_hasData = pState->m_hasData;
}

#endif // VOX_NATIVE_REDUCE_LATENCY


void VoxNativeSubDecoder::SetState(s32 stateIndex)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoder::SetState::s32", vox::VoxThread::GetCurThreadId());

	m_newState = stateIndex;

	if(m_currentState >= 0)
	{
		// Get rule and verify if new playlist should be resetted
		m_newRule = (*m_pTransitions)[m_currentState][m_newState].m_ruleIndex;
		m_resetPlaylist = ((*m_pTransitions)[m_currentState][m_newState].m_resetPlaylist) != 0;
	}

	m_newPlaylist = m_pStates->m_pPlaylistIndexes[m_newState];

	if(m_newRule >= 0)
	{
		InterpretTransitionRule(m_newRule);
	}
	else if(m_currentState == NATIVE_STATE_NONE) // Case : start of file playback -> no rule available.
	{
		UpdateSegmentsStates();
	}
}


void VoxNativeSubDecoder::StopSegment(SegmentState *pSegmentState)
{
	// If format is IMA-Adpcm, release decoding buffer used by current segment.
	if(m_audioFormat.m_compressionCode == k_ccIMAADPCM || m_audioFormat.m_compressionCode == k_ccMSADPCM)
	{
		ReleaseDecodingBuffer(pSegmentState->m_adpcmBufferIndex);
	}
		
	// If playbackState = NATIVE_STATE_FORCED_STOP, don't decrement nbSegmentsPlaying because it has been done.
	if(pSegmentState->m_playbackState == NATIVE_STATE_STOPPED)
	{
		m_nbSegmentsPlaying--;
	}

	// If current segment stops playing, then decoder has no more data to provide.
	if(pSegmentState->m_lifeState == k_nSegmentCurrent)
	{
		m_hasData = false;
	}
	pSegmentState->Reset();
}



void VoxNativeSubDecoder::SwapOldAndCurrentSegments(void)
{
	SegmentState tempSegmentState;

	tempSegmentState = m_currentSegmentState;
	m_currentSegmentState = m_oldSegmentState;
	m_currentSegmentState.m_lifeState = k_nSegmentCurrent;
	m_oldSegmentState = tempSegmentState;
	m_oldSegmentState.m_lifeState = k_nSegmentOld;
}



void VoxNativeSubDecoder::UpdateCurrentSegmentState(TransitionRule *pRule, bool isExtraSegmentNeeded)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoder::UpdateCurrentSegmentState", vox::VoxThread::GetCurThreadId());

	s32 segmentIndex = m_newPlaylistElement.m_segmentIndex;

	// If there is no new segment to play, let the current segment terminate its playback.
	if(segmentIndex == NATIVE_SEGMENT_NONE) 
	{
		m_currentSegmentState.m_nbLoops = 1;
		m_currentSegmentState.m_nbLoopsRemaining = 1;
		m_currentSegmentState.m_playbackState = NATIVE_STATE_STOPPING;
		m_mixingStartPosition = -1;
	}
	else
	{
		if(m_newPlaylistElement.m_entryPointType == k_nEntrySameTime)
		{
			// Update segment index. Other values are inherited from previous current segment.
			m_currentSegmentState.m_index = segmentIndex;

			// Readjust byte position since current decode block has to be redecoded.
			m_currentSegmentState.m_position = GetBytePositionFromSampleOffset(m_currentSegmentState.m_totalSamplesDecoded);
		}
		else // entryPointType = k_nEntryPreEntryCue
		{
			s32 startCueIndex = m_newPlaylistElement.m_playPreEntry == 1 ? NATIVE_CUE_SEGMENT_START : NATIVE_CUE_PRE_ENTRY;
			s32 endCueIndex = NATIVE_CUE_POST_EXIT;

			m_currentSegmentState.m_index = segmentIndex;
			m_currentSegmentState.m_startCue = (*m_pSegmentsCues)[segmentIndex][startCueIndex];
			m_currentSegmentState.m_endCue = (*m_pSegmentsCues)[segmentIndex][endCueIndex];
			m_currentSegmentState.m_nbLoops = m_newPlaylistElement.m_nbLoops;
			m_currentSegmentState.m_nbLoopsRemaining = m_currentSegmentState.m_nbLoops;
			m_currentSegmentState.m_playPostExit = m_newPlaylistElement.m_playPostExit;

			if(m_currentSegmentOffset >= 0)
			{
				m_currentSegmentState.m_totalSamplesDecoded = m_currentSegmentState.m_startCue;
			}
			else // Case when state change is too late to play full pre-entry of new segment (no zero padding).
			{
				m_currentSegmentState.m_totalSamplesDecoded = -m_currentSegmentOffset;
			}
			m_currentSegmentState.m_position = GetBytePositionFromSampleOffset(m_currentSegmentState.m_totalSamplesDecoded);
			m_currentSegmentState.m_playbackState = NATIVE_STATE_PLAYING;
		}

		if(isExtraSegmentNeeded && (m_audioFormat.m_compressionCode == k_ccIMAADPCM || m_audioFormat.m_compressionCode == k_ccMSADPCM))
		{
			m_currentSegmentState.m_adpcmBufferIndex = GetDecodingBuffer();
			m_currentSegmentState.m_setAdpcmBufferCursor = false;
		}
	}

	// If fade in of current segment is necessary, set the corresponding parameters.
	FadeParameters *pFade = &m_currentSegmentState.m_fadeParameters;

	if(!pRule)
	{
		pFade->Reset();
		return;
	}

	s32 sampleRate = m_audioFormat.m_sampleRate;
	pFade->m_nbSamples = (s32) (pRule->m_fadeInLength * sampleRate);
			
	// Set fade-in parameters
	if(pFade->m_nbSamples > 0)
	{
		s32 entryPointPosition = 0; // Position (in samples) where sound will start in current segment.

		switch(pRule->m_exitPointType)
		{
			case k_nExitImmediate:
			{
				// Evaluate nb of samples to wait before beginning to fade (starting at current decode)
				pFade->m_startOffset = (s32) ((pRule->m_fadeInOffset - pRule->m_fadeInLength) * sampleRate);

				if(m_newPlaylistElement.m_entryPointType == k_nEntryPreEntryCue)
				{	
					if(m_newPlaylistElement.m_playPreEntry == 0)
					{
						entryPointPosition = (*m_pSegmentsCues)[segmentIndex][NATIVE_CUE_PRE_ENTRY];
					}
				}
				else // entryPointType = k_nEntrySameTime
				{
					entryPointPosition = m_currentSegmentState.m_totalSamplesDecoded;
				}
				break;
			}	
			case k_nExitPostExitCue:
			{
				if(m_newPlaylistElement.m_entryPointType == k_nEntryPreEntryCue)
				{
					s32 segmentStartOffset;
					s32 preEntryLength = (*m_pSegmentsCues)[segmentIndex][NATIVE_CUE_PRE_ENTRY];
					s32 fadeInOffset = (s32) (pRule->m_fadeInOffset * sampleRate);

					if(m_newPlaylistElement.m_playPreEntry == 1)
					{
						// Calculate the distance between segment start and fade start (in samples)
						segmentStartOffset = preEntryLength - pFade->m_nbSamples + fadeInOffset;
					}
					else
					{
						entryPointPosition = (*m_pSegmentsCues)[segmentIndex][NATIVE_CUE_PRE_ENTRY];

						// Calculate the distance between segment start and fade start (in samples)
						segmentStartOffset = fadeInOffset - pFade->m_nbSamples;
					}

					// Evaluate nb of samples to wait before beginning to fade (starting at current decode)
					pFade->m_startOffset = m_currentSegmentOffset + segmentStartOffset;
				}
				break;
			}	
			case k_nExitNextGrid:
			{
				// TODO : Calculate pFade->m_startOffset and entryPointPosition
				break;
			}
			case k_nExitNextBar:
			{
				// TODO : Calculate pFade->m_startOffset and entryPointPosition
				break;
			}
			case k_nExitNextBeat:
			{
				// TODO : Calculate pFade->m_startOffset and entryPointPosition
				break;
			}
			case k_nExitNextCue:
			{
				// TODO : Calculate pFade->m_startOffset and entryPointPosition
				break;
			}
			case k_nExitCustomCue:
			{
				// TODO : Calculate pFade->m_startOffset and entryPointPosition
				break;
			}
		}

		// If fade-in starts earlier than data, shorten it consequently.
		if(pFade->m_startOffset < 0)
		{
			pFade->m_nbSamples += pFade->m_startOffset;
			pFade->m_startOffset = 0;
			if(pFade->m_nbSamples < 0)
			{
				pFade->m_nbSamples = 0;
			}
		}

		// If not looping and fade-in exceeds segment playback end, shorten it consequently
		if(m_currentSegmentState.m_nbLoopsRemaining == 1)
		{
			u32 playbackEndPosition;
			SIMPLE_VECTOR(s32) cuesVector = (*m_pSegmentsCues)[m_currentSegmentState.m_index];
			s32 cuesVectorSize = (s32) cuesVector.size();

			// Determine position where playback of current segment will end
			if(pRule->m_playPostExit == 1)
			{
				playbackEndPosition =  (*m_pSegmentsCues)[m_currentSegmentState.m_index][cuesVectorSize-1];
			}
			else
			{
				playbackEndPosition =  (*m_pSegmentsCues)[m_currentSegmentState.m_index][2];
			}

			s32 nbSamplesLeftToPlay = playbackEndPosition - entryPointPosition + 1;
			if(pFade->m_nbSamples > nbSamplesLeftToPlay)
			{
				pFade->m_nbSamples = nbSamplesLeftToPlay;
			}
		}

		pFade->m_nbSamplesRemaining = pFade->m_nbSamples;
		pFade->m_gainChange = (VOX_FX1715_ONE << VOX_FX1715_FRACT_SHIFT) / pFade->m_nbSamples;
		pFade->m_gain = 0;
	}
	else // No fade-in required, reset fade parameters.
	{
		pFade->Reset();
	}
}


// Dying segment only plays during one decode pass.

void VoxNativeSubDecoder::UpdateDyingSegmentState(TransitionRule *pRule)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoder::UpdateDyingSegmentState", vox::VoxThread::GetCurThreadId());

	m_dyingSegmentState = m_oldSegmentState;
	m_dyingSegmentState.m_lifeState = k_nSegmentDying;
	m_dyingSegmentState.m_playbackState = NATIVE_STATE_STOPPING;

	// Impose a small fade-out on dying segment.
	FadeParameters *pFade = &m_dyingSegmentState.m_fadeParameters;
	
	// Determine fade-out length so that it doesn't exceed segment playback end.
	u32 playbackEndPosition;
	SIMPLE_VECTOR(s32) cuesVector = (*m_pSegmentsCues)[m_dyingSegmentState.m_index];
	s32 cuesVectorSize = (s32) cuesVector.size();
	
	s32 nbSamplesFade = NATIVE_FORCED_FADE_LENGTH;

	// If segment was not fading, start with gain = 1.0, else inherit from segment's gain.
	if(m_oldSegmentState.m_fadeParameters.m_nbSamples == 0)
	{
		pFade->m_gain = VOX_FX1715_ONE << VOX_FX1715_FRACT_SHIFT;
	}
	else // Segment was fading, inherit fade length from its nb of fading samples remaining.
	{
		nbSamplesFade = pFade->m_nbSamplesRemaining;
	}

	// If there is a rule, bypass fade length according to rule's value.
	if(pRule)
	{
		nbSamplesFade = (s32) (pRule->m_fadeOutLength * m_audioFormat.m_sampleRate);
	}

	// Get segment's playback end position and determine the number of samples remaining.
	if(m_dyingSegmentState.m_playPostExit == 1)
	{
		playbackEndPosition =  (*m_pSegmentsCues)[m_oldSegmentState.m_index][cuesVectorSize-1];
	}
	else
	{
		playbackEndPosition =  (*m_pSegmentsCues)[m_oldSegmentState.m_index][2];
	}
	s32 nbSamplesLeftToPlay = playbackEndPosition - m_dyingSegmentState.m_totalSamplesDecoded + 1;

	// If fade length is longer than nb of samples remaining in segment, shorten it consequently.
	if(nbSamplesLeftToPlay < nbSamplesFade)
	{
		pFade->m_nbSamples = nbSamplesLeftToPlay;
	}
	else
	{
		pFade->m_nbSamples = nbSamplesFade;
	}

	pFade->m_nbSamplesRemaining = pFade->m_nbSamples;
	if(pFade->m_nbSamples > 0)
	{
		pFade->m_gainChange = -pFade->m_gain / pFade->m_nbSamples;
	}
}


void VoxNativeSubDecoder::UpdateOldSegmentState(TransitionRule *pRule)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoder::UpdateOldSegmentState", vox::VoxThread::GetCurThreadId());

	bool stopAtCuePoint = true;

	// Inherit state from current segment
	m_oldSegmentState = m_currentSegmentState;
	m_oldSegmentState.m_lifeState = k_nSegmentOld;

	// If fade out of old segment is necessary, set the corresponding parameters.
	FadeParameters *pFade = &m_oldSegmentState.m_fadeParameters;

	if(pRule)
	{
		m_oldSegmentState.m_playPostExit = pRule->m_playPostExit;
		s32 sampleRate = m_audioFormat.m_sampleRate;

		bool inheritSegmentFadeGain = pFade->m_nbSamples > 0 ? true : false;

		pFade->m_nbSamples = (s32) (pRule->m_fadeOutLength * sampleRate);

		// Set fade-out parameters.
		if(pFade->m_nbSamples > 0)
		{
			s32 exitPointPosition;
			s32 fadeOutOffset = (s32) (pRule->m_fadeOutOffset * sampleRate);
			SIMPLE_VECTOR(s32) cuesVector = (*m_pSegmentsCues)[m_oldSegmentState.m_index];
			s32 cuesVectorSize = (s32) cuesVector.size();

			// When exit type is immediate, let the segment looping (if it is), and
			// sound will be stopped at the end of fade-out rather than at cue point.
			if(pRule->m_exitPointType == k_nExitImmediate)
			{
				pFade->m_startOffset = fadeOutOffset;
				exitPointPosition = m_oldSegmentState.m_totalSamplesDecoded;

				if(m_oldSegmentState.m_nbLoopsRemaining != 1)
				{
					stopAtCuePoint = false;
				}
			}
			else
			{
				// Calculate actual exit point position relative to segment start
				switch(pRule->m_exitPointType)
				{
					case k_nExitPostExitCue:
					{
						exitPointPosition = (*m_pSegmentsCues)[m_oldSegmentState.m_index][NATIVE_CUE_POST_EXIT];
						break;
					}	
					case k_nExitNextGrid:
					{
						// TODO : Calculate actual exit point position relative to segment start
						break;
					}
					case k_nExitNextBar:
					{
						// TODO : Calculate actual exit point position relative to segment start
						break;
					}
					case k_nExitNextBeat:
					{
						// TODO : Calculate actual exit point position relative to segment start
						break;
					}
					case k_nExitNextCue:
					{
						u32 totalSamplesDecoded = m_oldSegmentState.m_totalSamplesDecoded;
						for(s32 i = 0; i < cuesVectorSize; i++)
						{
							// Find first cue whose position is larger than the number of samples decoded.
							if(cuesVector[i] > (s32) totalSamplesDecoded)
							{
								exitPointPosition = cuesVector[i];
								break;
							}
						}
						break;
					}
					case k_nExitCustomCue:
					{
						u32 totalSamplesDecoded = m_oldSegmentState.m_totalSamplesDecoded;
						// Start search after the 3rd cue (which is the post-exit cue).
						for(s32 i = 3; i < cuesVectorSize; i++)
						{
							// Find first cue whose position is larger than the number of samples decoded.
							if(cuesVector[i] > (s32) totalSamplesDecoded)
							{
								exitPointPosition = cuesVector[i];
								break;
							}
						}
						break;
					}
					case k_nExitImmediate:
					{
						// Already handled in the 'if' statement. Case explicit to avoid warning.
						break;
					}
				}
					
				pFade->m_startOffset = exitPointPosition - m_oldSegmentState.m_totalSamplesDecoded + fadeOutOffset;
			}

			// If state change is too late to start fade-out at desired position, shorten it consequently
			if(pFade->m_startOffset < 0)
			{
				pFade->m_nbSamples += pFade->m_startOffset;
				pFade->m_startOffset = 0;
				if(pFade->m_nbSamples < 0)
				{
					pFade->m_nbSamples = 0;
				}
			}

			// If stopping at cue point and fade-out exceeds that point, shorten fade-out consequently
			if(stopAtCuePoint)
			{
				u32 playbackEndPosition;
				if(pRule->m_playPostExit == 1)
				{
					playbackEndPosition =  (*m_pSegmentsCues)[m_oldSegmentState.m_index][cuesVectorSize-1];
				}
				else
				{
					playbackEndPosition =  (*m_pSegmentsCues)[m_oldSegmentState.m_index][2];
				}

				s32 nbSamplesLeftToPlay = playbackEndPosition - exitPointPosition + 1;

				if(pFade->m_nbSamples > nbSamplesLeftToPlay)
				{
					pFade->m_nbSamples = nbSamplesLeftToPlay;
				}
			}
		                   	
			pFade->m_nbSamplesRemaining = pFade->m_nbSamples;
			if(inheritSegmentFadeGain)
			{	
				pFade->m_gain = m_currentSegmentState.m_fadeParameters.m_gain;
			}
			else
			{
				pFade->m_gain = VOX_FX1715_ONE << VOX_FX1715_FRACT_SHIFT;
			}
			pFade->m_gainChange = -pFade->m_gain / pFade->m_nbSamples;
		}
		else
		{
			pFade->Reset();
		}
	}
	else
	{
		pFade->Reset();
	}

	if(stopAtCuePoint)
	{
		m_oldSegmentState.m_playbackState = NATIVE_STATE_STOPPING;
		m_oldSegmentState.m_nbLoops = 1;
		m_oldSegmentState.m_nbLoopsRemaining = 1;
	}
}



void VoxNativeSubDecoder::UpdateSegmentsStates(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoder::UpdateSegmentsStates", vox::VoxThread::GetCurThreadId());

	TransitionRule *pRule = 0;
	PlaylistElement *pElement;
	PlaylistElement *pNextElement;
	s32 segmentIndex = NATIVE_SEGMENT_NONE;

	// Get index of playlist associated with newState
 	s32 playlistIndex = m_pStates->m_pPlaylistIndexes[m_newState];

	// State has changed, get playlist element using a rule
	if(m_currentState != m_newState && m_currentState >= 0)
	{
		pRule = &m_pTransitionRules->m_pBuffer[m_newRule];
		ApplyTransitionRule(pRule);
	}
	else // State hasn't change, get playlist element without using a rule.
	{
		pElement = m_pPlaylists->GetPlaylistElement(playlistIndex, k_nSelectionUnforced);
		if(pElement)
		{
			m_newPlaylistElement = *pElement;
		}
		else
		{
			m_newPlaylistElement.m_segmentIndex = NATIVE_SEGMENT_NONE;
		}
	}
	
	segmentIndex = m_newPlaylistElement.m_segmentIndex;

	if(segmentIndex >= 0)
	{
		bool isExtraSegmentNeeded = IsExtraSegmentNeeded(pRule);

		// Increment nb of playing segments but do not allow more than 3.
		if(isExtraSegmentNeeded && m_nbSegmentsPlaying < 3)
		{
			m_nbSegmentsPlaying++;
		}

		if(m_nbSegmentsPlaying > 2)
		{
			UpdateDyingSegmentState(pRule);
			UpdateOldSegmentState(pRule);
		}
		else if(m_nbSegmentsPlaying > 1)
		{
			UpdateOldSegmentState(pRule);
		}
		UpdateCurrentSegmentState(pRule, isExtraSegmentNeeded);

		// Current segment's adpcm buffer will be decoded at start cue position in next decode.
		if(m_currentSegmentState.m_totalSamplesDecoded > 0)
		{
			m_currentSegmentState.m_setAdpcmBufferCursor = true;
		}

		// Inspect next playlist element to see where segment mixing is starting.
		if(m_currentSegmentState.m_nbLoopsRemaining == 1)
		{
			pNextElement = m_pPlaylists->PeekAtNextPlaylistElement(playlistIndex);
			if(pNextElement)
			{
				if(pNextElement->m_playPreEntry == 1 || m_newPlaylistElement.m_playPostExit == 1)
				{
					if(pNextElement->m_playPreEntry == 1)
					{
						m_mixingStartPosition = (*m_pSegmentsCues)[m_currentSegmentState.m_index][NATIVE_CUE_POST_EXIT] -
												(*m_pSegmentsCues)[pNextElement->m_segmentIndex][NATIVE_CUE_PRE_ENTRY];
					}
					else
					{
						m_mixingStartPosition = (*m_pSegmentsCues)[m_currentSegmentState.m_index][NATIVE_CUE_POST_EXIT];
					}
				}
			}
			else // No further segment to mix with current segment
			{
				m_mixingStartPosition = -1;
			}
		}
		else // Current segment is not finishing looping.
		{
			m_mixingStartPosition = -1;
		}
	}
	else if(segmentIndex == NATIVE_SEGMENT_NONE) // No more segment to play, terminate playback.
	{
		UpdateCurrentSegmentState(pRule, false);
	}

	// Update current parameters
	m_oldState = m_currentState;
	m_currentState = m_newState;
	m_oldPlaylist = m_currentPlaylist;
	m_currentPlaylist = m_newPlaylist;
	m_oldPlaylistElement = m_currentPlaylistElement;
	m_currentPlaylistElement = m_newPlaylistElement;
	m_currentRule = m_newRule;
}


} // End namespace vox
