#include "StdAfx.h"
#include "vox_filesystem_glf.h"

#if VOX_USE_GLF 

#include "vox_memory.h"
#include <glf/io.h>

namespace vox
{

/// Reads size bytes of data into buffer at ptr.
s32 readGLF( void * ptr, s32 size, s32 count, void * stream )
{
	return ((glf::FileStream*)stream)->Read(ptr, size * count)/size;
}

s32 writeGLF ( const void * ptr, s32 size, s32 count, void * stream )
{
	return ((glf::FileStream*)stream)->Write(ptr, size * count)/size;
}

/// Seeks to byte position offset.
s32 seekGLF ( void * stream, s32 offset, VoxFileSeekOrigin origin )
{
	//**-** GLF seek is void ... need to change
	((glf::FileStream*)stream)->Seek(offset, origin == k_nSeekEnd ? glf::ios::end : origin == k_nSeekCur ? glf::ios::cur : glf::ios::beg);
	return 0;
}

/// Returns the current byte offset in the stream.
s32 tellGLF ( void * stream )
{
	return (s32)((glf::FileStream*)stream)->Tell();
}

void* openGLF ( const c8 * filename, VoxFileAccessMode mode )
{
	glf::FileStream* file = VOX_NEW glf::FileStream();
	bool result = false;

	if(file)
	{
		switch(mode)
		{
			case k_nRead:
			case k_nReadBinary:
				result = file->Open(filename, glf::ios::read);
				break;
			case k_nCreateWrite:
			case k_nCreateWriteBinary:
				result = file->Open(filename, glf::ios::write | glf::ios::create);
				break;
			case k_nReadWrite:
			case k_nReadWriteBinary:
				result = file->Open(filename, glf::ios::read | glf::ios::write);
				break;
			case k_nCreateReadWrite:
			case k_nCreateReadWriteBinary:
				result = file->Open(filename, glf::ios::read | glf::ios::write | glf::ios::create);
				break;
			//case k_nAppend: //no supported
			//case k_nReadAndAppend:
			//case k_nAppendBinary:
			//case k_nReadAndAppendBinary:
			default:
				result = false;
		}
	}

	if(result)
	{
		return file;
	}
	else
	{
		VOX_DELETE(file);
	}

	return 0;
}

s32 closeGLF ( void * stream )
{
	((glf::FileStream*)stream)->Close();
	VOX_DELETE((glf::FileStream*)stream);
	return 0;
}

FileSystemInterface* VoxNewFileSystem()
{
	return VOX_NEW FileSystemGLF();
}

FileSystemGLF::FileSystemGLF()
{
	FileSystemInterface::m_IOFunc.open = openGLF;
	FileSystemInterface::m_IOFunc.close = closeGLF;
	FileSystemInterface::m_IOFunc.read = readGLF;
	FileSystemInterface::m_IOFunc.write = writeGLF;
	FileSystemInterface::m_IOFunc.seek = seekGLF;
	FileSystemInterface::m_IOFunc.tell = tellGLF;
}

FileSystemGLF::~FileSystemGLF()
{
}

//FileInterface* FileSystemGLF::OpenFile(c8* filename, VoxFileAccessMode mode)
//{
//	FileGLF* fileGLF = 0;
//	VOX_STRING fullpath;
//
//	if(m_directoriesStack.size() > 0)
//	{
//		fullpath = m_directoriesStack.back();
//	}
//
//	fullpath.append(filename);
//
//	glf::FileStream* file = VOX_NEW glf::FileStream();
//	
//	if(file)
//	{
//		if(file->Open(fullpath.c_str(), glf::ios::read))
//		{
//			fileGLF = VOX_NEW FileGLF((void*)file);
//		}
//		else
//		{
//			VOX_DELETE(file);
//		}
//	}
//
//	return fileGLF;
//}
//
//s32 FileSystemGLF::CloseFile(FileInterface* filePtr)
//{
//	if(filePtr)
//	{
//		glf::FileStream* file = (glf::FileStream*)((FileGLF*)filePtr)->GetFilePtr();
//		if(file)
//		{
//			((glf::FileStream*)file)->Close();
//			VOX_DELETE(file);
//		}
//		VOX_DELETE(filePtr);
//		return 0;
//	}
//
//	return -1;
//}

}
#endif //VOX_USE_GLF
