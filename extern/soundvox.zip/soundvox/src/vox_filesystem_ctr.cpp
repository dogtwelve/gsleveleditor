#include "StdAfx.h"
#include "vox_filesystem_ctr.h"

#if defined(_NN_CTR)

#include "vox_memory.h"
#include <stdio.h>
#include <string.h>

namespace vox
{

// User is responsible of allocating wszStr big enough for the convertion
void ConvertCharToWChar(const c8* szStr, wchar_t* wszStr)
{
	wszStr[0] = 0;
	if(szStr)
	{
		s32 len = strlen(szStr);
		for(s32 i = 0; i < len; i++)
			wszStr[i] = szStr[i];
		wszStr[len] = 0;
	}
}

/// Reads size bytes of data into buffer at ptr.
s32 readCTR( void * ptr, s32 size, s32 count, void * stream )
{
	if(!ptr || !stream || size == 0)
		return 0;

	nn::fs::FileStream*	file = (nn::fs::FileStream*)stream;

#ifdef __DEBUG__
	int readAmount = 0;
	nn::Result result = file->TryRead(&readAmount, ptr, size * count);

	if (result.IsSuccess())
		return readAmount/size;

	return 0;
#else
	return file->Read(ptr, size * count)/size;
#endif
}

s32 writeCTR ( const void * ptr, s32 size, s32 count, void * stream )
{
	if(!ptr || !stream || size == 0)
		return 0;

	nn::fs::FileStream*	file = (nn::fs::FileStream*)stream;

#ifdef __DEBUG__
	int writeAmount = 0;
	nn::Result result = file->TryWrite(&writeAmount, ptr, size * count);

	if (result.IsSuccess())
		return writeAmount/size;

	return 0;
#else
	return file->Write(ptr, size * count)/size;
#endif
}

/// Seeks to byte position offset.
s32 seekCTR ( void * stream, s32 offset, VoxFileSeekOrigin origin )
{
	if(!stream)
		return -1;

	nn::fs::FileStream*	file = (nn::fs::FileStream*)stream;

	nn::fs::PositionBase pos = nn::fs::POSITION_BASE_CURRENT;
	if (origin == k_nSeekSet)
	{
		pos = nn::fs::POSITION_BASE_BEGIN;
	}
	else if (origin == k_nSeekEnd)
	{
		pos = nn::fs::POSITION_BASE_END;
	}

	s64 offs = offset;

	nn::Result result = file->TrySeek(offs, pos);

	if (result.IsSuccess())
		return 0;

	return -1;
}

/// Returns the current byte offset in the stream.
s32 tellCTR ( void * stream )
{
	if(!stream)
		return -1;

	nn::fs::FileStream*	file = (nn::fs::FileStream*)stream;

#ifdef __DEBUG__
	s64 position;
	nn::Result result = file->TryGetPosition(&position);

	if (result.IsSuccess())
		return position;

	return -1;
#else
	return file->GetPosition();
#endif
}

void* openCTR ( const c8 * filename, VoxFileAccessMode mode )
{
	static wchar_t wszBuff[256];
	nn::fs::FileStream*	file = VOX_NEW nn::fs::FileStream();

	if(!file)
	{
		VOX_WARNING_LEVEL_2("File stream for %s could not be created\n", filename);
		return 0;
	}

	int flags = 0;
	switch(mode)
	{
		case k_nRead:
		case k_nReadBinary:
		{
			flags |= nn::fs::OPEN_MODE_READ;
			break;
		}
		default:
		{
			VOX_WARNING_LEVEL_2("VoxFileAccessMode not supported %d\n", mode);
			VOX_DELETE(file);
			return;
		}
	}

	nn::Result result;

	if(strlen(filename) < 255)
	{
		wszBuff[0] = 0;
		ConvertCharToWChar(filename, wszBuff);
		result = file->TryInitialize(wszBuff, flags);
	}
	else //if filename longer than wide char buffer allow, let os handle the conversion
	{
		result = file->TryInitialize(filename, flags);
	}

	if (result.IsSuccess())
		return file;

	VOX_DELETE(file);
	return 0;
}

s32 closeCTR ( void * stream )
{
	nn::fs::FileStream*	file = (nn::fs::FileStream*)stream;

	if(file)
	{
		file->Finalize();
		VOX_DELETE(file);
	}

	return 1;
}


FileSystemInterface* VoxNewFileSystem()
{
	return VOX_NEW FileSystemCTR();
}

FileSystemCTR::FileSystemCTR()
{
	FileSystemInterface::m_IOFunc.open = openCTR;
	FileSystemInterface::m_IOFunc.close = closeCTR;
	FileSystemInterface::m_IOFunc.read = readCTR;
	FileSystemInterface::m_IOFunc.write = writeCTR;
	FileSystemInterface::m_IOFunc.seek = seekCTR;
	FileSystemInterface::m_IOFunc.tell = tellCTR;
}

FileSystemCTR::~FileSystemCTR()
{
}

}
#endif
