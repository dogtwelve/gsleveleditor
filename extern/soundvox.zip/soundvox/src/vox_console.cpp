#include "StdAfx.h"
#include "vox_console.h"
#include "vox_macro.h"
#include <cstdio>
//#include <stdio.h>
#include <cstdarg>

#ifdef WIN32
#if VOX_DEBUG_SERVER_ENABLE
#define _WINSOCKAPI_
#endif
#include <windows.h>
#endif

namespace vox
{
s16 consoleGetColours();
void consoleSetColours(vox::s16 c);
void consoleSetColours(vox::s16 fg, vox::s16 bg);
	
static c8 strBuf[2048];

void SetColor(s32 level)
{
#ifdef WIN32
	s16 colors[6] = { 0x07, 0x0C, 0x0E, 0x0E, 0x0F, 0x0A };
	if(level >= 0 && level <=6)
	{
		consoleSetColours(colors[level]);
	}
#endif
}

//*** ConsoleVoxImpl ***//

ConsoleVoxImpl::ConsoleVoxImpl()
{
}

ConsoleVoxImpl::~ConsoleVoxImpl()
{
	m_messageQueue.clear();
}

void ConsoleVoxImpl::Print(s32 level, const c8* str, va_list arguments)
{
	if(level <= VOX_WARNING_LEVEL && m_messageQueue.size() < VOX_MAX_CONSOLE_ENTRY)
	{
		vsprintf(strBuf, str, arguments);
		ConsoleEntry entry;
		entry.level = level;
		entry.message = VOX_STRING(strBuf);
		m_messageQueue.push_back(entry);
	}
}

void ConsoleVoxImpl::Flush()
{
	char buf[1024];
	while(m_messageQueue.size() > 0)
	{
		sprintf(buf, "[VOX W%d] %s", m_messageQueue.front().level ,m_messageQueue.front().message.c_str());
		s16 c = consoleGetColours();
		SetColor(m_messageQueue.front().level);
		std::printf("%s", buf);
		consoleSetColours(c);
#ifdef WIN32
		OutputDebugString(buf);
#endif
		m_messageQueue.pop_front();
	}
}

//*** Console ***//

Console* Console::m_pInstance = 0;
Mutex Console::m_mutex = Mutex();
ConsoleImplInterface *Console::s_pConsoleImplementation = 0;
bool Console::s_isVoxImplementation = true;

Console::Console()
{
	m_pInstance = this;
}

Console::~Console()
{
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex);)

	// If vox implementation is used, delete it. Application is responsible to delete its own implementation.
	if(s_pConsoleImplementation != 0 && s_isVoxImplementation)
	{
		VOX_DELETE(s_pConsoleImplementation);
		s_pConsoleImplementation = 0;
	}
	m_pInstance = 0;
}

Console* Console::GetInstance(ConsoleImplInterface *pImplementation)
{
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex);)

	if(!m_pInstance)
		VOX_NEW Console();

	// If there is no implementation, create one.
	if(!s_pConsoleImplementation) 
	{
		// If implementation is provided, use it.
		if(pImplementation)
		{
			s_pConsoleImplementation = pImplementation;
			s_isVoxImplementation = false;
		}
		else // No implementation provided, use vox implementation.
		{
			s_pConsoleImplementation = VOX_NEW ConsoleVoxImpl();
			if(!s_pConsoleImplementation)
			{
				if(m_pInstance)
				{
					VOX_DELETE(m_pInstance);
					m_pInstance = 0;
				}
			}
		}
	}

	return m_pInstance;
}

void Console::Print(s32 level, const c8* str, ...)
{
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex);)

	va_list	argptr;
	va_start (argptr,str);
	if(s_pConsoleImplementation)
	{
		s_pConsoleImplementation->Print(level, str, argptr);
	}
	va_end(argptr);
}

void Console::Flush()
{
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex);)
	if(s_pConsoleImplementation)
	{
		s_pConsoleImplementation->Flush();
	}
}

void Console::PrintStatic(s32 level, const c8* str, ...)
{
	char strBuf[1024], strBuf2[1024];

	va_list	argptr;
	va_start (argptr,str);
	vsprintf(strBuf, str, argptr);
	va_end(argptr);
	sprintf(strBuf2, "[VOX W%d] %s", level ,strBuf);
	std::printf("%s", strBuf2);
#ifdef WIN32
	OutputDebugString(strBuf2);
#endif
}

s16 consoleGetColours()
{
#ifdef WIN32
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

	if(hConsole != INVALID_HANDLE_VALUE)
	{
		CONSOLE_SCREEN_BUFFER_INFO info;

		if(::GetConsoleScreenBufferInfo(hConsole, &info))
			return info.wAttributes;
	}
#endif
	return 0;
}

void consoleSetColours(s16 c)
{
#ifdef WIN32
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

	if(hConsole != INVALID_HANDLE_VALUE)
	{
		::SetConsoleTextAttribute(hConsole, c);
	}
#endif
}

};
