#include "StdAfx.h"
#include "vox_thread.h"
#include "vox_default_config.h"
#include "vox_macro.h"

#if defined(_ANDROID) || defined(__QNXNTO__)
#include <unistd.h>
#endif

extern vox::f64 _GetTime();

namespace vox
{

#if VOX_USE_GLF
void VoxRunnable::Run()
{
	VOX_PROFILING_REGISTER_THREAD( m_name, vox::VoxThread::GetCurThreadId());

	while(m_alive)
	{
		f64 preUpdateTime = _GetTime();
		m_callbackMethod(m_caller, m_param);

		f64 curtime = _GetTime();

		s32 sleepTime = VOX_THREAD_UPDATE_DT + (VOX_THREAD_UPDATE_DT - (s32)((preUpdateTime - m_lastUpdate) * 1000));
		if(sleepTime > VOX_THREAD_UPDATE_DT)
		sleepTime = VOX_THREAD_UPDATE_DT;

		sleepTime -= (s32)((curtime - preUpdateTime) * 1000);

		m_lastUpdate = preUpdateTime;

		if(sleepTime < 1)
			sleepTime = 1;
			
		glf::Thread::Sleep(sleepTime);
	}
}
#elif defined(_PS3)
void funcUpdate(std::uint64_t arg)
{
	vox::VoxThread::Update(arg);
}
#elif VOX_USE_PTHREAD
void* funcUpdate(void* arg)
{
	return vox::VoxThread::Update(arg);
}
#endif


VoxThread::VoxThread(ThreadUpdateCallback callbackMethod, void* caller, void* param, const c8* name):
	m_updateCallback(callbackMethod),
	m_caller(caller),
	m_param(param),
	m_update(true),
	m_alive(true) ,
	m_lastUpdate(0.0)
{
	VOX_ASSERT_MSG(m_updateCallback, "No callback defined, no thread created");
	if(m_updateCallback == 0)
	{
		m_alive = false;
	}
	else
	{
		if(name != 0)
		{
			strncpy(m_name, name, 63);
			m_name[63] = 0;
		}
		else
		{
			strcpy(m_name, "VoxThread");
		}

#if VOX_USE_GLF
		m_voxRunnable = VOX_NEW VoxRunnable(m_name);
		if(m_voxRunnable)
		{
			m_voxRunnable->m_callbackMethod = m_updateCallback;
			m_voxRunnable->m_caller = caller;
			m_voxRunnable->m_param = param;
#	if defined(_PS3)
			m_internThread.Start(m_voxRunnable, VOX_THREAD_PS3_PRIORITY);
#	else
			m_internThread.Start(m_voxRunnable);
#	endif
		}
		else
		{
			VOX_ASSERT_MSG(m_voxRunnable, "Could not create runnable for thread");
		}
#elif defined(_PS3)
		s32 priority = VOX_THREAD_PS3_PRIORITY; //To check
		s32 stacksize = 32 * 1024;
		sys_ppu_thread_create(&m_internThread, funcUpdate, (std::uint64_t)this,
			priority, stacksize, SYS_PPU_THREAD_CREATE_JOINABLE, m_name);
#elif defined(SN_TARGET_PSP2)
		SceInt32 threadPriority = VOX_VITA_THREAD_PRIORITY;
		SceInt32 cpuAffinityMask = VOX_THREAD_CPU_AFFINITY;

		// Determine on how many cpus the AudioOutput callback thread is set to run.
		int nbCpusUsed = 0;
		if(cpuAffinityMask & SCE_KERNEL_CPU_MASK_USER_0)
		{
			nbCpusUsed++;
		}
		if(cpuAffinityMask & SCE_KERNEL_CPU_MASK_USER_1)
		{
			nbCpusUsed++;
		}
		if(cpuAffinityMask & SCE_KERNEL_CPU_MASK_USER_2)
		{
			nbCpusUsed++;
		}

		if(nbCpusUsed > 1)
		{
			// Combination of multiple cpus other than SCE_KERNEL_CPU_MASK_USER_ALL is invalid
			cpuAffinityMask = SCE_KERNEL_CPU_MASK_USER_ALL;
			if(nbCpusUsed == 2)
			{
				VOX_WARNING_LEVEL_1("%s", "Vox update thread affinity has been forced to SCE_KERNEL_CPU_MASK_USER_ALL. All user available cpus will be used.");
			}
			
			// If more than one cpu is used, thread priority cannot be smaller than 128
			if(threadPriority < 128)
			{
				 threadPriority = SCE_KERNEL_DEFAULT_PRIORITY - 32;
				 VOX_WARNING_LEVEL_1("%s", "Vox update thread priority has been forced to SCE_KERNEL_DEFAULT_PRIORITY - 32 (max priority when using more than one CPU).");
			}
		}

		m_internThread = sceKernelCreateThread(
							m_name,
							&vox::VoxThread::Update,
							threadPriority,
							16 * 1024,
							0,
							cpuAffinityMask,
							SCE_NULL);
		if(m_internThread < 0)
		{
			VOX_WARNING_LEVEL_1("Failed to create thread : %d", m_internThread);
			return;
		}
		void* arg = this;
		s32 errCode = sceKernelStartThread(m_internThread, sizeof(this), &arg);

		if(errCode < 0)
		{
			VOX_WARNING_LEVEL_1("Vita Audio Output fail to start thread : %d", m_internThread);
			sceKernelDeleteThread(m_internThread);
			m_internThread = -1;
			return;
		}
#elif defined(_WIN32)
		DWORD dwGenericThread;
		m_internThread = CreateThread(NULL,0, &vox::VoxThread::Update, this, 0, &dwGenericThread);
		if(m_internThread == NULL)
		{
			DWORD dwError = GetLastError();
			VOX_WARNING_LEVEL_1("Error in Creating thread %d\n", dwError);
		}
#elif VOX_USE_PTHREAD
		s32 result = pthread_create(&m_internThread, 0, funcUpdate, this);
		if(result != 0)
		{
			VOX_WARNING_LEVEL_1("Error in Creating thread\n",0);
		}
#	if VOX_OVERRIDE_PTHREAD_DEFAULT_PRIORITY
		else
		{
			sched_param param;
			int sched_mode;
			pthread_getschedparam(m_internThread, &sched_mode, &param);
			VOX_WARNING_LEVEL_5("Thread %d created with priority %d scheduler policy %d", (s32)m_internThread, param.sched_priority, sched_mode);	
			
			s32 minprio = sched_get_priority_min(sched_mode);
			s32 maxprio = sched_get_priority_max(sched_mode);
			
			s32 threadprio = (VOX_PTHREAD_PRIORITY <= maxprio) ? ( VOX_PTHREAD_PRIORITY >= minprio ? VOX_PTHREAD_PRIORITY : minprio ) : maxprio ;
			
			sched_param param_thread;
			param_thread.sched_priority = threadprio;
			pthread_setschedparam(m_internThread, sched_mode, &param_thread);

			pthread_getschedparam(m_internThread, &sched_mode, &param);
			VOX_WARNING_LEVEL_5("Thread %d scheduler modified to priority %d scheduler policy %d", (s32)m_internThread, param.sched_priority, sched_mode);	
		}
#	endif	
#elif defined(_NN_CTR)
		m_internThread.StartUsingAutoStack(
			VoxThread::Update,
			(void*)this,
			VOX_NN_CTR_THREAD_STACK_SIZE,
			VOX_NN_CTR_THREAD_PRIORITY
		);
#endif
	}
}

VoxThread::~VoxThread()
{
	Stop();
}

void VoxThread::Stop()
{
	m_mutex.Lock();
	m_update = false;
	m_alive = false;
	m_mutex.Unlock();
	
#if VOX_USE_GLF
	m_voxRunnable->m_alive = false;
	m_internThread.Join();
#elif defined(_PS3)
	sys_ppu_thread_join(m_internThread, 0);
#elif defined(SN_TARGET_PSP2)
	s32 exitCode;
	if(m_internThread >= 0)
	{
		sceKernelWaitThreadEnd(m_internThread, &exitCode, NULL);
		sceKernelDeleteThread(m_internThread);
	}
#elif defined(_WIN32)
    WaitForSingleObject(m_internThread,INFINITE);
#elif VOX_USE_PTHREAD
	pthread_join(m_internThread, 0);
#elif defined(_NN_CTR)
	m_internThread.Join();
	m_internThread.Finalize();
#endif
}

#if !VOX_USE_GLF
#ifdef _PS3
void* VoxThread::Update(uint64_t iValue)
#elif  defined(SN_TARGET_PSP2)
s32 VoxThread::Update(u32 argsize, void* iValue)
#elif defined(_WIN32)
DWORD WINAPI VoxThread::Update(LPVOID iValue)
#elif VOX_USE_PTHREAD
void* VoxThread::Update(void* iValue)
#elif defined(_NN_CTR)
void VoxThread::Update(void* iValue)
#endif
{
#if defined(SN_TARGET_PSP2)
	iValue = *((VoxThread**)iValue);
#endif
	((VoxThread*)iValue)->_Update();

#if !defined(_NN_CTR)
	return 0;
#endif
}

void VoxThread::_Update()
{
	bool update, alive;

	m_mutex.Lock();
	update = m_update;
	alive = m_alive;
	m_mutex.Unlock();

	VOX_PROFILING_REGISTER_THREAD( m_name, vox::VoxThread::GetCurThreadId());

	while(alive)
	{
		f64 preUpdateTime = _GetTime();

		if(update)
		{
			m_updateCallback(m_caller, m_param);
		}

		f64 curtime = _GetTime();

		s32 sleepTime = VOX_THREAD_UPDATE_DT + (VOX_THREAD_UPDATE_DT - (s32)((preUpdateTime - m_lastUpdate) * 1000));
		//if(sleepTime > VOX_THREAD_UPDATE_DT)
		//	sleepTime = VOX_THREAD_UPDATE_DT;

		sleepTime -= (s32)((curtime - preUpdateTime) * 1000);

		m_lastUpdate = preUpdateTime;

		if(sleepTime < 1)
			sleepTime = 1;
		else if(sleepTime > VOX_THREAD_UPDATE_DT)
			sleepTime = VOX_THREAD_UPDATE_DT;

		VoxThread::Sleep(sleepTime);

		m_mutex.Lock();
		update = m_update;
		alive = m_alive;
		m_mutex.Unlock();
	}
#ifdef _PS3
	sys_ppu_thread_exit(0);
#endif
}
#endif

void VoxThread::Sleep(u32 sleepTimeMs)
{
#if VOX_USE_GLF
	glf::Thread::Sleep(sleepTimeMs);
#elif defined(_PS3)
	sys_timer_usleep(sleepTimeMs*1000);
#elif defined(SN_TARGET_PSP2)
	sceKernelDelayThread(sleepTimeMs*1000);
#elif defined(_WIN32)
	SleepEx(sleepTimeMs, true);
#elif VOX_USE_PTHREAD
	usleep(sleepTimeMs*1000);
#elif defined(_NN_CTR)
#include <nn/os.h>
	nn::os::Thread::Sleep(nn::fnd::TimeSpan::FromMilliSeconds(sleepTimeMs));
#endif
}

u32 VoxThread::GetCurThreadId()
{
#if VOX_USE_GLF
	Thread& t = glf::Thread::GetCurrent();
	return (u32)&t;
#elif defined(_PS3)
	sys_ppu_thread_t thread_id;
	sys_ppu_thread_get_id(&thread_id);
	return (u32)thread_id;
#elif defined(SN_TARGET_PSP2)
	return (u32)sceKernelGetThreadId();
#elif defined(_WIN32)
	return (u32)GetCurrentThreadId();
#elif VOX_USE_PTHREAD
	return (u32)pthread_self();
#elif defined(_NN_CTR)
	return (u32)nn::os::Thread::GetCurrentId();
#endif	
}

}
