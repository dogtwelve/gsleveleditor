#include "StdAfx.h"
#include "vox_mswav_subdecoder_imaadpcm.h"
#include "AdpcmDecoder.h"
#include "vox_macro.h"
#include "vox_memory.h"
#include  <cstring>
namespace vox
{
#define MAX_BLOCK_ALIGN 2048

VoxMSWavSubDecoderIMAADPCM::VoxMSWavSubDecoderIMAADPCM(StreamCursorInterface* pStreamCursor, WaveChunk* pWaveChunks)
: VoxMSWavSubDecoder(pStreamCursor,pWaveChunks)
, m_readBuffer(0)
, m_totalDataBytesRead(0)
, m_samplesInBuffer(0)
, m_samplesInBufferConsumed(0)
, m_totalSampleDecoded(0)
, m_blockReadBuffer(0)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderIMAADPCM::VoxMSWavSubDecoderIMAADPCM", vox::VoxThread::GetCurThreadId());

	VOX_ASSERT(pStreamCursor);
	
	GoToNextDataChunk();
	m_dataStartPosition = m_pStreamCursor->Tell();

	m_readBuffer = (u8*)VOX_ALLOC(sizeof(u8) * (pWaveChunks->m_formatHeader.blockAlign * 4));

	if(!m_readBuffer)
	{
		m_trackParams.Reset();
		return;
	}

	m_blockReadBuffer = (u8*)VOX_ALLOC(pWaveChunks->m_formatHeader.blockAlign);

	if(!m_blockReadBuffer)
	{
		VOX_FREE(m_readBuffer);
		m_readBuffer = 0;
		m_trackParams.Reset();
		return;
	}

	s32 preambleSize = sizeof(AdpcmState)*pWaveChunks->m_formatHeader.numChannels;

	if(((pWaveChunks->m_formatHeader.blockAlign - preambleSize) << 1) % pWaveChunks->m_formatHeader.numChannels != 0)
	{
		VOX_WARNING_LEVEL_3("Block size of adpcm is not compatible with %d channels, may cause seek issues", pWaveChunks->m_formatHeader.numChannels);
	}

	if(pWaveChunks->m_formatHeader.numChannels != 0)
	{
		m_samplesPerBlock = ((pWaveChunks->m_formatHeader.blockAlign - preambleSize) << 1) / pWaveChunks->m_formatHeader.numChannels  + 1;
	}
	else
	{
		m_trackParams.Reset();
		return;
	}

	m_trackParams.bitsPerSample = 16;						// Intended to be nb of decoded bits per sample
	m_trackParams.numChannels = pWaveChunks->m_formatHeader.numChannels;
	m_trackParams.samplingRate = pWaveChunks->m_formatHeader.sampleRate;
	m_trackParams.numSamples = pWaveChunks->m_factHeader.factData;

	if(m_trackParams.numChannels > 8)
		m_trackParams.Reset();
}

VoxMSWavSubDecoderIMAADPCM::~VoxMSWavSubDecoderIMAADPCM()
{
	VOX_FREE(m_readBuffer);
	VOX_FREE(m_blockReadBuffer);
}


s32 VoxMSWavSubDecoderIMAADPCM::Seek(u32 sample)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderIMAADPCM::Seek", vox::VoxThread::GetCurThreadId());
	if(sample > m_trackParams.numSamples)
	{
		VOX_WARNING_LEVEL_4("%s", "Decoder seek failed : position is outside stream");
		return -1;
	}

	if(sample < m_trackParams.numSamples)
	{		
		u32 blockIndex = sample / m_samplesPerBlock;

		// Consider all blocks preceding the one containing the requested sample as read.
		m_totalDataBytesRead = blockIndex * m_pWaveChunks->m_formatHeader.blockAlign;

		// Seek to start of block containing requested sample.
		m_pStreamCursor->Seek(m_dataStartPosition + m_totalDataBytesRead);
	
		u32 nbSamplesInPrecedingBlocks = blockIndex * m_samplesPerBlock;

		// Consider all samples before the one requested as consumed.
		m_samplesInBufferConsumed = sample - nbSamplesInPrecedingBlocks;

		// Set all samples before the one requested as decoded (this line must be before call to decode)
		m_totalSampleDecoded = nbSamplesInPrecedingBlocks;
		
		// Decode the whole block containing the requested sample.
		m_samplesInBuffer = DecodeBlock((void*)m_readBuffer);

		return 0;
	}
	return -1;
}



bool VoxMSWavSubDecoderIMAADPCM::HasData()
{
	if(m_pStreamCursor)
	{
		if(m_loop && ((m_totalSampleDecoded >= m_trackParams.numSamples) || ((m_totalDataBytesRead >= m_pWaveChunks->m_dataHeader.chunkSize) && (m_samplesInBufferConsumed == m_samplesInBuffer))))
		{
			Seek(0);
		}
		return !((m_totalSampleDecoded >= m_trackParams.numSamples) || ((m_totalDataBytesRead >= m_pWaveChunks->m_dataHeader.chunkSize) && (m_samplesInBufferConsumed == m_samplesInBuffer))) ;
	}
	return false;
}

// outbuf must be of block align * 4 bytes
// return nbSample (interleaved)
s32 VoxMSWavSubDecoderIMAADPCM::DecodeBlock(void* outbuf)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderIMAADPCM::DecodeBlock", vox::VoxThread::GetCurThreadId());
	s32 readSize = m_pWaveChunks->m_formatHeader.blockAlign <= m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead ? m_pWaveChunks->m_formatHeader.blockAlign : m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead;

	u8* readBuffer = m_blockReadBuffer;

	readSize = m_pStreamCursor->Read(readBuffer, readSize);

	//Process Preamble

	// reinit our state
	AdpcmState * curState = (AdpcmState*)readBuffer;
	m_states[0] = *curState;
#if VOX_BIG_ENDIAN
	m_states[0].ConvertToBE();
#endif
	for(s32 i = 1; i < m_pWaveChunks->m_formatHeader.numChannels; i++)
	{
		++curState;
		m_states[i] = *curState;
#if VOX_BIG_ENDIAN
		m_states[i].ConvertToBE();
#endif
	}

	// prepare destination
	s16* dst[8];
	dst[0] = (s16*)outbuf;
	for(s32 i = 1; i < m_pWaveChunks->m_formatHeader.numChannels; i++)
	{
		dst[i] = dst[i-1] + 1;
	}

	u8* c = readBuffer;

	//Process data
	for(s32 i = 0; i < m_pWaveChunks->m_formatHeader.numChannels; i++)
	{
		*dst[i] = m_states[i].m_prevSample;
		dst[i] += m_pWaveChunks->m_formatHeader.numChannels;
	}

	// skip our read pointer over the block preambles
	s32 preambleSize = sizeof(AdpcmState) * m_pWaveChunks->m_formatHeader.numChannels;
	c += preambleSize;

	s32 nbSamples = 1;
	u32 data;
	for(s32 i = 0 ; i < (readSize - preambleSize);)
	{
		for(s32 j = 0; j < m_pWaveChunks->m_formatHeader.numChannels; j++)
		{
			data = (u8)c[0] + ((u8)c[1] << 8) + ((u8)c[2] << 16) + ((u8)c[3] << 24);
			AdpcmDecoder::DecodeAdpcm(data, &(m_states[j]), dst[j], m_pWaveChunks->m_formatHeader.numChannels, 8);
			dst[j] += 8*m_pWaveChunks->m_formatHeader.numChannels;
			i+=4;	
			c+=4;
		}
		nbSamples+=8;
	}

	m_totalDataBytesRead += readSize;

	if(m_totalSampleDecoded + nbSamples > m_trackParams.numSamples)
	{
		nbSamples = m_trackParams.numSamples - m_totalSampleDecoded;
	}

	return nbSamples;
}


s32 VoxMSWavSubDecoderIMAADPCM::Decode(void* outbuf, s32 nbBytes)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderIMAADPCM::Decode", vox::VoxThread::GetCurThreadId());
	s32 nbSamplesDesired = nbBytes / (m_trackParams.numChannels * (m_trackParams.bitsPerSample >> 3));
	s32 nbSamples = nbSamplesDesired;
	s32 bufferoffset;
	s32 sampleAvailable;
	s32 nbSamplesToCopy;

	while(nbSamples > 0)
	{
		// Get a new decoded block if all samples have been consumed.
		if(m_samplesInBufferConsumed == m_samplesInBuffer)
		{
			m_samplesInBuffer = DecodeBlock((void*)m_readBuffer);
			m_samplesInBufferConsumed = 0;
		}

		// Set write offset in output buffer.
		bufferoffset = (nbSamplesDesired - nbSamples) * m_trackParams.numChannels;

		// Calculate the number of samples available in the current decoded block.
		sampleAvailable = m_samplesInBuffer - m_samplesInBufferConsumed;

		// Calculate the number of samples to copy from the decoded block to the output buffer.
		nbSamplesToCopy = (sampleAvailable > nbSamples) ? nbSamples : sampleAvailable;

		memcpy(&((s16*) outbuf)[bufferoffset], &(((short*)m_readBuffer)[m_samplesInBufferConsumed * m_trackParams.numChannels]), nbSamplesToCopy * m_trackParams.numChannels * sizeof(s16));

		nbSamples -= nbSamplesToCopy;
		m_samplesInBufferConsumed += nbSamplesToCopy;
		m_totalSampleDecoded += nbSamplesToCopy;

		if((m_totalSampleDecoded >= m_trackParams.numSamples) || ((m_totalDataBytesRead >= m_pWaveChunks->m_dataHeader.chunkSize) && (m_samplesInBufferConsumed == m_samplesInBuffer))) 
		{
			if(!(m_totalSampleDecoded >= m_trackParams.numSamples))
			{
				VOX_WARNING_LEVEL_4("Reached end of file but still waiting for samples, missing : %d", m_trackParams.numSamples - m_totalSampleDecoded);
			}
			if(!m_loop)
			{
				break;
			}
			else // If looping, seek to beginning of stream.
			{
				if(Seek(0) != 0)				
					break;		//could not go back to beginning
			}
		}
	}
	
	return (nbSamplesDesired - nbSamples)*( m_trackParams.numChannels * (m_trackParams.bitsPerSample>>3));
}

}
