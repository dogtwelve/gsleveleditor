
#include "StdAfx.h"
#include "vox_default_config.h"

#if VOX_DRIVER_USE_NACL

#include "vox_driver_nacl.h"




extern "C" void VoxSetPpInstance(pp::Instance *instance)
{
	vox::DriverNacl::s_ppInstance = instance;
}

namespace vox
{

pp::Instance* DriverNacl::s_ppInstance = 0;


DriverNaclSource::DriverNaclSource(void * trackParam, void* driverParam, u32 sourceId):
DriverCallbackSourceInterface(trackParam, driverParam, sourceId)
{
	Init();
}

DriverNaclSource::~DriverNaclSource()//**-**
{
}

void DriverNaclSource::PrintDebug()
{
}

	
//*** DriverNacl ***//

DriverInterface* CreateDriver()
{
	return VOX_NEW DriverNacl();
}

	
DriverNacl::DriverNacl()
{
	Init(0);
}

DriverNacl::~DriverNacl()
{
	Shutdown();
}

DriverSourceInterface* DriverNacl::CreateDriverSource(void * trackParam, void* driverParam, s32 priority)
{
	m_mutex.Lock();
	
	DriverNaclSource* driverSource = 0;

	if(m_audioUnitActive)
	{
		driverSource = VOX_NEW DriverNaclSource(trackParam, driverParam, m_nextSourceId);
		if(driverSource)
		{
			m_activeSources.push_back(driverSource);
			m_nextSourceId++;
		}
	}

	m_mutex.Unlock();
	return driverSource;
}

void DriverNacl::DestroyDriverSource(DriverSourceInterface* driverSource)
{
	m_mutex.Lock();
	if(driverSource)
	{
		VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> >::iterator it = m_activeSources.begin();
		VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> >::iterator end = m_activeSources.end();

		for(; it != end; it++)
		{
			if(*it == driverSource)
			{
				m_activeSources.erase(it);
				break;
			}
		}

		VOX_DELETE((DriverNaclSource*) driverSource);
	}
	m_mutex.Unlock();
}

void DriverNacl::Init(void* param)
{
	m_mutex.Lock();

	DriverCallbackInterface::Init(param);
	DriverCallbackSourceInterface::SetDriverSampleRate(VOX_NACL_DRIVER_PREFERRED_RATE);

	if (!s_ppInstance) // Must setup instance first
	{
		AU_CHECKSTATUS(1); // Error code 1
		m_mutex.Unlock();
		return;
	}

#if (VOX_NACL_DRIVER_PREFERRED_RATE == 44100)
	int blockLength = pp::AudioConfig::RecommendSampleFrameCount(PP_AUDIOSAMPLERATE_44100, VOX_NACL_DRIVER_PREFERRED_RATE * VOX_NACL_DRIVER_BUFFER_LENGTH);
	pp::AudioConfig config(s_ppInstance, PP_AUDIOSAMPLERATE_44100, blockLength);
	audio_interface = pp::Audio(s_ppInstance, config, vox::DriverNacl::playbackCallback, this);
#else
#if (VOX_NACL_DRIVER_PREFERRED_RATE == 48000)
	int blockLength = pp::AudioConfig::RecommendSampleFrameCount(PP_AUDIOSAMPLERATE_48000, VOX_NACL_DRIVER_PREFERRED_RATE * VOX_NACL_DRIVER_BUFFER_LENGTH);
	pp::AudioConfig config(s_ppInstance, PP_AUDIOSAMPLERATE_48000, blockLength);
	audio_interface = pp::Audio(s_ppInstance, config, vox::DriverNacl::playbackCallback, this);
#else
#error Nacl driver only supports 44100hz or 48000hz sampling rates
#endif // (VOX_NACL_DRIVER_PREFERRED_RATE == 48000)
#endif // (VOX_NACL_DRIVER_PREFERRED_RATE == 44100)

    
	if (audio_interface.is_null()) // Could not open audio device
	{
		AU_CHECKSTATUS(1); // Error code 1
		m_mutex.Unlock();
		return;
	}

	m_audioUnitActive = true;
	SetDefaultParameter();


	// Start callback function
    audio_interface.StartPlayback();
	
	m_mutex.Unlock();


}

void DriverNacl::Shutdown()
{
	m_mutex.Lock();

	if(m_audioUnitActive)
	{
		audio_interface.StopPlayback();

		m_audioUnitActive = false;
	}

	m_mutex.Unlock();
}

void DriverNacl::Suspend()
{
	// TODO : See if callback should be stopped
}

void DriverNacl::Resume()
{
	// TODO : Resume callback if it has been stopped by Suspend().
}

void DriverNacl::PrintDebug()
{
}


void DriverNacl::playbackCallback(void* samples, uint32_t buffer_size, void* data)
{
	
	if(data)	// userdata is simply a pointer to the (unique) DriverSdl object.
	{	
		((DriverNacl*)data)->FillBuffer((s16 *) samples, buffer_size >> 2);
	}
}

}//namespace vox

#endif // VOX_DRIVER_USE_NACL