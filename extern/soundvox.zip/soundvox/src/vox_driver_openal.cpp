#include "StdAfx.h"
#include "vox_default_config.h"

#if VOX_USE_OPENAL_DRIVER && VOX_OPENAL_DRIVER_PLATFORM

#include "vox_driver_openal.h"
#include <string.h>
#include "vox_macro.h"
#include "vox.h"

#ifdef _PS3

void* VoxAlloc(size_t size, const char* filename, const char* function, int line);
void* VoxAlloc(size_t size);
void VoxFree(void* ptr);

static const char* _alunknown = "AlFuncUnknown";

void AlFree(void* addr)
{
	VoxFree(addr);
}

void* AlAlloc(unsigned int size, AlMemHint hint, char const* filename, int line)
{
	return VoxAlloc(size, filename, _alunknown, line);
}

void* AlAlloc(unsigned int size , AlMemHint hint)
{
	return VoxAlloc(size);
}
#endif

namespace vox {

DriverInterface* CreateDriver()
{
	return VOX_NEW DriverOpenAL();
}

void GetALError(s32 error, const c8 * f, s32 l)
{
	if(0 != error) 
	{
		VOX_WARNING_LEVEL_3("%s:%d ==>There is an openal error = %#x", f, l, error);
		VOX_CONSOLE_FLUSH;
	}
}

#define LOG_OPENAL_ERROR GetALError(alGetError(), __FUNCTION__, __LINE__)
#define LOG_OPENAL_ALC_ERROR GetALError(alcGetError(m_device), __FUNCTION__, __LINE__)
//*** DriverOpenALSource ***//
DriverOpenALSource::DriverOpenALSource(void * trackParam, void* driverParam, ALuint sourceId):
	m_sourceId(sourceId),
	m_buffers(0)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenALSource::DriverOpenALSource", vox::VoxThread::GetCurThreadId());
	m_trackParams = *((TrackParams*)trackParam);
	if(driverParam != 0)
	{
		m_param.numBuffer = ((OpenALSourceParam*)driverParam)->numBuffer;
	}
	else
	{
		m_param.numBuffer = VOX_OPENAL_SOURCE_NUM_BUFFER;
	}
	Init();
}

DriverOpenALSource::~DriverOpenALSource()
{
	Cleanup();
}

void DriverOpenALSource::Play()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenALSource::Play", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_sourceId)
	{
		alSourcei(m_sourceId, AL_LOOPING, AL_FALSE);
		LOG_OPENAL_ERROR;
		alSourcePlay(m_sourceId);	
		LOG_OPENAL_ERROR;
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverOpenALSource::Stop()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenALSource::Stop", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_sourceId)
	{
		alSourceStop(m_sourceId);
		LOG_OPENAL_ERROR;
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverOpenALSource::Pause()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenALSource::Pause", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_sourceId)
	{
		alSourcePause(m_sourceId);
		LOG_OPENAL_ERROR;
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverOpenALSource::Reset()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenALSource::Reset", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_sourceId)
	{
		alSourceStop(m_sourceId);
		LOG_OPENAL_ERROR;
		alSourcei(m_sourceId, AL_BUFFER, 0);
		LOG_OPENAL_ERROR;
		//alSourcei(m_sourceId, AL_SOURCE_STATE, AL_INITIAL);
		//LOG_OPENAL_ERROR;
	}
	
	if(m_buffers)
	{
		for(s32 i = 0; i < m_param.numBuffer; i++)
		{
			m_buffers[i].queued = false;
		}
	}

	m_processedBytes = 0;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

s32 DriverOpenALSource::GetState()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenALSource::GetState", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	s32 result = DriverSource::STATE_ERROR;
	if(m_sourceId)
	{
		ALint state;
		alGetSourcei(m_sourceId, AL_SOURCE_STATE, &state);
		LOG_OPENAL_ERROR;
		result = ConvertSourceState(state);
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;
}

bool DriverOpenALSource::NeedData()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenALSource::NeedData", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	bool result = false;

	if(m_sourceId)
	{
		ALint buffersProcessed, buffersQueued;
		alGetSourcei(m_sourceId, AL_BUFFERS_PROCESSED, &buffersProcessed);
		LOG_OPENAL_ERROR;
		alGetSourcei(m_sourceId, AL_BUFFERS_QUEUED, &buffersQueued);
		LOG_OPENAL_ERROR;
		result = /*(GetState() != DriverSource::STATE_STOPPED) &&*/ ((buffersProcessed > 0) || (buffersQueued < m_param.numBuffer));
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;
}

void DriverOpenALSource::UploadData(void* soundData, s32 bufferSize)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenALSource::UploadData", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(!m_sourceId)
	{
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return;
	}

	OpenALBuffer* buffer;
	ALint buffersProcessed, buffersQueued;
	alGetSourcei(m_sourceId, AL_BUFFERS_PROCESSED, &buffersProcessed);
	LOG_OPENAL_ERROR;
	
	while(buffersProcessed > 0)
	{
		ALuint bid;
		alSourceUnqueueBuffers(m_sourceId, 1, &bid);
		LOG_OPENAL_ERROR;
		buffer = GetBuffer(bid);
		if(buffer)
		{
			m_processedBytes += buffer->size;
			buffer->queued = false;
		}
		else
		{
			VOX_WARNING_LEVEL_4("Unqueued a buffer not owned, might be a leak", 0);
		}
		alGetSourcei(m_sourceId, AL_BUFFERS_PROCESSED, &buffersProcessed);
		LOG_OPENAL_ERROR;
	}
	
	alGetSourcei(m_sourceId, AL_BUFFERS_QUEUED, &buffersQueued);
	LOG_OPENAL_ERROR;	
	
	if(!(buffersQueued < m_param.numBuffer) || bufferSize <= 0)
	{
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return;
	}
	
	buffer = GetFreeBuffer();

	if(!buffer)
	{
		/*ALuint bid;
		alSourceUnqueueBuffers(m_sourceId, 1, &bid);
		LOG_OPENAL_ERROR;
		buffer = GetBuffer(bid);
		if(!buffer)*/
		{
			VOX_WARNING_LEVEL_3("Could not unqueue buffer from source %d\n Current processed buffer : %d\n Current queued buffer : %d", m_sourceId, buffersProcessed, buffersQueued);
			VOX_WARNING_LEVEL_3("Buffer states (%d):",  m_param.numBuffer);
			for(s32 i  = 0; i < m_param.numBuffer; i++)
			{
				VOX_WARNING_LEVEL_3("\t Buffer id : %d state : %d", m_buffers[i].id, m_buffers[i].queued);
			}
		}
	}	

	if(!buffer)
	{
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return; //error
	}

	buffer->size = bufferSize;
	alBufferData(buffer->id, m_format, (ALvoid*)soundData, (ALsizei)buffer->size, (ALsizei)(m_trackParams.samplingRate));
	LOG_OPENAL_ERROR;
	alSourceQueueBuffers(m_sourceId, 1, &(buffer->id));
	LOG_OPENAL_ERROR;
	buffer->queued = true;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverOpenALSource::SetGain(f32 gain)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenALSource::SetGain", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_sourceId)
		alSourcef(m_sourceId,AL_GAIN,gain);
	LOG_OPENAL_ERROR;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverOpenALSource::SetPitch(f32 pitch)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenALSource::SetPitch", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_sourceId)
	{
		alSourcef(m_sourceId,AL_PITCH,pitch);
		LOG_OPENAL_ERROR;
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

f32 DriverOpenALSource::GetGain()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenALSource::DriverOpenALSource", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	f32 result =  0.0f;
	if(m_sourceId)
	{
		alGetSourcef(m_sourceId, AL_GAIN, &result);
		LOG_OPENAL_ERROR;
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;	
}

f32 DriverOpenALSource::GetPitch()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenALSource::DriverOpenALSource", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	f32 result =  0.0f;
	if(m_sourceId)
	{
		alGetSourcef(m_sourceId, AL_PITCH, &result);
		LOG_OPENAL_ERROR;
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;		
}
	
long DriverOpenALSource::GetByteOffset()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenALSource::GetByteOffset", vox::VoxThread::GetCurThreadId());
	ALint value = 0;
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_sourceId)
	{
		ALint buffersProcessed, state;
		alGetSourcei(m_sourceId, AL_SOURCE_STATE, &state);
		LOG_OPENAL_ERROR;
		if(state != AL_STOPPED)
		{
			alGetSourcei(m_sourceId,AL_BYTE_OFFSET, &value);
			LOG_OPENAL_ERROR;
		}
		else
		{
			alGetSourcei(m_sourceId, AL_BUFFERS_PROCESSED, &buffersProcessed);
			LOG_OPENAL_ERROR;
			OpenALBuffer* buffer;
			ALuint bid;
			for(s32 i = 0; i < m_param.numBuffer && buffersProcessed > 0; i++)
			{
				alSourceUnqueueBuffers(m_sourceId, 1, &bid);
				LOG_OPENAL_ERROR;
				buffer = GetBuffer(bid);
				if(buffer)
				{
					m_processedBytes += buffer->size;
					buffer->queued = false;
				}

				alGetSourcei(m_sourceId, AL_BUFFERS_PROCESSED, &buffersProcessed);
				LOG_OPENAL_ERROR;
			}
		}
	}
	value += m_processedBytes;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return value;
}

void DriverOpenALSource::SetByteOffset(s32 offset)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_processedBytes = offset;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverOpenALSource::Init()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenALSource::Init", vox::VoxThread::GetCurThreadId());
#if !VOX_OPENAL_ENABLE_SOURCE_POOL
	if(m_sourceId)
		Cleanup();

	alGenSources(1,&m_sourceId);
#endif

	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_sourceId)
	{
		m_buffers = (OpenALBuffer*)VOX_ALLOC(sizeof(OpenALBuffer) * (m_param.numBuffer));

		for(s32 i = 0; i < m_param.numBuffer; i++)
		{
			alGenBuffers(1, &(m_buffers[i].id));
			LOG_OPENAL_ERROR;
			m_buffers[i].queued = false;
		}	

		m_format = ConvertParamToALFormat();
	}
	m_processedBytes = 0;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverOpenALSource::Cleanup()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenALSource::Cleanup", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_sourceId)
	{
		alSourceStop(m_sourceId);
		LOG_OPENAL_ERROR;
		alSourcei(m_sourceId,AL_BUFFER,0);
		LOG_OPENAL_ERROR;
#if !VOX_OPENAL_ENABLE_SOURCE_POOL
		alDeleteSources(1, &m_sourceId);
		LOG_OPENAL_ERROR;
#endif
		m_sourceId = 0;
	}

	if(m_buffers)
	{
		for(s32 i = 0; i < m_param.numBuffer; i++)
		{
			alDeleteBuffers(1, &(m_buffers[i].id));
			LOG_OPENAL_ERROR;
		}
		VOX_FREE(m_buffers);
		m_buffers = 0;
	}
	
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

OpenALBuffer* DriverOpenALSource::GetFreeBuffer()
{
	for(s32 i = 0; i < m_param.numBuffer; i++)
	{
		if(m_buffers[i].queued == false)
			return &m_buffers[i];
	}

	return 0;
}

OpenALBuffer* DriverOpenALSource::GetBuffer(ALuint bufferId)
{
	for(s32 i = 0; i < m_param.numBuffer; i++)
	{
		if(m_buffers[i].id == bufferId)
			return &m_buffers[i];
	}

	return 0;
}

void DriverOpenALSource::SetFreeBuffer(ALuint bufferId)
{
	for(s32 i = 0; i < m_param.numBuffer; i++)
	{
		if(m_buffers[i].id == bufferId)
		{
			m_buffers[i].queued = false;
			return;
		}
	}
}

ALenum DriverOpenALSource::ConvertParamToALFormat()
{
	if(m_trackParams.bitsPerSample == 16 && m_trackParams.numChannels == 2)
	{
		return AL_FORMAT_STEREO16;
	}
	else if(m_trackParams.bitsPerSample == 8 && m_trackParams.numChannels == 2)
	{
		return AL_FORMAT_STEREO8;
	}
	else if(m_trackParams.bitsPerSample == 16 && m_trackParams.numChannels == 1)
	{
		return AL_FORMAT_MONO16;
	}
	else if(m_trackParams.bitsPerSample == 8 && m_trackParams.numChannels == 1)
	{
		return AL_FORMAT_MONO8;
	}
#ifdef AL_FORMAT_MONO32F
	else if(m_trackParams.bitsPerSample == 32 && m_trackParams.numChannels == 1)
	{
		return AL_FORMAT_MONO32F;
	}
#endif
#ifdef AL_FORMAT_STEREO32F
	else if(m_trackParams.bitsPerSample == 32 && m_trackParams.numChannels == 2)
	{
		return AL_FORMAT_STEREO32F;
	}
#endif

	return -1;
}

s32 DriverOpenALSource::ConvertSourceState(ALint alState)
{
	switch(alState)
	{
		case AL_INITIAL:
			return DriverSource::STATE_INITIAL;
		case AL_PLAYING:
			return DriverSource::STATE_PLAYING;
		case AL_PAUSED:
			return DriverSource::STATE_PAUSED;
		case AL_STOPPED:
			return DriverSource::STATE_STOPPED;
		default:
			return DriverSource::STATE_ERROR;
	}
}

void DriverOpenALSource::ReleaseSource()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenALSource::ReleaseSource", vox::VoxThread::GetCurThreadId());
	
#if VOX_OPENAL_ENABLE_SOURCE_POOL
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_sourceId)
	{
		alSourceStop(m_sourceId);
		LOG_OPENAL_ERROR;
		alSourcei(m_sourceId,AL_BUFFER,0);
		LOG_OPENAL_ERROR;
		m_sourceId = 0;
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
#endif
}

void DriverOpenALSource::Set3DParameter(s32 paramId, void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenALSource::Set3DParameter", vox::VoxThread::GetCurThreadId());
	
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_sourceId)
	{
		switch(paramId)
		{
			case Vox3DEmitterParameter::k_nRelativeToListener:
			{
				ALuint value = *((ALuint*)param);
				VOX_WARNING_LEVEL_5("Setting AL_SOURCE_RELATIVE for %d to %d", m_sourceId, value);
				alSourcei(m_sourceId, AL_SOURCE_RELATIVE, value);
				LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DEmitterParameter::k_nMaxDistance:
			{
				ALfloat value = *((ALfloat*)param);
#ifdef _IPHONE_OS
				value = value < 3.40282346638528860e+37 ? value : 3.40282346638528860e+37;
#endif
				VOX_WARNING_LEVEL_5("Setting AL_MAX_DISTANCE for %d to %f", m_sourceId, value);
				alSourcef(m_sourceId, AL_MAX_DISTANCE, value);
				LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DEmitterParameter::k_nReferenceDistance:
			{
				ALfloat value = *((ALfloat*)param);
				VOX_WARNING_LEVEL_5("Setting AL_REFERENCE_DISTANCE for %d to %f", m_sourceId, value);
				alSourcef(m_sourceId, AL_REFERENCE_DISTANCE, value);
				LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DEmitterParameter::k_nRolloffFactor:
			{
				ALfloat value = *((ALfloat*)param);
				VOX_WARNING_LEVEL_5("Setting AL_ROLLOFF_FACTOR for %d to %f", m_sourceId, value);
				alSourcef(m_sourceId, AL_ROLLOFF_FACTOR, value);
				LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DEmitterParameter::k_nInnerConeAngle:
			{
				ALfloat value = *((ALfloat*)param);
				VOX_WARNING_LEVEL_5("Setting AL_CONE_INNER_ANGLE for %d to %f", m_sourceId, value);
				alSourcef(m_sourceId, AL_CONE_INNER_ANGLE, value);
				LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DEmitterParameter::k_nOuterConeAngle:
			{
				ALfloat value = *((ALfloat*)param);
				VOX_WARNING_LEVEL_5("Setting AL_CONE_OUTER_ANGLE for %d to %f", m_sourceId, value);
				alSourcef(m_sourceId, AL_CONE_OUTER_ANGLE, value);
				LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DEmitterParameter::k_nOuterConeGain:
			{
				ALfloat value = *((ALfloat*)param);
				VOX_WARNING_LEVEL_5("Setting AL_CONE_OUTER_GAIN for %d to %f", m_sourceId, value);
				alSourcef(m_sourceId, AL_CONE_OUTER_GAIN, value);
				LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DEmitterParameter::k_nPosition:
			{
				VoxVector3f* value = (VoxVector3f*)param;
				alSource3f(m_sourceId, AL_POSITION, value->x, value->y, value->z );
				LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DEmitterParameter::k_nVelocity:
			{
				VoxVector3f* value = (VoxVector3f*)param;
				alSource3f(m_sourceId, AL_VELOCITY, value->x, value->y, value->z );
				LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DEmitterParameter::k_nDirection:
			{
				VoxVector3f* value = (VoxVector3f*)param;
				alSource3f(m_sourceId, AL_DIRECTION, value->x, value->y, value->z );
				LOG_OPENAL_ERROR;
				break;
			}
			default:
			{
				VOX_WARNING_LEVEL_4("OpenAL source doesn't support property %d", paramId);
				break;
			}
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverOpenALSource::PrintDebug()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	ALfloat fValue;
	ALfloat fArray[3];
	ALint iValue;

	VOX_WARNING_LEVEL_1("    ###########################################################################",0);
	VOX_WARNING_LEVEL_1("    ##########################     Source OpenAL     ##########################",0);
	VOX_WARNING_LEVEL_1("    ###########################################################################",0);
	VOX_WARNING_LEVEL_1("    #",0);
	VOX_WARNING_LEVEL_1("    #	Source Id : %d", m_sourceId);
	VOX_WARNING_LEVEL_1("    #",0);

	if(m_sourceId)
	{
		alGetSourcei(m_sourceId, AL_SOURCE_STATE, &iValue);
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("    #	State : %#x", iValue);

		alGetSourcei(m_sourceId, AL_SOURCE_RELATIVE, &iValue);
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("    #	Relative to listener : %d", iValue);

		alGetSourcef(m_sourceId, AL_PITCH, &fValue);
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("    #	Pitch : %f", fValue);

		alGetSourcef(m_sourceId, AL_GAIN, &fValue);
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("    #	Gain : %f", fValue);

		alGetSourcef(m_sourceId, AL_MIN_GAIN, &fValue);
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("    #	Minimum gain : %f", fValue);

		alGetSourcef(m_sourceId, AL_MAX_GAIN, &fValue);
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("    #	Maximum gain : %f", fValue);

		alGetSourcef(m_sourceId, AL_MAX_DISTANCE, &fValue);
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("    #	Max distance : %f", fValue);

		alGetSourcef(m_sourceId, AL_ROLLOFF_FACTOR, &fValue);
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("    #	Rolloff factor : %f", fValue);

		alGetSourcef(m_sourceId, AL_CONE_OUTER_GAIN, &fValue);
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("    #	Cone outer Gain : %f", fValue);

		alGetSourcef(m_sourceId, AL_CONE_INNER_ANGLE, &fValue);
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("    #	Cone inner angle : %f", fValue);

		alGetSourcef(m_sourceId, AL_CONE_OUTER_ANGLE, &fValue);
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("    #	Cone outer angle : %f", fValue);

		alGetSourcef(m_sourceId, AL_REFERENCE_DISTANCE, &fValue);
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("    #	Reference distance : %f", fValue);

		alGetSourcefv(m_sourceId, AL_POSITION, fArray);
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("    #	Position : ( %f, %f, %f )", fArray[0], fArray[1], fArray[2]);

		alGetSourcefv(m_sourceId, AL_VELOCITY, fArray);
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("    #	Velocity : ( %f, %f, %f )", fArray[0], fArray[1], fArray[2]);

		alGetSourcefv(m_sourceId, AL_DIRECTION, fArray);
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("    #	Direction : ( %f, %f, %f )", fArray[0], fArray[1], fArray[2]);
	}

	VOX_WARNING_LEVEL_1("    #",0);
	VOX_WARNING_LEVEL_1("    ###########################################################################",0);

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

//*** DriverOpenAL ***//

DriverOpenAL::DriverOpenAL():
	m_device(0),
	m_context(0)
{
	Init(0);
}

DriverOpenAL::~DriverOpenAL()
{
	Shutdown();
}

void DriverOpenAL::Init(void* param)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());

#ifdef _WIN32
	//Some hw devices on windows don't work properly, try to get software
	m_device = alcOpenDevice("Generic Software");
	LOG_OPENAL_ALC_ERROR;
	if(!m_device)
	{
		m_device = alcOpenDevice(NULL);
		LOG_OPENAL_ALC_ERROR;
	}
#else
	m_device = alcOpenDevice(NULL);
	LOG_OPENAL_ALC_ERROR;
#endif

	if(m_device == NULL)
	{ 
		VOX_WARNING_LEVEL_1("Failed to open device",0);
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return; 
	}

	m_context = alcCreateContext(m_device, NULL);	
	LOG_OPENAL_ALC_ERROR;

	if(m_context == NULL)
	{ 
		VOX_WARNING_LEVEL_1("Failed to create context",0);
		alcCloseDevice(m_device);
		LOG_OPENAL_ALC_ERROR;
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return; 
	}

	alcMakeContextCurrent(m_context);
	LOG_OPENAL_ALC_ERROR;

#if VOX_OPENAL_ENABLE_SOURCE_POOL
	ALuint sourceId[VOX_OPENAL_MAX_SOURCE];
	alGenSources(VOX_OPENAL_MAX_SOURCE, sourceId);
	LOG_OPENAL_ERROR;
	OpenALSourcePoolItem item;
	item.driverSource = 0;
	for(s32 i = 0; i < VOX_OPENAL_MAX_SOURCE; i++)
	{
		if(sourceId[i])
		{
			item.sourceId = sourceId[i];
			m_sourcePool.push_back(item);
		}
	}
#endif

	SetDefaultParameter();

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
#if VOX_OPENAL_ENABLE_SOURCE_POOL
	VOX_WARNING_LEVEL_5("Created OpenAL driver with %d sources", m_sourcePool.size());
#endif
}

void DriverOpenAL::Shutdown()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	alcMakeContextCurrent(NULL);
	LOG_OPENAL_ALC_ERROR;

	if(m_context)
	{
		alcDestroyContext(m_context);
		LOG_OPENAL_ALC_ERROR;
	}

	if(m_device)
		if(!alcCloseDevice(m_device))
			VOX_ASSERT_MSG(0, "Close device failed");/*log an error or call a super clean*/ //error: could not close device since some ressources were not freed

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverOpenAL::Suspend()
{
	alcMakeContextCurrent(NULL);
	LOG_OPENAL_ALC_ERROR;
	alcSuspendContext(m_context);
	LOG_OPENAL_ALC_ERROR;
}

void DriverOpenAL::Resume()
{
	alcMakeContextCurrent(m_context);
	LOG_OPENAL_ALC_ERROR;
	alcProcessContext(m_context);
	LOG_OPENAL_ALC_ERROR;
}

DriverSourceInterface* DriverOpenAL::CreateDriverSource(void * trackParam, void* driverParam, s32 priority)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenAL::CreateDriverSource", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	
	DriverOpenALSource* driverSource = 0;

	if(m_context)
	{
#if VOX_OPENAL_ENABLE_SOURCE_POOL
		OpenALSourcePoolItem item = GetSource(priority);
		
		if(item.sourceId) //valid source
		{
			if(item.driverSource)
			{
				item.driverSource->ReleaseSource();
			}

			driverSource = VOX_NEW DriverOpenALSource(trackParam, driverParam, item.sourceId);
			item.driverSource = driverSource; 
			item.priority = priority;
			m_sourcePool.push_back(item); //If driver source creation failed, push back a free source
		}
#else
		driverSource = VOX_NEW DriverOpenALSource(trackParam, driverParam);
#endif
	}

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return driverSource;
}

void DriverOpenAL::Set3DParameter(s32 paramId, void* param)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	_Set3DParameter(paramId, param);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverOpenAL::_Set3DParameter(s32 paramId, void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenAL::_Set3DParameter", vox::VoxThread::GetCurThreadId());
	if(m_context)
	{
		switch(paramId)
		{
			case Vox3DGeneralParameter::k_nDopplerFactor:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting alDopplerFactor to %f", value);
				alDopplerFactor(value);
				LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DGeneralParameter::k_nSpeedOfSound:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting alSpeedOfSound to %f", value);
				alSpeedOfSound(value);
				LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DGeneralParameter::k_nDistanceModel: 
			{
				u32 value = GetOpenAL3DModel(*((u32*)param));
				VOX_WARNING_LEVEL_5("Setting alDistanceModel to %x", value);
				alDistanceModel(value);
				LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DGeneralParameter::k_nListenerPosition:
			{
				VoxVector3f* vector = (VoxVector3f*)param;
				alListener3f(AL_POSITION, vector->x, vector->y, vector->z);
				LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DGeneralParameter::k_nListenerVelocity:
			{
				VoxVector3f* vector = (VoxVector3f*)param;
				alListener3f(AL_VELOCITY, vector->x, vector->y, vector->z);
				LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DGeneralParameter::k_nListenerOrientation:
			{
				VoxVector3f* vector = (VoxVector3f*)param;
				ALfloat orientation[6];
				orientation[0] = vector[0].x;
				orientation[1] = vector[0].y;
				orientation[2] = vector[0].z;
				orientation[3] = vector[1].x;
				orientation[4] = vector[1].y;
				orientation[5] = vector[1].z;
				alListenerfv(AL_ORIENTATION, orientation);
				LOG_OPENAL_ERROR;
				break;
			}
			default:
			{
				VOX_WARNING_LEVEL_4("OpenAL driver doesn't support property %d", paramId);
				break;
			}
		}
	}
}

void DriverOpenAL::SetDefaultParameter()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenAL::SetDefaultParameter", vox::VoxThread::GetCurThreadId());
	VOX_WARNING_LEVEL_5("Setting default parameter to OpenAL driver", 0);
	ALfloat fvalue;
	ALuint uivalue;

	// Doppler factor
	fvalue = VOX_DEFAULT_3D_DOPPLER_FACTOR;
	_Set3DParameter(Vox3DGeneralParameter::k_nDopplerFactor, &fvalue);

	// Speed of sound
	fvalue = VOX_DEFAULT_3D_SPEED_OF_SOUND;
	_Set3DParameter(Vox3DGeneralParameter::k_nSpeedOfSound, &fvalue);

	// 3D attenuation model
	uivalue = VOX_DEFAULT_3D_MODEL;
	_Set3DParameter(Vox3DGeneralParameter::k_nDistanceModel, &uivalue);	
	
	// Listener position
	ALfloat position[3] = VOX_DEFAULT_3D_LISTENER_POSITION;
	VoxVector3f positionv = VoxVector3f(position);
	_Set3DParameter(Vox3DGeneralParameter::k_nListenerPosition, &positionv);

	// Listener velocity
	ALfloat velocity[3] = VOX_DEFAULT_3D_LISTENER_VELOCITY;
	VoxVector3f velocityv = VoxVector3f(velocity);
	_Set3DParameter(Vox3DGeneralParameter::k_nListenerVelocity, &velocityv);

	// Listener Orientation
	ALfloat lookat[3] = VOX_DEFAULT_3D_LISTENER_LOOKAT;
	ALfloat up[3] = VOX_DEFAULT_3D_LISTENER_UP;
	VoxVector3f orientationv[2];
	orientationv[0] = VoxVector3f(lookat);
	orientationv[1] = VoxVector3f(up);
	_Set3DParameter(Vox3DGeneralParameter::k_nListenerOrientation, &orientationv);
}

ALuint DriverOpenAL::GetOpenAL3DModel(s32 vox3DModel)
{
	switch(vox3DModel)
	{
		case Vox3DDistanceModel::k_nNone:
		{
			return AL_NONE;
			break;
		}
		case Vox3DDistanceModel::k_nInverseDistance:
		{
			return AL_INVERSE_DISTANCE;
			break;
		}
		case Vox3DDistanceModel::k_nInverseDistanceClamped:
		{
			return AL_INVERSE_DISTANCE_CLAMPED;
			break;
		}
		case Vox3DDistanceModel::k_nLinearDistance:
		{
			return AL_LINEAR_DISTANCE;
			break;
		}
		case Vox3DDistanceModel::k_nLinearDistanceClamped:
		{
			return AL_LINEAR_DISTANCE_CLAMPED;
			break;
		}
		case Vox3DDistanceModel::k_nExponentDistance:
		{
			return AL_EXPONENT_DISTANCE;
			break;
		}
		case Vox3DDistanceModel::k_nExponentDistanceClamped:
		{
			return AL_EXPONENT_DISTANCE_CLAMPED;
			break;
		}
	}

	VOX_WARNING_LEVEL_2("Vox 3D attenuation model %x is not supported by OpenAL driver", vox3DModel);
	return AL_NONE;
}

void DriverOpenAL::DestroyDriverSource(DriverSourceInterface* driverSource)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenAL::DestroyDriverSource", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(driverSource)
	{
#if VOX_OPENAL_ENABLE_SOURCE_POOL
		VOX_LIST<OpenALSourcePoolItem, SAllocator<OpenALSourcePoolItem> >::iterator iter = m_sourcePool.begin();
		VOX_LIST<OpenALSourcePoolItem, SAllocator<OpenALSourcePoolItem> >::iterator end = m_sourcePool.end();

		for(;iter != end; iter++)
		{
			if((*iter).driverSource == driverSource)
			{
				(*iter).driverSource = 0;
				break;
			}
		}
#endif
		VOX_DELETE(driverSource);
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverOpenAL::PrintDebug()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	ALfloat fValue;
	ALfloat fArray[6];
	ALint iValue;

	VOX_WARNING_LEVEL_1("###############################################################################",0);
	VOX_WARNING_LEVEL_1("############################     Driver OpenAL     ############################",0);
	VOX_WARNING_LEVEL_1("###############################################################################",0);
	VOX_WARNING_LEVEL_1("#",0);
	
	if(m_context)
	{
		fValue = alGetFloat(AL_DOPPLER_FACTOR);
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("#	Doppler factor : %f", fValue);
		fValue = alGetFloat(AL_SPEED_OF_SOUND );
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("#	Speed of sound : %f", fValue);
		iValue = alGetInteger(AL_DISTANCE_MODEL);
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("#	Distance model : %#x", iValue);

		VOX_WARNING_LEVEL_1("#",0);
		VOX_WARNING_LEVEL_1("#  Listener properties", 0);
		VOX_WARNING_LEVEL_1("#",0);
		alGetListenerfv(AL_POSITION, fArray);
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("#		Position : ( %f, %f, %f )", fArray[0], fArray[1], fArray[2]);
		alGetListenerfv(AL_VELOCITY, fArray);
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("#		Velocity : ( %f, %f, %f )", fArray[0], fArray[1], fArray[2]);
		alGetListenerfv(AL_ORIENTATION, fArray);
		LOG_OPENAL_ERROR;
		VOX_WARNING_LEVEL_1("#		Look at  : ( %f, %f, %f )", fArray[0], fArray[1], fArray[2]);
		VOX_WARNING_LEVEL_1("#		Up       : ( %f, %f, %f )", fArray[3], fArray[4], fArray[5]);
	}
	else
	{
		VOX_WARNING_LEVEL_1("#	No active openal context", 0);
	}
	VOX_WARNING_LEVEL_1("#",0);
	VOX_WARNING_LEVEL_1("###############################################################################",0);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}


#if VOX_OPENAL_ENABLE_SOURCE_POOL
OpenALSourcePoolItem DriverOpenAL::GetSource(s32 priority)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverOpenAL::GetSource", vox::VoxThread::GetCurThreadId());
	VOX_LIST<OpenALSourcePoolItem, SAllocator<OpenALSourcePoolItem> >::iterator iter = m_sourcePool.begin();
	VOX_LIST<OpenALSourcePoolItem, SAllocator<OpenALSourcePoolItem> >::iterator end = m_sourcePool.end();

	OpenALSourcePoolItem item;
	item.sourceId = 0;
	item.driverSource = 0;
	//First look for free source
	for(;iter != end; iter++)
	{
		if(!(*iter).driverSource)
		{
			item = *iter;
			m_sourcePool.erase(iter); //remove source from list to make sure newer allocated source are at the end of the list
			VOX_WARNING_LEVEL_5("Allocated free OpenAL source to emitter", 0);
			return item;
		}
	}
	//Else steal a source from a lower priority emitter
	iter = m_sourcePool.begin();
	end = m_sourcePool.end();
	for(;iter != end; iter++)
	{
		if((*iter).priority < priority)
		{
			item = *iter;
			m_sourcePool.erase(iter);
			VOX_WARNING_LEVEL_3("Stole OpenAL source from lower priority emitter", 0);
			return item;
		}
	}

	VOX_WARNING_LEVEL_3("Could not get a OpenAL source", 0);
	return item;//Could not find a source
}
#endif

}//namespace vox

#endif //VOX_USE_OPENAL_DRIVER && VOX_OPENAL_DRIVER_PLATFORM
