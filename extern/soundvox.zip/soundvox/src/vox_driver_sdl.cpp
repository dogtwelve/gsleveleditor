#include "StdAfx.h"
#include "vox_default_config.h"

#if VOX_DRIVER_USE_SDL && VOX_SDL_DRIVER_PLATFORM

#include "vox_driver_sdl.h"
#include "vox_macro.h"

static unsigned int NextPowerOf2(unsigned int value)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "NextPowerOf2", vox::VoxThread::GetCurThreadId());

    unsigned int powerOf2 = 1;
	
    if(value)
    {
        value--;
        while(value)
        {
            value >>= 1;
            powerOf2 <<= 1;
        }
    }
    return powerOf2;
}


namespace vox {

DriverSdlSource::DriverSdlSource(void * trackParam, void* driverParam, u32 sourceId):
DriverCallbackSourceInterface(trackParam, driverParam, sourceId)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSdlSource::DriverSdlSource", vox::VoxThread::GetCurThreadId());
	Init();
}

DriverSdlSource::~DriverSdlSource()//**-**
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSdlSource::DriverSdlSource", vox::VoxThread::GetCurThreadId());
}

void DriverSdlSource::PrintDebug()
{
}

	
//*** DriverSdl ***//

DriverInterface* CreateDriver()
{
	return VOX_NEW DriverSdl();
}

	
DriverSdl::DriverSdl()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSdl::DriverSdl", vox::VoxThread::GetCurThreadId());
	Init(0);
}

DriverSdl::~DriverSdl()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSdl::~DriverSdl", vox::VoxThread::GetCurThreadId());
	Shutdown();
}

DriverSourceInterface* DriverSdl::CreateDriverSource(void * trackParam, void* driverParam, s32 priority)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSdl::CreateDriverSource", vox::VoxThread::GetCurThreadId());
	m_mutex.Lock();
	
	DriverSdlSource* driverSource = 0;

	if(m_audioUnitActive)
	{
		driverSource = VOX_NEW DriverSdlSource(trackParam, driverParam, m_nextSourceId);
		if(driverSource)
		{
			m_activeSources.push_back(driverSource);
			m_nextSourceId++;
		}
	}

	m_mutex.Unlock();
	return driverSource;
}

void DriverSdl::DestroyDriverSource(DriverSourceInterface* driverSource)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSdl::DestroyDriverSource", vox::VoxThread::GetCurThreadId());
	m_mutex.Lock();
	if(driverSource)
	{
		VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> >::iterator it = m_activeSources.begin();
		VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> >::iterator end = m_activeSources.end();

		for(; it != end; it++)
		{
			if(*it == driverSource)
			{
				m_activeSources.erase(it);
				break;
			}
		}

		VOX_DELETE((DriverSdlSource*) driverSource);
	}
	m_mutex.Unlock();
}

void DriverSdl::Init(void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSdl::Init", vox::VoxThread::GetCurThreadId());
	m_mutex.Lock();

	DriverCallbackInterface::Init(param);
	DriverCallbackSourceInterface::SetDriverSampleRate(VOX_SDL_DRIVER_PREFERRED_RATE);

	// TODO : See if necessary or if should be done in the application
	//SDL_InitSubSystem(SDL_INIT_AUDIO);
	// End TODO

	// Fill structure used to open audio device (samples must be a power of 2)
	SDL_AudioSpec desiredSpec;
	desiredSpec.freq = VOX_SDL_DRIVER_PREFERRED_RATE;
	desiredSpec.format = AUDIO_S16LSB;					// signed 16-bits (little endian)
	desiredSpec.channels = 2;
	desiredSpec.samples = (Uint16) NextPowerOf2((unsigned int) (VOX_SDL_DRIVER_BUFFER_LENGTH * VOX_SDL_DRIVER_PREFERRED_RATE));
	desiredSpec.padding = 0;
	desiredSpec.callback = playbackCallback;
	desiredSpec.userdata = this;						// Provided as callback argument.

	DriverCallbackSourceInterface::SetDriverCallbackPeriod( (float) desiredSpec.samples / (float) VOX_SDL_DRIVER_PREFERRED_RATE);

	// Open audio device
	SDL_AudioSpec obtainedSpec;

	int status = SDL_OpenAudio(&desiredSpec, &obtainedSpec); // Returns 0 if successfull.

	if(status) // Could not open audio device
	{
		AU_CHECKSTATUS(status);
		m_mutex.Unlock();
		return;
	}

	m_audioUnitActive = true;
	SetDefaultParameter();

	// Start callback function 'playbackCallback()'.
	SDL_PauseAudio(0);
	
	m_mutex.Unlock();
}

void DriverSdl::Shutdown()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSdl::Shutdown", vox::VoxThread::GetCurThreadId());
	m_mutex.Lock();

	if(m_audioUnitActive)
	{
		SDL_PauseAudio(1);	// Stop callback
		SDL_CloseAudio();
		// TODO : See if necessary or if should be done by the application
		//SDL_QuitSubSystem(SDL_INIT_AUDIO);
		// End TODO

		m_audioUnitActive = false;
	}

	m_mutex.Unlock();
}

void DriverSdl::Suspend()
{
	// TODO : See if callback should be stopped (with SDL_PauseAudio(1));
}

void DriverSdl::Resume()
{
	// TODO : Resume callback (with SDL_PauseAudio(0)) if it has been stopped by Suspend().
}


void DriverSdl::PrintDebug()
{
}


void DriverSdl::playbackCallback(void *userdata, Uint8 *stream, int len)
{
	VOX_PROFILING_START_FRAME_LAZY;
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverSdl::playbackCallback", vox::VoxThread::GetCurThreadId());
	
	if(userdata)	// userdata is simply a pointer to the (unique) DriverSdl object.
	{	
		((DriverSdl*)userdata)->FillBuffer((s16 *) stream, len >> 2);
	}
}


}//namespace vox

#endif //VOX_DRIVER_USE_SDL && VOX_SDL_DRIVER_PLATFORM
