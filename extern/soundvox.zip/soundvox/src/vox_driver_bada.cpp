#include "StdAfx.h"
#include "vox_default_config.h"

#if VOX_DRIVER_USE_BADA && VOX_BADA_DRIVER_PLATFORM

#include "vox_driver_bada.h"
#include "vox_macro.h"
#include "vox_memory.h"
#include "vox.h"


namespace vox {


//*** AudioOutListener ***//

void AudioOutListener::OnAudioOutBufferEndReached(void)
{
	m_pBadaDriver->Update();
}

void AudioOutListener::OnAudioOutErrorOccurred(result r)
{
}

void AudioOutListener::OnAudioOutInterrupted(void)
{
}

void AudioOutListener::OnAudioOutReleased(void)
{
}

void AudioOutListener::SetDriver(DriverBada *pDriver)
{
	m_pBadaDriver = pDriver;
}


//*** DriverBadaSource ***//


DriverBadaSource::DriverBadaSource(void * trackParam, void* driverParam, u32 sourceId):
DriverCallbackSourceInterface(trackParam, driverParam, sourceId)
{
	Init();
}

DriverBadaSource::~DriverBadaSource()//**-**
{
}


void DriverBadaSource::PrintDebug()
{
}


//*** DriverBada ***//


DriverInterface* CreateDriver()
{
	return VOX_NEW DriverBada();
}

DriverBada::DriverBada()
{
	Init(0);
}

DriverBada::~DriverBada()
{
	Shutdown();
}


DriverSourceInterface* DriverBada::CreateDriverSource(void * trackParam, void* driverParam, s32 priority)
{
	m_mutex.Lock();

	DriverBadaSource* driverSource = 0;

	if(m_audioUnitActive)
	{
		driverSource = VOX_NEW DriverBadaSource(trackParam, driverParam, m_nextSourceId);
		if(driverSource)
		{
			m_activeSources.push_back(driverSource);
			m_nextSourceId++;
		}
	}

	m_mutex.Unlock();
	return driverSource;
}


void DriverBada::DestroyDriverSource(DriverSourceInterface* driverSource)
{
	m_mutex.Lock();
	if(driverSource)
	{
		VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> >::iterator it = m_activeSources.begin();
		VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> >::iterator end = m_activeSources.end();

		for(; it != end; it++)
		{
			if(*it == driverSource)
			{
				m_activeSources.erase(it);
				break;
			}
		}

		VOX_DELETE( (DriverBadaSource*)driverSource);
	}
	m_mutex.Unlock();
}


void DriverBada::Init(void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverBada::Init", vox::VoxThread::GetCurThreadId());
	m_mutex.Lock();

	result status;

	DriverCallbackInterface::Init(param);

	// Construct object necessary to connect to bada audio API.
	m_audioOutListener.SetDriver(this);
	status = m_audioOut.Construct(m_audioOutListener);

	if(status != E_SUCCESS)
	{
		AU_CHECKSTATUS(status);
		m_mutex.Unlock();
		return;
	}

	// Get device optimal sample rate and prepare AudioOut object.
	int driverSampleRate;
	#if VOX_BADA_DRIVER_USE_PREFERRED_RATE
		driverSampleRate = VOX_BADA_DRIVER_PREFERRED_RATE;
	#else
		driverSampleRate = m_audioOut.GetOptimizedSampleRate();
	#endif
	DriverCallbackSourceInterface::SetDriverSampleRate(driverSampleRate);
	status = m_audioOut.Prepare(AUDIO_ENCODING_TYPE_PCM_16BIT, AUDIO_CHANNEL_TYPE_STEREO, driverSampleRate);

	if(status != E_SUCCESS)
	{
		AU_CHECKSTATUS(status);
		m_mutex.Unlock();
		return;
	}

	// Construct (intermediate) buffers necessary to provide AudioOut with samples
	int totalBufferSize = (int) (VOX_BADA_DRIVER_BUFFER_LENGTH * driverSampleRate * 4); // In bytes (stereo).

	int minBufferSize = m_audioOut.GetMinBufferSize();
	int maxBufferSize = m_audioOut.GetMaxBufferSize();

	if(totalBufferSize < minBufferSize)
	{
		totalBufferSize = minBufferSize;
	}
	else if(totalBufferSize > maxBufferSize)
	{
		totalBufferSize = maxBufferSize;
	}

	m_pDataArray = (s16 *) VOX_ALLOC(totalBufferSize);
	if(!m_pDataArray)
	{
		m_audioOut.Unprepare();
		m_mutex.Unlock();
		return;
	}

	DriverCallbackSourceInterface::SetDriverCallbackPeriod((totalBufferSize >> 2) / driverSampleRate);

	m_writeBuffer.Construct(totalBufferSize);

	// Write 3 buffers filled with zeroes in AudioOut's queue
	memset(m_pDataArray, 0, totalBufferSize);
	m_writeBuffer.SetArray((byte *) m_pDataArray, 0, totalBufferSize);
	m_audioOut.WriteBuffer(m_writeBuffer);

	m_writeBuffer.Flip(POSITION_TO_ZERO);
	m_writeBuffer.SetArray((byte *) m_pDataArray, 0, totalBufferSize);
	m_audioOut.WriteBuffer(m_writeBuffer);

	m_writeBuffer.Flip(POSITION_TO_ZERO);
	m_writeBuffer.SetArray((byte *) m_pDataArray, 0, totalBufferSize);
	m_audioOut.WriteBuffer(m_writeBuffer);

	// Set 3D and doppler default parameters.
	SetDefaultParameter();

	// Allocate memory for (stereo) mixing buffer.
	m_sMixingBuffer.m_mixingBuffer = (s32*) VOX_ALLOC(sizeof(s32) * totalBufferSize >> 1);
	m_sMixingBuffer.m_nbSample = totalBufferSize >> 2;

	status = m_audioOut.Start();

	if(status != E_SUCCESS || m_sMixingBuffer.m_mixingBuffer == 0)
	{
		m_audioOut.Unprepare();
		VOX_FREE(m_pDataArray);
		m_pDataArray = 0;
		m_sMixingBuffer.m_nbSample = 0;
		AU_CHECKSTATUS(status);
		m_mutex.Unlock();
		return;
	}
	else
	{
		m_audioUnitActive = true;
	}

	m_mutex.Unlock();
}

void DriverBada::Shutdown()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverBada::Shutdown", vox::VoxThread::GetCurThreadId());
	m_mutex.Lock();

	// TODO : Release all resources related to bada
	if(m_audioUnitActive)
	{
		m_audioOut.Reset();		// Stops audioOut and puts state to AUDIOOUT_STATE_PREPARED
		m_audioOut.Unprepare();
		m_audioUnitActive = false;
	}

	// Free intermediate buffer.
	if(m_pDataArray)
		VOX_FREE(m_pDataArray);
	m_pDataArray = 0;

	m_mutex.Unlock();
}

void DriverBada::Suspend()
{
	// TODO : See what should be done here
}

void DriverBada::Resume()
{
	// TODO : See what should be done here
}

void DriverBada::PrintDebug()
{
}


void DriverBada::Update(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverBada::Update", vox::VoxThread::GetCurThreadId());
	m_mutex.Lock();

	if(m_audioUnitActive)
	{
		_FillBuffer(m_pDataArray, m_sMixingBuffer.m_nbSample);

		m_writeBuffer.Flip(POSITION_TO_ZERO);
		m_writeBuffer.SetArray((byte *) m_pDataArray, 0, m_sMixingBuffer.m_nbSample << 2);
		m_audioOut.WriteBuffer(m_writeBuffer);
	}

	m_mutex.Unlock();
}

}//namespace vox

#endif //VOX_DRIVER_USE_BADA && VOX_BADA_DRIVER_PLATFORM
