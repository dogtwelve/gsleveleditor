#include "vox_driver_iphone_remoteio_helper.h"

#if VOX_DRIVER_USE_IPHONE_REMOTEIO && VOX_IPHONE_REMOTEIO_DRIVER_PLATFORM

#import <UIKit/UIDevice.h>
#include "vox_memory.h"
#include <sys/types.h>
#include <sys/sysctl.h>
#include <string.h>

namespace vox
{
	int GetMajorOSVersion()
	{
		NSString* firmware = [[UIDevice currentDevice] systemVersion];
		NSString* major = [firmware substringToIndex:1];
		return [major intValue];
	}
	
	bool Is1stGenDevice()
	{
		bool is1stGen = false;
		::size_t size;
		sysctlbyname("hw.machine", NULL, &size, NULL, 0);
		char *machine = (char*)VOX_ALLOC(size);
		sysctlbyname("hw.machine", machine, &size, NULL, 0);
		
		
		if ( 0 == strcmp( "iPhone1,1", machine ) )
			is1stGen = true;
		else if ( 0 == strcmp( "iPod1,1", machine ) )
			is1stGen = true;
		
		VOX_FREE(machine);
		
		return is1stGen;
	}
}

#endif //VOX_DRIVER_USE_IPHONE_REMOTEIO && VOX_IPHONE_REMOTEIO_DRIVER_PLATFORM

