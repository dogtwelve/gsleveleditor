#include "StdAfx.h"
#include "vox_default_config.h"

#if VOX_DRIVER_USE_CTR_HW && VOX_CTR_DRIVER_PLATFORM

#include <vox_driver_ctr_hw.h>
#include <math.h>

extern "C++" vox::f64 _GetTime();

extern double	utime;
extern s32		uQty;
extern double	uMax;

//DriverSourceCTRHW
namespace vox
{

// Stop process states (see NOTE 1 at the end of this file)
#define STOP_PROCESS_NONE			0
#define STOP_PROCESS_RAMP_DOWN		1
#define STOP_PROCESS_FILL_ZEROES	2
#define STOP_PROCESS_STOP_VOICE		3

#define MAX_DOPPLER_PITCH				10.0f		
#define MIN_DOPPLER_PITCH				0.001f
#define ANGLE_180_DEGREES				180
#define VOLUME_RAMP_LENGTH				128			// Nb of samples involved in volume ramping.
#define PARAMS_UPDATE_CALLBACK_RATIO	5			// Nb of callbacks between parameter updates (gain, pitch, ..)
#define BASIC_DSP_CALLBACK_RATE			0.004889f
#define DSP_CALLBACK_RATE				PARAMS_UPDATE_CALLBACK_RATIO * BASIC_DSP_CALLBACK_RATE

#ifndef M_PI
	#define M_PI	3.14159265358979323846264f
#endif

// Listener, general 3D and doppler static parameters
CTRListenerParameters DriverSourceCTRHW::s_listenerParameters;
u32 DriverSourceCTRHW::s_distanceModel = Vox3DDistanceModel::k_nInverseDistanceClamped;
f32 DriverSourceCTRHW::s_dopplerFactor = 1.0f;			
f32 DriverSourceCTRHW::s_alteredSpeedOfSound = 343.3f;
f32 DriverSourceCTRHW::m_lastUpdateDT = DSP_CALLBACK_RATE;


DriverSourceCTRHW::DriverSourceCTRHW(void * trackParam, void* driverParam, s32 sourceId):
m_isReady(false)
,m_trackParams(*((TrackParams*)trackParam))
,m_processedBytes(0)
,m_currentWriteBuffer(0)
,m_currentReadBuffer(0)
,m_useHWState(false)
,m_state(DriverSource::STATE_INITIAL)
,m_byteOffset(0)
,m_pVoiceData((CTRVoice*)sourceId)
,m_gain(1.0f)
,m_oldGain(1.0f)
,m_deltaGain(0.0f)
,m_userPitch(1.0f)
,m_oldPitch(1.0f)
,m_deltaPitch(0.0f)
,m_callbackCount(0)
,m_isPauseUpdateNeeded(false)
,m_isPlayUpdateNeeded(false)
,m_isStopUpdateNeeded(false)
,m_stopProcessState(STOP_PROCESS_NONE)
,m_isResetNeeded(false)
,m_finishedCheckCount(0)
,m_isFirstUploadDone(false)
,m_isFirstPlayDone(false)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSourceCTRHW::DriverSourceCTRHW", vox::VoxThread::GetCurThreadId());

	if(m_pVoiceData)
	{
		m_bytesPerSample = (m_trackParams.bitsPerSample >> 3) * m_trackParams.numChannels;

		// Determine the desired number of buffers
		if(driverParam != 0)
		{
			m_numBuffer = ((CTRSourceParam*)driverParam)->numBuffer;
		}
		else
		{
			m_numBuffer = VOX_DRIVER_SOURCE_NUM_BUFFER;
		}

		s32 buffersize = VOX_EMITTER_BUFFER_DURATION_MS * m_trackParams.samplingRate * m_bytesPerSample / 1000;
		
		// Make buffersize a multiple of sample size
		buffersize -= (buffersize % m_bytesPerSample);

		if(buffersize < (VOX_DRIVER_CTR_SOURCE_BUFFER_SAMPLE * sizeof(s32)*2))
		{
			VOX_WARNING_LEVEL_2("%s", "Emitter buffer to small, may cause playback issue");
		}

		for(int i = 0; i < m_numBuffer; i++)
		{
			CTRBuffer newBuffer;
			newBuffer.free = true;
			newBuffer.m_cursorPos = 0;
			newBuffer.m_totalSize = buffersize;
			newBuffer.m_usedSize = 0;
			newBuffer.m_data = 0;
			m_bufferList.push_back(newBuffer);
		}
		if(m_numBuffer != m_bufferList.size())
		{
			VOX_WARNING_LEVEL_3("Could not allocate all buffer for source % d : %d allocated on %d", 0, m_bufferList.size(), m_numBuffer);
		}

		// Get the number of buffers really allocated
		m_numBuffer = m_bufferList.size();

		if(m_numBuffer <= 0)
		{
			m_state = DriverSource::STATE_ERROR; // No buffer allocated
		}
	}
	else // Could not get a voice.
	{
		m_state = DriverSource::STATE_ERROR;
	}
}


DriverSourceCTRHW::~DriverSourceCTRHW()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSourceCTRHW::~DriverSourceCTRHW", vox::VoxThread::GetCurThreadId());
	if(m_isReady)
	{
		Cleanup();
	}
}


void DriverSourceCTRHW::Init()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSourceCTRHW::Init", vox::VoxThread::GetCurThreadId());

	if(m_pVoiceData)
	{
		nn::snd::MixParam mix;
		if(m_trackParams.numChannels == 1)
		{
			m_pVoiceData->m_pVoice->SetChannelCount( 1 );

			mix.mainBus[nn::snd::CHANNEL_INDEX_FRONT_LEFT ] = 0.707f;
			mix.mainBus[nn::snd::CHANNEL_INDEX_FRONT_RIGHT] = 0.707f;
			mix.mainBus[nn::snd::CHANNEL_INDEX_REAR_LEFT ] = 0.0f;
			mix.mainBus[nn::snd::CHANNEL_INDEX_REAR_RIGHT] = 0.0f;
		}
		else if (m_trackParams.numChannels ==2)
		{
			m_pVoiceData->m_pVoice->SetChannelCount( 2 );

			// Gains are at 0.99 instead of 1.0f because sound doesn't fade in correctly with 1.0f (!!!)
			mix.mainBus[nn::snd::CHANNEL_INDEX_FRONT_LEFT ] = 0.99f; // (L)
			mix.mainBus[nn::snd::CHANNEL_INDEX_FRONT_RIGHT] = 0.99f; // (R)
			mix.mainBus[nn::snd::CHANNEL_INDEX_REAR_LEFT ] = 0.0f; // (L)
			mix.mainBus[nn::snd::CHANNEL_INDEX_REAR_RIGHT] = 0.0f; // (R)
		}
		else
		{
			m_state = DriverSource::STATE_ERROR;
		}

		m_pVoiceData->m_pVoice->SetMixParam(mix);

		if(m_trackParams.bitsPerSample == 8)
		{
			m_pVoiceData->m_pVoice->SetSampleFormat( nn::snd::SAMPLE_FORMAT_PCM8 );
		}
		else if(m_trackParams.bitsPerSample == 16)
		{
			m_pVoiceData->m_pVoice->SetSampleFormat( nn::snd::SAMPLE_FORMAT_PCM16 );
		}
		else if(m_trackParams.bitsPerSample == 256) // Support for BCWav
		{
			//Will set sample format on play, need actual data to know
		}
		else
		{
			m_state = DriverSource::STATE_ERROR;
		}		

		m_pVoiceData->m_pVoice->SetVolume(1.0f);
		m_pVoiceData->m_pVoice->SetPitch(1.0f);
		m_pVoiceData->m_pVoice->SetSampleRate(m_trackParams.samplingRate);
		m_pVoiceData->m_pVoice->SetInterpolationType(VOX_DRIVER_CTR_INTERPOLATION_TYPE);
		m_pVoiceData->m_pVoice->SetStartFrameFadeInFlag(true);

		m_isReady = true;
	}
}


void DriverSourceCTRHW::Cleanup()
{
	//nothing to do ...
}


void DriverSourceCTRHW::Play()
{
	m_isPlayUpdateNeeded = true;
}


void DriverSourceCTRHW::_Play()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSourceCTRHW::Play", vox::VoxThread::GetCurThreadId());

	if(m_state != DriverSource::STATE_ERROR && m_pVoiceData)
	{
		if(m_pVoiceData->m_pVoice)
		{
			if(GetState() != DriverSource::STATE_PAUSED)
			{
				m_finishedCheckCount = 0;

				if(m_bufferList[m_currentReadBuffer].free)
				{
					VOX_WARNING_LEVEL_3("Can't start source %d, no data available", 0);
					return;
				}
				else
				{
					s32 nByteNeeded = VOX_DRIVER_CTR_SOURCE_BUFFER_SAMPLE * sizeof(s32);

					if(m_trackParams.bitsPerSample != 256) // Formats other than BCWav
					{
						// Fill first buffer
						nn::snd::WaveBuffer* pBuf = &(m_pVoiceData->m_waveBuffer[0]);

						if(pBuf->status == nn::snd::WaveBuffer::STATUS_DONE || pBuf->status == nn::snd::WaveBuffer::STATUS_FREE)
						{
							s32 byteWritten = FillBuffer((u8*)m_pVoiceData->m_dataBuffer[0], nByteNeeded);
							nn::snd::FlushDataCache(reinterpret_cast<uptr>(m_pVoiceData->m_dataBuffer[0]), byteWritten);

							nn::snd::InitializeWaveBuffer(pBuf);
							pBuf->bufferAddress = m_pVoiceData->m_dataBuffer[0];
							pBuf->sampleLength  = nn::snd::GetSampleLength(byteWritten, m_trackParams.bitsPerSample == 8 ? nn::snd::SAMPLE_FORMAT_PCM8 : nn::snd::SAMPLE_FORMAT_PCM16, m_trackParams.numChannels);
							pBuf->loopFlag  = false;
							m_pVoiceData->m_pVoice->AppendWaveBuffer(pBuf);
						}
					}
					else
					{
						m_pVoiceData->m_waveInfo = nn::snd::Bcwav::GetWaveInfo(m_bufferList[m_currentReadBuffer].m_data);						
						m_pVoiceData->m_adpcmInfo = *nn::snd::Bcwav::GetDspAdpcmInfo(m_bufferList[m_currentReadBuffer].m_data, 0);

						const void* pBcwavBody = nn::snd::Bcwav::GetWave(m_bufferList[m_currentReadBuffer].m_data, nn::snd::Bcwav::CHANNEL_INDEX_L);
						m_pVoiceData->m_bcwavWaveOffset = reinterpret_cast<size_t>(pBcwavBody) - reinterpret_cast<size_t>(m_bufferList[m_currentReadBuffer].m_data);

						m_pVoiceData->m_pVoice->SetSampleRate(m_pVoiceData->m_waveInfo.sampleRate);
						m_pVoiceData->m_pVoice->SetSampleFormat((nn::snd::SampleFormat)m_pVoiceData->m_waveInfo.encoding);
						m_pVoiceData->m_pVoice->SetChannelCount(1);
						m_pVoiceData->m_pVoice->SetAdpcmParam(m_pVoiceData->m_adpcmInfo.param);

						// Fill first buffer
						nn::snd::WaveBuffer* pBuf = &(m_pVoiceData->m_waveBuffer[0]);

						if(pBuf->status == nn::snd::WaveBuffer::STATUS_DONE || pBuf->status == nn::snd::WaveBuffer::STATUS_FREE)
						{
							s32 byteWritten = FillBufferBCWav((u8*)m_pVoiceData->m_dataBuffer[0], nByteNeeded);
							m_pVoiceData->m_isLooped = false;
							nn::snd::FlushDataCache(reinterpret_cast<uptr>(m_pVoiceData->m_dataBuffer[0]), byteWritten);

							nn::snd::InitializeWaveBuffer(pBuf);
							pBuf->bufferAddress = m_pVoiceData->m_dataBuffer[0];
							pBuf->sampleLength  = nn::snd::GetSampleLength(byteWritten, nn::snd::SAMPLE_FORMAT_ADPCM, 1);
							pBuf->loopFlag  = false;
							
							pBuf->pAdpcmContext = &m_pVoiceData->m_adpcmInfo.context;
							m_pVoiceData->m_pVoice->AppendWaveBuffer(pBuf);
						}
						//int id = 0;
						//nn::snd::WaveBuffer* pBuf = &(m_pVoiceData->m_waveBuffer[id]);
						//if(pBuf->status == nn::snd::WaveBuffer::STATUS_DONE || pBuf->status == nn::snd::WaveBuffer::STATUS_FREE)
						//{
						//	nn::snd::InitializeWaveBuffer(pBuf);
						//	pBuf->bufferAddress = nn::snd::Bcwav::GetWave(m_bufferList[m_currentReadBuffer].m_data, nn::snd::Bcwav::CHANNEL_INDEX_L);

						//	const nn::snd::Bcwav::WaveInfo& info = nn::snd::Bcwav::GetWaveInfo(m_bufferList[m_currentReadBuffer].m_data);

						//	s32 datasize = m_bufferList[m_currentReadBuffer].m_usedSize - ((s32)pBuf->bufferAddress - (s32)m_bufferList[m_currentReadBuffer].m_data);
						//	pBuf->sampleLength  = nn::snd::GetSampleLength(datasize, (nn::snd::SampleFormat)info.encoding, m_trackParams.numChannels);
						//	pBuf->loopFlag  = false;

						//	m_pVoiceData->m_pVoice->SetSampleFormat((nn::snd::SampleFormat)info.encoding);
						//	if(info.encoding == nn::snd::Bcwav::ENCODING_DSP_ADPCM)
						//	{
						//		const nn::snd::Bcwav::DspAdpcmInfo* adpcmInfo = nn::snd::Bcwav::GetDspAdpcmInfo(m_bufferList[m_currentReadBuffer].m_data, 0);
						//		m_pVoiceData->m_adpcmContext = adpcmInfo->context;
						//		m_pVoiceData->m_pVoice->SetAdpcmParam(adpcmInfo->param);
						//		pBuf->pAdpcmContext = &m_pVoiceData->m_adpcmContext;
						//	}

						//	m_pVoiceData->m_pVoice->AppendWaveBuffer(pBuf);

						//	m_bufferList[m_currentReadBuffer].free = true;
						//	m_currentReadBuffer = (m_currentReadBuffer + 1) % m_numBuffer;
						//}
					}
					m_pVoiceData->m_currentBuffer = VOX_DRIVER_CTR_SOURCE_BUFFER > 1 ? 1 : 0;
				}
			}
		
			m_pVoiceData->m_pVoice->SetState( nn::snd::Voice::STATE_PLAY );
			m_state = DriverSource::STATE_PLAYING;
			m_useHWState = true;
		}		
	}
}


void DriverSourceCTRHW::Stop()
{
	m_isStopUpdateNeeded = true;
}


void DriverSourceCTRHW::_Stop()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSourceCTRHW::Stop", vox::VoxThread::GetCurThreadId());

	if(m_state != DriverSource::STATE_ERROR && m_pVoiceData)
	{
		if(m_pVoiceData->m_pVoice)
		{
			m_pVoiceData->m_pVoice->SetState( nn::snd::Voice::STATE_STOP );
			m_state = DriverSource::STATE_STOPPED;
			m_useHWState = true;
		}		
	}
}


void DriverSourceCTRHW::Pause()
{
	m_isPauseUpdateNeeded = true;
}

void DriverSourceCTRHW::_Pause()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSourceCTRHW::Pause", vox::VoxThread::GetCurThreadId());

	if(m_state != DriverSource::STATE_ERROR && m_pVoiceData)
	{
		if(m_pVoiceData->m_pVoice)
		{
			m_pVoiceData->m_pVoice->SetState( nn::snd::Voice::STATE_PAUSE );
			m_state = DriverSource::STATE_PAUSED;
		}		
	}
}


void DriverSourceCTRHW::Reset()
{
	m_isResetNeeded = true;
}

void DriverSourceCTRHW::_Reset()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSourceCTRHW::Reset", vox::VoxThread::GetCurThreadId());

	if(m_state != DriverSource::STATE_ERROR && m_pVoiceData)
	{
		if(m_pVoiceData->m_pVoice)
		{
			m_pVoiceData->m_pVoice->SetState( nn::snd::Voice::STATE_STOP );
			m_byteOffset = 0;
			m_state = DriverSource::STATE_INITIAL;
			m_useHWState = false;
		}		
	}

	FreeAllBuffer();
}

s32 DriverSourceCTRHW::GetState()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSourceCTRHW::GetState", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex);)
	if(m_useHWState && m_state != DriverSource::STATE_ERROR && m_pVoiceData)
	{
		if(m_pVoiceData->m_pVoice)
		{
			nn::snd::Voice::State state =  m_pVoiceData->m_pVoice->GetState();
			switch(state)
			{
				case nn::snd::Voice::STATE_PLAY:
				{
					m_state = DriverSource::STATE_PLAYING;
					break;
				}
				case nn::snd::Voice::STATE_PAUSE:
				{
					m_state = DriverSource::STATE_PAUSED;
					break;
				}
				case nn::snd::Voice::STATE_STOP:
				{
					m_state = DriverSource::STATE_STOPPED;
					break;
				}
				default : //unknown state
				{
					m_state = DriverSource::STATE_ERROR;
					break;
				}
			}
		}		
		else
		{
			m_state = DriverSource::STATE_ERROR;
		}		
	}

	return m_state;
}

void DriverSourceCTRHW::FreeAllBuffer()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSourceCTRHW::FreeAllBuffer", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex);)
	for(int i = 0; i < m_numBuffer; i++)
	{
		m_bufferList[i].free = true;
		m_currentReadBuffer = 0;
		m_currentWriteBuffer = 0;
	}
}


void DriverSourceCTRHW::FreeDisposableData(s32 maxNbBytes, s32 &nbBuffersFreed, s32 &nbBytesFreed)
{
	ScopeMutex sm(&m_mutex);

	if(!m_isReady)
		return;

	if(m_trackParams.bitsPerSample == 256)
		maxNbBytes = 0; //can't rewind BCWav

	nbBuffersFreed = 0;
	nbBytesFreed = 0;

	if(maxNbBytes <= 0)
		return;

	s32 bufferIndex;
	s32 nbBytesInBuffer;
	s32 cursorPosition;					// In bytes
	s32 nbBytesFromCurrentPosition = 0;
	s32 nbBytesFromEnd = 0;
	s32 nbBytesInPreviousBuffers = 0;
	s32 earliestDisposableBuffer = -1;		// Buffer containing position = current cursor + safety margin.
	s32 earliestDisposablePosition = 0;		// Position of current cursor + safety margin in 'earliestBuffer'

	// Get a safety margin (in bytes) equivalent to VOX_NATIVE_LATENCY_SAFETY_MARGIN driver callbacks
	s32 safetyMargin = VOX_DRIVER_CTR_SOURCE_BUFFER_SAMPLE * VOX_NATIVE_LATENCY_SAFETY_MARGIN * sizeof(s32);
	
	// Determine the the earliest buffer (and position) where data can be overwritten
	bufferIndex = m_currentReadBuffer;
	for(s32 i = 0; i < m_numBuffer; i++)
	{
		if(!m_bufferList[bufferIndex].free)
		{
			nbBytesInBuffer = m_bufferList[bufferIndex].m_usedSize;
			cursorPosition = m_bufferList[bufferIndex].m_cursorPos;
			nbBytesFromCurrentPosition += nbBytesInBuffer - cursorPosition;

			if(nbBytesFromCurrentPosition > safetyMargin)
			{
				earliestDisposableBuffer = bufferIndex;
				earliestDisposablePosition = cursorPosition + safetyMargin - nbBytesInPreviousBuffers;
				break;
			}
		}

		bufferIndex = (bufferIndex + 1) % m_numBuffer;
		nbBytesInPreviousBuffers = nbBytesFromCurrentPosition;
	}

	// Free buffers starting with buffer following read buffer
	nbBytesInPreviousBuffers = 0;
	bufferIndex = m_currentReadBuffer == 0 ? m_numBuffer - 1 : m_currentReadBuffer - 1;

	for(s32 i = 0; i < m_numBuffer; i++)
	{
		if(!m_bufferList[bufferIndex].free)
		{
			nbBytesInBuffer = m_bufferList[bufferIndex].m_usedSize;
			cursorPosition = m_bufferList[bufferIndex].m_cursorPos;
			nbBytesFromEnd += nbBytesInBuffer - cursorPosition;

			if(bufferIndex == earliestDisposableBuffer)
			{
				if(cursorPosition + nbBytesFromEnd - maxNbBytes < earliestDisposablePosition)
				{
					m_bufferList[bufferIndex].m_usedSize = earliestDisposablePosition;
					if(earliestDisposablePosition == 0)
					{
						m_bufferList[bufferIndex].free = true;
						nbBuffersFreed++;
						m_currentWriteBuffer = bufferIndex;
					}
					else
					{
						m_currentWriteBuffer = (bufferIndex + 1) % m_numBuffer;
					}
				}
				else
				{
					m_bufferList[bufferIndex].m_usedSize = cursorPosition + nbBytesFromEnd - maxNbBytes;
					m_currentWriteBuffer = (bufferIndex + 1) % m_numBuffer;
				}
				nbBytesFreed += nbBytesInBuffer - m_bufferList[bufferIndex].m_usedSize;
				break;
			}
			else // Buffer is not the earliest disposable buffer
			{
				if(nbBytesFromEnd < maxNbBytes) // Buffer can be freed completely
				{
					m_bufferList[bufferIndex].free = true;
					nbBuffersFreed++;
					nbBytesFreed += nbBytesInBuffer;
				}
				else // Part of the buffer can be overwritten
				{
					m_bufferList[bufferIndex].m_usedSize = cursorPosition + nbBytesFromEnd - maxNbBytes;
					nbBytesFreed += nbBytesInBuffer - m_bufferList[bufferIndex].m_usedSize;
					m_currentWriteBuffer = (bufferIndex + 1) % m_numBuffer;
					break;
				}
			}
			nbBytesInPreviousBuffers = nbBytesFromEnd;
		}

		bufferIndex = bufferIndex == 0 ? m_numBuffer - 1 : bufferIndex - 1;
	}
}


bool DriverSourceCTRHW::NeedData()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSourceCTRHW::NeedData", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex);)
	
	if(!m_isReady)
		return false;
	
	bool result = false;

	if(m_state != DriverSource::STATE_ERROR && m_numBuffer > 0 && m_pVoiceData) //Check if next buffer is free
	{
		result = m_bufferList[m_currentWriteBuffer].free;
	}

	return result;
}

void DriverSourceCTRHW::UploadData(void* soundData, s32 bufferSize)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSourceCTRHW::UploadData", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex);)

	if(!m_isReady)
		return;	

	if(!m_pVoiceData)
	{
		return;
	}

	if(m_state == DriverSource::STATE_ERROR)
	{
		return;
	}

	//check that current writebuffer is free
	if(!m_bufferList[m_currentWriteBuffer].free)
	{
		VOX_WARNING_LEVEL_3("Trying to upload to source %d, but no buffer free", 0);
		return;
	}

	m_bufferList[m_currentWriteBuffer].m_totalSize = bufferSize; //Since this use reference, size doesn't matter
	m_bufferList[m_currentWriteBuffer].m_data = (u8*)soundData;
	m_bufferList[m_currentWriteBuffer].m_usedSize = bufferSize;
	m_bufferList[m_currentWriteBuffer].m_cursorPos = 0;
	m_bufferList[m_currentWriteBuffer].free = false;
	m_currentWriteBuffer++;
	m_currentWriteBuffer %= m_numBuffer;

	m_isFirstUploadDone = true;
}


void DriverSourceCTRHW::SetGain(f32 gain)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSourceCTRHW::SetGain", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex);)
	if(m_state != DriverSource::STATE_ERROR && m_pVoiceData)
	{
		if(m_pVoiceData->m_pVoice)
		{
			if(m_state == DriverSource::STATE_PLAYING)
			{
				m_gain = gain;
				m_deltaGain = (m_gain - m_oldGain) * ( DSP_CALLBACK_RATE / (m_lastUpdateDT > DSP_CALLBACK_RATE ? m_lastUpdateDT : DSP_CALLBACK_RATE));
			}
			else
			{
				m_gain = gain;
				m_oldGain = gain;
			}
		}		
	}
}



void DriverSourceCTRHW::SetPitch(f32 pitch)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSourceCTRHW::SetPitch", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex);)
	if(m_state != DriverSource::STATE_ERROR && m_pVoiceData)
	{
		if(m_pVoiceData->m_pVoice)
		{
			if(m_state == DriverSource::STATE_PLAYING)
			{
				m_userPitch = pitch;
				m_deltaPitch = (m_userPitch - m_oldPitch) * ( DSP_CALLBACK_RATE / (m_lastUpdateDT > DSP_CALLBACK_RATE ? m_lastUpdateDT : DSP_CALLBACK_RATE));
			}
			else
			{
				m_userPitch = pitch;
				m_oldPitch = pitch; 
			}
		}		
	}
}

f32 DriverSourceCTRHW::GetGain()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSourceCTRHW::GetGain", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex);)
	if(m_state != DriverSource::STATE_ERROR && m_pVoiceData)
	{
		if(m_pVoiceData->m_pVoice)
		{
			return m_gain;//m_pVoiceData->m_pVoice->GetVolume();
		}		
	}
	return 0.0f;
}

f32 DriverSourceCTRHW::GetPitch()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSourceCTRHW::GetPitch", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex);)
	if(m_state != DriverSource::STATE_ERROR && m_pVoiceData)
	{
		if(m_pVoiceData->m_pVoice)
		{
			return m_userPitch;
		}		
	}
	return 0.0f;
}

void DriverSourceCTRHW::Set3DParameter(s32 paramId, void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverSourceCTRHW::Set3DParameter", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_pVoiceData)
	{
		switch(paramId)
		{
			case Vox3DEmitterParameter::k_nRelativeToListener:
			{
				s32 value = *((s32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Relative to listener' for %d to %d", m_pVoiceData, value);
				m_relativeToListener = value;
				break;
			}
			case Vox3DEmitterParameter::k_nMaxDistance:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Max distance' for %d to %f", m_pVoiceData, value);
				m_maxDistance = value;
				break;
			}
			case Vox3DEmitterParameter::k_nReferenceDistance:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Reference distance' for %d to %f", m_pVoiceData, value);
				m_referenceDistance = value;
				break;
			}
			case Vox3DEmitterParameter::k_nRolloffFactor:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Rolloff factor' for %d to %f", m_pVoiceData, value);
				m_rolloffFactor = value;
				break;
			}
			case Vox3DEmitterParameter::k_nInnerConeAngle:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Inner cone angle' for %d to %f", m_pVoiceData, value);
				m_innerConeAngle = value;
				break;
			}
			case Vox3DEmitterParameter::k_nOuterConeAngle:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Outer cone angle' for %d to %f", m_pVoiceData, value);
				m_outerConeAngle = value;
				break;
			}
			case Vox3DEmitterParameter::k_nOuterConeGain:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Outer cone gain' for %d to %f", m_pVoiceData, value);
				m_outerConeGain = value;
				break;
			}
			case Vox3DEmitterParameter::k_nPosition:
			{
				VoxVector3f* value = (VoxVector3f*)param;
				m_position.x = value->x;
				m_position.y = value->y;
				m_position.z = value->z;
				break;
			}
			case Vox3DEmitterParameter::k_nVelocity:
			{
				VoxVector3f* value = (VoxVector3f*)param;
				m_velocity.x = value->x;
				m_velocity.y = value->y;
				m_velocity.z = value->z;
				break;
			}
			case Vox3DEmitterParameter::k_nDirection:
			{
				VoxVector3f* value = (VoxVector3f*)param;
				m_direction.x = value->x;
				m_direction.y = value->y;
				m_direction.z = value->z;
				break;
			}
			default:
			{
				VOX_WARNING_LEVEL_4("CTRHW source doesn't support property %d", paramId);
				break;
			}
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}


s32 DriverSourceCTRHW::FillBuffer(u8* buffer, s32 size)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverSourceCTRHW::FillBuffer", vox::VoxThread::GetCurThreadId());

	// Second step of the stop process. Fill one buffer with zeroes.
	if(m_stopProcessState == STOP_PROCESS_FILL_ZEROES)
	{
		memset(buffer, 0, size);
		m_stopProcessState = STOP_PROCESS_STOP_VOICE;
		return size;
	}

	s32 neededSize = size;

	if(!m_bufferList[m_currentReadBuffer].free)
	{
		if(m_stopProcessState == STOP_PROCESS_NONE) // Sound doesn't need to be stopped. Feed data as usual.
		{
			while(neededSize > 0)
			{
				s32 availableBytes = m_bufferList[m_currentReadBuffer].m_usedSize - m_bufferList[m_currentReadBuffer].m_cursorPos;
				if( neededSize <= availableBytes)
				{
					memcpy(buffer + (size - neededSize), m_bufferList[m_currentReadBuffer].m_data + m_bufferList[m_currentReadBuffer].m_cursorPos, neededSize);
					m_bufferList[m_currentReadBuffer].m_cursorPos += neededSize;
					neededSize = 0;
				}
				else if(availableBytes > 0)
				{
					memcpy(buffer + (size - neededSize), m_bufferList[m_currentReadBuffer].m_data + m_bufferList[m_currentReadBuffer].m_cursorPos, availableBytes);
					neededSize -= availableBytes;
					m_bufferList[m_currentReadBuffer].m_cursorPos += availableBytes;
				}

				if(m_bufferList[m_currentReadBuffer].m_usedSize == m_bufferList[m_currentReadBuffer].m_cursorPos)
				{
					m_bufferList[m_currentReadBuffer].free = true;
					m_currentReadBuffer = (m_currentReadBuffer + 1) % m_numBuffer;
					if(m_bufferList[m_currentReadBuffer].free)
						break;
				}
			}
		}
		else if(m_stopProcessState == STOP_PROCESS_RAMP_DOWN) // First sted of the stop process. Ramp-down 5ms of data.
		{
			s32 rampedSize = 0;
			if(m_trackParams.numChannels == 1)
			{
				rampedSize = RampDownMonoBuffer(buffer, size);
			}
			else if(m_trackParams.numChannels == 2)
			{
				rampedSize = RampDownStereoBuffer(buffer, size);
			}
			m_stopProcessState = STOP_PROCESS_FILL_ZEROES;
			return rampedSize;
		}
	}

	return size - neededSize;
}

s32 DriverSourceCTRHW::FillBufferBCWav(u8* buffer, s32 size)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverSourceCTRHW::FillBufferBCWav", vox::VoxThread::GetCurThreadId());
	s32 neededSize = size;
	if(!m_bufferList[m_currentReadBuffer].free && size > 0)
	{
		if(m_bufferList[m_currentReadBuffer].m_cursorPos == 0)
		{
			m_pVoiceData->m_isLooped = true;
			m_bufferList[m_currentReadBuffer].m_cursorPos += m_pVoiceData->m_bcwavWaveOffset;
		}

		s32 availableBytes = m_bufferList[m_currentReadBuffer].m_usedSize - m_bufferList[m_currentReadBuffer].m_cursorPos;
		if(availableBytes > neededSize)
		{
			memcpy(buffer, m_bufferList[m_currentReadBuffer].m_data + m_bufferList[m_currentReadBuffer].m_cursorPos, neededSize);
			m_bufferList[m_currentReadBuffer].m_cursorPos += neededSize;
			neededSize = 0;
		}
		else if(availableBytes > 0)
		{
			memcpy(buffer, m_bufferList[m_currentReadBuffer].m_data + m_bufferList[m_currentReadBuffer].m_cursorPos, availableBytes);
			neededSize -= availableBytes;
			m_bufferList[m_currentReadBuffer].m_cursorPos += availableBytes;
		}

		if(m_bufferList[m_currentReadBuffer].m_usedSize <= m_bufferList[m_currentReadBuffer].m_cursorPos)
		{
			m_bufferList[m_currentReadBuffer].free = true;
			m_currentReadBuffer = (m_currentReadBuffer + 1) % m_numBuffer;
		}
	}

	return size - neededSize;
}


s32 DriverSourceCTRHW::GetNbAvailableSamples(s32 nbSamplesNeeded)
{
	s32 nbAvailableSamples = 0;
	s32 currentBuffer = m_currentReadBuffer;

	for(s32 i = 0; i < m_numBuffer; i++)
	{
		if(m_bufferList[currentBuffer].free)
		{
			return nbAvailableSamples;
		}
		else // Buffer is not free, 
		{
			nbAvailableSamples += (m_bufferList[currentBuffer].m_usedSize - m_bufferList[currentBuffer].m_cursorPos) / m_bytesPerSample;
			if(nbAvailableSamples >= nbSamplesNeeded)
			{
				// Enough samples to provide the number needed.
				return nbAvailableSamples;
			}
			else // Still needing samples, get next buffer
			{
				currentBuffer++;
				currentBuffer %= m_numBuffer;
			}
		}
	}
	// Should never get here ! Means that no buffer is free and their total samples is smaller than request
	return -1;
}


s32 DriverSourceCTRHW::RampDownMonoBuffer(u8* buffer, s32 size)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverSourceCTRHW::RampDownMonoBuffer", vox::VoxThread::GetCurThreadId());

	s16 *pBufferCursor = (s16 *) buffer;

	// Calculate the nominal number of samples to ramp
	s32 nbSamplesToRamp = (s32) (BASIC_DSP_CALLBACK_RATE * m_trackParams.samplingRate);

	// Determine if non-free buffers contain enough samples to perform nominal ramping
	s32 nbAvailableSamples = GetNbAvailableSamples(nbSamplesToRamp);
	
	// If no available samples, do not fill buffer. It will be filled in ProcessDSPCallback().
	if(nbAvailableSamples <= 0)
		return 0;

	// If not enough samples to provide nominal ramping, limit ramping to the number of samples available
	if(nbAvailableSamples < nbSamplesToRamp)
	{
		nbSamplesToRamp = nbAvailableSamples;
	}

	// If the number of samples desired is less than the ramp length, limit ramping to the number of samples desired
	if(nbSamplesToRamp > size / m_bytesPerSample)
	{
		nbSamplesToRamp = size / m_bytesPerSample;
	}

	s32 totalSamplesToRamp = nbSamplesToRamp;

	fx1814 currentGain = VOX_FX1814_ONE;
	fx1814 gainIncrement = -VOX_FX1814_ONE / nbSamplesToRamp;

	while(nbSamplesToRamp > 0)
	{
		s32 availableSamples = (m_bufferList[m_currentReadBuffer].m_usedSize - m_bufferList[m_currentReadBuffer].m_cursorPos) / m_bytesPerSample;
		s32 nbSamplesToFill = nbSamplesToRamp <= availableSamples ? nbSamplesToRamp : availableSamples;
		s16 *pData = (s16*) (m_bufferList[m_currentReadBuffer].m_data + m_bufferList[m_currentReadBuffer].m_cursorPos);

		// Ramp down signal (only part of the ramp length since not enough data in the current pass)
		for(int i = 0; i < nbSamplesToFill; i++)
		{
			currentGain += gainIncrement;
			pBufferCursor[i] = (s16) (((*pData) * currentGain) >> VOX_FX1814_FRACT_SHIFT);
			pData++;
		}

		m_bufferList[m_currentReadBuffer].m_cursorPos += nbSamplesToFill * m_bytesPerSample;
		nbSamplesToRamp -= nbSamplesToFill;

		// If input buffer is done, get next one (if not free).
		if(m_bufferList[m_currentReadBuffer].m_usedSize == m_bufferList[m_currentReadBuffer].m_cursorPos)
		{
			m_bufferList[m_currentReadBuffer].free = true;
			m_currentReadBuffer = (m_currentReadBuffer + 1) % m_numBuffer;
			if(m_bufferList[m_currentReadBuffer].free)
				break;
		}
	}

	return ((totalSamplesToRamp - nbSamplesToRamp) * m_bytesPerSample);
}


s32 DriverSourceCTRHW::RampDownStereoBuffer(u8* buffer, s32 size)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverSourceCTRHW::RampDownStereoBuffer", vox::VoxThread::GetCurThreadId());

	s16 *pBufferCursor = (s16 *) buffer;

	// Calculate the nominal number of samples to ramp
	s32 nbSamplesToRamp = (s32) (BASIC_DSP_CALLBACK_RATE * m_trackParams.samplingRate);

	// Determine if non-free buffers contain enough samples to perform nominal ramping
	s32 nbAvailableSamples = GetNbAvailableSamples(nbSamplesToRamp);
	
	// If no available samples, do not fill buffer. It will be filled in ProcessDSPCallback().
	if(nbAvailableSamples <= 0)
		return 0;

	// If not enough samples to provide nominal ramping, limit ramping to the number of samples available
	if(nbAvailableSamples < nbSamplesToRamp)
	{
		nbSamplesToRamp = nbAvailableSamples;
	}

	// If the number of samples desired is less than the ramp length, limit ramping to the number of samples desired
	if(nbSamplesToRamp > size / m_bytesPerSample)
	{
		nbSamplesToRamp = size / m_bytesPerSample;
	}

	s32 totalSamplesToRamp = nbSamplesToRamp;

	fx1814 currentGain = VOX_FX1814_ONE;
	fx1814 gainIncrement = -VOX_FX1814_ONE / nbSamplesToRamp;

	while(nbSamplesToRamp > 0)
	{
		s32 availableSamples = (m_bufferList[m_currentReadBuffer].m_usedSize - m_bufferList[m_currentReadBuffer].m_cursorPos) / m_bytesPerSample;
		s32 nbSamplesToFill = nbSamplesToRamp <= availableSamples ? nbSamplesToRamp : availableSamples;
		s16 *pData = (s16*) (m_bufferList[m_currentReadBuffer].m_data + m_bufferList[m_currentReadBuffer].m_cursorPos);

		// Ramp down signal (only part of the ramp length since not enough data in the current pass)
		for(int i = 0; i < nbSamplesToFill; i++)
		{
			currentGain += gainIncrement;
				
			// Left channel
			*pBufferCursor = (s16) (((*pData) * currentGain) >> VOX_FX1814_FRACT_SHIFT);
			pData++;
			pBufferCursor++;

			// Right channel
			*pBufferCursor = (s16) (((*pData) * currentGain) >> VOX_FX1814_FRACT_SHIFT);
			pData++;
			pBufferCursor++;
		}

		m_bufferList[m_currentReadBuffer].m_cursorPos += nbSamplesToFill * m_bytesPerSample;
		nbSamplesToRamp -= nbSamplesToFill;

		// If input buffer is done, get next one (if not free).
		if(m_bufferList[m_currentReadBuffer].m_usedSize == m_bufferList[m_currentReadBuffer].m_cursorPos)
		{
			m_bufferList[m_currentReadBuffer].free = true;
			m_currentReadBuffer = (m_currentReadBuffer + 1) % m_numBuffer;
			if(m_bufferList[m_currentReadBuffer].free)
				break;
		}
	}

	return ((totalSamplesToRamp - nbSamplesToRamp) * m_bytesPerSample);
}


s32 DriverSourceCTRHW::GetBufferCount()
{
	return m_numBuffer;
}


void DriverSourceCTRHW::ProcessDSPCallback()
{
	//VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverSourceCTRHW::ProcessDSPCallback", vox::VoxThread::GetCurThreadId());
	VOX_PROFILING_START_EVENT( VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverSourceCTRHW::ProcessDSPCallback", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);

	if(!m_isReady)
	{
		Init();
	}

	if(m_isPlayUpdateNeeded && m_isFirstUploadDone)
	{
		_Play();
		m_isFirstPlayDone = true;
		m_isPlayUpdateNeeded = false;
		m_callbackCount = 0;				// Force a parameter update
	}

	// No further processing before _Play() has finished its first execution.
	if(!m_isFirstPlayDone)
		return;

	// Reset can only be done when not in 'stop process' to avoid stopping the voice during ramp-down.
	if(m_isResetNeeded && m_stopProcessState == STOP_PROCESS_NONE)
	{
		_Reset();
		m_isResetNeeded = false;
		m_callbackCount = 0;				// Force a parameter update
	}

	if(m_isPauseUpdateNeeded)
	{
		_Pause();
		m_isPauseUpdateNeeded = false;
		m_callbackCount = 0;				// Force a parameter update
	}

	// Start the 'stop process' (1 FillBuffer() including ramp-down + 1 FillBuffer() with memset(,0,))
	if(m_isStopUpdateNeeded && m_stopProcessState == STOP_PROCESS_NONE)
	{
		if(m_pVoiceData->m_pVoice->GetState() != nn::snd::Voice::STATE_STOP)
		{
			m_stopProcessState = STOP_PROCESS_RAMP_DOWN;
		}
		m_isStopUpdateNeeded = false;
		m_callbackCount = 0;				// Force a parameter update
	}

	// End of the 'stop process'. Stop the voice.
	if(m_stopProcessState == STOP_PROCESS_STOP_VOICE)
	{
		_Stop();
		m_stopProcessState = STOP_PROCESS_NONE;
	}

	if(m_callbackCount == 0)
	{
		if(m_oldPitch != m_userPitch)
		{
			if(abs(m_userPitch - m_oldPitch) < abs(m_deltaPitch))
			{
				m_oldPitch = m_userPitch;
			}
			else
			{
				m_oldPitch += m_deltaPitch;
			}
		}
		f32 pitch = m_oldPitch; //TODO add ramping

		if (m_pVoiceData->m_pVoice != NULL && m_trackParams.numChannels == 1)
		{
			f32 px = 0.0f, pz = 0.0f;
			f32 leftPan, rightPan, rearPan, frontPan;
	
			// Get volume attenuation caused by source to listener distance
			f32 gain3D = GetDistanceGain();
		 
			// Get volume attenuation caused by source directional sound propagation
			gain3D *= GetDirectionalGain();
		 
			// Get 2D projections of source position relative to listener
			Get2DSourceProjections(px, pz);
			
			// Calculate gains to send to quad mix
			rightPan = 0.5f * (1.0f + px);
			leftPan = sqrt(1.0f - rightPan);
			rightPan = sqrt(rightPan);

			// If source is in front of listener, put all power in front speakers to avoid lowpass filtering when rear is involved
			if(pz >= 0.0f)
			{
				frontPan = 1.0f;
				rearPan = 0.0f;
			}
			else
			{
				frontPan = 1.0f + pz;
				rearPan = -pz;
			}

			nn::snd::MixParam mix;

			mix.mainBus[nn::snd::CHANNEL_INDEX_FRONT_LEFT] = gain3D * frontPan * leftPan;
			mix.mainBus[nn::snd::CHANNEL_INDEX_FRONT_RIGHT] = gain3D * frontPan * rightPan;
			mix.mainBus[nn::snd::CHANNEL_INDEX_REAR_LEFT] = gain3D * rearPan * leftPan;
			mix.mainBus[nn::snd::CHANNEL_INDEX_REAR_RIGHT] = gain3D * rearPan * rightPan;

			m_pVoiceData->m_pVoice->SetMixParam(mix);

			f32 dopPitch = GetDopplerPitch();
			pitch *= dopPitch;
		}

		m_pVoiceData->m_pVoice->SetPitch( pitch );	

		if(m_oldGain != m_gain)
		{
			f32 dg = m_gain - m_oldGain;
			if(abs(dg) < abs(m_deltaGain))
			{
				m_oldGain = m_gain;
			}
			else
			{
				m_oldGain += m_deltaGain;
			}
		}

		m_pVoiceData->m_pVoice->SetVolume( m_oldGain );
		//TODO add volume ramping
	}

	m_callbackCount = (m_callbackCount + 1) % PARAMS_UPDATE_CALLBACK_RATIO;

	// Verify is voice is playing. If not, don't try to fill buffers.
	if(m_pVoiceData->m_pVoice->GetState() != nn::snd::Voice::STATE_PLAY)
		return;

	VOX_PROFILING_END_EVENT( VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverSourceCTRHW::ProcessDSPCallback", vox::VoxThread::GetCurThreadId());

	if (m_pVoiceData->m_pVoice != NULL && (m_pVoiceData->m_waveBuffer[m_pVoiceData->m_currentBuffer].status == nn::snd::WaveBuffer::STATUS_DONE || m_pVoiceData->m_waveBuffer[m_pVoiceData->m_currentBuffer].status == nn::snd::WaveBuffer::STATUS_FREE))
	{
		s32 nByteNeeded = VOX_DRIVER_CTR_SOURCE_BUFFER_SAMPLE * sizeof(s32);

		if(m_trackParams.bitsPerSample != 256)
		{
			s32 byteWritten = FillBuffer((u8*)m_pVoiceData->m_dataBuffer[m_pVoiceData->m_currentBuffer], nByteNeeded);

			if(byteWritten > 0)
			{
				m_finishedCheckCount = 0;
				{
					VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverSourceCTRHW::ProcessDSPCallback::FlushDataCache", vox::VoxThread::GetCurThreadId());
					nn::snd::FlushDataCache(reinterpret_cast<uptr>(m_pVoiceData->m_dataBuffer[m_pVoiceData->m_currentBuffer]), byteWritten);
				}

				nn::snd::InitializeWaveBuffer(&(m_pVoiceData->m_waveBuffer[m_pVoiceData->m_currentBuffer]));
				m_pVoiceData->m_waveBuffer[m_pVoiceData->m_currentBuffer].bufferAddress = m_pVoiceData->m_dataBuffer[m_pVoiceData->m_currentBuffer];
				m_pVoiceData->m_waveBuffer[m_pVoiceData->m_currentBuffer].sampleLength  = nn::snd::GetSampleLength(byteWritten, m_trackParams.bitsPerSample == 8 ? nn::snd::SAMPLE_FORMAT_PCM8 : nn::snd::SAMPLE_FORMAT_PCM16, m_trackParams.numChannels);
				
				m_pVoiceData->m_waveBuffer[m_pVoiceData->m_currentBuffer].loopFlag  = false;
				m_pVoiceData->m_pVoice->AppendWaveBuffer(&(m_pVoiceData->m_waveBuffer[m_pVoiceData->m_currentBuffer]));

				m_pVoiceData->m_currentBuffer = (m_pVoiceData->m_currentBuffer + 1) % VOX_DRIVER_CTR_SOURCE_BUFFER;
			}
			else
			{
				++m_finishedCheckCount;
				if(m_finishedCheckCount > 5)
				{
					bool isFinished = true;
					for(s32 i = 0; i < VOX_DRIVER_CTR_SOURCE_BUFFER; ++i)
					{//
						if((m_pVoiceData->m_waveBuffer[m_pVoiceData->m_currentBuffer].status != nn::snd::WaveBuffer::STATUS_DONE)
							&& (m_pVoiceData->m_waveBuffer[m_pVoiceData->m_currentBuffer].status != nn::snd::WaveBuffer::STATUS_FREE))
						{
							isFinished = false;
							break;
						}
					}
					if(isFinished) // Neither voice nor driver has data. Stop the voice.
					{
						m_pVoiceData->m_pVoice->SetState(nn::snd::Voice::STATE_STOP);
					}
				}
			}		
		}
		else
		{
			s32 byteWritten = FillBufferBCWav((u8*)m_pVoiceData->m_dataBuffer[m_pVoiceData->m_currentBuffer], nByteNeeded);

			if(byteWritten > 0)
			{
				m_finishedCheckCount = 0;
				{
					VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverSourceCTRHW::ProcessDSPCallback::FlushDataCache", vox::VoxThread::GetCurThreadId());
					nn::snd::FlushDataCache(reinterpret_cast<uptr>(m_pVoiceData->m_dataBuffer[m_pVoiceData->m_currentBuffer]), byteWritten);
				}

				nn::snd::InitializeWaveBuffer(&(m_pVoiceData->m_waveBuffer[m_pVoiceData->m_currentBuffer]));
				m_pVoiceData->m_waveBuffer[m_pVoiceData->m_currentBuffer].bufferAddress = m_pVoiceData->m_dataBuffer[m_pVoiceData->m_currentBuffer];
				m_pVoiceData->m_waveBuffer[m_pVoiceData->m_currentBuffer].sampleLength  = nn::snd::GetSampleLength(byteWritten, nn::snd::SAMPLE_FORMAT_ADPCM, 1);
				m_pVoiceData->m_waveBuffer[m_pVoiceData->m_currentBuffer].loopFlag  = false;

				if(m_pVoiceData->m_isLooped)
				{
					m_pVoiceData->m_waveBuffer[m_pVoiceData->m_currentBuffer].pAdpcmContext = &m_pVoiceData->m_adpcmInfo.loopContext;
					m_pVoiceData->m_isLooped = false;
				}
				else
				{
					m_pVoiceData->m_waveBuffer[m_pVoiceData->m_currentBuffer].pAdpcmContext = NULL;
				}

				m_pVoiceData->m_pVoice->AppendWaveBuffer(&(m_pVoiceData->m_waveBuffer[m_pVoiceData->m_currentBuffer]));

				m_pVoiceData->m_currentBuffer = (m_pVoiceData->m_currentBuffer + 1) % VOX_DRIVER_CTR_SOURCE_BUFFER;
			}
			else
			{
				++m_finishedCheckCount;
				if(m_finishedCheckCount > 5)
				{
					bool isFinished = true;
					for(s32 i = 0; i < VOX_DRIVER_CTR_SOURCE_BUFFER; ++i)
					{
						if((m_pVoiceData->m_waveBuffer[m_pVoiceData->m_currentBuffer].status != nn::snd::WaveBuffer::STATUS_DONE)
							&& (m_pVoiceData->m_waveBuffer[m_pVoiceData->m_currentBuffer].status != nn::snd::WaveBuffer::STATUS_FREE))
						{
							isFinished = false;
							break;
						}
					}
					if(isFinished) // Neither voice nor driver has data. Stop the voice.
					{
						m_pVoiceData->m_pVoice->SetState(nn::snd::Voice::STATE_STOP);
					}
				}
			}	
			/*if(!m_bufferList[m_currentReadBuffer].free)
			{
				int id = m_pVoiceData->m_currentBuffer;
				nn::snd::WaveBuffer* pBuf = &(m_pVoiceData->m_waveBuffer[id]);
				if(pBuf->status == nn::snd::WaveBuffer::STATUS_DONE || pBuf->status == nn::snd::WaveBuffer::STATUS_FREE)
				{
					nn::snd::InitializeWaveBuffer(pBuf);
					pBuf->bufferAddress = nn::snd::Bcwav::GetWave(m_bufferList[m_currentReadBuffer].m_data, nn::snd::Bcwav::CHANNEL_INDEX_L);

					const nn::snd::Bcwav::WaveInfo& info = nn::snd::Bcwav::GetWaveInfo(m_bufferList[m_currentReadBuffer].m_data);

					s32 datasize = m_bufferList[m_currentReadBuffer].m_usedSize - ((s32)pBuf->bufferAddress - (s32)m_bufferList[m_currentReadBuffer].m_data);
					pBuf->sampleLength  = nn::snd::GetSampleLength(datasize, (nn::snd::SampleFormat)info.encoding, m_trackParams.numChannels);
					pBuf->loopFlag  = false;

					m_pVoiceData->m_pVoice->SetSampleFormat((nn::snd::SampleFormat)info.encoding);
					if(info.encoding == nn::snd::Bcwav::ENCODING_DSP_ADPCM)
					{
						//const nn::snd::Bcwav::DspAdpcmInfo* adpcmInfo = nn::snd::Bcwav::GetDspAdpcmInfo(m_bufferList[m_currentReadBuffer].m_data, 0);
						//m_pVoiceData->m_adpcmContext = adpcmInfo->context;
						//m_pVoiceData->m_pVoice->SetAdpcmParam(adpcmInfo->param);
						pBuf->pAdpcmContext = &m_pVoiceData->m_adpcmContext;
					}

					m_pVoiceData->m_pVoice->AppendWaveBuffer(pBuf);

					m_bufferList[m_currentReadBuffer].free = true;
					m_currentReadBuffer = (m_currentReadBuffer + 1) % m_numBuffer;
				}

				m_pVoiceData->m_currentBuffer = (m_pVoiceData->m_currentBuffer + 1) % VOX_DRIVER_CTR_SOURCE_BUFFER;
			}
			else
			{
				bool isFinished = true;
				for(s32 i = 0; i < VOX_DRIVER_CTR_SOURCE_BUFFER; ++i)
				{
					if(m_pVoiceData->m_waveBuffer[m_pVoiceData->m_currentBuffer].status != nn::snd::WaveBuffer::STATUS_DONE)
					{
						isFinished = false;
						break;
					}
				}
				if(isFinished)
				{
					m_pVoiceData->m_pVoice->SetState(nn::snd::Voice::STATE_STOP);
				}
			}*/
		}
	}
}


// Method 'GetDirectionalGain()' calculates the source gain related to direction of propagation. The gain is related to
// the angle between the source-to-listener and source direction vectors as follow:
//
// 1) If the angle is smaller than the cone inner angle, gain = 1.0f
// 2) If the angle is larger than the cone outer angle, gain = m_outerConeGain.
// 3) If the angle is between the cone inner and outer angles, gain is interpolated between 1.0f and m_outerConeGain.
//
// The angle between source-to-listener and sourceDirection vectors is calculted according to:
//
// angle = arccos(sqrt((slVector.sourceDirection)^2 / (slVector^2 * sourceDirection^2)),
//
// when scalar product slVector.sourceDirection is positive. When scalar product is negative, the calculated angle is
// transformed according to "angle = 180 - angle;".
	
f32 DriverSourceCTRHW::GetDirectionalGain(void)
{		
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverSourceCTRHW::GetDirectionalGain", vox::VoxThread::GetCurThreadId());
	// Calculate gain only if source is directional (but not omni-directional).
	if(m_innerConeAngle < 360.0f && (m_direction.x != 0.0f || m_direction.y != 0.0f || m_direction.z != 0.0f))
	{
		f32 angle;				// Angle between sourceDirection and sourceToListener vectors.
		f32 scalarProduct;
		f32 numerator;
		f32 denominator;
		f32 slVectorX;			// x component of source to listener vector.
		f32 slVectorY;			// y component of source to listener vector.
		f32 slVectorZ;			// z component of source to listener vector.
		f32 slVectorSquare;
		f32 sourceDirectionSquare;
			
		if(m_relativeToListener) // Source position is relative to listener.
		{
			slVectorX = -m_position.x;
			slVectorY = -m_position.y;
			slVectorZ = -m_position.z;
		}
		else // Source position is not relative to listener.
		{
			slVectorX = s_listenerParameters.m_position.x - m_position.x;
			slVectorY = s_listenerParameters.m_position.y - m_position.y;
			slVectorZ = s_listenerParameters.m_position.z - m_position.z;
		}
			
		// Calculate square of scalar product between sourceToListener and sourceDirection vectors.
		scalarProduct = slVectorX * m_direction.x + slVectorY * m_direction.y +	slVectorZ * m_direction.z;
			
		f32 scalarProductSquare = scalarProduct * scalarProduct;	
			
		// Calculate square of length of source-to-listener vector.
		slVectorSquare = slVectorX * slVectorX + slVectorY * slVectorY + slVectorZ * slVectorZ;			
			
		// Calculate square of length of source direction vector.
		sourceDirectionSquare = m_direction.x * m_direction.x + m_direction.y * m_direction.y +
								m_direction.z * m_direction.z;	
			
		// Calculate the angle between source-to-listener and direction vectors (in degrees).
		angle = acos(sqrt(scalarProductSquare / (slVectorSquare * sourceDirectionSquare)));
		angle = angle * ANGLE_180_DEGREES / M_PI; 	// Conversion from radians to degrees.
			
		// Convert angle when scalar product is negative (because argument of acos is positive).
		if(scalarProduct < 0.0f)
		{
			angle = ANGLE_180_DEGREES - angle;
		}
			
		// Get the angle between direction vector and inner cone (half the cone inner angle).
		f32 halfInConeAngle = m_innerConeAngle / 2.0f;
			
		if(angle > halfInConeAngle)
		{
			// Get the angle between direction vector and outer cone (half the cone outer angle).
			f32 halfOutConeAngle = m_outerConeAngle / 2.0f;
				
			// If the source-to-listener vector is located between the inner and outer cones,
			// interpolate the gain between 1.0f and coneOuterGain.
			if(angle < halfOutConeAngle)
			{
				numerator = (halfOutConeAngle - angle) + m_outerConeGain * (angle - halfInConeAngle);
				denominator = halfOutConeAngle - halfInConeAngle;
				if(denominator > 0.0f)
				{
					return(numerator / denominator);
				}
			}
			else // Angle is larger than halfOutConeAngle, gain = m_outerConeGain.
			{
				return(m_outerConeGain );
			}
		}
	}
		
	// If source is non-directional or if angle <= halfInConeAngle, gain = 1.0f.
	return(1.0f);
}
	
	
// Method 'GetDistanceGain()' calculates volume attenuation induced by source to listener distance. The calculation is
// dependent upon the current distance model.
	
f32 DriverSourceCTRHW::GetDistanceGain(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverSourceCTRHW::GetDistanceGain", vox::VoxThread::GetCurThreadId());
	f32 distanceX;
	f32 distanceY;
	f32 distanceZ;
	f32 distance;
	f32 numerator = 1.0f;
	f32 denominator = 1.0f;
	f32 attenuation;
	
	if(m_relativeToListener) // Source position is relative to listener.
	{
		distanceX = m_position.x;
		distanceY = m_position.y;
		distanceZ = m_position.z;
	}
	else // Source position is not relative to listener.
	{
		distanceX = m_position.x - s_listenerParameters.m_position.x;
		distanceY = m_position.y - s_listenerParameters.m_position.y;
		distanceZ = m_position.z - s_listenerParameters.m_position.z;
	}
	
	distance = sqrt(distanceX * distanceX + distanceY * distanceY + distanceZ * distanceZ);
	
	// Evaluate volume attenuation according to distance model.
	if(s_distanceModel == Vox3DDistanceModel::k_nInverseDistance)
	{
		denominator = m_referenceDistance + m_rolloffFactor * (distance - m_referenceDistance);
		
		if(denominator > 0.0f)
		{			
			return(m_referenceDistance / denominator);
		}
	}
	else if(s_distanceModel == Vox3DDistanceModel::k_nInverseDistanceClamped)
	{
		if(distance < m_referenceDistance)
		{
			distance = m_referenceDistance;
		}
		else if(distance > m_maxDistance)
		{
			distance = m_maxDistance;
		}
		
		denominator = m_referenceDistance + m_rolloffFactor * (distance - m_referenceDistance);
		
		if(denominator > 0.0f)
		{			
			return(m_referenceDistance / denominator);
		}
	}
	else if(s_distanceModel == Vox3DDistanceModel::k_nLinearDistance)
	{
		numerator = (distance - m_referenceDistance) * m_rolloffFactor;
		denominator = m_maxDistance - m_referenceDistance;
		
		if(denominator > 0.0f)
		{
			attenuation = 1.0f - (numerator / denominator);
			if(attenuation < 0.0f)
			{
				attenuation = 0.0f;
			}
			return(attenuation);
		}
	}
	else if(s_distanceModel == Vox3DDistanceModel::k_nLinearDistanceClamped)
	{
		if(distance < m_referenceDistance)
		{
			distance = m_referenceDistance;
		}
		else if(distance > m_maxDistance)
		{
			distance = m_maxDistance;
		}
		
		numerator = (distance - m_referenceDistance) * m_rolloffFactor;
		denominator = m_maxDistance - m_referenceDistance;
		
		if(denominator > 0.0f)
		{
			attenuation = 1.0f - (numerator / denominator);
			if(attenuation < 0.0f)
			{
				attenuation = 0.0f;
			}
			return(attenuation);
		}		
	}
	else if(s_distanceModel == Vox3DDistanceModel::k_nExponentDistance)
	{
		if(m_rolloffFactor > 0.0f && m_referenceDistance > 0.0f)
		{					
			attenuation = pow(distance / m_referenceDistance, -m_rolloffFactor);
			return (attenuation);
		}					
	}
	else if(s_distanceModel == Vox3DDistanceModel::k_nExponentDistanceClamped)
	{	
		if(m_rolloffFactor > 0.0f && m_referenceDistance > 0.0f)
		{		
			if(distance < m_referenceDistance)
			{
				distance = m_referenceDistance;
			}
			else if(distance > m_maxDistance)
			{
				distance = m_maxDistance;
			}
			
			attenuation = pow(distance / m_referenceDistance, -m_rolloffFactor);
			return (attenuation);
		}					
	}
	
	return 1.0f;
}

// Method 'GetDopplerPitch()' calculates doppler shift based on a formula taken from the OpenAL 1.1 Specification.
// However, calculations differ slightly from the specification in order to minimize multiplications and divisions
// (while keeping the same result). The implemented formula is :
//	
// dopplerShitf = (psv - plv) / ((speedOfSound / dopplerFactor) * slVectorLength - psv)
// and
// psv = projected source velocity (projected on source to listener vector).
// plv = projected listener velocity (projected on source to listener vector).
// m_speedOfSound = speed of sound
// DopplerFactor = doppler factor.
// slVectorLength = magnitude of source to listener vector.
	
f32 DriverSourceCTRHW::GetDopplerPitch(void)
{	
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverSourceCTRHW::GetDopplerPitch", vox::VoxThread::GetCurThreadId());
	if(s_dopplerFactor > 0.0f)
	{
		f32 slVectorX;
		f32 slVectorY;
		f32 slVectorZ;
		f32 plv = 0.0f;
		f32	psv;
		
		// Calculate source to listener vector.
		if(m_relativeToListener)				// Source position is relative to listener.
		{
			slVectorX = -m_position.x;
			slVectorY = -m_position.y;
			slVectorZ = -m_position.z;
		}
		else // Source position is not relative to listener.
		{
			slVectorX = s_listenerParameters.m_position.x - m_position.x;
			slVectorY = s_listenerParameters.m_position.y - m_position.y;
			slVectorZ = s_listenerParameters.m_position.z - m_position.z;
			
			// Calculate projection of listener velocity on sourceToListener vector.
			plv = (s_listenerParameters.m_velocity.x * slVectorX +
				   s_listenerParameters.m_velocity.y * slVectorY +
				   s_listenerParameters.m_velocity.z * slVectorZ);
		}
			
		// Calculate the length of source to listener vector.
		f32 slVectorLength = sqrt(slVectorX * slVectorX + slVectorY * slVectorY + slVectorZ * slVectorZ);

		// Calculate projection of source velocity on sourceToListener vector.
		psv = (m_velocity.x * slVectorX + m_velocity.y * slVectorY + m_velocity.z * slVectorZ);
			
		// Limit source and listener absolute velocities with the speedOfSound/dopplerFactor ratio.
		f32 speedOfSoundFactor = s_alteredSpeedOfSound * slVectorLength;
		
		// Limit projected listener velocity to speedOfSoundFactor
		if(plv > speedOfSoundFactor)
		{
			plv = speedOfSoundFactor;
		}

		f32 denominator = speedOfSoundFactor - psv;
			
		// Return calculated pitch only is denominator is larger than 0.
		if(denominator > 0.0f)
		{
			float dopplerPitch = (1.0f + (psv - plv) / denominator);
			if(dopplerPitch > MAX_DOPPLER_PITCH)
			{
				dopplerPitch = MAX_DOPPLER_PITCH;
			}
			else if(dopplerPitch < MIN_DOPPLER_PITCH)
			{
				dopplerPitch = MIN_DOPPLER_PITCH;
			}
			
			return dopplerPitch;
		}
	}
	
	return 1.0;
}


void DriverSourceCTRHW::Get2DSourceProjections(f32 &px, f32 &pz)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverSourceCTRHW::Get2DSourceProjections", vox::VoxThread::GetCurThreadId());
	f32 x, y, z;
	f32 positionNorm;
		
	if(m_relativeToListener)
	{
		// Calculate the norm of the source (relative) position vector.
		positionNorm = sqrt(m_position.x * m_position.x + m_position.y * m_position.y + m_position.z * m_position.z);
			
		if(positionNorm > 0.0f)
		{
			x = m_position.x / positionNorm;
			z = m_position.z / positionNorm;
		}
		else
		{
			x = 0.0f;
			z = 0.0f;
		}
			
	}
	else // Source position is not relative to listener.
	{
		// Get source position relative to listener.
		x = m_position.x - s_listenerParameters.m_position.x;
		y = m_position.y - s_listenerParameters.m_position.y;
		z = m_position.z - s_listenerParameters.m_position.z;
		
		// Calculate the norm of the source (relative) position vector.
		positionNorm = sqrt(x * x + y * y +	z * z);

		// Get the 'at' vector
		f32 atX = s_listenerParameters.m_atOrientation.x;
		f32 atY = s_listenerParameters.m_atOrientation.y;
		f32 atZ = s_listenerParameters.m_atOrientation.z;

		// Calculate the norm of the 'at' vector
		f32 atNorm = sqrt(atX * atX + atY * atY + atZ * atZ);
		
		// Calculate vector product between 'at' and 'up' vectors to use for 'x' projection
		f32 atUpVectorProductX = atY * s_listenerParameters.m_upOrientation.z - atZ * s_listenerParameters.m_upOrientation.y;
		f32 atUpVectorProductY = atZ * s_listenerParameters.m_upOrientation.x - atX * s_listenerParameters.m_upOrientation.z;
		f32 atUpVectorProductZ = atX * s_listenerParameters.m_upOrientation.y - atY * s_listenerParameters.m_upOrientation.x;

		// Calculate the norm of the ('at' x 'up') vector product.
		f32 atUpNorm = sqrt(atUpVectorProductX * atUpVectorProductX + atUpVectorProductY * atUpVectorProductY +
							atUpVectorProductZ * atUpVectorProductZ);
			
		if(positionNorm > 0.0f)
		{
			// Normalize source (relative) position
			x /= positionNorm;
			y /= positionNorm;
			z /= positionNorm;

			// Project the 'listener to source' vector upon the 'at' vector.
			if(atNorm > 0.0f)
			{
				// Normalize listener's 'at' vector
				atX /= atNorm;
				atY /= atNorm;
				atZ /= atNorm;

				pz = x * atX + y * atY + z * atZ;
			}
			else
			{
				px = 0.0f;
				pz = 0.0f;
			}
			
			// Project the 'listener to source' vector upon the 'at' x 'up' vector.
			if(atUpNorm > 0.0f)
			{
				// Normalize ('at' x 'up') vector product.
				atUpVectorProductX /= atUpNorm;
				atUpVectorProductY /= atUpNorm;
				atUpVectorProductZ /= atUpNorm;

				px = x * atUpVectorProductX + y * atUpVectorProductY + z * atUpVectorProductZ;
			}
			else
			{
				px = 0.0f;
				pz = 0.0f;
			}
		}
		else
		{
			px = 0.0f;
			pz = 0.0f;
		}
	}
}

void DriverSourceCTRHW::Set3DParameters(CTRListenerParameters listenerParameters, Vox3DGeneralParameters parameters3D)
{	
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverSourceCTRHW::Set3DParameters", vox::VoxThread::GetCurThreadId());
	s_listenerParameters = listenerParameters;
	s_distanceModel = parameters3D.distanceModel;
	s_dopplerFactor = parameters3D.dopplerFactor;
	if(s_dopplerFactor > 0.0f)
	{
		s_alteredSpeedOfSound = parameters3D.speedOfSound / s_dopplerFactor;
	}
	else
	{
		s_alteredSpeedOfSound = parameters3D.speedOfSound;
	}
}

}//DriverSourceCTRHW

//DriverCTRHW
namespace vox
{
bool DriverCTRHW::m_isCallbackThreadActive = false;
bool DriverCTRHW::m_isCallbackThreadNeedUpdate = false;

DriverInterface* CreateDriver()
{
	return VOX_NEW DriverCTRHW();
}

DriverCTRHW::DriverCTRHW()
:m_voiceBufferHeapMemory(0)
{
	Init(0);
}

DriverCTRHW::~DriverCTRHW()
{
	Shutdown();
}

void DriverCTRHW::Init(void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCTRHW::Init", vox::VoxThread::GetCurThreadId());
	SetDefaultParameter();

	nn::Result result;

	s32 memorySize = VOX_DRIVER_CTR_MAX_VOICE * VOX_DRIVER_CTR_SOURCE_BUFFER * VOX_DRIVER_CTR_SOURCE_BUFFER_SAMPLE * 4/*stereo pcm16*/;
	m_voiceBufferHeapMemory = (u8*)VOX_ALLOC_ALIGN( memorySize, (vox::VoxMemHint) (vox::k_nVoxMemHint_Align32 | vox::k_nVoxMemHint_DeviceMemory));

	if(m_voiceBufferHeapMemory)
	{
		m_voiceBufferExtHeap.Initialize( (uptr)m_voiceBufferHeapMemory, memorySize, nn::os::ALLOCATE_OPTION_LINEAR );

		// dsp, snd initialization
		result = nn::dsp::Initialize();
		NN_UTIL_PANIC_IF_FAILED(result);
		result = nn::dsp::LoadDefaultComponent();
		NN_UTIL_PANIC_IF_FAILED(result);
		result = nn::snd::Initialize();
		NN_UTIL_PANIC_IF_FAILED(result);

		// default master volume
		nn::snd::SetMasterVolume( 1.0 );

		// retrieve current output mode
		m_nextOutputMode = vox::k_nOutputModeUnknown;

		nn::snd::CTR::OutputMode outputMode = nn::snd::CTR::GetSoundOutputMode();
		switch(outputMode)
		{
			case nn::snd::CTR::OUTPUT_MODE_MONO:
			{
				m_nextOutputMode = vox::k_nOutputModeMono;
				break;
			}
			case nn::snd::CTR::OUTPUT_MODE_STEREO:
			{
				m_nextOutputMode = vox::k_nOutputModeStereo;
				break;
			}
			case nn::snd::CTR::OUTPUT_MODE_3DSURROUND:
			{
				m_nextOutputMode = vox::k_nOutputModeSurround;
				break;
			}
		}

		m_currentOutputMode = m_nextOutputMode;

		m_isCallbackThreadNeedUpdate = true;
		m_threadSoundCallback.StartUsingAutoStack(
			DriverCTRHW::TreadFunc,
			(void*)this,
			VOX_DRIVER_CTR_SOUND_THREAD_STACK_SIZE,
			VOX_DRIVER_CTR_SOUND_THREAD_PRIORITY
		);
	}
}

void DriverCTRHW::Shutdown()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCTRHW::Shutdown", vox::VoxThread::GetCurThreadId());
	bool isCallbackThreadNeedUpdate = m_isCallbackThreadNeedUpdate;
	m_isCallbackThreadNeedUpdate = false;

	while(m_isCallbackThreadActive)
	{
		nn::os::Thread::Sleep(nn::fnd::TimeSpan::FromMilliSeconds(5));//DSP thread update every 4.89ms
	}

	if( isCallbackThreadNeedUpdate )
	{
		m_threadSoundCallback.Join();
		m_threadSoundCallback.Finalize();
	}

	nn::Result result;
	result = nn::snd::Finalize();
	NN_UTIL_PANIC_IF_FAILED(result);
	result = nn::dsp::UnloadComponent();
	NN_UTIL_PANIC_IF_FAILED(result);
	nn::dsp::Finalize();

	m_voiceBufferExtHeap.Finalize();
	if(m_voiceBufferHeapMemory)
		VOX_FREE(m_voiceBufferHeapMemory);
}

void DriverCTRHW::Suspend()
{
	nn::dsp::Sleep();
}

void DriverCTRHW::Resume()
{
	nn::dsp::WakeUp();
}

void DriverCTRHW::Set3DParameter(s32 paramId, void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCTRHW::Set3DParameter", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	_Set3DParameter(paramId, param);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

DriverSourceInterface* DriverCTRHW::CreateDriverSource(void * trackParam, void* driverParam, s32 priority)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCTRHW::CreateDriverSource", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);

	if(m_activeSources.size() >= VOX_DRIVER_CTR_MAX_VOICE || !m_voiceBufferHeapMemory)
	{
		if(m_voiceBufferHeapMemory)
			VOX_WARNING_LEVEL_3("Maximum driver voice (%d) already allocated, cannot created new driver voice", VOX_DRIVER_CTR_MAX_VOICE);
		return 0;
	}
	else
	{
		CTRVoice* pVoiceData = VOX_NEW CTRVoice();

		if(pVoiceData)
		{
			pVoiceData->m_pVoice = nn::snd::AllocVoice(128, NULL, NULL);
			if(!pVoiceData->m_pVoice)
			{
				VOX_WARNING_LEVEL_3("%s", "Could not allocate voice");
				VOX_FREE(pVoiceData);
				return 0;
			}
		}
		else
		{
			VOX_WARNING_LEVEL_3("%s", "Could not create CTRVoice");
		}

		if(pVoiceData)
		{
			TrackParams* tParams = (TrackParams*)trackParam;
			//if(tParams->bitsPerSample != 256)
			{
				for(s32 i = 0; i < VOX_DRIVER_CTR_SOURCE_BUFFER; i++)
				{
					pVoiceData->m_dataBuffer[i] = reinterpret_cast<s16*>(m_voiceBufferExtHeap.Allocate(VOX_DRIVER_CTR_SOURCE_BUFFER_SAMPLE * sizeof(s32), 32));
					if(!pVoiceData->m_dataBuffer[i])
					{
						VOX_WARNING_LEVEL_3("Failed to allocate voice buffer %d of size %d", i, VOX_DRIVER_CTR_SOURCE_BUFFER_SAMPLE * sizeof(s32));
						for(s32 j = 0; j < i; j++)
						{
							m_voiceBufferExtHeap.Free(pVoiceData->m_dataBuffer[j]);
						}
						nn::snd::FreeVoice(pVoiceData->m_pVoice);
						VOX_FREE(pVoiceData);

						return 0;
					}
				}
			}
			/*else
			{
				for(s32 i = 0; i < VOX_DRIVER_CTR_SOURCE_BUFFER; i++)
				{
					pVoiceData->m_dataBuffer[i] = 0;
				}
			}*/
		}

		DriverSourceCTRHW* pSource = VOX_NEW DriverSourceCTRHW(trackParam, driverParam, (s32)pVoiceData);
		if(!pSource)
		{
			VOX_WARNING_LEVEL_3("%s", "Could not create driver source");
			for(s32 j = 0; j < VOX_DRIVER_CTR_SOURCE_BUFFER; j++)
			{
				m_voiceBufferExtHeap.Free(pVoiceData->m_dataBuffer[j]);
			}
			nn::snd::FreeVoice(pVoiceData->m_pVoice);
			VOX_FREE(pVoiceData);
			return 0;
		}
		
		m_activeSources.push_back(pSource);

		return (DriverSourceInterface*)pSource;
	}

	return 0;
}

void DriverCTRHW::DestroyDriverSource(DriverSourceInterface* driverSource)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCTRHW::DestroyDriverSource", vox::VoxThread::GetCurThreadId());
	ScopeMutex sm(&m_mutex);

	TrackParams tp = ((DriverSourceCTRHW*)driverSource)->GetTrackParams();
	if(driverSource)
	{
		VOX_LIST<DriverSourceCTRHW*, SAllocator<DriverSourceCTRHW*> >::iterator it = m_activeSources.begin();
		VOX_LIST<DriverSourceCTRHW*, SAllocator<DriverSourceCTRHW*> >::iterator end = m_activeSources.end();

		for(; it != end; ++it)
		{
			if((*it) == (DriverSourceCTRHW*)driverSource)
			{
				m_activeSources.erase(it);
				break;
			}
		}

		CTRVoice* pVoiceData = ((DriverSourceCTRHW*)driverSource)->GetCTRVoice();

		if(pVoiceData)
		{
			//if(tp.bitsPerSample != 256)
			{
				for(s32 j = 0; j < VOX_DRIVER_CTR_SOURCE_BUFFER; j++)
				{
					m_voiceBufferExtHeap.Free(pVoiceData->m_dataBuffer[j]);
				}
			}
			nn::snd::FreeVoice(pVoiceData->m_pVoice);
			VOX_FREE(pVoiceData);
		}
		VOX_DELETE( driverSource);
	}
}

void DriverCTRHW::SetDefaultParameter()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCTRHW::SetDefaultParameter", vox::VoxThread::GetCurThreadId());
	VOX_WARNING_LEVEL_5("%s", "Setting default parameter to callback driver");
	f32 fvalue;
	u32 uivalue;

	// Doppler factor
	fvalue = VOX_DEFAULT_3D_DOPPLER_FACTOR;
	_Set3DParameter(Vox3DGeneralParameter::k_nDopplerFactor, &fvalue);

	// Speed of sound
	fvalue = VOX_DEFAULT_3D_SPEED_OF_SOUND;
	_Set3DParameter(Vox3DGeneralParameter::k_nSpeedOfSound, &fvalue);

	// 3D attenuation model
	uivalue = VOX_DEFAULT_3D_MODEL;
	_Set3DParameter(Vox3DGeneralParameter::k_nDistanceModel, &uivalue);	
	
	// Listener position
	f32 position[3] = VOX_DEFAULT_3D_LISTENER_POSITION;
	VoxVector3f positionv = VoxVector3f(position);
	_Set3DParameter(Vox3DGeneralParameter::k_nListenerPosition, &positionv);

	// Listener velocity
	f32 velocity[3] = VOX_DEFAULT_3D_LISTENER_VELOCITY;
	VoxVector3f velocityv = VoxVector3f(velocity);
	_Set3DParameter(Vox3DGeneralParameter::k_nListenerVelocity, &velocityv);

	// Listener Orientation
	f32 lookat[3] = VOX_DEFAULT_3D_LISTENER_LOOKAT;
	f32 up[3] = VOX_DEFAULT_3D_LISTENER_UP;
	VoxVector3f orientationv[2];
	orientationv[0] = VoxVector3f(lookat);
	orientationv[1] = VoxVector3f(up);
	_Set3DParameter(Vox3DGeneralParameter::k_nListenerOrientation, &orientationv);
}

void DriverCTRHW::_Set3DParameter(s32 paramId, void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverCTRHW::_Set3DParameter", vox::VoxThread::GetCurThreadId());
	//if(m_audioUnitActive)
	{
		switch(paramId)
		{
			case Vox3DGeneralParameter::k_nDopplerFactor:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Doppler factor' to %f", value);
				m_3DGeneralParameters.dopplerFactor = value;
				break;
			}
			case Vox3DGeneralParameter::k_nSpeedOfSound:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Speed of sound' to %f", value);
				m_3DGeneralParameters.speedOfSound = value;
				break;
			}
			case Vox3DGeneralParameter::k_nDistanceModel: 
			{
				u32 value = *((u32*)param);
				VOX_WARNING_LEVEL_5("Setting 'Distance model' to %x", value);
				m_3DGeneralParameters.distanceModel = value;
				break;
			}
			case Vox3DGeneralParameter::k_nListenerPosition:
			{
				VoxVector3f* vector = (VoxVector3f*)param;
				m_listener.m_position.x = vector->x;
				m_listener.m_position.y = vector->y;
				m_listener.m_position.z = vector->z;
				break;
			}
			case Vox3DGeneralParameter::k_nListenerVelocity:
			{
				VoxVector3f* vector = (VoxVector3f*)param;
				m_listener.m_velocity.x = vector->x;
				m_listener.m_velocity.y = vector->y;
				m_listener.m_velocity.z = vector->z;
				break;
			}
			case Vox3DGeneralParameter::k_nListenerOrientation:
			{
				VoxVector3f* vector = (VoxVector3f*)param;

				m_listener.m_atOrientation.x = vector[0].x;
				m_listener.m_atOrientation.y = vector[0].y;
				m_listener.m_atOrientation.z = vector[0].z;
				m_listener.m_upOrientation.x = vector[1].x;
				m_listener.m_upOrientation.y = vector[1].y;
				m_listener.m_upOrientation.z = vector[1].z;
				break;
			}
			default:
			{
				VOX_WARNING_LEVEL_4("Driver doesn't support property %d", paramId);
				break;
			}
		}
	}
}

void DriverCTRHW::TreadFunc(void * arg)
{
	m_isCallbackThreadActive = true;
	while (m_isCallbackThreadNeedUpdate)
	{
		nn::snd::WaitForDspSync();
		VOX_PROFILING_FRAME_START( vox::VoxThread::GetCurThreadId());
		{
			VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverCTRHW::TreadFun", vox::VoxThread::GetCurThreadId());
			if(arg)
			{
				((DriverCTRHW*)arg)->ProcessCallback();
			}

			nn::snd::SendParameterToDsp();
		}
	}
	m_isCallbackThreadActive = false;
}

void DriverCTRHW::ProcessCallback(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverCTRHW::ProcessCallback", vox::VoxThread::GetCurThreadId());

	ScopeMutex sm(&m_mutex);

	if(m_currentOutputMode != m_nextOutputMode)
	{
		switch(m_nextOutputMode)
		{
			case k_nOutputModeMono:
			{
				nn::snd::SetSoundOutputMode(nn::snd::OUTPUT_MODE_MONO);
				break;
			}
			case k_nOutputModeStereo:
			{
				nn::snd::SetSoundOutputMode(nn::snd::OUTPUT_MODE_STEREO);
				break;
			}
			case k_nOutputModeSurround:
			{
				nn::snd::SetSoundOutputMode(nn::snd::OUTPUT_MODE_3DSURROUND);
				break;
			}
			default:
			{
				VOX_WARNING_LEVEL_2("Output mode %d not recognized by CTR HW driver", m_nextOutputMode); 
				m_nextOutputMode = m_currentOutputMode; //Not supported ignore
				break;
			}
		}

		m_currentOutputMode = m_nextOutputMode;
	}

	// Provide listener and general 3D parameters to all sources
	DriverSourceCTRHW::Set3DParameters(m_listener, m_3DGeneralParameters);

	VOX_LIST<DriverSourceCTRHW*, SAllocator<DriverSourceCTRHW*> >::iterator it = m_activeSources.begin();
	VOX_LIST<DriverSourceCTRHW*, SAllocator<DriverSourceCTRHW*> >::iterator end = m_activeSources.end();
		
	for(; it != end; it++)
	{
		(*it)->ProcessDSPCallback();
	}
}

} //DriverCTRHW

#endif //VOX_DRIVER_USE_CTR_HW && VOX_CTR_DRIVER_PLATFORM

// NOTE 1 : The 3DS sound DSP performs ramping when volume is changed. Since emitter volume is set
//			to 0 when it is stopped, the 3DS will perform its own ramping. The voice must not be
//			stopped before the DSP ramp-down is over, which is the reason why we perform a 'Stop process'
//			including a buffer filled partly with ramped-down data (just in	case DSP gets to that point
//			before terminating its own ramp-down) and another filled with zeroes.
