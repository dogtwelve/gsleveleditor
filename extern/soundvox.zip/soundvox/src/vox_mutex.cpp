#include "StdAfx.h"
#include "vox_mutex.h"
#include "vox_macro.h"
#if VOX_USE_GLF
#include <glf/core/thread.h>
#endif
#if defined(_NN_CTR)
#include <nn/fnd.h>
#endif

#if defined(_ANDROID) || defined(__QNXNTO__)
#include <unistd.h>
#endif

#include <cstring>

namespace vox {

//! Default constructor
/*!
	Mutex construction will create the mutex instance depending on the current platform
*/
Mutex::Mutex()
{
#if VOX_USE_GLF
	m_mutex = VOX_NEW glf::Mutex();
	VOX_ASSERT_MSG(m_mutex, "Could not allocate GLF mutex, operation will not be mutexed");
#elif defined(_PS3)
	sys_lwmutex_attribute_t lwmutex_attr;
	sys_lwmutex_attribute_initialize(lwmutex_attr);
	sys_lwmutex_create((sys_lwmutex_t*)&m_mutex, &lwmutex_attr);
#elif defined(SN_TARGET_PSP2)
	m_mutex = sceKernelCreateLwMutex(&m_mutexWorkArea, "VoxMutex", SCE_KERNEL_MUTEX_ATTR_TH_PRIO, 0, NULL);
	VOX_ASSERT_MSG(m_mutex >= 0, "Failed to obtain mutex");
#elif defined(_WIN32)
    m_mutex = CreateMutex(NULL,FALSE,NULL);
#elif VOX_USE_PTHREAD
	pthread_mutex_init ((pthread_mutex_t*)&m_mutex, 0 );
#elif defined(_NN_CTR)
#	if VOX_USE_LIGHT_MUTEX
	m_mutex = VOX_NEW nn::os::LightSemaphore();
	VOX_ASSERT_MSG(m_mutex, "Could not allocate CTR LightSemaphore, operation will not be mutexed");
	if(m_mutex)
		m_mutex->Initialize(1,1);
#	else
	m_lockCount = 0;
	m_mutex = VOX_NEW nn::os::Mutex();
	VOX_ASSERT_MSG(m_mutex, "Could not allocate CTR mutex, operation will not be mutexed");
	if(m_mutex)
		m_mutex->Initialize();
#	endif
#else
	VOX_ASSERT(0); // TODO
#endif
}

//! Default destructor
/*!
	Destroy platform dependent mutex
*/
Mutex::~Mutex()
{
#if VOX_USE_GLF
	if(m_mutex)
		VOX_DELETE(m_mutex);
#elif defined(_PS3)
	sys_lwmutex_destroy((sys_lwmutex_t*)&m_mutex);
#elif defined(SN_TARGET_PSP2)
	if(m_mutex >= 0)
		sceKernelDeleteLwMutex(&m_mutexWorkArea);
#elif defined(_WIN32)
	CloseHandle(m_mutex);
#elif VOX_USE_PTHREAD
	pthread_mutex_destroy ((pthread_mutex_t*)&m_mutex );
#elif defined(_NN_CTR)
	if(m_mutex)
	{
#	if VOX_USE_LIGHT_MUTEX
		m_mutex->Release();
#	else
		if(m_lockCount > 0)
			m_mutex->Unlock();
#	endif
		m_mutex->Finalize();
		VOX_DELETE(m_mutex);
	}
#endif
}

Mutex::Mutex(const Mutex &mutex)
{
#if VOX_USE_GLF
	m_mutex = VOX_NEW glf::Mutex();
	VOX_ASSERT_MSG(m_mutex, "Could not allocate GLF mutex, operation will not be mutexed");
#elif defined(_NN_CTR)
#	if VOX_USE_LIGHT_MUTEX
	m_mutex = VOX_NEW nn::os::LightSemaphore();
	VOX_ASSERT_MSG(m_mutex, "Could not allocate CTR LightSemaphore, operation will not be mutexed");
	if(m_mutex)
		m_mutex->Initialize(1,1);
#	else
	m_lockCount = 0;
	m_mutex = VOX_NEW nn::os::Mutex();
	VOX_ASSERT_MSG(m_mutex, "Could not allocate CTR mutex, operation will not be mutexed");
	if(m_mutex)
		m_mutex->Initialize();
#	endif
#else
	memcpy(this, &mutex, sizeof(Mutex));
#endif
}

//! Lock the mutex
/*!
	Infinite timeout mutex method, will block until mutex is acquired
*/
void Mutex::Lock()
{
#if VOX_USE_GLF
	if(m_mutex)
		m_mutex->Lock();
#elif defined(_PS3)
	sys_lwmutex_lock((sys_lwmutex_t*)&m_mutex, 0);
#elif defined(SN_TARGET_PSP2)
	sceKernelLockLwMutex(&m_mutexWorkArea,1, NULL);
#elif defined(_WIN32)
	int errorcode = WaitForSingleObject(m_mutex,INFINITE);
	VOX_ASSERT_MSG(errorcode==WAIT_OBJECT_0, "Error while locking mutex\n");
#elif VOX_USE_PTHREAD
	pthread_mutex_lock((pthread_mutex_t*)&m_mutex);
#elif defined(_NN_CTR)
	if(m_mutex)
	{
#	if VOX_USE_LIGHT_MUTEX
		m_mutex->Acquire();
#	else
		m_mutex->Lock();
		m_lockCount++;
#	endif
	}
#endif
}

//! Release the mutex
void Mutex::Unlock()
{
#if VOX_USE_GLF
	if(m_mutex)
		m_mutex->Unlock();
#elif defined(_PS3)
	sys_lwmutex_unlock((sys_lwmutex_t*)&m_mutex);
#elif defined(SN_TARGET_PSP2)
	sceKernelUnlockLwMutex(&m_mutexWorkArea, 1);
#elif defined(_WIN32)
	ReleaseMutex(m_mutex);
#elif VOX_USE_PTHREAD
	pthread_mutex_unlock((pthread_mutex_t*)&m_mutex);
#elif defined(_NN_CTR)
	if(m_mutex)
	{
#	if VOX_USE_LIGHT_MUTEX
		m_mutex->Release();
#	else
		m_lockCount--;
		if(m_lockCount == 0)
		{
			m_mutex->Unlock();
		}
		if(m_lockCount < 0)
			m_lockCount = 0;
#	endif
	}
#endif
}

//! TryLock method
/*!
	Will try to acquire the lock on the mutex, however will not wait
	\return True if the mutex was aquired
*/
bool Mutex::TryLock()
{
#if VOX_USE_GLF
	if(m_mutex)
		return m_mutex->TryLock();
	else
		return true;
#elif defined(_PS3)
	return sys_lwmutex_trylock((sys_lwmutex_t*)&m_mutex) == CELL_OK;
#elif defined(SN_TARGET_PSP2)
	return sceKernelTryLockLwMutex(&m_mutexWorkArea, 1) == SCE_OK;
#elif defined(_WIN32)
	DWORD result = WaitForSingleObject(m_mutex,0);
	return (result == WAIT_ABANDONED) || (result == WAIT_OBJECT_0);//while WAIT_ABANDONED grant ownership but means a problem with mutex logic ...
#elif VOX_USE_PTHREAD
	return pthread_mutex_trylock((pthread_mutex_t*)&m_mutex) == 0;
#elif defined(_NN_CTR)
	if(m_mutex)
	{
#	if VOX_USE_LIGHT_MUTEX
		bool ret = m_mutex->TryAcquire();
#	else
		bool ret = m_mutex->TryLock();
		if(ret)
			m_lockCount++;
#	endif
		return ret;
	}
	else
		return true;
#endif
}


//! Get a read token from the access controller
/*!
	Will try to acquire a read token from the access controller, will block until token is acquired. 
	Multiple read token are available, but they cannot coexist with write token.
*/
void AccessController::GetReadAccess()
{
	bool done = false;
	do
	{
		m_mutex.Lock();
		if(m_writers == 0)
		{
			++m_readers;
			done = true;
			m_mutex.Unlock();
		}
		else
		{
			m_mutex.Unlock();
#if VOX_USE_GLF
			glf::Thread::Sleep(1);
#elif defined(_PS3)
			sys_timer_usleep(1000);
#elif defined(_WIN32)
			Sleep(1);
#elif VOX_USE_PTHREAD
			usleep(1000);
#elif defined(_NN_CTR)
			nn::os::Thread::Sleep(nn::fnd::TimeSpan::FromMilliSeconds(1));
#endif
		}		
	}
	while(!done);

	//VOX_WARNING_LEVEL_5("%s :  %d\n", __FUNCTION__, m_mutex);
}

//! Release a read token from the access controller
void AccessController::ReleaseReadAccess()
{
	m_mutex.Lock();
	--m_readers;
	m_mutex.Unlock();
	//VOX_WARNING_LEVEL_5("%s :  %d\n", __FUNCTION__, m_mutex);
}

//! Get a write token from the access controller
/*!
	Will try to acquire a write token from the access controller, will block until token is acquired. 
	Only one write token are available and cannot coexist with read token.
*/
void AccessController::GetWriteAccess()
{	
	bool done = false;
	do
	{
		m_mutex.Lock();
		if(m_writers == 0 && m_readers == 0)
		{
			++m_writers;
			done = true;
			m_mutex.Unlock();
		}
		else
		{
			m_mutex.Unlock();
#if VOX_USE_GLF
			glf::Thread::Sleep(1);
#elif defined(_PS3)
			sys_timer_usleep(1000);
#elif defined(_WIN32)
			Sleep(1);
#elif VOX_USE_PTHREAD
			usleep(1000);
#elif defined(_NN_CTR)
			nn::os::Thread::Sleep(nn::fnd::TimeSpan::FromMilliSeconds(1));
#endif
		}		
	}
	while(!done);

	//VOX_WARNING_LEVEL_5("%s :  %d\n", __FUNCTION__, m_mutex);
}

//! Release a write token from the access controller
void AccessController::ReleaseWriteAccess()
{
	m_mutex.Lock();
	--m_writers;
	m_mutex.Unlock();
	//VOX_WARNING_LEVEL_5("%s :  %d\n", __FUNCTION__, m_mutex);
}

} //namespace vox
