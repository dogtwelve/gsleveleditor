#include "StdAfx.h"
#include "vox_filesystem_ps3.h"

#if defined(_PS3) && !VOX_USE_GLF

#include "vox_memory.h"
#include <stdio.h>

namespace vox
{

/// Reads size bytes of data into buffer at ptr.
s32 readPS3( void * ptr, s32 size, s32 count, void * stream )
{
	return fread(ptr, size, count, (FILE*) stream);
}

/// Seeks to byte position offset.
s32 seekPS3 ( void * stream, s32 offset, VoxFileSeekOrigin origin )
{
	return fseek((FILE*)stream, offset, origin == k_nSeekEnd ? SEEK_END : origin == k_nSeekCur ? SEEK_CUR : SEEK_SET);
}

/// Returns the current byte offset in the stream.
s32 tellPS3 ( void * stream )
{
	return ftell((FILE*)stream);
}

// Vox PS3 filesystem only allow reading
void* openPS3 ( const c8 * filename, VoxFileAccessMode mode )
{
	FILE* file = 0;

	switch(mode)
	{
		case k_nRead:
			file = fopen(filename, "r");
			break;
		case k_nReadBinary:
			file = fopen(filename, "rb");
			break;
		default:
			file = 0;
	}

	return file;
}

s32 closePS3 ( void * stream )
{
	return fclose((FILE*) stream);
}


FileSystemInterface* VoxNewFileSystem()
{
	return VOX_NEW FileSystemPS3();
}

FileSystemPS3::FileSystemPS3()
{
	FileSystemInterface::m_IOFunc.open = openPS3;
	FileSystemInterface::m_IOFunc.close = closePS3;
	FileSystemInterface::m_IOFunc.read = readPS3;
	FileSystemInterface::m_IOFunc.write = 0;
	FileSystemInterface::m_IOFunc.seek = seekPS3;
	FileSystemInterface::m_IOFunc.tell = tellPS3;
}

FileSystemPS3::~FileSystemPS3()
{
}

}
#endif
