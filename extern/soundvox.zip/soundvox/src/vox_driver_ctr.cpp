#include "vox_default_config.h"

#if VOX_DRIVER_USE_CTR && VOX_CTR_DRIVER_PLATFORM

#include "vox_driver_ctr.h"

extern void* VOX_FCRamAlloc( size_t size, size_t aim );
extern void VOX_FCRamFree( void* ptr );

namespace vox {

DriverCTRSource::DriverCTRSource(void * trackParam, void* driverParam, u32 sourceId):
DriverCallbackSourceInterface(trackParam, driverParam, sourceId)
{
	Init();
}

DriverCTRSource::~DriverCTRSource()//**-**
{

}

void DriverCTRSource::PrintDebug()
{
}

//*** DriverCTR ***//

DriverInterface* CreateDriver()
{
	return VOX_NEW DriverCTR();
}

DriverCTR::DriverCTR()
{
	m_voice = NULL;
	Init(0);
}

DriverCTR::~DriverCTR()
{
	Shutdown();
}

DriverSourceInterface* DriverCTR::CreateDriverSource(void * trackParam, void* driverParam, s32 priority)
{
	m_mutex.Lock();
	
	DriverCTRSource* driverSource = 0;

	if(m_audioUnitActive)
	{
		driverSource = VOX_NEW DriverCTRSource(trackParam, driverParam, m_nextSourceId);
		if(driverSource)
		{
			m_activeSources.push_back(driverSource);
			m_nextSourceId++;
		}
	}

	m_mutex.Unlock();
	return driverSource;
}

void DriverCTR::DestroyDriverSource(DriverSourceInterface* driverSource)
{
	m_mutex.Lock();
	if(driverSource)
	{
		VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> >::iterator it = m_activeSources.begin();
		VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> >::iterator end = m_activeSources.end();

		for(; it != end; it++)
		{
			if(*it == driverSource)
			{
				m_activeSources.erase(it);
				break;
			}
		}

		VOX_DELETE((DriverCTRSource*) driverSource);
	}
	m_mutex.Unlock();
}

///////////////////////////////////////////////////////////////////////////////

    u32 idx = 0;
    f32 frq = 0.5f;
    f32 dlt = 0.00001f;
    void MakeSineWave(s16* p, s32 n)
    {

		if (frq > 4.0f)
        {
            frq = 0.5f;
            idx = 0;
        }

		for (int i = 0; i < n; i++)
        {
            frq += dlt;
            p[i] = (32767.0f * nn::math::SinFIdx(frq*idx++));
        }
    }

///////////////////////////////////////////////////////////////////////////////

void DriverCTR::Init(void* param)
{
	m_mutex.Lock();

	DriverCallbackInterface::Init(param);
	DriverCallbackSourceInterface::SetDriverSampleRate(VOX_NN_CTR_DRIVER_PREFERRED_RATE);
	DriverCallbackSourceInterface::SetDriverCallbackPeriod(0.004889f);

    nn::Result result;

	m_pcmBuffer = (u8 *)VOX_FCRamAlloc( nMemorySize, 32 );
    m_expHeap.Initialize( (uptr)m_pcmBuffer, nMemorySize, nn::os::ALLOCATE_OPTION_LINEAR );

    // dsp, snd initialization
    result = nn::dsp::Initialize();
    NN_UTIL_PANIC_IF_FAILED(result);
    result = nn::dsp::LoadDefaultComponent();
    NN_UTIL_PANIC_IF_FAILED(result);
    result = nn::snd::Initialize();
    NN_UTIL_PANIC_IF_FAILED(result);

    m_threadSound.StartUsingAutoStack(
        DriverCTR::TreadFunc,
        (void*)this,
        SOUND_THREAD_STACK_SIZE,
        SOUND_THREAD_PRIORITY
    );

    // default master volume
    nn::snd::SetMasterVolume( 1.0 );

    for (int i = 0; i < nBuffers; i++)
    {
        m_memory[i] = reinterpret_cast<s16*>(m_expHeap.Allocate(nBufferSize * sizeof(s32), 32));
        NN_TASSERT_(m_memory[i]);

		FillBuffer(m_memory[i], nBufferSize);
        //MakeSineWave(m_memory[i], nBufferSize);
        nn::snd::FlushDataCache(reinterpret_cast<uptr>(m_memory[i]), nBufferSize * sizeof(s32));
    }

	// allocate voice object
    m_voice = nn::snd::AllocVoice(128, NULL, NULL);
    NN_TASSERT_(m_voice);

	m_voice->SetChannelCount( 2 );
	m_voice->SetSampleFormat( nn::snd::SAMPLE_FORMAT_PCM16 );

    nn::snd::MixParam mix;
    mix.mainBus[nn::snd::CHANNEL_INDEX_FRONT_LEFT ] = 1.0f; // (L)
    mix.mainBus[nn::snd::CHANNEL_INDEX_FRONT_RIGHT] = 1.0f; // (R)
    m_voice->SetMixParam(mix);
    m_voice->SetVolume(1.0f);

	m_voice->SetSampleRate(NN_SND_HW_I2S_CLOCK_32KHZ);
	m_voice->SetPitch(1.0);
	m_voice->SetInterpolationType( nn::snd::INTERPOLATION_TYPE_NONE );

	for (int i = 0; i < nBuffers; i++)
	{
		nn::snd::InitializeWaveBuffer(&m_buffer[i]);
		m_buffer[i].bufferAddress = m_memory[i];
		m_buffer[i].sampleLength  = nn::snd::GetSampleLength(nBufferSize * sizeof(s32), nn::snd::SAMPLE_FORMAT_PCM16, 2);
		m_buffer[i].loopFlag  = false;
		m_voice->AppendWaveBuffer(&m_buffer[i]);
	}
	m_currentBufferId = 0;

	m_voice->SetState( nn::snd::Voice::STATE_PLAY );

	m_audioUnitActive = true;
	SetDefaultParameter();
	
	m_mutex.Unlock();
}

void DriverCTR::Shutdown()
{
	m_mutex.Lock();

	if(m_audioUnitActive)
	{
	    nn::Result result;

		result = nn::snd::Finalize();
		NN_UTIL_PANIC_IF_FAILED(result);

		result = nn::dsp::UnloadComponent();
		NN_UTIL_PANIC_IF_FAILED(result);
		nn::dsp::Finalize();

		nn::snd::FreeVoice(m_voice);

		m_expHeap.Finalize();
		VOX_FCRamFree( m_pcmBuffer );

		m_audioUnitActive = false;
	}

	m_mutex.Unlock();
}

void DriverCTR::Suspend()
{
}

void DriverCTR::Resume()
{
}

void DriverCTR::PrintDebug()
{
}

void DriverCTR::TreadFunc(void * arg)
{
	while (true)  // TODO remplacer avec condition de fin pour le join du thread
	{
		nn::snd::WaitForDspSync();

		if(arg)
		{
			((DriverCTR*)arg)->processCallback();
		}

		nn::snd::SendParameterToDsp();
	}
}

void DriverCTR::processCallback()
{
    if (m_voice != NULL && m_buffer[m_currentBufferId].status == nn::snd::WaveBuffer::STATUS_DONE)
    {
        s32 id = m_currentBufferId;
        nn::snd::WaveBuffer* pBuf = &m_buffer[id];

		FillBuffer(m_memory[id], nBufferSize);
        //MakeSineWave(m_memory[id], nBufferSize);
        nn::snd::FlushDataCache(reinterpret_cast<uptr>(m_memory[id]), nBufferSize * sizeof(s32));

        nn::snd::InitializeWaveBuffer(pBuf);
        pBuf->bufferAddress = m_memory[id];
        pBuf->sampleLength  = nn::snd::GetSampleLength(nBufferSize * sizeof(s32), nn::snd::SAMPLE_FORMAT_PCM16, 2);
        pBuf->loopFlag  = false;
        m_voice->AppendWaveBuffer(pBuf);

		m_currentBufferId = (m_currentBufferId + 1) % nBuffers;
    }
}

}//namespace vox

#endif //VOX_DRIVER_USE_CTR && VOX_CTR_DRIVER_PLATFORM
