#include "StdAfx.h"
#include "vox_default_config.h"

#include "vox_driver_callback_template.h"
#include "vox_macro.h"
#include "vox_memory.h"
#include "vox.h"

#if VOX_NEON_MIXER
#ifdef __ANDROID__
#include <cpu-features.h>
#endif
#endif

namespace vox {

#if VOX_NEON_MIXER
	
bool DriverCallbackSourceInterface::DetectNeon()
{
#ifdef __ANDROID__
    if (android_getCpuFamily() != ANDROID_CPU_FAMILY_ARM)
		return false;

    uint64_t features = android_getCpuFeatures();
    if ((features & ANDROID_CPU_ARM_FEATURE_NEON) == 0)
		return false;
    
	return true;
	
#endif // __ANDROID__


// other platforms are PSP2 and 3DS which support neon in armv7
// Iphone is done by disabling VOX_NEON_MIXER on armv6
	return true;

}


#ifdef SN_TARGET_PSP2
#define VOX_UNDERSCORE_ASM_FUNCTION_NAMES 1
#else 
#ifdef __ANDROID__
#define VOX_UNDERSCORE_ASM_FUNCTION_NAMES 1
#else // IPHONE
#define VOX_UNDERSCORE_ASM_FUNCTION_NAMES 0
#endif
#endif

#if VOX_UNDERSCORE_ASM_FUNCTION_NAMES
extern "C" int _FillBufferNeonStereo16NoInterAsm(s16 *data, s32 *buffer, s32 *stop, s16*ramps);
extern "C" int _FillBufferNeonMono16NoInterAsm(s16 *data, s32 *buffer, s32 *stop, s16*ramps);
extern "C" int _FillBufferNeonStereo16Asm(s32 *arm_params, s16 *neon_params);
extern "C" int _FillBufferNeonMono16Asm(s32 *arm_params, s16 *neon_params);
extern "C" int _FillBufferNeonMono16BiquadAsm(s32 *params);

#else
extern "C" int FillBufferNeonStereo16NoInterAsm(s16 *data, s32 *buffer, s32 *stop, s16*ramps);
extern "C" int FillBufferNeonMono16NoInterAsm(s16 *data, s32 *buffer, s32 *stop, s16*ramps);
extern "C" int FillBufferNeonStereo16Asm(s32 *arm_params, s16 *neon_params);
extern "C" int FillBufferNeonMono16Asm(s32 *arm_params, s16 *neon_params);
extern "C" int FillBufferNeonMono16BiquadAsm(s32 *params);

#endif

// Block size must be in multiples of 128 bytes
// With 16 byte memory alignment
// (In other words, blocks of 16 samples with 2 sample alignment, per channel).
// You cannot call this function with 0 samples to mix, minimum is 16 samples per channel.
//
// data:         Points toward source data, if we render 80 samples, then we need 80 valid samples per channel here.
// buffer:       Mixing buffer start address.
// length:       Numbert of samples to mix per channel. Must be a multiple of 16!
// volumeLeft:  Left  channel volume at the start of the block. 16384 = 0db gain.
// volumeRight: Right channel volume at the start of the block.
// rampLeft:    Ramping speed per sample for left  channel. Note that volume is only ramped for each 16 sample block.
// rampRight:   Ramping speed per sample for right channel.


void DriverCallbackSourceInterface::FillBufferNeonStereo16NoInter
	(s16* data, s32* buffer, int length, s32 volumeLeft, s32 volumeRight, s32 rampLeft, s32 rampRight)
{
						
	s32* stop = buffer + length*2;
	s16 rampData[16];
	if (volumeLeft > 16383)
		volumeLeft = 16383;
	if (volumeRight > 16383)
		volumeRight = 16383;
	rampData[0] = volumeLeft << 1;
	rampData[2] = volumeLeft << 1;
	rampData[4] = volumeLeft << 1;
	rampData[6] = volumeLeft << 1;
	rampData[1] = volumeRight << 1;
	rampData[3] = volumeRight << 1;
	rampData[5] = volumeRight << 1;
	rampData[7] = volumeRight << 1;
	rampData[8] = rampLeft  << 5;
	rampData[9] = rampRight << 5;
	rampData[10]= rampLeft  << 5;
	rampData[11]= rampRight << 5;
	rampData[12]= rampLeft  << 5;
	rampData[13]= rampRight << 5;
	rampData[14]= rampLeft  << 5;
	rampData[15]= rampRight << 5;

	
	{
		VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "Loop neon", vox::VoxThread::GetCurThreadId());
#if VOX_UNDERSCORE_ASM_FUNCTION_NAMES
		_FillBufferNeonStereo16NoInterAsm(data, buffer, stop, rampData);
#else
		FillBufferNeonStereo16NoInterAsm(data, buffer, stop, rampData);
#endif
	}


}


void DriverCallbackSourceInterface::FillBufferNeonMono16NoInter
	(s16* data, s32* buffer, int length, s32 volumeLeft, s32 volumeRight, s32 rampLeft, s32 rampRight)
{	

	if (volumeLeft > 16383)
		volumeLeft = 16383;
	if (volumeRight > 16383)
		volumeRight = 16383;
	
	s32* stop = buffer + length*2;
	s16 rampData[16];
	// Not the same ramp data format as stereo!!!
	rampData[0] = volumeLeft << 1;
	rampData[1] = volumeLeft << 1;
	rampData[2] = volumeLeft << 1;
	rampData[3] = volumeLeft << 1;
	rampData[4] = volumeRight << 1;
	rampData[5] = volumeRight << 1;
	rampData[6] = volumeRight << 1;
	rampData[7] = volumeRight << 1;
	rampData[8] = rampLeft  << 5;
	rampData[9] = rampLeft  << 5;
	rampData[10]= rampLeft  << 5;
	rampData[11]= rampLeft  << 5;
	rampData[12]= rampRight << 5;
	rampData[13]= rampRight << 5;
	rampData[14]= rampRight << 5;
	rampData[15]= rampRight << 5;

	
	{
		VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "Loop neon", vox::VoxThread::GetCurThreadId());
#if VOX_UNDERSCORE_ASM_FUNCTION_NAMES
		_FillBufferNeonMono16NoInterAsm(data, buffer, stop, rampData);
#else
		FillBufferNeonMono16NoInterAsm(data, buffer, stop, rampData);
#endif
	}

}
	
void DriverCallbackSourceInterface::FillBufferNeonStereo16
(s16* data_buffer, unsigned int data_index, unsigned int data_delta,
 s32* buffer, int length,
 s32 volumeLeft, s32 volumeRight, s32 rampLeft, s32 rampRight)
{
	//int v;		
	s32 armData[5];

	if (volumeLeft > 16383)
		volumeLeft = 16383;
	if (volumeRight > 16383)
		volumeRight = 16383;
	
	armData[0] = (int)(buffer);
	armData[1] = length;
	armData[2] = (int)(data_buffer);
	armData[3] = data_index;
	armData[4] = data_delta;
	
	s16 rampData[32];
	rampData[0] = (data_index << 2) - 32768;
	rampData[2] = rampData[0] + (data_delta<<2);
	rampData[4] = rampData[2] + (data_delta<<2);
	rampData[6] = rampData[4] + (data_delta<<2);
	rampData[1] = rampData[0];
	rampData[3] = rampData[2];
	rampData[5] = rampData[4];
	rampData[7] = rampData[6];
	
	rampData[8] = (data_delta<<4);
	rampData[9] = (data_delta<<4);
	rampData[10]= (data_delta<<4);
	rampData[11]= (data_delta<<4);
	rampData[12]= (data_delta<<4);
	rampData[13]= (data_delta<<4);
	rampData[14]= (data_delta<<4);
	rampData[15]= (data_delta<<4);
	
	rampData[16] = volumeLeft << 1;
	rampData[17] = volumeRight << 1;
	rampData[18] = volumeLeft << 1;
	rampData[19] = volumeRight << 1;
	rampData[20] = volumeLeft << 1;
	rampData[21] = volumeRight << 1;
	rampData[22] = volumeLeft << 1;
	rampData[23] = volumeRight << 1;

	rampData[24] = rampLeft  << 3;
	rampData[25] = rampRight << 3;
	rampData[26] = rampLeft  << 3;
	rampData[27] = rampRight << 3;
	rampData[28] = rampLeft  << 3;
	rampData[29] = rampRight << 3;
	rampData[30] = rampLeft  << 3;
	rampData[31] = rampRight << 3;
	
	
	{
		VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "Loop neon", vox::VoxThread::GetCurThreadId());
#if VOX_UNDERSCORE_ASM_FUNCTION_NAMES
		_FillBufferNeonStereo16Asm(armData, rampData);
#else
		FillBufferNeonStereo16Asm(armData, rampData);
#endif		
	}
	
}		


void DriverCallbackSourceInterface::FillBufferNeonMono16
(s16* data_buffer, unsigned int data_index, unsigned int data_delta,
 s32* buffer, int length,
 s32 volumeLeft, s32 volumeRight, s32 rampLeft, s32 rampRight)
{

	s32 armData[5];
	
	if (volumeLeft > 16383)
		volumeLeft = 16383;
	if (volumeRight > 16383)
		volumeRight = 16383;
	
	armData[0] = (int)(buffer);
	armData[1] = length;
	armData[2] = (int)(data_buffer);
	armData[3] = data_index;
	armData[4] = data_delta;
	
	s16 rampData[32];
	rampData[0] = (data_index << 2) - 32768;
	rampData[1] = rampData[0] + (data_delta<<2);
	rampData[2] = rampData[1] + (data_delta<<2);
	rampData[3] = rampData[2] + (data_delta<<2);
	// rampData[4..7] are unused

	rampData[8] = (data_delta<<4);
	rampData[9] = (data_delta<<4);
	rampData[10]= (data_delta<<4);
	rampData[11]= (data_delta<<4);
	// rampData[12..15] are unused
	
	// not interlaced!
	rampData[16] = volumeLeft << 1;
	rampData[17] = volumeLeft << 1;
	rampData[18] = volumeLeft << 1;
	rampData[19] = volumeLeft << 1;
	rampData[20] = volumeRight << 1;
	rampData[21] = volumeRight << 1;
	rampData[22] = volumeRight << 1;
	rampData[23] = volumeRight << 1;

	rampData[24] = rampLeft  << 3;
	rampData[25] = rampLeft  << 3;
	rampData[26] = rampLeft  << 3;
	rampData[27] = rampLeft  << 3;
	rampData[28] = rampRight << 3;
	rampData[29] = rampRight << 3;
	rampData[30] = rampRight << 3;
	rampData[31] = rampRight << 3;
	
	
	{
		VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "Loop neon", vox::VoxThread::GetCurThreadId());		
#if VOX_UNDERSCORE_ASM_FUNCTION_NAMES
		_FillBufferNeonMono16Asm(armData, rampData);
#else
		FillBufferNeonMono16Asm(armData, rampData);
#endif
		
	}
}		


#if VOX_ENHANCED_3D

void DriverCallbackSourceInterface::FillBufferNeonMono16Biquad
(s16* data, unsigned int currentSample, unsigned int effectivePitch,
 s32* buffer, int length,
 s32 currentLeftGain, s32 currentRightGain, s32 leftGainIncrement, s32 rightGainIncrement)
{

	int loopParam[34];
	int filterMemory[12];

	loopParam[0] = (VoxFilter::clip_s16(m_filter[0].a0 * 4096.f) &0xffff ) + (VoxFilter::clip_s16(m_filter[2].a0 * 16384.f)&0xffff)*65536;
	loopParam[1] = (VoxFilter::clip_s16(m_filter[1].a0 * 4096.f) &0xffff ) + (VoxFilter::clip_s16(m_filter[3].a0 * 16384.f)&0xffff)*65536;
	loopParam[2] = (VoxFilter::clip_s16(m_filter[0].a1 * 4096.f) &0xffff ) + (VoxFilter::clip_s16(m_filter[2].a1 * 16384.f)&0xffff)*65536;
	loopParam[3] = (VoxFilter::clip_s16(m_filter[1].a1 * 4096.f) &0xffff ) + (VoxFilter::clip_s16(m_filter[3].a1 * 16384.f)&0xffff)*65536;
	loopParam[4] = (VoxFilter::clip_s16(m_filter[0].a2 * 4096.f) &0xffff ) + (VoxFilter::clip_s16(m_filter[2].a2 * 16384.f)&0xffff)*65536;
	loopParam[5] = (VoxFilter::clip_s16(m_filter[1].a2 * 4096.f) &0xffff ) + (VoxFilter::clip_s16(m_filter[3].a2 * 16384.f)&0xffff)*65536;
	loopParam[6] = VoxFilter::clip_s32(m_filter[0].b1 * 65536.f * 16384.f);
	loopParam[7] = VoxFilter::clip_s32(m_filter[2].b1 * 65536.f * 16384.f);
	loopParam[8] = VoxFilter::clip_s32(m_filter[1].b1 * 65536.f * 16384.f);
	loopParam[9] = VoxFilter::clip_s32(m_filter[3].b1 * 65536.f * 16384.f);
	loopParam[10]= VoxFilter::clip_s32(m_filter[0].b2 * 65536.f * 32768.f);
	loopParam[11]= VoxFilter::clip_s32(m_filter[2].b2 * 65536.f * 32768.f);
	loopParam[12]= VoxFilter::clip_s32(m_filter[1].b2 * 65536.f * 32768.f);
	loopParam[13]= VoxFilter::clip_s32(m_filter[3].b2 * 65536.f * 32768.f);
	loopParam[14]= ((currentSample*2)&0x7fff)*65536 + ((~(currentSample*2))&0x7fff);
	loopParam[15]= (((currentSample+effectivePitch)*2)&0x7fff)*65536 + ((~((currentSample+effectivePitch)*2))&0x7fff);
	loopParam[16]= ((effectivePitch*4)&0x7fff)*65536 + ((-(effectivePitch*4))&0x7fff);
	loopParam[17]= ((effectivePitch*4)&0x7fff)*65536 + ((-(effectivePitch*4))&0x7fff);
	loopParam[18]= m_leftSideDelay? 0xffffffff : 0x00000000 ;
	loopParam[19]= m_leftSideDelay? 0xffffffff : 0x00000000 ;
	loopParam[20]= VoxFilter::clip_s16(currentLeftGain  * 2) + VoxFilter::clip_s16((currentLeftGain  + leftGainIncrement ) * 2) * 65536;
	loopParam[21]= VoxFilter::clip_s16(currentRightGain * 2) + VoxFilter::clip_s16((currentRightGain + rightGainIncrement) * 2) * 65536;
	loopParam[22]= (leftGainIncrement  * 4) + (leftGainIncrement  * 4) * 65536;
	loopParam[23]= (rightGainIncrement * 4) + (rightGainIncrement * 4) * 65536;
	loopParam[24]= (int)buffer;
	loopParam[25]= (int)filterMemory;
	loopParam[26]= effectivePitch*2;
	loopParam[27]= (length-8);
	loopParam[28]= (int)m_delayBuffer;
	loopParam[29]= m_delayWriteCounter*2;
	loopParam[30]= m_delayReadCounter*2;
	loopParam[31]= (int)data;
	loopParam[32]= currentSample;
	loopParam[33]= currentSample + effectivePitch;

	filterMemory[0] = VoxFilter::clip_s32(m_filter[0].y2 * 8192.f);
	filterMemory[1] = VoxFilter::clip_s32(m_filter[1].y2 * 8192.f);
	filterMemory[2] = VoxFilter::clip_s32(m_filter[0].y1 * 8192.f);
	filterMemory[3] = VoxFilter::clip_s32(m_filter[1].y1 * 8192.f);
	filterMemory[4] = VoxFilter::clip_s16(m_filter[0].x2 * 1) + VoxFilter::clip_s16(m_filter[1].x2 * 1)*65536;
	filterMemory[5] = VoxFilter::clip_s16(m_filter[0].x1 * 1) + VoxFilter::clip_s16(m_filter[1].x1 * 1)*65536;
	filterMemory[6] = VoxFilter::clip_s32(m_filter[2].y2 * 8192.f);
	filterMemory[7] = VoxFilter::clip_s32(m_filter[3].y2 * 8192.f);
	filterMemory[8] = VoxFilter::clip_s32(m_filter[2].y1 * 8192.f);
	filterMemory[9] = VoxFilter::clip_s32(m_filter[3].y1 * 8192.f);
	filterMemory[10]= VoxFilter::clip_s16(m_filter[2].x2 * 0.125) + VoxFilter::clip_s16(m_filter[3].x2 * 0.125)*65536;
	filterMemory[11]= VoxFilter::clip_s16(m_filter[2].x1 * 0.125) + VoxFilter::clip_s16(m_filter[3].x1 * 0.125)*65536;

	{
		VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "Resampler with Neon biquad", vox::VoxThread::GetCurThreadId());		
#if VOX_UNDERSCORE_ASM_FUNCTION_NAMES
		_FillBufferNeonMono16BiquadAsm(loopParam);
#else
		FillBufferNeonMono16BiquadAsm(loopParam);
#endif
		
	}


 	m_filter[0].y2 = filterMemory[0] / 8192.f;
	m_filter[1].y2 = filterMemory[1] / 8192.f;
	m_filter[0].y1 = filterMemory[2] / 8192.f;
	m_filter[1].y1 = filterMemory[3] / 8192.f;
	m_filter[0].x2 = (signed short)(filterMemory[4]);
	m_filter[1].x2 = (signed short)(filterMemory[4] >> 16);
	m_filter[0].x1 = (signed short)(filterMemory[5]);
	m_filter[1].x1 = (signed short)(filterMemory[5] >> 16);
   	m_filter[2].y2 = filterMemory[6] / 8192.f;
	m_filter[3].y2 = filterMemory[7] / 8192.f;
	m_filter[2].y1 = filterMemory[8] / 8192.f;
	m_filter[3].y1 = filterMemory[9] / 8192.f;
	m_filter[2].x2 = ((signed short)(filterMemory[10])      ) * 8.f;
	m_filter[3].x2 = ((signed short)(filterMemory[10] >> 16)) * 8.f;
	m_filter[2].x1 = ((signed short)(filterMemory[11])      ) * 8.f;
	m_filter[3].x1 = ((signed short)(filterMemory[11] >> 16)) * 8.f;

}		

#endif  // VOX_ENHANCED_3D


#endif // VOX_NEON_MIXER


} // End of namespace vox