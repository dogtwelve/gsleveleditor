#include "StdAfx.h"
#include <vox_decoder_bcwav.h>

#if VOX_CTR_DRIVER_PLATFORM && VOX_DRIVER_USE_CTR_HW

#include <nn/snd.h>

// DecoderBCWav
namespace vox
{
DecoderInterface* DecoderBCWavFactory(void* params)
{
	return VOX_NEW DecoderBCWav(); 
}


DecoderCursorInterface* DecoderBCWav::CreateNewCursor( StreamCursorInterface* pStreamCursor )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderBCWav::CreateNewCursor", vox::VoxThread::GetCurThreadId());
	
	if(pStreamCursor->AllowBufferReference())
	{
		if(!m_bcwavParam)
		{
			u8*  pBcwavHeader;
			pStreamCursor->ReadRef(pBcwavHeader, 0x400);
			pStreamCursor->Seek(0);

			if(((u32)pBcwavHeader & (0x0000001f)) != 0)
			{
				VOX_WARNING_LEVEL_2("BCWav buffer is not aligned on 32 bytes : 0x%8x", pBcwavHeader);
				return 0;
			}

			m_bcwavParam = VOX_NEW BCWavParam();
			if(!m_bcwavParam)
			{
				VOX_WARNING_LEVEL_2("%s", "DecoderBCWav could not create param struct");
				return 0;
			}

			const nn::snd::Bcwav::WaveInfo& info = nn::snd::Bcwav::GetWaveInfo(pBcwavHeader);
			
			m_bcwavParam->m_encoding = info.encoding;
			if(info.isLoop)
				VOX_WARNING_LEVEL_3("%s", "Found a looping point in BCWav file, emitter looping parameter might not work properly")
			
			m_bcwavParam->m_sampleRate = info.sampleRate;

			m_bcwavParam->m_numChannel = nn::snd::Bcwav::GetChannelCount(pBcwavHeader);

			//u8* waveBuf = (u8*)nn::snd::Bcwav::GetWave(m_bcwavParam, 0);

			m_bcwavParam->m_dataSize = pStreamCursor->Size();
			//m_bcwavParam->m_dataSize = pStreamCursor->Size() - ((s32)waveBuf - (s32)pBcwavHeader);

			VOX_WARNING_LEVEL_5("BCWav info : Encoding : %d, NumChannel : %d, DataSize : %d, Sample rate : %d", m_bcwavParam->m_encoding, m_bcwavParam->m_numChannel, m_bcwavParam->m_dataSize, m_bcwavParam->m_sampleRate);
		}

		if(m_bcwavParam->m_encoding == nn::snd::Bcwav::ENCODING_DSP_ADPCM && m_bcwavParam->m_numChannel == 1)
		{
			return VOX_NEW DecoderBCWavCursor(this, pStreamCursor);
		}
		else
		{
			VOX_WARNING_LEVEL_2("%s", "DecoderBCWav only support mono BCWav with DSP ADPCM encoding");
			return 0;
		}
	}

	//Must support reference for whole file
	VOX_WARNING_LEVEL_2("%s", "DecoderBCWav incompatible with stream type");
	return 0;
}

void DecoderBCWav::DestroyCursor(DecoderCursorInterface* pDecoderCursor)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderBCWav::DestroyCursor", vox::VoxThread::GetCurThreadId());
	VOX_DELETE(pDecoderCursor);
}

void* DecoderBCWav::GetParam()
{
	return m_bcwavParam;
}

}

// DecoderBCWavCursor
namespace vox
{
DecoderBCWavCursor::DecoderBCWavCursor(DecoderInterface* pDecoder, StreamCursorInterface* pStreamCursor ) 
: DecoderCursorInterface( pDecoder, pStreamCursor ) 
, m_hasSentData(false)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderBCWavCursor", vox::VoxThread::GetCurThreadId());
	Init();
}

void DecoderBCWavCursor::Init()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderBCWavCursor::Init", vox::VoxThread::GetCurThreadId());
	if(m_pDecoder)
	{
		BCWavParam* params = (BCWavParam*)m_pDecoder->GetParam();
		if(params)
		{
			m_trackParams.bitsPerSample = 256; //fake to identifie BCWav (size should be a multiple of 32 bytes)
			m_trackParams.numChannels = params->m_numChannel;
			m_trackParams.samplingRate = params->m_sampleRate;
			m_trackParams.numSamples = params->m_dataSize / params->m_numChannel / 32;
		}
		else
		{
			m_trackParams.Reset();
		}
	}
	else
	{
		m_trackParams.Reset();
	}
}

s32  DecoderBCWavCursor::DecodeRef( void* &outputBuffer, s32 nbBytes )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderBCWavCursor::DecodeRef", vox::VoxThread::GetCurThreadId());
	if(m_pStreamCursor)
	{
		m_pStreamCursor->Seek(0);	
		u8* buf;	
		s32 readBytes = m_pStreamCursor->ReadRef(buf, m_pStreamCursor->Size());
		outputBuffer = buf;
		m_hasSentData = true;
		return readBytes;
	}

	return 0;
}

}

#endif
