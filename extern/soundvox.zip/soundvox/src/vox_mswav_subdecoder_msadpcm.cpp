#include "StdAfx.h"
#include "vox_mswav_subdecoder_msadpcm.h"
#include "vox_macro.h"
#include "vox_memory.h"
#include  <cstring>


namespace vox
{

VoxMSWavSubDecoderMSADPCM::VoxMSWavSubDecoderMSADPCM(StreamCursorInterface* pStreamCursor, WaveChunk* pWaveChunks)
: VoxMSWavSubDecoder(pStreamCursor,pWaveChunks)
, m_readBuffer(0)
, m_totalDataBytesRead(0)
, m_dataStartPosition(0)
, m_samplesInBuffer(0)
, m_samplesInBufferConsumed(0)
, m_totalSampleDecoded(0)
, m_blockReadBuffer(0)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderMSADPCM::VoxMSWavSubDecoderMSADPCM", vox::VoxThread::GetCurThreadId());

	#if VOX_BIG_ENDIAN
		VOX_WARNING_LEVEL_3("%s", "MS-ADPCM files are not supported on big-endian platforms");
		m_trackParams.Reset();
		return;
	#endif
	VOX_ASSERT(pStreamCursor);
	
	// Get the extended bytes from fmt chunk
	m_pStreamCursor->Seek(k_nRiffChunkSize + k_nFmtChunkSize, ORIGIN_START);
	u32 nbFmtExtraBytes = pWaveChunks->m_formatHeader.chunkDataSize - (k_nFmtChunkSize - k_nChunkHeaderSize);
	m_pStreamCursor->Read((u8*)&m_fmtExtendedInfos, nbFmtExtraBytes);

	GoToNextDataChunk();
	m_dataStartPosition = m_pStreamCursor->Tell();

	m_readBuffer = (u8*)VOX_ALLOC(sizeof(u8) * (pWaveChunks->m_formatHeader.blockAlign * 4));

	if(!m_readBuffer)
	{
		m_trackParams.Reset();
		return;
	}

	m_blockReadBuffer = (u8*)VOX_ALLOC(pWaveChunks->m_formatHeader.blockAlign);

	if(!m_blockReadBuffer)
	{
		VOX_FREE(m_readBuffer);
		m_readBuffer = 0;
		m_trackParams.Reset();
		return;
	}

	m_trackParams.bitsPerSample = 16;						// Intended to be nb of decoded bits per sample
	m_trackParams.numChannels = pWaveChunks->m_formatHeader.numChannels;
	m_trackParams.samplingRate = pWaveChunks->m_formatHeader.sampleRate;
	m_trackParams.numSamples = pWaveChunks->m_factHeader.factData;

	if(m_trackParams.numChannels <= 0 || m_trackParams.numChannels > 2)
	{
		VOX_WARNING_LEVEL_3("%s", "Only mono and stereo files are presently supported for MS-ADPCM format");
		m_trackParams.Reset();
		return;
	}

	s32 preambleSize = MS_ADPCM_MONO_HEADER_SIZE * pWaveChunks->m_formatHeader.numChannels;

	if(((pWaveChunks->m_formatHeader.blockAlign - preambleSize) << 1) % pWaveChunks->m_formatHeader.numChannels != 0)
	{
		VOX_WARNING_LEVEL_3("Block size of adpcm is not compatible with %d channels, may cause seek issues", pWaveChunks->m_formatHeader.numChannels);
	}
}

VoxMSWavSubDecoderMSADPCM::~VoxMSWavSubDecoderMSADPCM()
{
	VOX_FREE(m_readBuffer);
	VOX_FREE(m_blockReadBuffer);
}


s32 VoxMSWavSubDecoderMSADPCM::Seek(u32 sample)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderMSADPCM::Seek", vox::VoxThread::GetCurThreadId());
	if(sample > m_trackParams.numSamples)
	{
		VOX_WARNING_LEVEL_4("%s", "Decoder seek failed : position is outside stream");
		return -1;
	}

	if(sample < m_trackParams.numSamples)
	{
		u32 blockIndex = sample / m_fmtExtendedInfos.m_samplesPerBlock;

		// Consider all blocks preceding the one containing the requested sample as read.
		m_totalDataBytesRead = blockIndex * m_pWaveChunks->m_formatHeader.blockAlign;

		// Seek to start of block containing requested sample.
		m_pStreamCursor->Seek(m_dataStartPosition + m_totalDataBytesRead);
	
		u32 nbSamplesInPrecedingBlocks = blockIndex * m_fmtExtendedInfos.m_samplesPerBlock;

		// Consider all samples before the one requested as consumed.
		m_samplesInBufferConsumed = sample - nbSamplesInPrecedingBlocks;

		// Set all samples before the one requested as decoded (this line must be before call to decode)
		m_totalSampleDecoded = nbSamplesInPrecedingBlocks;
		
		// Decode the whole block containing the requested sample.
		m_samplesInBuffer = DecodeBlock((void*)m_readBuffer);

		return 0;
	}
	return -1;
}



bool VoxMSWavSubDecoderMSADPCM::HasData()
{
	if(m_pStreamCursor)
	{
		if(m_loop && ((m_totalSampleDecoded >= m_trackParams.numSamples) || ((m_totalDataBytesRead >= m_pWaveChunks->m_dataHeader.chunkSize) && (m_samplesInBufferConsumed == m_samplesInBuffer))))
		{
			Seek(0);
		}
		return !((m_totalSampleDecoded >= m_trackParams.numSamples) || ((m_totalDataBytesRead >= m_pWaveChunks->m_dataHeader.chunkSize) && (m_samplesInBufferConsumed == m_samplesInBuffer))) ;
	}
	return false;
}


s32 VoxMSWavSubDecoderMSADPCM::DecodeBlock(void* outbuf)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderMSADPCM::DecodeBlock", vox::VoxThread::GetCurThreadId());

	s32	i;
	s16	*coefficient[2];
	MsAdpcmState decoderState[2];
	MsAdpcmState *state[2];
	s16 *decoded = static_cast<s16*> (outbuf);

	s32 readSize = m_pWaveChunks->m_formatHeader.blockAlign <= m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead ? m_pWaveChunks->m_formatHeader.blockAlign : m_pWaveChunks->m_dataHeader.chunkSize - m_totalDataBytesRead;

	u8* readBuffer = m_blockReadBuffer;

	readSize = m_pStreamCursor->Read(readBuffer, readSize);

	state[0] = &decoderState[0];
	if (m_trackParams.numChannels == 2)
		state[1] = &decoderState[1];
	else
		state[1] = &decoderState[0];

	// Initialize predictor.
	for(i = 0; i < m_trackParams.numChannels; i++)
	{
		state[i]->predictor = *readBuffer++;
	}

	// Initialize delta.
	for(i = 0; i < m_trackParams.numChannels; i++)
	{
		state[i]->delta = (readBuffer[1] << 8) | readBuffer[0];
		readBuffer += sizeof(u16);
	}

	// Initialize first two samples.
	for(i = 0; i < m_trackParams.numChannels; i++)
	{
		state[i]->sample1 = (readBuffer[1] << 8) | readBuffer[0];
		readBuffer += sizeof(u16);
	}

	for (i = 0; i < m_trackParams.numChannels; i++)
	{
		state[i]->sample2 = (readBuffer[1] << 8) | readBuffer[0];
		readBuffer += sizeof(u16);
	}

	coefficient[0] = m_fmtExtendedInfos.m_coefficients[state[0]->predictor];
	coefficient[1] = m_fmtExtendedInfos.m_coefficients[state[1]->predictor];

	for(i = 0; i < m_trackParams.numChannels; i++)
		*decoded++ = state[i]->sample2;

	for (i = 0; i < m_trackParams.numChannels; i++)
		*decoded++ = state[i]->sample1;

	s32 loopCount = readSize - 7 * m_pWaveChunks->m_formatHeader.numChannels;

	// The first two samples have already been 'decoded' in	the block header.
	s32 nbSamples = (loopCount << 1) / m_trackParams.numChannels + 2;

	while(loopCount > 0)
	{
		*decoded++ = DecodeSample(state[0], static_cast<u32> (*readBuffer >> 4), coefficient[0]);
		*decoded++ = DecodeSample(state[1], static_cast<u32> (*readBuffer & 0x0f), coefficient[1]);

		readBuffer++;
		loopCount--;
	}

	m_totalDataBytesRead += readSize;
	if(m_totalSampleDecoded + nbSamples > m_trackParams.numSamples)
	{
		nbSamples = m_trackParams.numSamples - m_totalSampleDecoded;
	}

	return nbSamples;
}


// Compute a linear PCM value from the given differential coded	value.
s16 VoxMSWavSubDecoderMSADPCM::DecodeSample(MsAdpcmState *state, u32 code, const s16 *coefficient)
{
	s32	linearSample, delta;

	linearSample = ((state->sample1 * coefficient[0]) +	(state->sample2 * coefficient[1])) >> 8;

	// Variable 'code' is a 4-bit interpreted as signed complement-2 (reason for 28-shifts and s32-cast)
	linearSample += state->delta * ((static_cast<s32> (code << 28)) >> 28);

	// Clamp linearSample to a signed 16-bit value.
	if(linearSample < MIN_INT16)
		linearSample = MIN_INT16;
	else if (linearSample > MAX_INT16)
		linearSample = MAX_INT16;

	delta = ((s32) state->delta * adaptive[code]) >> 8;
	if(delta < 16)
	{
		delta = 16;
	}

	state->delta = delta;
	state->sample2 = state->sample1;
	state->sample1 = linearSample;

	// Because of earlier range checking, new_sample will be in the range of an s16.
	return static_cast<s16> (linearSample);
}


s32 VoxMSWavSubDecoderMSADPCM::Decode(void* outbuf, s32 nbBytes)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxMSWavSubDecoderMSADPCM::Decode", vox::VoxThread::GetCurThreadId());
	s32 nbSamplesDesired = nbBytes / (m_trackParams.numChannels * (m_trackParams.bitsPerSample >> 3));
	s32 nbSamples = nbSamplesDesired;
	s32 bufferoffset;
	s32 sampleAvailable;
	s32 nbSamplesToCopy;

	while(nbSamples > 0)
	{
		// Get a new decoded block if all samples have been consumed.
		if(m_samplesInBufferConsumed == m_samplesInBuffer)
		{
			m_samplesInBuffer = DecodeBlock((void*)m_readBuffer);
			m_samplesInBufferConsumed = 0;
		}

		// Set write offset in output buffer.
		bufferoffset = (nbSamplesDesired - nbSamples) * m_trackParams.numChannels;

		// Calculate the number of samples available in the current decoded block.
		sampleAvailable = m_samplesInBuffer - m_samplesInBufferConsumed;

		// Calculate the number of samples to copy from the decoded block to the output buffer.
		nbSamplesToCopy = (sampleAvailable > nbSamples) ? nbSamples : sampleAvailable;

		memcpy(&((s16*) outbuf)[bufferoffset], &(((short*)m_readBuffer)[m_samplesInBufferConsumed * m_trackParams.numChannels]), nbSamplesToCopy * m_trackParams.numChannels * sizeof(s16));

		nbSamples -= nbSamplesToCopy;
		m_samplesInBufferConsumed += nbSamplesToCopy;
		m_totalSampleDecoded += nbSamplesToCopy;

		if((m_totalSampleDecoded >= m_trackParams.numSamples) || ((m_totalDataBytesRead >= m_pWaveChunks->m_dataHeader.chunkSize) && (m_samplesInBufferConsumed == m_samplesInBuffer))) 
		{
			if(!(m_totalSampleDecoded >= m_trackParams.numSamples))
			{
				VOX_WARNING_LEVEL_4("Reached end of file but still waiting for samples, missing : %d", m_trackParams.numSamples - m_totalSampleDecoded);
			}
			if(!m_loop)
			{
				break;
			}
			else // If looping, seek to beginning of stream.
			{
				if(Seek(0) != 0)				
					break;		//could not go back to beginning
			}
		}
	}
	
	return (nbSamplesDesired - nbSamples)*( m_trackParams.numChannels * (m_trackParams.bitsPerSample>>3));
}

} // namespace vox
