#include "StdAfx.h"
#include "vox_native_subdecoder_pcm.h"
#include "vox_macro.h"


namespace vox
{


#if VOX_NATIVE_REDUCE_LATENCY

NativeSubDecoderPCMState::NativeSubDecoderPCMState(NativePlaylistsManager *pPlaylists)
:NativeSubDecoderState(pPlaylists)
{
}

NativeSubDecoderPCMState::~NativeSubDecoderPCMState()
{
}

#endif // VOX_NATIVE_REDUCE_LATENCY

///


VoxNativeSubDecoderPCM::VoxNativeSubDecoderPCM(StreamCursorInterface* pStreamCursor, NativeChunks* pNativeChunks,
											   States *pStates, AudioSegments *pAudioSegments, 
											   DOUBLE_VECTOR(s32) *pSegmentsCues,
											   TransitionRules *pTransitionRules,
											   DOUBLE_VECTOR(TransitionParams) *pTransitions,
											   STRING_MAP(s32, StringCompare) *pStateLabels,
											   NativePlaylistsManager *pPlaylists):
	VoxNativeSubDecoder(pStreamCursor, pNativeChunks, pStates, pAudioSegments, pSegmentsCues, pTransitionRules, pTransitions,
						pStateLabels, pPlaylists)
{

}


VoxNativeSubDecoderPCM::~VoxNativeSubDecoderPCM(void)
{

}


s32 VoxNativeSubDecoderPCM::DecodeCurrentSegmentWithOffset(void* outputBuffer, s32 nbBytes)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderPCM::DecodeCurrentSegmentWithOffset", vox::VoxThread::GetCurThreadId());

	s32 nbBytesDecoded = 0;
	s32 readsize = 0;
	u32 segmentStartOffset = m_pAudioSegments->m_pBuffer[m_currentSegmentState.m_index].m_start;
	s32 blockAlign = m_audioFormat.m_blockAlign;
	u32 loopEndBytePosition = (m_currentSegmentState.m_endCue + 1) * blockAlign;

	u32 segmentStart = m_dataStart + segmentStartOffset;

	// Fill the section preceding the segment's pre-entry position with zeroes
	if(m_currentSegmentOffset > 0)
	{
		nbBytesDecoded = m_currentSegmentOffset * blockAlign;
		memset(outputBuffer, 0, nbBytesDecoded);
		m_currentSegmentOffset = 0;
	}
	
	u32 absolutePosition = segmentStart + m_currentSegmentState.m_position;

	if((u32) m_pStreamCursor->Tell() != absolutePosition)
	{
		m_pStreamCursor->Seek(absolutePosition, ORIGIN_START);
	}

	while(nbBytesDecoded < nbBytes)
	{
		if(loopEndBytePosition >= m_currentSegmentState.m_position + (nbBytes - nbBytesDecoded))
		{
			readsize = m_pStreamCursor->Read(((u8*) outputBuffer) + nbBytesDecoded, (nbBytes - nbBytesDecoded));
			m_currentSegmentState.m_position += readsize;
		}
		else
		{
			readsize = m_pStreamCursor->Read(((u8*) outputBuffer) + nbBytesDecoded, loopEndBytePosition - m_currentSegmentState.m_position);
			m_currentSegmentState.m_position = loopEndBytePosition;
		}

		if(!readsize) // Not end of data, but could not read anything
		{
			m_currentSegmentState.m_playbackState = NATIVE_STATE_STOPPED;
			break;
		}

		nbBytesDecoded += readsize;
		m_currentSegmentState.m_totalSamplesDecoded = m_currentSegmentState.m_position / blockAlign;

		if(m_currentSegmentState.m_totalSamplesDecoded > m_currentSegmentState.m_endCue)
		{
			// If looping and first loop is completed, reset start cue at pre-entry cue.
			if((m_currentSegmentState.m_nbLoops >> 1 != 0) &&
			    m_currentSegmentState.m_nbLoopsRemaining == m_currentSegmentState.m_nbLoops)
			{
				m_currentSegmentState.m_startCue = (*m_pSegmentsCues)[m_currentSegmentState.m_index][NATIVE_CUE_PRE_ENTRY];
			}
			m_currentSegmentState.m_nbLoopsRemaining--;

			// If finished looping and post-exit should be played, set end cue to segment end.
			if(m_currentSegmentState.m_nbLoopsRemaining == 0)
			{
				// If post-exit should be played, set end cue to segment end.
				if(m_currentSegmentState.m_playPostExit == 1)
				{
					s32 lastCueIndex = (*m_pSegmentsCues)[m_currentSegmentState.m_index].size() - 1;
					m_currentSegmentState.m_endCue = (*m_pSegmentsCues)[m_currentSegmentState.m_index][lastCueIndex];
				}

				UpdateSegmentsStates();

				// Update loopEndBytePosition since endCue can be changed by UpdateSegmentsStates()
				loopEndBytePosition = (m_currentSegmentState.m_endCue + 1) * blockAlign;
			}
				
			if(m_currentSegmentState.m_playbackState == NATIVE_STATE_PLAYING)
			{
				// If still looping, seek to start cue
				if(m_currentSegmentState.m_nbLoopsRemaining != 0)
				{
					Seek(-1, &m_currentSegmentState);
				}
			}
			else if(m_currentSegmentState.m_playbackState == NATIVE_STATE_STOPPING)
			{
				if(m_currentSegmentState.m_totalSamplesDecoded > m_currentSegmentState.m_endCue)
				{
					m_currentSegmentState.m_playbackState = NATIVE_STATE_STOPPED;
					break;
				}	
			}
		}
	}

	#if VOX_BIG_ENDIAN
		if(m_audioFormat.m_bitsPerSample == 16)
		{
			u16* tbuf = (u16*)outputBuffer;
			s32 nbIterations = nbBytesDecoded >> 1;
			for(s32 i = 0; i < nbIterations; i++)
			{
				ConvertShortToBE(*tbuf);
				tbuf++;
			}
		}
	#endif

	return nbBytesDecoded;
}


s32 VoxNativeSubDecoderPCM::DecodeSegment(void* outputBuffer, s32 nbBytes, SegmentState *pSegmentState)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderPCM::DecodeSegment", vox::VoxThread::GetCurThreadId());

	s32 nbBytesDecoded = 0;
	s32 readsize = 0;
	u32 segmentStartOffset = m_pAudioSegments->m_pBuffer[pSegmentState->m_index].m_start;
	s32 blockAlign = m_audioFormat.m_blockAlign;
	u32 loopEndBytePosition = (pSegmentState->m_endCue + 1) * blockAlign;

	u32 segmentStart = m_dataStart + segmentStartOffset;
	u32 absolutePosition = segmentStart + pSegmentState->m_position;

	if((u32) m_pStreamCursor->Tell() != absolutePosition)
	{
		m_pStreamCursor->Seek(absolutePosition, ORIGIN_START);
	}

	while(nbBytesDecoded < nbBytes)
	{
		if(loopEndBytePosition >= pSegmentState->m_position + (nbBytes - nbBytesDecoded))
		{
			readsize = m_pStreamCursor->Read(((u8*) outputBuffer) + nbBytesDecoded, (nbBytes - nbBytesDecoded));
			pSegmentState->m_position += readsize;
		}
		else
		{
			readsize = m_pStreamCursor->Read(((u8*) outputBuffer) + nbBytesDecoded, loopEndBytePosition - pSegmentState->m_position);
			pSegmentState->m_position = loopEndBytePosition;
		}

		if(!readsize) // Not end of data, but could not read anything
		{
			pSegmentState->m_playbackState = NATIVE_STATE_STOPPED;
			break;
		}

		nbBytesDecoded += readsize;
		pSegmentState->m_totalSamplesDecoded = pSegmentState->m_position / blockAlign;

		if(pSegmentState->m_totalSamplesDecoded > pSegmentState->m_endCue)
		{
			// If looping and first loop is completed, reset start cue at pre-entry cue.
			if((pSegmentState->m_nbLoops >> 1 != 0) &&
			    pSegmentState->m_nbLoopsRemaining == pSegmentState->m_nbLoops)
			{
				pSegmentState->m_startCue = (*m_pSegmentsCues)[pSegmentState->m_index][NATIVE_CUE_PRE_ENTRY];
			}
			pSegmentState->m_nbLoopsRemaining--;

			if(pSegmentState->m_nbLoopsRemaining == 0)
			{
				// If post-exit should be played, set end cue to segment end.
				if(pSegmentState->m_playPostExit == 1)
				{
					s32 lastCueIndex = (*m_pSegmentsCues)[pSegmentState->m_index].size() - 1;
					pSegmentState->m_endCue = (*m_pSegmentsCues)[pSegmentState->m_index][lastCueIndex];
					loopEndBytePosition = (pSegmentState->m_endCue + 1) * blockAlign;
				}
				
				if(pSegmentState->m_lifeState == k_nSegmentCurrent)
				{
					UpdateSegmentsStates();

					// Update loopEndBytePosition since endCue can be changed by UpdateSegmentsStates()
					loopEndBytePosition = (pSegmentState->m_endCue + 1) * blockAlign;
				}
			}
				
			if(pSegmentState->m_playbackState == NATIVE_STATE_PLAYING)
			{
				// If still looping, seek to start cue
				if(pSegmentState->m_nbLoopsRemaining != 0)
				{
					Seek(-1, pSegmentState);
				}
			}
			else if(pSegmentState->m_playbackState == NATIVE_STATE_STOPPING)
			{
				if(pSegmentState->m_totalSamplesDecoded > pSegmentState->m_endCue)
				{
					pSegmentState->m_playbackState = NATIVE_STATE_STOPPED;
					break;
				}	
			}
		}
	}

	#if VOX_BIG_ENDIAN
		if(m_audioFormat.m_bitsPerSample == 16)
		{
			u16* tbuf = (u16*)outputBuffer;
			s32 nbIterations = nbBytesDecoded >> 1;
			for(s32 i = 0; i < nbIterations; i++)
			{
				ConvertShortToBE(*tbuf);
				tbuf++;
			}
		}
	#endif

	// If dying segment, stop it (only allowed to do one decode pass).
	if(pSegmentState->m_lifeState == k_nSegmentDying)
	{
		pSegmentState->m_playbackState = NATIVE_STATE_STOPPED;
	}

	return nbBytesDecoded;
}


#if VOX_NATIVE_REDUCE_LATENCY

s32 VoxNativeSubDecoderPCM::EmulateDecodeCurrentSegmentWithOffset(s32 nbBytes)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderPCM::EmulateDecodeCurrentSegmentWithOffset", vox::VoxThread::GetCurThreadId());

	s32 nbBytesDecoded = 0;
	s32 readsize = 0;
	u32 segmentStartOffset = m_pAudioSegments->m_pBuffer[m_currentSegmentState.m_index].m_start;
	s32 blockAlign = m_audioFormat.m_blockAlign;
	u32 loopEndBytePosition = (m_currentSegmentState.m_endCue + 1) * blockAlign;

	u32 segmentStart = m_dataStart + segmentStartOffset;

	// Fill the section preceding the segment's pre-entry position with zeroes
	if(m_currentSegmentOffset > 0)
	{
		nbBytesDecoded = m_currentSegmentOffset * blockAlign;
		m_currentSegmentOffset = 0;
	}
	
	u32 absolutePosition = segmentStart + m_currentSegmentState.m_position;

	if((u32) m_pStreamCursor->Tell() != absolutePosition)
	{
		m_pStreamCursor->Seek(absolutePosition, ORIGIN_START);
	}

	while(nbBytesDecoded < nbBytes)
	{
		if(loopEndBytePosition >= m_currentSegmentState.m_position + (nbBytes - nbBytesDecoded))
		{
			readsize = nbBytes - nbBytesDecoded;
			m_pStreamCursor->Seek(readsize, ORIGIN_CURRENT);
			m_currentSegmentState.m_position += readsize;
		}
		else
		{
			readsize = loopEndBytePosition - m_currentSegmentState.m_position;
			m_pStreamCursor->Seek(readsize, ORIGIN_CURRENT);
			m_currentSegmentState.m_position = loopEndBytePosition;
		}

		if(!readsize) // Not end of data, but could not read anything
		{
			m_currentSegmentState.m_playbackState = NATIVE_STATE_STOPPED;
			break;
		}

		nbBytesDecoded += readsize;
		m_currentSegmentState.m_totalSamplesDecoded = m_currentSegmentState.m_position / blockAlign;

		if(m_currentSegmentState.m_totalSamplesDecoded > m_currentSegmentState.m_endCue)
		{
			// If looping and first loop is completed, reset start cue at pre-entry cue.
			if((m_currentSegmentState.m_nbLoops >> 1 != 0) &&
			    m_currentSegmentState.m_nbLoopsRemaining == m_currentSegmentState.m_nbLoops)
			{
				m_currentSegmentState.m_startCue = (*m_pSegmentsCues)[m_currentSegmentState.m_index][NATIVE_CUE_PRE_ENTRY];
			}
			m_currentSegmentState.m_nbLoopsRemaining--;

			// If finished looping and post-exit should be played, set end cue to segment end.
			if(m_currentSegmentState.m_nbLoopsRemaining == 0)
			{
				// If post-exit should be played, set end cue to segment end.
				if(m_currentSegmentState.m_playPostExit == 1)
				{
					s32 lastCueIndex = (*m_pSegmentsCues)[m_currentSegmentState.m_index].size() - 1;
					m_currentSegmentState.m_endCue = (*m_pSegmentsCues)[m_currentSegmentState.m_index][lastCueIndex];
				}

				UpdateSegmentsStates();

				// Update loopEndBytePosition since endCue can be changed by UpdateSegmentsStates()
				loopEndBytePosition = (m_currentSegmentState.m_endCue + 1) * blockAlign;
			}
				
			if(m_currentSegmentState.m_playbackState == NATIVE_STATE_PLAYING)
			{
				// If still looping, seek to start cue
				if(m_currentSegmentState.m_nbLoopsRemaining != 0)
				{
					Seek(-1, &m_currentSegmentState);
				}
			}
			else if(m_currentSegmentState.m_playbackState == NATIVE_STATE_STOPPING)
			{
				if(m_currentSegmentState.m_totalSamplesDecoded > m_currentSegmentState.m_endCue)
				{
					m_currentSegmentState.m_playbackState = NATIVE_STATE_STOPPED;
					break;
				}	
			}
		}
	}

	return nbBytesDecoded;
}


s32 VoxNativeSubDecoderPCM::EmulateDecodeSegment(s32 nbBytes, SegmentState *pSegmentState)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderPCM::EmulateDecodeSegment", vox::VoxThread::GetCurThreadId());

	s32 nbBytesDecoded = 0;
	s32 readsize = 0;
	u32 segmentStartOffset = m_pAudioSegments->m_pBuffer[pSegmentState->m_index].m_start;
	s32 blockAlign = m_audioFormat.m_blockAlign;
	u32 loopEndBytePosition = (pSegmentState->m_endCue + 1) * blockAlign;

	u32 segmentStart = m_dataStart + segmentStartOffset;
	u32 absolutePosition = segmentStart + pSegmentState->m_position;

	if((u32) m_pStreamCursor->Tell() != absolutePosition)
	{
		m_pStreamCursor->Seek(absolutePosition, ORIGIN_START);
	}

	while(nbBytesDecoded < nbBytes)
	{
		if(loopEndBytePosition >= pSegmentState->m_position + (nbBytes - nbBytesDecoded))
		{
			readsize = nbBytes - nbBytesDecoded;
			m_pStreamCursor->Seek(readsize, ORIGIN_CURRENT);
			pSegmentState->m_position += readsize;
		}
		else
		{
			readsize = loopEndBytePosition - pSegmentState->m_position;
			m_pStreamCursor->Seek(readsize, ORIGIN_CURRENT);
			pSegmentState->m_position = loopEndBytePosition;
		}

		if(!readsize) // Not end of data, but could not read anything
		{
			pSegmentState->m_playbackState = NATIVE_STATE_STOPPED;
			break;
		}

		nbBytesDecoded += readsize;
		pSegmentState->m_totalSamplesDecoded = pSegmentState->m_position / blockAlign;

		if(pSegmentState->m_totalSamplesDecoded > pSegmentState->m_endCue)
		{
			// If looping and first loop is completed, reset start cue at pre-entry cue.
			if((pSegmentState->m_nbLoops >> 1 != 0) &&
			    pSegmentState->m_nbLoopsRemaining == pSegmentState->m_nbLoops)
			{
				pSegmentState->m_startCue = (*m_pSegmentsCues)[pSegmentState->m_index][NATIVE_CUE_PRE_ENTRY];
			}
			pSegmentState->m_nbLoopsRemaining--;

			if(pSegmentState->m_nbLoopsRemaining == 0)
			{
				// If post-exit should be played, set end cue to segment end.
				if(pSegmentState->m_playPostExit == 1)
				{
					s32 lastCueIndex = (*m_pSegmentsCues)[pSegmentState->m_index].size() - 1;
					pSegmentState->m_endCue = (*m_pSegmentsCues)[pSegmentState->m_index][lastCueIndex];
					loopEndBytePosition = (pSegmentState->m_endCue + 1) * blockAlign;
				}
				
				if(pSegmentState->m_lifeState == k_nSegmentCurrent)
				{
					UpdateSegmentsStates();

					// Update loopEndBytePosition since endCue can be changed by UpdateSegmentsStates()
					loopEndBytePosition = (pSegmentState->m_endCue + 1) * blockAlign;
				}
			}
				
			if(pSegmentState->m_playbackState == NATIVE_STATE_PLAYING)
			{
				// If still looping, seek to start cue
				if(pSegmentState->m_nbLoopsRemaining != 0)
				{
					Seek(-1, pSegmentState);
				}
			}
			else if(pSegmentState->m_playbackState == NATIVE_STATE_STOPPING)
			{
				if(pSegmentState->m_totalSamplesDecoded > pSegmentState->m_endCue)
				{
					pSegmentState->m_playbackState = NATIVE_STATE_STOPPED;
					break;
				}	
			}
		}
	}

	// If dying segment, stop it (only allowed to do one decode pass).
	if(pSegmentState->m_lifeState == k_nSegmentDying)
	{
		pSegmentState->m_playbackState = NATIVE_STATE_STOPPED;
	}

	return nbBytesDecoded;
}

void VoxNativeSubDecoderPCM::GetState(NativeSubDecoderPCMState *pState)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderPCM::GetState", vox::VoxThread::GetCurThreadId());

	VoxNativeSubDecoder::GetState(pState);
}


void VoxNativeSubDecoderPCM::SetState(NativeSubDecoderPCMState *pState)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderPCM::SetState", vox::VoxThread::GetCurThreadId());

	VoxNativeSubDecoder::SetState(pState);
}

#endif // VOX_NATIVE_REDUCE_LATENCY

u32 VoxNativeSubDecoderPCM::GetBytePositionFromSampleOffset(u32 sampleOffset)
{
	return (sampleOffset * m_audioFormat.m_blockAlign);
}


void VoxNativeSubDecoderPCM::Reset(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderPCM::Reset", vox::VoxThread::GetCurThreadId());

	VoxNativeSubDecoder::Reset();
}


s32 VoxNativeSubDecoderPCM::Seek(s32 samplePosition, SegmentState *pSegmentState)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderPCM::Seek", vox::VoxThread::GetCurThreadId());

	u32 targetPosition;	// In bytes

	// If position is not specified, seek to segment's state loop start.
	if(samplePosition < 0)
	{
		samplePosition = pSegmentState->m_startCue;
	}

	targetPosition = samplePosition * m_audioFormat.m_blockAlign;

	u32 segmentNbSamples = m_pAudioSegments->m_pBuffer[pSegmentState->m_index].m_nbSamples;

	if(samplePosition > (s32) segmentNbSamples)
	{
		VOX_WARNING_LEVEL_4("%s", "Decoder seek failed : position is outside stream");
		return -1;
	}
	else
	{
		// Find start position of segment (relative to beginning of file)
		u32 segmentStartOffset = m_pAudioSegments->m_pBuffer[pSegmentState->m_index].m_start;
		u32 segmentStart = m_dataStart + segmentStartOffset;

		// Seek to start of block containing requested sample.
		s32 seekResult = m_pStreamCursor->Seek(segmentStart + targetPosition);
	
		if(!seekResult) // Seek has succeeded
		{
			pSegmentState->m_position = targetPosition;
			pSegmentState->m_totalSamplesDecoded = samplePosition;
		}

		return seekResult;
	}
	return -1;
}


}
