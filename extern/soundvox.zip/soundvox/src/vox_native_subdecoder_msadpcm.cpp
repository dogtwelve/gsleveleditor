#include "StdAfx.h"
#include "vox_native_subdecoder_msadpcm.h"
#include "vox_macro.h"
#include "vox_memory.h"
#include  <cstring>

namespace vox
{

#define BUFFER_AVAILABLE	0
#define BUFFER_UNAVAILABLE	1


#if VOX_NATIVE_REDUCE_LATENCY

NativeSubDecoderMSADPCMState::NativeSubDecoderMSADPCMState(NativePlaylistsManager *pPlaylists)
:NativeSubDecoderState(pPlaylists)
{
}

NativeSubDecoderMSADPCMState::~NativeSubDecoderMSADPCMState()
{
}

#endif // VOX_NATIVE_REDUCE_LATENCY

///


VoxNativeSubDecoderMSADPCM::VoxNativeSubDecoderMSADPCM(StreamCursorInterface* pStreamCursor, 
													   NativeChunks* pNativeChunks, States *pStates,
													   AudioSegments *pAudioSegments,
													   DOUBLE_VECTOR(s32) *pSegmentsCues,
													   TransitionRules *pTransitionRules,
													   DOUBLE_VECTOR(TransitionParams) *pTransitions,
													   STRING_MAP(s32, StringCompare) *pStateLabels,
													   NativePlaylistsManager *pPlaylists,
													   FmtExtendedInfos *pFmtExtendedInfos):
VoxNativeSubDecoder(pStreamCursor, pNativeChunks, pStates, pAudioSegments, pSegmentsCues, pTransitionRules, pTransitions, 
					pStateLabels, pPlaylists)
, m_pDecodeBuffers(0)
, m_blockReadBuffer(0)
, m_totalDataBytesRead(0)
, m_pFmtExtendedInfos(pFmtExtendedInfos)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderMSADPCM::VoxNativeSubDecoderMSADPCM", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT(pStreamCursor);

	m_audioFormat = pNativeChunks->m_formatChunk.m_format;
	s32 blockAlign = m_audioFormat.m_blockAlign;

	m_pDecodeBuffers = (u8**) VOX_ALLOC(sizeof(u8*) * 3);
	m_blockReadBuffer = (u8*) VOX_ALLOC(blockAlign);

	if(!m_pDecodeBuffers || !m_blockReadBuffer)
	{
		m_audioFormat.Reset(); // To avoid data source creation.
		return;
	}

	m_pDecodeBuffers[0] = (u8*) VOX_ALLOC(blockAlign * 4);
	m_pDecodeBuffers[1] = (u8*) VOX_ALLOC(blockAlign * 4);
	m_pDecodeBuffers[2] = (u8*) VOX_ALLOC(blockAlign * 4);

	if(!m_pDecodeBuffers[0] || !m_pDecodeBuffers[1] || !m_pDecodeBuffers[2])
	{
		m_audioFormat.Reset(); // To avoid data source creation.
		return;
	}

	m_samplesInBuffer[0] = 0;
	m_samplesInBuffer[1] = 0;
	m_samplesInBuffer[2] = 0;
	m_samplesInBufferConsumed[0] = 0;
	m_samplesInBufferConsumed[1] = 0;
	m_samplesInBufferConsumed[2] = 0;
	m_decodeBuffersState[0] = BUFFER_AVAILABLE;
	m_decodeBuffersState[1] = BUFFER_AVAILABLE;
	m_decodeBuffersState[2] = BUFFER_AVAILABLE;

	if(m_audioFormat.m_nbChannels > 8)
	{
		m_audioFormat.Reset();
	}

	s32 preambleSize = MS_ADPCM_MONO_HEADER_SIZE * m_audioFormat.m_nbChannels;

	if(((m_audioFormat.m_blockAlign - preambleSize) << 1) % m_audioFormat.m_nbChannels != 0)
	{
		VOX_WARNING_LEVEL_3("Block size of adpcm is not compatible with %d channels, may cause seek issues", m_audioFormat.m_nbChannels);
	}
}


VoxNativeSubDecoderMSADPCM::~VoxNativeSubDecoderMSADPCM(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderMSADPCM::~VoxNativeSubDecoderMSADPCM", vox::VoxThread::GetCurThreadId());

	if(m_pDecodeBuffers)
	{
		if(m_pDecodeBuffers[0])
		{
			VOX_FREE(m_pDecodeBuffers[0]);
			m_pDecodeBuffers[0] = 0;
		}
		if(m_pDecodeBuffers[1])
		{
			VOX_FREE(m_pDecodeBuffers[1]);
			m_pDecodeBuffers[1] = 0;
		}
		if(m_pDecodeBuffers[2])
		{
			VOX_FREE(m_pDecodeBuffers[2]);
			m_pDecodeBuffers[2] = 0;
		}
		VOX_FREE(m_pDecodeBuffers);
		m_pDecodeBuffers = 0;
	}

	if(m_blockReadBuffer)
	{
		VOX_FREE(m_blockReadBuffer);
		m_blockReadBuffer = 0;
	}
}


s32 VoxNativeSubDecoderMSADPCM::DecodeBlock(void* outbuf, SegmentState *pSegmentState)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderMSADPCM::DecodeBlock", vox::VoxThread::GetCurThreadId());

	s32	i;
	s16	*coefficient[2];
	MsAdpcmState decoderState[2];
	MsAdpcmState *state[2];
	s16 *decoded = static_cast<s16*> (outbuf);

	s16 nbChannels = m_audioFormat.m_nbChannels;
	u32 segmentSize = m_pAudioSegments->m_pBuffer[pSegmentState->m_index].m_size; // See if should be defined here
	u32 segmentNbSamples = m_pAudioSegments->m_pBuffer[pSegmentState->m_index].m_nbSamples;

	// Determine absolute position of cursor in file and seek to that position
	u32 segmentStartOffset = m_pAudioSegments->m_pBuffer[pSegmentState->m_index].m_start;
	u32 segmentStart = m_dataStart + segmentStartOffset;
	u32 absolutePosition = segmentStart + pSegmentState->m_position;

	if((u32) m_pStreamCursor->Tell() != absolutePosition)
	{
		m_pStreamCursor->Seek(absolutePosition, ORIGIN_START);
	}

	u8* readBuffer = m_blockReadBuffer;

	s32 readSize;
	
	if(((u32) m_audioFormat.m_blockAlign) <= segmentSize - pSegmentState->m_position)
	{
		readSize = (s32) m_audioFormat.m_blockAlign;
	}
	else
	{
		readSize = (s32) (segmentSize - pSegmentState->m_position);
	}

	readSize = m_pStreamCursor->Read(readBuffer, readSize);
	pSegmentState->m_position += readSize;

	state[0] = &decoderState[0];
	if(nbChannels == 2)
		state[1] = &decoderState[1];
	else
		state[1] = &decoderState[0];

	// Initialize predictor.
	for(i = 0; i < nbChannels; i++)
	{
		state[i]->predictor = *readBuffer++;
	}

	// Initialize delta.
	for(i = 0; i < nbChannels; i++)
	{
		state[i]->delta = (readBuffer[1] << 8) | readBuffer[0];
		readBuffer += sizeof(u16);
	}

	// Initialize first two samples.
	for(i = 0; i < nbChannels; i++)
	{
		state[i]->sample1 = (readBuffer[1] << 8) | readBuffer[0];
		readBuffer += sizeof(u16);
	}

	for (i = 0; i < nbChannels; i++)
	{
		state[i]->sample2 = (readBuffer[1] << 8) | readBuffer[0];
		readBuffer += sizeof(u16);
	}

	coefficient[0] = m_pFmtExtendedInfos->m_coefficients[state[0]->predictor];
	coefficient[1] = m_pFmtExtendedInfos->m_coefficients[state[1]->predictor];

	for(i = 0; i < nbChannels; i++)
		*decoded++ = state[i]->sample2;

	for (i = 0; i < nbChannels; i++)
		*decoded++ = state[i]->sample1;

	s32 loopCount = readSize - 7 * nbChannels;

	// The first two samples have already been 'decoded' in	the block header.
	s32 nbSamples = (loopCount << 1) / nbChannels + 2;

	while(loopCount > 0)
	{
		*decoded++ = DecodeSample(state[0], static_cast<u32> (*readBuffer >> 4), coefficient[0]);
		*decoded++ = DecodeSample(state[1], static_cast<u32> (*readBuffer & 0x0f), coefficient[1]);

		readBuffer++;
		loopCount--;
	}
	
	// Ignore zero padding at the end of segment's last block.
	if(pSegmentState->m_totalSamplesDecoded + nbSamples > segmentNbSamples)
	{
		nbSamples = segmentNbSamples - pSegmentState->m_totalSamplesDecoded;
	}

	return nbSamples;
}


// Compute a linear PCM value from the given differential coded	value.
s16 VoxNativeSubDecoderMSADPCM::DecodeSample(MsAdpcmState *state, u32 code, const s16 *coefficient)
{
	s32	linearSample, delta;

	linearSample = ((state->sample1 * coefficient[0]) +	(state->sample2 * coefficient[1])) >> 8;

	// Variable 'code' is a 4-bit interpreted as signed complement-2 (reason for 28-shifts and s32-cast)
	linearSample += state->delta * ((static_cast<s32> (code << 28)) >> 28);

	// Clamp linearSample to a signed 16-bit value.
	if(linearSample < MIN_INT16)
		linearSample = MIN_INT16;
	else if (linearSample > MAX_INT16)
		linearSample = MAX_INT16;

	delta = ((s32) state->delta * adaptive[code]) >> 8;
	if(delta < 16)
	{
		delta = 16;
	}

	state->delta = delta;
	state->sample2 = state->sample1;
	state->sample1 = linearSample;

	// Because of earlier range checking, new_sample will be in the range of an s16.
	return static_cast<s16> (linearSample);
}

s32 VoxNativeSubDecoderMSADPCM::DecodeCurrentSegmentWithOffset(void* outputBuffer, s32 nbBytes)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderMSADPCM::DecodeCurrentSegmentWithOffset", vox::VoxThread::GetCurThreadId());

	s16 nbChannels = m_audioFormat.m_nbChannels;
	s32 nbSamplesDesired = nbBytes / (nbChannels * (m_audioFormat.m_bitsPerSample >> 3));
	s32 nbSamples = nbSamplesDesired;
	s32 bufferoffset;
	s32 nbSamplesAvailable;
	s32 nbSamplesLeftInLoop;
	s32 nbSamplesToCopy;
	
	// Determine which decodeBuffer has to be used.
	s32 bufferIndex = m_currentSegmentState.m_adpcmBufferIndex;

	// Fill the section preceding the segment's pre-entry position with zeroes
	if(m_currentSegmentOffset > 0)
	{
		memset(outputBuffer, 0, m_currentSegmentOffset * nbChannels * (m_audioFormat.m_bitsPerSample >> 3));
		nbSamples = nbSamplesDesired - m_currentSegmentOffset;
		m_currentSegmentOffset = 0;
	}

	while(nbSamples > 0)
	{
		// Set current decoding buffer to a specific position.
		if(m_currentSegmentState.m_setAdpcmBufferCursor)
		{
			SetDecodingBufferToSegmentPosition(&m_currentSegmentState);
			m_currentSegmentState.m_setAdpcmBufferCursor = false;
		}

		// Get a new decoded block if all samples have been consumed.
		if(m_samplesInBufferConsumed[bufferIndex] == m_samplesInBuffer[bufferIndex])
		{
			m_samplesInBuffer[bufferIndex] = DecodeBlock((void*)m_pDecodeBuffers[bufferIndex], &m_currentSegmentState);
			m_samplesInBufferConsumed[bufferIndex] = 0;
		}

		if(!m_samplesInBuffer[bufferIndex]) // Not end of data, but could not read anything
		{
			m_currentSegmentState.m_playbackState = NATIVE_STATE_STOPPED;
			break;
		}

		// Set write offset in output buffer.
		bufferoffset = (nbSamplesDesired - nbSamples) * nbChannels;

		// Calculate the number of samples available in the current decoded block.
		nbSamplesAvailable = m_samplesInBuffer[bufferIndex] - m_samplesInBufferConsumed[bufferIndex];

		// Calculate nb of samples left in current loop
		nbSamplesLeftInLoop = m_currentSegmentState.m_endCue - m_currentSegmentState.m_totalSamplesDecoded + 1;

		// Find min between nb of samples left in block and nb of samples left in loop
		nbSamplesAvailable = nbSamplesAvailable < nbSamplesLeftInLoop ? nbSamplesAvailable : nbSamplesLeftInLoop;

		// Calculate the number of samples to copy from the decoded block to the output buffer.
		nbSamplesToCopy = (nbSamplesAvailable > nbSamples) ? nbSamples : nbSamplesAvailable;

		memcpy(&((s16*) outputBuffer)[bufferoffset], &(((short*)m_pDecodeBuffers[bufferIndex])[m_samplesInBufferConsumed[bufferIndex] * nbChannels]), nbSamplesToCopy * nbChannels * sizeof(s16));

		nbSamples -= nbSamplesToCopy;
		m_samplesInBufferConsumed[bufferIndex] += nbSamplesToCopy;
		m_currentSegmentState.m_totalSamplesDecoded += nbSamplesToCopy;

		if(m_currentSegmentState.m_totalSamplesDecoded > m_currentSegmentState.m_endCue)
		{
			// If looping and first loop is completed, reset start cue at pre-entry cue.
			if((m_currentSegmentState.m_nbLoops >> 1 != 0) &&
			    m_currentSegmentState.m_nbLoopsRemaining == m_currentSegmentState.m_nbLoops)
			{
				m_currentSegmentState.m_startCue = (*m_pSegmentsCues)[m_currentSegmentState.m_index][NATIVE_CUE_PRE_ENTRY];
			}
			m_currentSegmentState.m_nbLoopsRemaining--;

			// If finished looping and post-exit should be played, set end cue to segment end.
			if(m_currentSegmentState.m_nbLoopsRemaining == 0)
			{
				// If post-exit should be played, set end cue to segment end.
				if(m_currentSegmentState.m_playPostExit == 1)
				{
					s32 lastCueIndex = (*m_pSegmentsCues)[m_currentSegmentState.m_index].size() - 1;
					m_currentSegmentState.m_endCue = (*m_pSegmentsCues)[m_currentSegmentState.m_index][lastCueIndex];
				}

				UpdateSegmentsStates();
			}
				
			if(m_currentSegmentState.m_playbackState == NATIVE_STATE_PLAYING)
			{
				// If still looping, seek to start cue
				if(m_currentSegmentState.m_nbLoopsRemaining != 0)
				{
					Seek(-1, &m_currentSegmentState);
				}
			}
			else if(m_currentSegmentState.m_playbackState == NATIVE_STATE_STOPPING)
			{
				if(m_currentSegmentState.m_totalSamplesDecoded > m_currentSegmentState.m_endCue)
				{
					m_currentSegmentState.m_playbackState = NATIVE_STATE_STOPPED;
					break;
				}	
			}
		}
	}

	return (nbSamplesDesired - nbSamples)*(nbChannels * (m_audioFormat.m_bitsPerSample >> 3));
}


s32 VoxNativeSubDecoderMSADPCM::DecodeSegment(void* outputBuffer, s32 nbBytes, SegmentState *pSegmentState)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderMSADPCM::DecodeSegment", vox::VoxThread::GetCurThreadId());

	s16 nbChannels = m_audioFormat.m_nbChannels;
	s32 nbSamplesDesired = nbBytes / (nbChannels * (m_audioFormat.m_bitsPerSample >> 3));
	s32 nbSamples = nbSamplesDesired;
	s32 bufferoffset;
	s32 nbSamplesAvailable;
	s32 nbSamplesLeftInLoop;
	s32 nbSamplesToCopy;
	
	// Determine which decodeBuffer has to be used.
	s32 bufferIndex = pSegmentState->m_adpcmBufferIndex;

	while(nbSamples > 0)
	{
		// Set current decoding buffer to a specific position.
		if(pSegmentState->m_setAdpcmBufferCursor)
		{
			SetDecodingBufferToSegmentPosition(pSegmentState);
			pSegmentState->m_setAdpcmBufferCursor = false;
		}

		// Get a new decoded block if all samples have been consumed.
		if(m_samplesInBufferConsumed[bufferIndex] == m_samplesInBuffer[bufferIndex])
		{
			m_samplesInBuffer[bufferIndex] = DecodeBlock((void*)m_pDecodeBuffers[bufferIndex], pSegmentState);
			m_samplesInBufferConsumed[bufferIndex] = 0;
		}

		if(!m_samplesInBuffer[bufferIndex]) // Not end of data, but could not read anything
		{
			pSegmentState->m_playbackState = NATIVE_STATE_STOPPED;
			break;
		}

		// Set write offset in output buffer.
		bufferoffset = (nbSamplesDesired - nbSamples) * nbChannels;

		// Calculate the number of samples available in the current decoded block.
		nbSamplesAvailable = m_samplesInBuffer[bufferIndex] - m_samplesInBufferConsumed[bufferIndex];

		// Calculate nb of samples left in current loop
		nbSamplesLeftInLoop = pSegmentState->m_endCue - pSegmentState->m_totalSamplesDecoded + 1;

		// Find min between nb of samples left in block and nb of samples left in loop
		nbSamplesAvailable = nbSamplesAvailable < nbSamplesLeftInLoop ? nbSamplesAvailable : nbSamplesLeftInLoop;

		// Calculate the number of samples to copy from the decoded block to the output buffer.
		nbSamplesToCopy = (nbSamplesAvailable > nbSamples) ? nbSamples : nbSamplesAvailable;

		memcpy(&((s16*) outputBuffer)[bufferoffset], &(((short*)m_pDecodeBuffers[bufferIndex])[m_samplesInBufferConsumed[bufferIndex] * nbChannels]), nbSamplesToCopy * nbChannels * sizeof(s16));

		nbSamples -= nbSamplesToCopy;
		m_samplesInBufferConsumed[bufferIndex] += nbSamplesToCopy;
		pSegmentState->m_totalSamplesDecoded += nbSamplesToCopy;

		if(pSegmentState->m_totalSamplesDecoded > pSegmentState->m_endCue)
		{
			// If looping and first loop is completed, reset start cue at pre-entry cue.
			if((pSegmentState->m_nbLoops >> 1 != 0) &&
			    pSegmentState->m_nbLoopsRemaining == pSegmentState->m_nbLoops)
			{
				pSegmentState->m_startCue = (*m_pSegmentsCues)[pSegmentState->m_index][NATIVE_CUE_PRE_ENTRY];
			}
			pSegmentState->m_nbLoopsRemaining--;

			// If finished looping and post-exit should be played, set end cue to segment end.
			if(pSegmentState->m_nbLoopsRemaining == 0)
			{
				// If post-exit should be played, set end cue to segment end.
				if(pSegmentState->m_playPostExit == 1)
				{
					s32 lastCueIndex = (*m_pSegmentsCues)[pSegmentState->m_index].size() - 1;
					pSegmentState->m_endCue = (*m_pSegmentsCues)[pSegmentState->m_index][lastCueIndex];
				}
				
				if(pSegmentState->m_lifeState == k_nSegmentCurrent)
				{
					UpdateSegmentsStates();
				}
			}

			if(pSegmentState->m_playbackState == NATIVE_STATE_PLAYING)
			{
				// If still looping, seek to start cue
				if(pSegmentState->m_nbLoopsRemaining != 0)
				{
					Seek(-1, pSegmentState);
				}
			}
			else if(pSegmentState->m_playbackState == NATIVE_STATE_STOPPING)
			{
				if(pSegmentState->m_totalSamplesDecoded > pSegmentState->m_endCue)
				{
					pSegmentState->m_playbackState = NATIVE_STATE_STOPPED;
					break;
				}	
			}
		}
	}

	// If dying segment, stop it (only allowed to do one decode pass).
	if(pSegmentState->m_lifeState == k_nSegmentDying)
	{
		pSegmentState->m_playbackState = NATIVE_STATE_STOPPED;
	}

	return (nbSamplesDesired - nbSamples)*(nbChannels * (m_audioFormat.m_bitsPerSample >> 3));
}

#if VOX_NATIVE_REDUCE_LATENCY

s32 VoxNativeSubDecoderMSADPCM::EmulateDecodeBlock(SegmentState *pSegmentState)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderMSADPCM::EmulateDecodeBlock", vox::VoxThread::GetCurThreadId());

	u32 segmentSize = m_pAudioSegments->m_pBuffer[pSegmentState->m_index].m_size;
	u32 segmentNbSamples = m_pAudioSegments->m_pBuffer[pSegmentState->m_index].m_nbSamples;

	s32 readSize;
	
	if(((u32) m_audioFormat.m_blockAlign) <= segmentSize - pSegmentState->m_position)
	{
		readSize = (s32) m_audioFormat.m_blockAlign;
	}
	else
	{
		readSize = (s32) (segmentSize - pSegmentState->m_position);
	}

	pSegmentState->m_position += readSize;

	s32 loopCount = readSize - 7 * m_audioFormat.m_nbChannels;

	// The first two samples have already been 'decoded' in	the block header.
	s32 nbSamples = (loopCount << 1) / m_audioFormat.m_nbChannels + 2;
	
	// Ignore zero padding at the end of segment's last block.
	if(pSegmentState->m_totalSamplesDecoded + nbSamples > segmentNbSamples)
	{
		nbSamples = segmentNbSamples - pSegmentState->m_totalSamplesDecoded;
	}

	return nbSamples;
}


s32 VoxNativeSubDecoderMSADPCM::EmulateDecodeCurrentSegmentWithOffset(s32 nbBytes)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderMSADPCM::EmulateDecodeCurrentSegmentWithOffset", vox::VoxThread::GetCurThreadId());

	s16 nbChannels = m_audioFormat.m_nbChannels;
	s32 nbSamplesDesired = nbBytes / (nbChannels * (m_audioFormat.m_bitsPerSample >> 3));
	s32 nbSamples = nbSamplesDesired;
	s32 bufferoffset;
	s32 nbSamplesAvailable;
	s32 nbSamplesLeftInLoop;
	s32 nbSamplesToCopy;
	
	// Determine which decodeBuffer has to be used.
	s32 bufferIndex = m_currentSegmentState.m_adpcmBufferIndex;

	// Fill the section preceding the segment's pre-entry position with zeroes
	if(m_currentSegmentOffset > 0)
	{
		nbSamples = nbSamplesDesired - m_currentSegmentOffset;
		m_currentSegmentOffset = 0;
	}

	while(nbSamples > 0)
	{
		// Set decoding buffer to position specified by segment's total nb of samples decoded.
		if(m_currentSegmentState.m_setAdpcmBufferCursor)
		{
			EmulateSetDecodingBufferToSegmentPosition(&m_currentSegmentState);
			m_currentSegmentState.m_setAdpcmBufferCursor = false;
		}

		// Get a new decoded block if all samples have been consumed.
		if(m_samplesInBufferConsumed[bufferIndex] == m_samplesInBuffer[bufferIndex])
		{
			m_samplesInBuffer[bufferIndex] = EmulateDecodeBlock(&m_currentSegmentState);
			m_samplesInBufferConsumed[bufferIndex] = 0;
		}

		if(!m_samplesInBuffer[bufferIndex]) // Not end of data, but could not read anything
		{
			m_currentSegmentState.m_playbackState = NATIVE_STATE_STOPPED;
			break;
		}

		// Set write offset in output buffer.
		bufferoffset = (nbSamplesDesired - nbSamples) * nbChannels;

		// Calculate the number of samples available in the current decoded block.
		nbSamplesAvailable = m_samplesInBuffer[bufferIndex] - m_samplesInBufferConsumed[bufferIndex];

		// Calculate nb of samples left in current loop
		nbSamplesLeftInLoop = m_currentSegmentState.m_endCue - m_currentSegmentState.m_totalSamplesDecoded + 1;

		// Find min between nb of samples left in block and nb of samples left in loop
		nbSamplesAvailable = nbSamplesAvailable < nbSamplesLeftInLoop ? nbSamplesAvailable : nbSamplesLeftInLoop;

		// Calculate the number of samples to copy from the decoded block to the output buffer.
		nbSamplesToCopy = (nbSamplesAvailable > nbSamples) ? nbSamples : nbSamplesAvailable;

		nbSamples -= nbSamplesToCopy;
		m_samplesInBufferConsumed[bufferIndex] += nbSamplesToCopy;
		m_currentSegmentState.m_totalSamplesDecoded += nbSamplesToCopy;

		if(m_currentSegmentState.m_totalSamplesDecoded > m_currentSegmentState.m_endCue)
		{
			// If looping and first loop is completed, reset start cue at pre-entry cue.
			if((m_currentSegmentState.m_nbLoops >> 1 != 0) &&
			    m_currentSegmentState.m_nbLoopsRemaining == m_currentSegmentState.m_nbLoops)
			{
				m_currentSegmentState.m_startCue = (*m_pSegmentsCues)[m_currentSegmentState.m_index][NATIVE_CUE_PRE_ENTRY];
			}
			m_currentSegmentState.m_nbLoopsRemaining--;

			// If finished looping and post-exit should be played, set end cue to segment end.
			if(m_currentSegmentState.m_nbLoopsRemaining == 0)
			{
				// If post-exit should be played, set end cue to segment end.
				if(m_currentSegmentState.m_playPostExit == 1)
				{
					s32 lastCueIndex = (*m_pSegmentsCues)[m_currentSegmentState.m_index].size() - 1;
					m_currentSegmentState.m_endCue = (*m_pSegmentsCues)[m_currentSegmentState.m_index][lastCueIndex];
				}

				UpdateSegmentsStates();
			}
				
			if(m_currentSegmentState.m_playbackState == NATIVE_STATE_PLAYING)
			{
				// If still looping, seek to start cue
				if(m_currentSegmentState.m_nbLoopsRemaining != 0)
				{
					Seek(-1, &m_currentSegmentState);
				}
			}
			else if(m_currentSegmentState.m_playbackState == NATIVE_STATE_STOPPING)
			{
				if(m_currentSegmentState.m_totalSamplesDecoded > m_currentSegmentState.m_endCue)
				{
					m_currentSegmentState.m_playbackState = NATIVE_STATE_STOPPED;
					break;
				}	
			}
		}
	}

	return (nbSamplesDesired - nbSamples)*(nbChannels * (m_audioFormat.m_bitsPerSample >> 3));
}


s32 VoxNativeSubDecoderMSADPCM::EmulateDecodeSegment(s32 nbBytes, SegmentState *pSegmentState)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderMSADPCM::EmulateDecodeSegment", vox::VoxThread::GetCurThreadId());

	s16 nbChannels = m_audioFormat.m_nbChannels;
	s32 nbSamplesDesired = nbBytes / (nbChannels * (m_audioFormat.m_bitsPerSample >> 3));
	s32 nbSamples = nbSamplesDesired;
	s32 bufferoffset;
	s32 nbSamplesAvailable;
	s32 nbSamplesLeftInLoop;
	s32 nbSamplesToCopy;
	
	// Determine which decodeBuffer has to be used.
	s32 bufferIndex = pSegmentState->m_adpcmBufferIndex;

	while(nbSamples > 0)
	{
		// Set decoding buffer to position specified by segment's total nb of samples decoded.
		if(pSegmentState->m_setAdpcmBufferCursor)
		{
			EmulateSetDecodingBufferToSegmentPosition(pSegmentState);
			pSegmentState->m_setAdpcmBufferCursor = false;
		}

		// Get a new decoded block if all samples have been consumed.
		if(m_samplesInBufferConsumed[bufferIndex] == m_samplesInBuffer[bufferIndex])
		{
			m_samplesInBuffer[bufferIndex] = EmulateDecodeBlock(pSegmentState);
			m_samplesInBufferConsumed[bufferIndex] = 0;
		}

		if(!m_samplesInBuffer[bufferIndex]) // Not end of data, but could not read anything
		{
			pSegmentState->m_playbackState = NATIVE_STATE_STOPPED;
			break;
		}

		// Set write offset in output buffer.
		bufferoffset = (nbSamplesDesired - nbSamples) * nbChannels;

		// Calculate the number of samples available in the current decoded block.
		nbSamplesAvailable = m_samplesInBuffer[bufferIndex] - m_samplesInBufferConsumed[bufferIndex];

		// Calculate nb of samples left in current loop
		nbSamplesLeftInLoop = pSegmentState->m_endCue - pSegmentState->m_totalSamplesDecoded + 1;

		// Find min between nb of samples left in block and nb of samples left in loop
		nbSamplesAvailable = nbSamplesAvailable < nbSamplesLeftInLoop ? nbSamplesAvailable : nbSamplesLeftInLoop;

		// Calculate the number of samples to copy from the decoded block to the output buffer.
		nbSamplesToCopy = (nbSamplesAvailable > nbSamples) ? nbSamples : nbSamplesAvailable;

		nbSamples -= nbSamplesToCopy;
		m_samplesInBufferConsumed[bufferIndex] += nbSamplesToCopy;
		pSegmentState->m_totalSamplesDecoded += nbSamplesToCopy;

		if(pSegmentState->m_totalSamplesDecoded > pSegmentState->m_endCue)
		{
			// If looping and first loop is completed, reset start cue at pre-entry cue.
			if((pSegmentState->m_nbLoops >> 1 != 0) &&
			    pSegmentState->m_nbLoopsRemaining == pSegmentState->m_nbLoops)
			{
				pSegmentState->m_startCue = (*m_pSegmentsCues)[pSegmentState->m_index][NATIVE_CUE_PRE_ENTRY];
			}
			pSegmentState->m_nbLoopsRemaining--;

			// If finished looping and post-exit should be played, set end cue to segment end.
			if(pSegmentState->m_nbLoopsRemaining == 0)
			{
				// If post-exit should be played, set end cue to segment end.
				if(pSegmentState->m_playPostExit == 1)
				{
					s32 lastCueIndex = (*m_pSegmentsCues)[pSegmentState->m_index].size() - 1;
					pSegmentState->m_endCue = (*m_pSegmentsCues)[pSegmentState->m_index][lastCueIndex];
				}
				
				if(pSegmentState->m_lifeState == k_nSegmentCurrent)
				{
					UpdateSegmentsStates();
				}
			}

			if(pSegmentState->m_playbackState == NATIVE_STATE_PLAYING)
			{
				// If still looping, seek to start cue
				if(pSegmentState->m_nbLoopsRemaining != 0)
				{
					Seek(-1, pSegmentState);
				}
			}
			else if(pSegmentState->m_playbackState == NATIVE_STATE_STOPPING)
			{
				if(pSegmentState->m_totalSamplesDecoded > pSegmentState->m_endCue)
				{
					pSegmentState->m_playbackState = NATIVE_STATE_STOPPED;
					break;
				}	
			}
		}
	}

	// If dying segment, stop it (only allowed to do one decode pass).
	if(pSegmentState->m_lifeState == k_nSegmentDying)
	{
		pSegmentState->m_playbackState = NATIVE_STATE_STOPPED;
	}

	return (nbSamplesDesired - nbSamples)*(nbChannels * (m_audioFormat.m_bitsPerSample >> 3));
}


void VoxNativeSubDecoderMSADPCM::EmulateSetDecodingBufferToSegmentPosition(SegmentState *pSegmentState)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderMSADPCM::EmulateSetDecodingBufferToSegmentPosition", vox::VoxThread::GetCurThreadId());

	s32 bufferIndex = pSegmentState->m_adpcmBufferIndex;
	u32 totalSamplesDecoded = pSegmentState->m_totalSamplesDecoded;

	// Set the total nb of samples decoded to coincide with the current block not being decoded.
	pSegmentState->m_totalSamplesDecoded = (pSegmentState->m_totalSamplesDecoded / m_pFmtExtendedInfos->m_samplesPerBlock) * m_pFmtExtendedInfos->m_samplesPerBlock;

	// Decode current block.
	m_samplesInBuffer[bufferIndex] = EmulateDecodeBlock(pSegmentState);

	// Set the sample position in the current decoded block according to total nb of samples decoded.
	m_samplesInBufferConsumed[bufferIndex] = totalSamplesDecoded - pSegmentState->m_totalSamplesDecoded;

	// Put back the total nb of samples decoded to the value it was when entering the method.
	pSegmentState->m_totalSamplesDecoded = totalSamplesDecoded;
}


void VoxNativeSubDecoderMSADPCM::GetState(NativeSubDecoderMSADPCMState *pState)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderMSADPCM::GetState", vox::VoxThread::GetCurThreadId());

	VoxNativeSubDecoder::GetState(pState);

	// Get the availability state of decode buffers. Note that the nb of samples in buffers
	// need not be saved since buffers will be redecoded after rewinding to this state.
	pState->m_decodeBuffersState[0] = m_decodeBuffersState[0];
	pState->m_decodeBuffersState[1] = m_decodeBuffersState[1];
	pState->m_decodeBuffersState[2] = m_decodeBuffersState[2];
}


void VoxNativeSubDecoderMSADPCM::SetState(NativeSubDecoderMSADPCMState *pState)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderMSADPCM::SetState", vox::VoxThread::GetCurThreadId());

	VoxNativeSubDecoder::SetState(pState);

	// Set the availability state of decode buffers. There is no need to obtain the nb of samples
	// in buffers since blocks will be redecoded after rewinding to the subdecoder's state.
	m_decodeBuffersState[0] = pState->m_decodeBuffersState[0];
	m_decodeBuffersState[1] = pState->m_decodeBuffersState[1];
	m_decodeBuffersState[2] = pState->m_decodeBuffersState[2];

	// Set decode buffers to be decoded at the rewinded position of each segment
	if(m_dyingSegmentState.m_playbackState == NATIVE_STATE_PLAYING)
	{
		m_dyingSegmentState.m_setAdpcmBufferCursor = true;
	}
	if(m_oldSegmentState.m_playbackState == NATIVE_STATE_PLAYING)
	{
		m_oldSegmentState.m_setAdpcmBufferCursor = true;
	}
	if(m_currentSegmentState.m_playbackState == NATIVE_STATE_PLAYING)
	{
		m_currentSegmentState.m_setAdpcmBufferCursor = true;
	}
}

#endif // VOX_NATIVE_REDUCE_LATENCY

u32 VoxNativeSubDecoderMSADPCM::GetBytePositionFromSampleOffset(u32 sampleOffset)
{
	// Provide the byte position of start of block containing sample located at sampleOffset.
	return (sampleOffset / m_pFmtExtendedInfos->m_samplesPerBlock * m_audioFormat.m_blockAlign);
}



s32 VoxNativeSubDecoderMSADPCM::GetDecodingBuffer(void)
{
	if(m_decodeBuffersState[0] == BUFFER_AVAILABLE)
	{
		m_decodeBuffersState[0] = BUFFER_UNAVAILABLE;
		return 0;
	}
	else if(m_decodeBuffersState[1] == BUFFER_AVAILABLE)
	{
		m_decodeBuffersState[1] = BUFFER_UNAVAILABLE;
		return 1;
	}
	else if(m_decodeBuffersState[2] == BUFFER_AVAILABLE)
	{
		m_decodeBuffersState[2] = BUFFER_UNAVAILABLE;
		return 2;
	}

	return -1;
}


void VoxNativeSubDecoderMSADPCM::ReleaseDecodingBuffer(s32 bufferIndex)
{
	if(bufferIndex >= 0)
	{
		m_decodeBuffersState[bufferIndex] = BUFFER_AVAILABLE;
		m_samplesInBuffer[bufferIndex] = 0;
		m_samplesInBufferConsumed[bufferIndex] = 0;
	}
}


void VoxNativeSubDecoderMSADPCM::Reset(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderMSADPCM::Reset", vox::VoxThread::GetCurThreadId());

	m_samplesInBuffer[0] = 0;
	m_samplesInBuffer[1] = 0;
	m_samplesInBuffer[2] = 0;
	m_samplesInBufferConsumed[0] = 0;
	m_samplesInBufferConsumed[1] = 0;
	m_samplesInBufferConsumed[2] = 0;
	m_decodeBuffersState[0] = BUFFER_AVAILABLE;
	m_decodeBuffersState[1] = BUFFER_AVAILABLE;
	m_decodeBuffersState[2] = BUFFER_AVAILABLE;

	VoxNativeSubDecoder::Reset();
}


s32 VoxNativeSubDecoderMSADPCM::Seek(s32 samplePosition, SegmentState *pSegmentState)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderMSADPCM::Seek", vox::VoxThread::GetCurThreadId());

	u32 segmentNbSamples = m_pAudioSegments->m_pBuffer[pSegmentState->m_index].m_nbSamples;
	s32 bufferIndex = pSegmentState->m_adpcmBufferIndex;
	
	// If position is not specified, seek to segment's state loop start.
	if(samplePosition < 0)
	{
		samplePosition = pSegmentState->m_startCue;
	}

	if(samplePosition > (s32) segmentNbSamples)
	{
		VOX_WARNING_LEVEL_4("%s", "Decoder seek failed : position is outside stream");
		return -1;
	}
	else
	{		
		u32 blockIndex = samplePosition / m_pFmtExtendedInfos->m_samplesPerBlock;

		// Consider all blocks preceding the one containing the requested sample as read.
		pSegmentState->m_position = blockIndex * m_audioFormat.m_blockAlign;

		// Find start position of segment (relative to beginning of file)
		u32 segmentStartOffset = m_pAudioSegments->m_pBuffer[pSegmentState->m_index].m_start;
		u32 segmentStart = m_dataStart + segmentStartOffset;

		// Seek to start of block containing requested sample.
		s32 seekResult = m_pStreamCursor->Seek(segmentStart + pSegmentState->m_position);
	
		if(!seekResult) // Seek has succeeded
		{
			u32 nbSamplesInPrecedingBlocks = blockIndex * m_pFmtExtendedInfos->m_samplesPerBlock;

			// Consider all samples before the one requested as consumed.
			m_samplesInBufferConsumed[bufferIndex] = samplePosition - nbSamplesInPrecedingBlocks;

			// Set all samples before the one requested as decoded (this line must be before call to decode)
			pSegmentState->m_totalSamplesDecoded = nbSamplesInPrecedingBlocks + m_samplesInBufferConsumed[bufferIndex];

			// Decode the whole block containing the requested sample.
			m_samplesInBuffer[bufferIndex] = DecodeBlock((void*) m_pDecodeBuffers[bufferIndex], pSegmentState);
		}

		return seekResult;
	}
	return -1;
}


void VoxNativeSubDecoderMSADPCM::SetDecodingBufferToSegmentPosition(SegmentState *pSegmentState)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "VoxNativeSubDecoderMSADPCM::SetDecodingBufferToSegmentPosition", vox::VoxThread::GetCurThreadId());

	s32 bufferIndex = pSegmentState->m_adpcmBufferIndex;
	u32 totalSamplesDecoded = pSegmentState->m_totalSamplesDecoded;

	// Set the total nb of samples decoded to coincide with the current block not being decoded.
	pSegmentState->m_totalSamplesDecoded = (pSegmentState->m_totalSamplesDecoded / m_pFmtExtendedInfos->m_samplesPerBlock) * m_pFmtExtendedInfos->m_samplesPerBlock;

	// Get the position of the block containing the next sample to be decoded
	pSegmentState->m_position = (pSegmentState->m_totalSamplesDecoded / m_pFmtExtendedInfos->m_samplesPerBlock) * m_audioFormat.m_blockAlign;

	// Decode current block.
	m_samplesInBuffer[bufferIndex] = DecodeBlock((void*)m_pDecodeBuffers[bufferIndex], pSegmentState);

	// Set the sample position in the current decoded block according to total nb of samples decoded.
	m_samplesInBufferConsumed[bufferIndex] = totalSamplesDecoded - pSegmentState->m_totalSamplesDecoded;

	// Put back the total nb of samples decoded to the value it was when entering the method.
	pSegmentState->m_totalSamplesDecoded = totalSamplesDecoded;
}


} // End namespace vox
