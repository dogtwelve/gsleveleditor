//
//  vox_iPod_controller.mm
//  iSimple
//
//  Created by alexandre.belanger@gameloft.com on 9/25/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "vox_iPod_controller.h"
#import <MediaPlayer/MediaPlayer.h>
#import "vox_ipod_notification_handler.h"
#include "vox_macro.h"
#include "vox_thread.h"

@implementation VoxDummyNSThreadClass

-(void) dummy
{
}

@end

#include <sys/time.h>

namespace vox
{

inline vox::f64 _GetCurTime()
{
	struct timeval	tp;
	vox::f64 sec, usec;
	gettimeofday(&tp, 0);
	sec = tp.tv_sec;
	usec = tp.tv_usec;
	return (sec + usec/1000000);
}
	
static VoxiPodNotificationHandler* s_iPodStateNotificationHandler = 0;
static VoxiPodController* s_iPodControllerInstance = 0;
	
VoxiPodController* VoxiPodController::GetiPodController()
{
	if(!s_iPodControllerInstance)
	{
		s_iPodControllerInstance = VOX_NEW VoxiPodController();
	}
	
	return s_iPodControllerInstance;
}
	
void VoxiPodController::DestroyiPodController()
{
	if(s_iPodControllerInstance)
	{
		VOX_DELETE (s_iPodControllerInstance);
		s_iPodControllerInstance = 0;
	}	
}
	
VoxiPodController::VoxiPodController() //**-**
{
	m_nowPlayingItem = nil;
	m_nowPlayingItemPosition = 0.f;
	m_iPodState = VoxIpodState::k_nOther;
	m_isNowPlayingItemValid = false;
	m_isNowPlayingItemUpdating = false;
	m_isStateValid = false;
	m_isStateUpdating = false;
	m_isIpodQueryPending = false;
	m_commandThread = 0;
	m_externalLibraryCallback = 0;
	m_playlists = nil;
	m_artists = nil;
	m_albums = nil;
	m_songs = nil;
	m_isQueryEnabled = true;
	m_isPollingIpod = false;
	m_nextPoll = 0.0;
	m_lastPollState = -1;
	m_lastPollItem = 0;
	m_isSuspended = false;
	
	mpc = NSClassFromString(@"MPMusicPlayerController");
	
	//Test if Cocoa is in multi-threaded mode
	if([NSThread isMultiThreaded] == NO)
	{
		VOX_WARNING_LEVEL_2("Cocoa not in multithreaded mode, trying to force",0);
		VoxDummyNSThreadClass* dummyThreadClass = [VoxDummyNSThreadClass alloc];
		[NSThread detachNewThreadSelector:@selector(dummy) toTarget:dummyThreadClass withObject:nil];
		[dummyThreadClass release];
	}
}

VoxiPodController::~VoxiPodController() //**-**
{
	if(m_commandThread)
		VOX_DELETE(m_commandThread);
	
	if(s_iPodStateNotificationHandler)
	{
		[s_iPodStateNotificationHandler release];
		s_iPodStateNotificationHandler = 0;
	}

#if VOX_IPOD_QUERY_ASYNC	
	Suspend();
#else
	VoxiPodController *vic = GetiPodController();
	// Release playlist
	if(vic->m_playlists != nil)
	{
		[vic->m_playlists release];
		vic->m_playlists = nil;
	}
	
	// Release artists
	if(vic->m_artists != nil)
	{
		[vic->m_artists release];
		vic->m_artists = nil;
	}
	
	// Release albums
	if(vic->m_albums != nil)
	{
		[vic->m_albums release];
		vic->m_albums = nil;
	}
	
	// Release songs
	if(vic->m_songs != nil)
	{
		[vic->m_songs release];
		vic->m_songs = nil;
	}
#endif
}

void VoxiPodController::Init(iPodPlayerStateChangedCallback stateCallback, iPodPlayerNowPlayingChangedCallback songCallback, iPodLibraryChangedCallback libraryCallback) //**-**
{
	if(mpc)
	{
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer]; //This line initialize iPodMusicPlayer to take control of the iPod player
		VOX_ASSERT_MSG(m_player, "Could not get iPod Music PLayer instance");
		
#if VOX_IPOD_QUERY_ASYNC		
		m_commandThread = VOX_NEW VoxThread(&vox::VoxiPodController::ThreadRoutine, this, 0);
#endif		

		s_iPodStateNotificationHandler = [VoxiPodNotificationHandler alloc];
		if(s_iPodStateNotificationHandler)
		{
			m_externalLibraryCallback = libraryCallback;
			[s_iPodStateNotificationHandler initHandler];
#if VOX_IPOD_QUERY_ASYNC
			m_externalStateCallback = stateCallback;
			m_externalSongCallback = songCallback;

			[s_iPodStateNotificationHandler setStateCallback:&VoxiPodController::_StateChangedHandler];
			[s_iPodStateNotificationHandler setSongCallback:&VoxiPodController::_SongChangedHandler];
			[s_iPodStateNotificationHandler setLibraryCallback:&VoxiPodController::_LibraryChangedHandler];
#else
			[s_iPodStateNotificationHandler setStateCallback:stateCallback];
			[s_iPodStateNotificationHandler setSongCallback:songCallback];
			[s_iPodStateNotificationHandler setLibraryCallback:&VoxiPodController::LibraryChangeHandler];
#endif
		}
	}	
}

void VoxiPodController::DropQuery()
{ 
	VOX_WARNING_LEVEL_5("%s", __FUNCTION__);
	if(m_iPodQuery.m_isRunning) 
		m_iPodQuery.m_dropResult = true;
	
	if(m_playlists != nil)
		[m_playlists release];
	m_playlists = nil;
	
	if(m_artists != nil)
		[m_artists release];
	m_artists = nil;
	
	if(m_albums != nil)
		[m_albums release];
	m_albums = nil;
	
	if(m_songs != nil)
		[m_songs release];
	m_songs = nil;
}	
	
void VoxiPodController::Suspend()
{
	VOX_WARNING_LEVEL_5("%s", __FUNCTION__);
	
	m_isSuspended = true;
	
	m_commandQueueMutex.Lock();
	m_commandQueue.clear();
	m_commandQueueMutex.Unlock();
	
	if(m_iPodQuery.m_isRunning) 
		m_iPodQuery.m_dropResult = true;	
	
	m_queryMutex.Lock();
	
	if(m_playlists != nil)
		[m_playlists release];
	m_playlists = nil;
	
	if(m_artists != nil)
		[m_artists release];
	m_artists = nil;
	
	if(m_albums != nil)
		[m_albums release];
	m_albums = nil;
	
	if(m_songs != nil)
		[m_songs release];
	m_songs = nil;
	
	m_queryMutex.Unlock();
	
	m_isNowPlayingItemValid = false;
	m_isStateValid = false;
}

void VoxiPodController::Resume()
{
	VOX_WARNING_LEVEL_5("%s", __FUNCTION__);
	
	m_isSuspended = false;
	
	QueueCommand(k_nVoxIpodControllerCommandProcessSongChanged, 0, true);
	QueueCommand(k_nVoxIpodControllerCommandProcessStateChanged, 0, true);
}
	
void VoxiPodController::Play()
{
#if VOX_IPOD_QUERY_ASYNC
    QueueCommand(k_nVoxIpodControllerCommandPlay);
#else
	_Play();
#endif
}

void VoxiPodController::_Play()
{
	if(mpc)
	{
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		if(m_player)
		{
			[m_player play];
		}
	}
}

void VoxiPodController::Pause()
{
#if VOX_IPOD_QUERY_ASYNC
    QueueCommand(k_nVoxIpodControllerCommandPause);
#else
	_Pause();
#endif	
}

void VoxiPodController::_Pause()
{
	if(mpc)
	{
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		if(m_player)
		{
			[m_player pause];
		}
	}
}
	
void VoxiPodController::Stop()
{
#if VOX_IPOD_QUERY_ASYNC
    QueueCommand(k_nVoxIpodControllerCommandStop);
#else
	_Stop();
#endif    
}

void VoxiPodController::_Stop()
{
	if(mpc)
	{
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		if(m_player)
		{
			[m_player stop];
		}
	}   
}

void VoxiPodController::Next()
{
#if VOX_IPOD_QUERY_ASYNC
    QueueCommand(k_nVoxIpodControllerCommandNext);
#else
	_Next();
#endif 
}

void VoxiPodController::_Next()
{
	if(mpc)
	{
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		if(m_player)
		{
			[m_player skipToNextItem];
		}
	}
}

void VoxiPodController::Previous()
{
#if VOX_IPOD_QUERY_ASYNC
    QueueCommand(k_nVoxIpodControllerCommandPrevious);
#else
	_Previous();
#endif     
}

void VoxiPodController::_Previous()
{
	if(mpc)
	{
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		if(m_player)
		{
			[m_player skipToPreviousItem];
		}
	}    
}

void VoxiPodController::SetShuffleMode(s32 shuffleMode)
{
#if VOX_IPOD_QUERY_ASYNC
    QueueCommand(k_nVoxIpodControllerCommandSetShuffleMode);
#else
	_SetShuffleMode(shuffleMode);
#endif
}

void VoxiPodController::_SetShuffleMode(s32 shuffleMode)
{
	if(mpc)
	{
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		if(m_player)
		{
			switch(shuffleMode)
			{
				case VoxIpodShuffleMode::k_nDefault:
				{
					[m_player setShuffleMode:MPMusicShuffleModeDefault];
					break;
				}
				case VoxIpodShuffleMode::k_nOff:
				{
					[m_player setShuffleMode:MPMusicShuffleModeOff];
					break;
				}
				case VoxIpodShuffleMode::k_nSongs:
				{
					[m_player setShuffleMode:MPMusicShuffleModeSongs];
					break;
				}
				case VoxIpodShuffleMode::k_nAlbums:
				{
					[m_player setShuffleMode:MPMusicShuffleModeAlbums];
					break;
				}
			}				
		}
	}
}

void VoxiPodController::SetRepeatMode(s32 repeatMode)
{
#if VOX_IPOD_QUERY_ASYNC
    QueueCommand(k_nVoxIpodControllerCommandSetRepeatMode, repeatMode);
#else
	_SetRepeatMode(repeatMode);
#endif
}	

void VoxiPodController::_SetRepeatMode(s32 repeatMode)
{
	if(mpc)
	{
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		if(m_player)
		{
			switch(repeatMode)
			{
				case VoxIpodRepeatMode::k_nDefault:
				{
					[m_player setRepeatMode:MPMusicRepeatModeDefault];
					break;
				}
				case VoxIpodRepeatMode::k_nNone:
				{
					[m_player setRepeatMode:MPMusicRepeatModeNone];
					break;
				}
				case VoxIpodRepeatMode::k_nOne:
				{
					[m_player setRepeatMode:MPMusicRepeatModeOne];
					break;
				}
				case VoxIpodRepeatMode::k_nAll:
				{
					[m_player setRepeatMode:MPMusicRepeatModeAll];
					break;
				}
			}				
		}
	}
}	
	
void VoxiPodController::LibraryChangeHandler() //**-**
{
	NSLog(@"Dammit, user synced his device !!!");
	VoxiPodController *vic = GetiPodController();

	if(vic->m_iPodQuery.m_isRunning)
	{
		//test os ?
		//Disable all query if sync happen during query
		//vic->m_isQueryEnabled = false;
		
		vic->m_iPodQuery.m_dropResult = true;
	}
	
	// Reset playlist
	if(vic->m_playlists != nil)
	{
		[vic->m_playlists release];
		vic->m_playlists = nil;
	}

	// Reset artists
	if(vic->m_artists != nil)
	{
		[vic->m_artists release];
		vic->m_artists = nil;
	}
	
	// Reset albums
	if(vic->m_albums != nil)
	{
		[vic->m_albums release];
		vic->m_albums = nil;
	}
	
	// Reset songs
	if(vic->m_songs != nil)
	{
		[vic->m_songs release];
		vic->m_songs = nil;
	}
	
	if(vic->m_externalLibraryCallback) //mutex?
		vic->m_externalLibraryCallback();
}

s32 VoxiPodController::GetPlaylistCount()
{
#if VOX_IPOD_QUERY_ASYNC	
	if (m_isIpodQueryPending || m_iPodQuery.m_isRunning)
		return VoxIpodQueryState::k_nQueryRunning;

	ScopeMutex sm(&m_queryMutex);

	if(m_playlists == nil)
	{
		_GetPlaylists();
		//if (m_isIpodQueryPending || m_iPodQuery.m_isRunning)
			return VoxIpodQueryState::k_nQueryRunning;
	}

	//if(m_playlists != nil)
	else
	{
		s32 count = [m_playlists count];
		if(count == 0)
		{
			[m_playlists release];
			m_playlists = nil;
		}
		
		return count;
	}
#else
	if(m_playlists == nil)
	{
		_GetPlaylists();
	}

	if(m_playlists != nil)
	{
		return [m_playlists count];
	}
#endif
	
	return 0;
}
	

std::string VoxiPodController::GetPlaylistName(s32 playlistIndex)
{
#if VOX_IPOD_QUERY_ASYNC	
	if (m_isIpodQueryPending || m_iPodQuery.m_isRunning)
		return std::string("");
	ScopeMutex sm(&m_queryMutex);
#endif

	if(m_playlists == nil)
	{
		return std::string("");
	}
	
	s32 count = [m_playlists count];
	if(count <= playlistIndex || playlistIndex < 0)
	{
		return std::string("");
	}
	
	MPMediaPlaylist *playlist = [m_playlists objectAtIndex:playlistIndex];
	if(playlist)
	{
		NSString* nsname = [playlist valueForProperty: MPMediaPlaylistPropertyName];
		if(nsname)
		{
			const char* tempName = [nsname UTF8String];
			if(tempName)
				return std::string(tempName); 
		}
	}
	
	return std::string("");
}
	
void VoxiPodController::SetPlaylist(s32 playlistIndex)
{
#if VOX_IPOD_QUERY_ASYNC
    QueueCommand(k_nVoxIpodControllerCommandSetPlaylist, playlistIndex);
#else
	_SetPlaylist(playlistIndex);
#endif
}
    
void VoxiPodController::_SetPlaylist(s32 playlistIndex)
{
	MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];

	if(m_playlists == nil || m_player == nil)
	{
		return;
	}
	
	s32 count = [m_playlists count];
	if(count <= playlistIndex)
	{
		return;
	}
	
	if(playlistIndex < 0)
	{
		VOX_WARNING_LEVEL_5("Setting whole library as playlist",0);
		MPMediaQuery* songQuery = [MPMediaQuery songsQuery];
		if(songQuery)
		{
			[m_player setQueueWithQuery:songQuery];
		}
	}
	else
	{
		VOX_WARNING_LEVEL_5("Setting playlist %d as current", playlistIndex);
		MPMediaPlaylist *playlist = [m_playlists objectAtIndex:playlistIndex];
		
		if(playlist)
		{
			[m_player setQueueWithItemCollection:playlist];
		}	
	}
}
	
void VoxiPodController::_GetPlaylists()
{
#if VOX_IPOD_QUERY_ASYNC
	if(m_playlists != nil)
	{
		[m_playlists release];
		m_playlists = nil;
	}

	m_isIpodQueryPending = true;
	QueueCommand(k_nVoxIpodControllerCommandPlaylistQuery);

	//m_iPodQuery.GetPlaylists(&m_playlists);	
#else
	MPMediaQuery *myPlaylistsQuery = [MPMediaQuery playlistsQuery];
	if(m_playlists != nil)
	{
		[m_playlists release];
	}
	m_playlists = [myPlaylistsQuery collections];
	if(m_playlists)
		[m_playlists retain];	
#endif
}


s32 VoxiPodController::GetArtistCount()
{
#if VOX_IPOD_QUERY_ASYNC	
	if (m_isIpodQueryPending || m_iPodQuery.m_isRunning)
		return VoxIpodQueryState::k_nQueryRunning;

	ScopeMutex sm(&m_queryMutex);

	if(m_artists == nil)
	{
		_GetArtists();
		//if (m_isIpodQueryPending || m_iPodQuery.m_isRunning)
			return VoxIpodQueryState::k_nQueryRunning;
	}

	if(m_artists != nil)
	{
		s32 count = [m_artists count];
		if(count == 0)
		{
			[m_artists release];
			m_artists = nil;
		}
		
		return count;
	}
#else
	if(m_artists == nil)
	{
		_GetArtists();
	}

	if(m_artists != nil)
	{
		return [m_artists count];
	}
#endif
	
	return 0;
}
	
std::string VoxiPodController::GetArtistName(s32 artistIndex)
{
#if VOX_IPOD_QUERY_ASYNC	
	if (m_isIpodQueryPending || m_iPodQuery.m_isRunning)
		return std::string("");
	ScopeMutex sm(&m_queryMutex);
#endif

	if(m_artists == nil)
	{
		return std::string("");
	}
	
	s32 count = [m_artists count];
	if(count <= artistIndex || artistIndex < 0)
	{
		return std::string("");
	}
	
	MPMediaItemCollection *artist = [m_artists objectAtIndex:artistIndex];
	if(artist)
	{
		MPMediaItem *representativeItem = [artist representativeItem];
		NSString* nsname = [representativeItem valueForProperty: MPMediaItemPropertyArtist];
		if(nsname)
		{
			const char* tempName = [nsname UTF8String];
			if(tempName)
				return std::string(tempName); 
		}
	}
	
	return std::string("");
}
	
void VoxiPodController::SetArtist(s32 artistIndex)
{
#if VOX_IPOD_QUERY_ASYNC
    QueueCommand(k_nVoxIpodControllerCommandSetArtist, artistIndex);
#else
	_SetArtist(artistIndex);
#endif
}	
    
void VoxiPodController::_SetArtist(s32 artistIndex)
{	
	MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
	
	if(m_artists == nil || m_player == nil)
	{
		return;
	}
	
	s32 count = [m_artists count];
	if(count <= artistIndex)
	{
		return;
	}

	if(artistIndex >= 0)
	{
		VOX_WARNING_LEVEL_5("Setting artist %d as current", artistIndex);
		MPMediaItemCollection *artist = [m_artists objectAtIndex:artistIndex];
		
		if(artist)
		{
			NSArray *songs = [artist items];
			if(songs)
			{
				// NOTE : The creation of 'artistCollection' from 'artist' is a work-around so that all sounds from the query could
				//        be queued for playback. When using 'artist', only one sound would be inserted in the queue.
				MPMediaItemCollection *artistCollection = [MPMediaItemCollection collectionWithItems: songs];
				
				if(artistCollection)
				{
					[m_player setQueueWithItemCollection:artistCollection];
				}
			}
		}
	}
	else
	{
		VOX_WARNING_LEVEL_2("Artist indexes lower than 0 are not supported. Call SetPlaylist(-1) to enqueue all songs for playback", 0);
	}
}
	
	
void VoxiPodController::_GetArtists()
{
#if VOX_IPOD_QUERY_ASYNC
	if(m_artists != nil)
	{
		[m_artists release];
		m_artists = nil;
	}
	
	m_isIpodQueryPending = true;
	QueueCommand(k_nVoxIpodControllerCommandArtistQuery);

	//m_iPodQuery.GetArtists(&m_artists);	
#else
	MPMediaQuery *myArtistsQuery = [MPMediaQuery artistsQuery];
	if(m_artists != nil)
	{
		[m_artists release];
	}
	m_artists = [myArtistsQuery collections];
	if(m_artists)
		[m_artists retain];
#endif	
}
	
	
s32 VoxiPodController::GetAlbumCount()
{
#if VOX_IPOD_QUERY_ASYNC	
	if (m_isIpodQueryPending || m_iPodQuery.m_isRunning)
		return VoxIpodQueryState::k_nQueryRunning;

	ScopeMutex sm(&m_queryMutex);

	if(m_albums == nil)
	{
		_GetAlbums();
		//if (m_isIpodQueryPending || m_iPodQuery.m_isRunning)
			return VoxIpodQueryState::k_nQueryRunning;
	}

	if(m_albums != nil)
	{
		s32 count = [m_albums count];
		if(count == 0)
		{
			[m_albums release];
			m_albums = nil;
		}
		
		return count;
	}
#else
	if(m_albums == nil)
	{
		_GetAlbums();
	}

	if(m_albums != nil)
	{
		return [m_albums count];
	}
#endif
	
	return 0;
}
	
	
std::string VoxiPodController::GetAlbumName(s32 albumIndex)
{
#if VOX_IPOD_QUERY_ASYNC	
	if (m_isIpodQueryPending || m_iPodQuery.m_isRunning)
		return std::string("");
	ScopeMutex sm(&m_queryMutex);
#endif

	if(m_albums == nil)
	{
		return std::string("");
	}
		
	s32 count = [m_albums count];
	if(count <= albumIndex || albumIndex < 0)
	{
		return std::string("");
	}
	
	MPMediaItemCollection *album = [m_albums objectAtIndex:albumIndex];
	if(album)
	{
		MPMediaItem *representativeItem = [album representativeItem];
		NSString* nsname = [representativeItem valueForProperty: MPMediaItemPropertyAlbumTitle];
		if(nsname)
		{
			const char* tempName = [nsname UTF8String];
			if(tempName)
				return std::string(tempName); 
		}
	}
		
	return std::string("");
}
	
void VoxiPodController::SetAlbum(s32 albumIndex)
{
#if VOX_IPOD_QUERY_ASYNC
    QueueCommand(k_nVoxIpodControllerCommandSetAlbum, albumIndex);
#else
	_SetAlbum(albumIndex);
#endif
}
	
void VoxiPodController::_SetAlbum(s32 albumIndex)
{	
	MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		
	if(m_albums == nil || m_player == nil)
	{
		return;
	}
		
	s32 count = [m_albums count];
	if(count <= albumIndex)
	{
		return;
	}
		
	if(albumIndex >= 0)
	{
		VOX_WARNING_LEVEL_5("Setting album %d as current", albumIndex);
		MPMediaItemCollection *album = [m_albums objectAtIndex:albumIndex];
				
		if(album)
		{
			NSArray *songs = [album items];
			if(songs)
			{
				// NOTE : The creation of 'albumCollection' from 'album' is a work-around so that all sounds from the query could
				//        be queued for playback. When using 'album', only one sound would be inserted in the queue.
				MPMediaItemCollection *albumCollection = [MPMediaItemCollection collectionWithItems: songs];
				
				if(albumCollection)
				{
					[m_player setQueueWithItemCollection:albumCollection];
				}
			}
		}
	}
	else
	{
		VOX_WARNING_LEVEL_2("Album indexes lower than 0 are not supported. Call SetPlaylist(-1) to enqueue all songs for playback", 0);
	}
}
	
	
void VoxiPodController::_GetAlbums()
{
#if VOX_IPOD_QUERY_ASYNC
	if(m_albums != nil)
	{
		[m_albums release];
		m_albums = nil;
	}
	
	m_isIpodQueryPending = true;
	QueueCommand(k_nVoxIpodControllerCommandAlbumQuery);

	//m_iPodQuery.GetAlbums(&m_albums);	
#else
	MPMediaQuery *myAlbumsQuery = [MPMediaQuery albumsQuery];
	
	if(m_albums != nil)
	{
		[m_albums release];
	}
	m_albums = myAlbumsQuery.collections;
	if(m_albums)
		[m_albums retain];
#endif	
}	
	
	
s32 VoxiPodController::GetSongCount()
{
#if VOX_IPOD_QUERY_ASYNC	
	if (m_isIpodQueryPending || m_iPodQuery.m_isRunning)
		return VoxIpodQueryState::k_nQueryRunning;

	ScopeMutex sm(&m_queryMutex);

	if(m_songs == nil)
	{
		_GetSongs();
		//if (m_isIpodQueryPending || m_iPodQuery.m_isRunning)
			return VoxIpodQueryState::k_nQueryRunning;
	}

	if(m_songs != nil)
	{
		s32 count = [m_songs count];
		if(count == 0)
		{
			[m_songs release];
			m_songs = nil;
		}
		
		return count;
	}
#else
	if(m_songs == nil)
	{
		_GetSongs();
	}

	if(m_songs != nil)
	{
		return [m_songs count];
	}
#endif
	
	return 0;
}
	
	
std::string VoxiPodController::GetSongName(s32 songIndex)
{
#if VOX_IPOD_QUERY_ASYNC	
	if (m_isIpodQueryPending || m_iPodQuery.m_isRunning)
		return std::string("");
	ScopeMutex sm(&m_queryMutex);
#endif

	if(m_songs == nil)
	{
		return std::string("");
	}
		
	s32 count = [m_songs count];
	if(count <= songIndex || songIndex < 0)
	{
		return std::string("");
	}
		
	MPMediaItemCollection *song = [m_songs objectAtIndex:songIndex];
	if(song)
	{
		MPMediaItem *representativeItem = [song representativeItem];
		NSString* nsname = [representativeItem valueForProperty: MPMediaItemPropertyTitle];
		if(nsname)
		{
			const char* tempName = [nsname UTF8String];
			if(tempName)
				return std::string(tempName); 
		}
	}
		
	return std::string("");
}

void VoxiPodController::SetSong(s32 songIndex)
{
#if VOX_IPOD_QUERY_ASYNC
    QueueCommand(k_nVoxIpodControllerCommandSetSong, songIndex);
#else
	_SetSong(songIndex);
#endif
}
	
void VoxiPodController::_SetSong(s32 songIndex)
{
	MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
	
	if(m_songs == nil || m_player == nil)
	{
		return;
	}
	
	s32 count = [m_songs count];
	if(count <= songIndex)
	{
		return;
	}
	
	if(songIndex >= 0)
	{
		VOX_WARNING_LEVEL_5("Setting song %d as current", songIndex);
		MPMediaItemCollection *song = [m_songs objectAtIndex:songIndex];
		if(song)
		{
			// Note : The creation of an array and another collection from the 'song' collection is a workaround
			// since setting queue directly with 'song' doesn't work on FW 4.3 (beta version).
			NSArray *songs = [song items];
			if(songs)
			{
				MPMediaItemCollection *songCollection = [MPMediaItemCollection collectionWithItems: songs];
				
				if(songCollection)
				{
					[m_player setQueueWithItemCollection:songCollection];
				}
			}
		}	
	}
	else
	{
		VOX_WARNING_LEVEL_2("Song indexes lower than 0 are not supported. Call SetPlaylist(-1) to enqueue all songs for playback", 0);
	}
}

void VoxiPodController::_GetSongs()
{	
#if VOX_IPOD_QUERY_ASYNC
	if(m_songs != nil)
	{
		[m_songs release];
		m_songs = nil;
	}
	
	m_isIpodQueryPending = true;
	QueueCommand(k_nVoxIpodControllerCommandSongQuery);

	//m_iPodQuery.GetSongs(&m_songs);	
#else
	MPMediaQuery *mySongsQuery = [MPMediaQuery songsQuery];
	if(m_songs != nil)
	{
		[m_songs release];
	}
	m_songs = [mySongsQuery collections];
	if(m_songs)
		[m_songs retain];
#endif	

}	
	
s32 VoxiPodController::GetPlaybackState()
{
#if VOX_IPOD_QUERY_ASYNC
    VOX_WARNING_LEVEL_1("DEPRECATED [%s] : Please use VoxiPodController::GetPlaybackStateAsync", __FUNCTION__);
#endif

	MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
	if(m_player)
		return m_player.playbackState;
	
	return -1;
}
	
std::string VoxiPodController::GetNowPlayingItemTitle()
{
#if VOX_IPOD_QUERY_ASYNC
	VOX_WARNING_LEVEL_1("DEPRECATED [%s] : Please use VoxiPodController::GetNowPlayingItemData", __FUNCTION__);
#endif

	MPMediaItem* nowPlayingItem;
	MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
	if(m_player)
	{
		nowPlayingItem = m_player.nowPlayingItem;
		if(nowPlayingItem)
		{
			NSString* nsstr = [nowPlayingItem valueForProperty: MPMediaItemPropertyTitle];
			if(nsstr)
			{
				const char* tempstr = [nsstr UTF8String];
				if(tempstr)
					return std::string(tempstr); 
			}
		}
	}
	
	return std::string("");
}
	
std::string VoxiPodController::GetNowPlayingItemArtist()
{
#if VOX_IPOD_QUERY_ASYNC
    VOX_WARNING_LEVEL_1("DEPRECATED [%s] : Please use VoxiPodController::GetNowPlayingItemData", __FUNCTION__);
#endif

	MPMediaItem* nowPlayingItem;
	MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
	if(m_player)
	{
		nowPlayingItem = m_player.nowPlayingItem;
		if(nowPlayingItem)
		{
			NSString* nsstr = [nowPlayingItem valueForProperty: MPMediaItemPropertyArtist];
			if(nsstr)
			{
				const char* tempstr = [nsstr UTF8String];
				if(tempstr)
					return std::string(tempstr); 
			}
		}
	}
	
	return std::string("");	
}
	
std::string VoxiPodController::GetNowPlayingItemAlbumTitle()
{
#if VOX_IPOD_QUERY_ASYNC
    VOX_WARNING_LEVEL_1("DEPRECATED [%s] : Please use VoxiPodController::GetNowPlayingItemData", __FUNCTION__);
#endif


	MPMediaItem* nowPlayingItem;
	MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
	if(m_player)
	{
		nowPlayingItem = m_player.nowPlayingItem;
		if(nowPlayingItem)
		{
			NSString* nsstr = [nowPlayingItem valueForProperty: MPMediaItemPropertyAlbumTitle];
			if(nsstr)
			{
				const char* tempstr = [nsstr UTF8String];
				if(tempstr)
					return std::string(tempstr); 
			}
		}
	}
	
	return std::string("");	
}
	
f32 VoxiPodController::GetNowPlayingCursorPosition()
{
#if VOX_IPOD_QUERY_ASYNC
    VOX_WARNING_LEVEL_1("DEPRECATED [%s] : Please use VoxiPodController::GetNowPlayingItemData", __FUNCTION__);
#endif

	MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
	f32 curPos = 0.f;
	if(m_player)
	{
		curPos = (f32)m_player.currentPlaybackTime;
	}
	
	return curPos;		
}
	
f32 VoxiPodController::GetNowPlayingDuration()
{
#if VOX_IPOD_QUERY_ASYNC
    VOX_WARNING_LEVEL_1("DEPRECATED [%s] : Please use VoxiPodController::GetNowPlayingItemData", __FUNCTION__);
#endif

	MPMediaItem* nowPlayingItem;
	MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
	f32 duration = 0.f;
	if(m_player)
	{
		nowPlayingItem = m_player.nowPlayingItem;
		if(nowPlayingItem)
		{
			NSNumber* nsnum = [nowPlayingItem valueForProperty: MPMediaItemPropertyPlaybackDuration];
			if(nsnum)
				duration = [nsnum floatValue];
		}
	}
	
	return duration;			
}

s32 VoxiPodController::GetNowPlayingItemData(std::string* title, std::string* artist, std::string* album, f32* cursorPosition, f32* playbackDuration) //**-**
{
	s32 errorCode = VoxIpodQueryState::k_nQueryError;

#if !VOX_IPOD_QUERY_ASYNC
	return errorCode;
#endif	

	if(m_isNowPlayingItemValid)
	{
		m_nowPlayingItemMutex.Lock();

		if(m_nowPlayingItem != nil)
		{
			errorCode = VoxIpodQueryState::k_nQuerySuccess;

			if(title)
			{
				NSString* nsstr = [m_nowPlayingItem valueForProperty: MPMediaItemPropertyTitle];
				if(nsstr)
				{
					const char* tempstr = [nsstr UTF8String];
					if(tempstr)
						*title = tempstr; 
					else
						*title = "";
				}
				else
					*title = "";
			}

			if(artist)
			{
				NSString* nsstr = [m_nowPlayingItem valueForProperty: MPMediaItemPropertyArtist];
				if(nsstr)
				{
					const char* tempstr = [nsstr UTF8String];
					if(tempstr)
						*artist = tempstr; 
					else
						*artist = "";
				}
				else
					*artist = "";
			}

			if(album)
			{
				NSString* nsstr = [m_nowPlayingItem valueForProperty: MPMediaItemPropertyAlbumTitle];
				if(nsstr)
				{
					const char* tempstr = [nsstr UTF8String];
					if(tempstr)
						*album = tempstr; 
					else
						*album = "";
				}
				else
					*album = "";
			}

			if(cursorPosition)
			{
				*cursorPosition = m_nowPlayingItemPosition;
			}

			if(playbackDuration)
			{
				NSNumber* nsnum = [m_nowPlayingItem valueForProperty: MPMediaItemPropertyPlaybackDuration];
				if(nsnum)
					*playbackDuration = (f32)[nsnum floatValue];
				else
					*playbackDuration = 0.f;
			}
		}
		
		m_nowPlayingItemMutex.Unlock();
		
		m_isNowPlayingItemValid = false; //Only good for one query
	}
	else
	{
		errorCode = VoxIpodQueryState::k_nQueryRunning;

		if(!m_isNowPlayingItemUpdating)
		{
			m_isNowPlayingItemUpdating = true;
			QueueCommand(k_nVoxIpodControllerCommandGetNowPlayingItemData);
		}
	}

    return errorCode;
}

s32 VoxiPodController::GetPlaybackStateAsync()
{
	s32 errorCode = VoxIpodQueryState::k_nQueryError;

#if !VOX_IPOD_QUERY_ASYNC
	return errorCode;
#endif	

	if(m_isStateValid)
	{
		errorCode = m_iPodState;
		m_isStateValid = false; //Only good for one query
	}
	else
	{
		errorCode = VoxIpodQueryState::k_nQueryRunning;

		if(!m_isStateUpdating)
		{
			m_isStateUpdating = true;
			QueueCommand(k_nVoxIpodControllerCommandGetPlaybackStateAsync);			
		}
	}

    return errorCode;
}

void VoxiPodController::_GetNowPlayingItemData()
{
	MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
	MPMediaItem* nowPlayingItem = nil;
	f32 curPos = 0.f;

	if(m_player)
	{
		curPos = (f32)m_player.currentPlaybackTime;
		nowPlayingItem = m_player.nowPlayingItem;
	}

	m_nowPlayingItemMutex.Lock();

	m_nowPlayingItemPosition = curPos;

	if(m_nowPlayingItem)
	{
		[m_nowPlayingItem release];
	}

	m_nowPlayingItem = nowPlayingItem;

	if(m_nowPlayingItem)
		[m_nowPlayingItem retain];

	m_nowPlayingItemMutex.Unlock();
	
	m_isNowPlayingItemValid = true;
	m_isNowPlayingItemUpdating = false;
}

void VoxiPodController::_GetPlaybackStateAsync()
{
	m_iPodState = -1;
	MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
	if(m_player)
		m_iPodState = m_player.playbackState;

	m_isStateValid = true;
	m_isStateUpdating = false;
}

void VoxiPodController::ThreadRoutine(void* caller, void* param)
{
    ((VoxiPodController*)caller)->ProcessQueue();
}

void VoxiPodController::ProcessQueue()
{
    if(m_iPodQuery.m_isRunning)
        return;
        
    VoxIpodControllerCommand command;
    bool isEmpty;
    
	if(m_isPollingIpod)
	{
		f64 curtime = _GetCurTime();
		if(curtime >= m_nextPoll)
		{
			QueueCommand(k_nVoxIpodControllerCommandPollIpod);
			m_nextPoll = curtime + VOX_IPOD_POLLING_DT;
		}
	}
	
    m_commandQueueMutex.Lock();
    isEmpty = m_commandQueue.size() <= 0;
    if(!isEmpty)
    {
        command = m_commandQueue.front();
        m_commandQueue.pop_front();
    }
    
    m_commandQueueMutex.Unlock();
    
    if(isEmpty || command.m_type == k_nVoxIpodControllerCommandCancelled)
        return;
        
	NSAutoreleasePool* ap = [[NSAutoreleasePool alloc] init];
	
    switch(command.m_type)
    {
        case k_nVoxIpodControllerCommandPlay:
        {
            _Play();
            break;
        }
        case k_nVoxIpodControllerCommandPause:
        {
            _Pause();
            break;
        }
        case k_nVoxIpodControllerCommandStop:
        {
            _Stop();
            break;
        }
        case k_nVoxIpodControllerCommandNext:
        {
            _Next();
            break;
        }
        case k_nVoxIpodControllerCommandPrevious:
        {
            _Previous();
            break;
        }
        case k_nVoxIpodControllerCommandSetShuffleMode:
        {
            _SetShuffleMode(command.m_param);
            break;
        }
        case k_nVoxIpodControllerCommandSetRepeatMode:
        {
            _SetRepeatMode(command.m_param);
            break;
        }
        case k_nVoxIpodControllerCommandSetPlaylist:
        {
            _SetPlaylist(command.m_param);
            break;
        }
        case k_nVoxIpodControllerCommandSetArtist:
        {
            _SetArtist(command.m_param);
            break;
        }
        case k_nVoxIpodControllerCommandSetAlbum:
        {
            _SetAlbum(command.m_param);
            break;
        }
        case k_nVoxIpodControllerCommandSetSong:
        {
            _SetSong(command.m_param);
            break;
        }
		case k_nVoxIpodControllerCommandGetNowPlayingItemData:
        {
            _GetNowPlayingItemData();
            break;
        }
        case k_nVoxIpodControllerCommandGetPlaybackStateAsync:
        {
            _GetPlaybackStateAsync();
            break;
        }	
		case k_nVoxIpodControllerCommandPlaylistQuery:
        {
            m_iPodQuery.GetPlaylists(VoxIpodControllerQueryData((void*)&m_playlists, &m_queryMutex));
			m_isIpodQueryPending = false;
            break;
        }
		case k_nVoxIpodControllerCommandArtistQuery:
        {
            m_iPodQuery.GetArtists(VoxIpodControllerQueryData((void*)&m_artists, &m_queryMutex));
			m_isIpodQueryPending = false;
            break;
        }
		case k_nVoxIpodControllerCommandAlbumQuery:
		{
            m_iPodQuery.GetAlbums(VoxIpodControllerQueryData((void*)&m_albums, &m_queryMutex));
			m_isIpodQueryPending = false;
            break;
        }
		case k_nVoxIpodControllerCommandSongQuery:
        {
            m_iPodQuery.GetSongs(VoxIpodControllerQueryData((void*)&m_songs, &m_queryMutex));
			m_isIpodQueryPending = false;
            break;
        }
		case k_nVoxIpodControllerCommandProcessSongChanged:
        {
            _ProcessSongChanged();
            break;
        }	
		case k_nVoxIpodControllerCommandProcessStateChanged:
        {
            _ProcessStateChanged();
            break;
        }	
		case k_nVoxIpodControllerCommandProcessLibraryChanged:
        {
            _ProcessLibraryChanged();
            break;
        }
		case k_nVoxIpodControllerCommandPollIpod:
        {
            _PollIpod();
            break;
        }	
        default:
        {
            VOX_WARNING_LEVEL_2("Unknown iPod controller command : %d", command.m_type);
            break;
        }
    }
	
	[ap release];
}

void VoxiPodController::QueueCommand(VoxIpodControllerCommandType commandType, s32 param, bool isHighPrio)
{
	if(m_isSuspended)
		return;
	
    m_commandQueueMutex.Lock();
    
	if(   commandType == k_nVoxIpodControllerCommandProcessSongChanged
	   || commandType == k_nVoxIpodControllerCommandProcessStateChanged
	   || commandType == k_nVoxIpodControllerCommandProcessLibraryChanged
	   || commandType == k_nVoxIpodControllerCommandPollIpod)
	{
		//Need to cancel other command of the same type to avoid processing same callback twice
		VOX_LIST<VoxIpodControllerCommand, SAllocator<VoxIpodControllerCommand> >::iterator iter = m_commandQueue.begin();
		VOX_LIST<VoxIpodControllerCommand, SAllocator<VoxIpodControllerCommand> >::iterator end = m_commandQueue.end();	
		
		for(;iter != end; iter++)
		{
			if((*iter).m_type == commandType)
				(*iter).m_type = k_nVoxIpodControllerCommandCancelled;
		}
	}
	
    if(isHighPrio)
    {
        m_commandQueue.push_front(VoxIpodControllerCommand(commandType, param));
    }
    else
    {
        m_commandQueue.push_back(VoxIpodControllerCommand(commandType, param));
    }
    
    m_commandQueueMutex.Unlock();
}
    
void VoxiPodController::_LibraryChangedHandler()
{
	VoxiPodController *vic = GetiPodController();	
	if(vic)
	{
		vic->m_iPodQuery.m_dropResult = true;
		vic->QueueCommand(k_nVoxIpodControllerCommandProcessLibraryChanged, 0, true);
	}
}
	
void VoxiPodController::_SongChangedHandler()
{
	VoxiPodController *vic = GetiPodController();	
	if(vic)
	{
		vic->QueueCommand(k_nVoxIpodControllerCommandProcessSongChanged, 0, true);
	}
}
	
void VoxiPodController::_StateChangedHandler(s32 dummyState)
{
	VoxiPodController *vic = GetiPodController();	
	if(vic)
	{
		vic->QueueCommand(k_nVoxIpodControllerCommandProcessStateChanged, 0, true);
	}
}

void VoxiPodController::_ProcessLibraryChanged()
{
	m_queryMutex.Lock();
	
	if(m_playlists)
	{
		[m_playlists release];
		m_playlists = nil;
	}
	
	if(m_artists)
	{
		[m_artists release];
		m_artists = nil;
	}
	
	if(m_albums)
	{
		[m_albums release];
		m_albums = nil;
	}
	
	if(m_songs)
	{
		[m_songs release];
		m_songs = nil;
	}

	m_queryMutex.Unlock();
	
	if(s_iPodStateNotificationHandler)
	{
		[s_iPodStateNotificationHandler reset];		 
	}
	
	if(m_externalLibraryCallback)
		m_externalLibraryCallback();
	
	m_isPollingIpod = true;
	VOX_WARNING_LEVEL_5("%s", "User sync his device starting periodic polling");
}
		
void VoxiPodController::_ProcessStateChanged()
{
	m_isStateValid = false;
	
	if (m_externalStateCallback)
	{
		s32 iPodState = -1;
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		if(m_player)
			iPodState = m_player.playbackState;	
		
		m_externalStateCallback(iPodState);
	}
	
}
	
void VoxiPodController::_ProcessSongChanged()
{
	m_isNowPlayingItemValid = false;
	
	if(m_externalSongCallback)
		m_externalSongCallback();
}

void VoxiPodController::_PollIpod()
{
	//state
	if (m_externalStateCallback)
	{
		s32 iPodState = -1;
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		if(m_player)
			iPodState = m_player.playbackState;	
		
		if ( iPodState != m_lastPollState)
		{
			m_isStateValid = false;
			m_lastPollState = iPodState;
			m_externalStateCallback(iPodState);
		}		
	}	
	
	//Song
	if(m_externalSongCallback)
	{
		MPMusicPlayerController* m_player = [mpc iPodMusicPlayer];
		MPMediaItem* nowPlayingItem = nil;
	
		if(m_player)
		{
			nowPlayingItem = m_player.nowPlayingItem;
		}
		
		if(nowPlayingItem != nil && m_lastPollItem != nil)
		{
			NSNumber* oldid = 0;
			NSNumber* newid = 0;
			
			newid = [nowPlayingItem valueForProperty:MPMediaItemPropertyPersistentID];
			oldid = [m_lastPollItem valueForProperty:MPMediaItemPropertyPersistentID];	
			
			if(oldid != nil && newid != nil)
			{
				if([oldid longLongValue] != [newid longLongValue])
				{
					[m_lastPollItem release];
					m_lastPollItem = nowPlayingItem;
					[m_lastPollItem retain];
				
					m_externalSongCallback();
				}
			}
		}
		if(nowPlayingItem == nil || m_lastPollItem == nil)
		{
			if(m_lastPollItem == nil && nowPlayingItem != nil)
			{
				m_lastPollItem = nowPlayingItem;
				[m_lastPollItem retain];
				m_externalSongCallback();
			}
			else if(nowPlayingItem == nil && m_lastPollItem != nil)
			{
				[m_lastPollItem release];
				m_lastPollItem = nil;
				m_externalSongCallback();
			}
		}
	}
}
	
}
