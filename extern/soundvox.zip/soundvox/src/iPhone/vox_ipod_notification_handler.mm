//
//  vox_ipod_notification_handler.m
//  iSimple
//
//  Created by alexandre.belanger@gameloft.com on 9/25/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "vox_ipod_notification_handler.h"
#import <MediaPlayer/MediaPlayer.h>

@implementation VoxiPodNotificationHandler

-(id) alloc
{
	self = [super init];
	m_stateCallback = 0;
	return self;
}

-(void) dealloc
{
	if(m_stateCallback || m_songCallback)
	{
		MPMusicPlayerController* iPod = [MPMusicPlayerController iPodMusicPlayer];
		if(iPod)
			[iPod endGeneratingPlaybackNotifications];
	}
	
	if(m_songCallback)
	{
		[[NSNotificationCenter defaultCenter] removeObserver:self name:MPMusicPlayerControllerPlaybackStateDidChangeNotification object:nil];
	}
	
	if(m_stateCallback)
	{
		[[NSNotificationCenter defaultCenter] removeObserver:self name:MPMusicPlayerControllerNowPlayingItemDidChangeNotification object:nil];
	}
	
	if(m_libraryCallback)
	{
		MPMediaLibrary* library = [MPMediaLibrary defaultMediaLibrary];
		if(library)
			[library beginGeneratingLibraryChangeNotifications];
		[[NSNotificationCenter defaultCenter] removeObserver:self name:MPMediaLibraryDidChangeNotification  object:library];
	}
	
	[super dealloc];
}

-(void) initHandler
{
	m_stateCallback = 0;
	m_songCallback = 0;
	m_libraryCallback = 0;
}

-(void) reset
{
	if(m_stateCallback || m_songCallback)
	{
		MPMusicPlayerController* iPod = [MPMusicPlayerController iPodMusicPlayer];
		if(iPod)
			[iPod endGeneratingPlaybackNotifications];
	}
	
	if(m_songCallback)
	{
		[[NSNotificationCenter defaultCenter] removeObserver:self name:MPMusicPlayerControllerPlaybackStateDidChangeNotification object:nil];
	}
	
	if(m_stateCallback)
	{
		[[NSNotificationCenter defaultCenter] removeObserver:self name:MPMusicPlayerControllerNowPlayingItemDidChangeNotification object:nil];
	}
	
	if(m_libraryCallback)
	{
		MPMediaLibrary* library = [MPMediaLibrary defaultMediaLibrary];
		if(library)
			[library endGeneratingLibraryChangeNotifications];
		[[NSNotificationCenter defaultCenter] removeObserver:self name:MPMediaLibraryDidChangeNotification  object:library];
	}	
	
	[self setStateCallback:m_stateCallback];
	[self setSongCallback:m_songCallback];
	[self setLibraryCallback:m_libraryCallback];	
}

-(void) setStateCallback:(iPodPlayerStateChangedCallback) stateCallback
{
	if(m_stateCallback) //already registered
	{
		m_stateCallback = stateCallback;
	}
	else
	{
		MPMusicPlayerController* iPod = [MPMusicPlayerController iPodMusicPlayer];
		if(iPod)
		{
			m_stateCallback = stateCallback;
			if(m_stateCallback)
			{			
				[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handle_stateChanged:) name:MPMusicPlayerControllerPlaybackStateDidChangeNotification object:nil];
			}
		
			if(!m_songCallback)
			{
				[iPod beginGeneratingPlaybackNotifications];
			}
		}
	}
}

-(void) setSongCallback:(iPodPlayerNowPlayingChangedCallback) songCallback
{
	if(m_songCallback) //already registered
	{
		m_songCallback = songCallback;
	}
	else
	{
		MPMusicPlayerController* iPod = [MPMusicPlayerController iPodMusicPlayer];
		if(iPod)
		{
			m_songCallback = songCallback;
			if(m_songCallback)
			{			
				[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handle_songChanged:) name:MPMusicPlayerControllerNowPlayingItemDidChangeNotification object:nil];
			}

			if(!m_stateCallback)
			{
				[iPod beginGeneratingPlaybackNotifications];
			}	
		}
	}
}

-(void) setLibraryCallback:(iPodLibraryChangedCallback) libraryCallback
{
	if(m_libraryCallback) //already registered
	{
		m_libraryCallback = libraryCallback;
	}
	else
	{
		MPMediaLibrary* library = [MPMediaLibrary defaultMediaLibrary];
		if(library)
		{	
			m_libraryCallback = libraryCallback;
			if(m_libraryCallback)
			{
				[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handle_libraryChanged:) name:MPMediaLibraryDidChangeNotification  object:library];
				[library beginGeneratingLibraryChangeNotifications];
			}
		}
	}
}

-(void) handle_stateChanged:(NSNotification*) aNotification
{
#if VOX_IPOD_QUERY_ASYNC
	if(m_stateCallback)
	{
		m_stateCallback(-1);
	}
#else	
	MPMusicPlayerController* iPod = [MPMusicPlayerController iPodMusicPlayer];
	if(m_stateCallback && iPod)
	{
		m_stateCallback(iPod.playbackState);
	}
#endif
}

-(void) handle_songChanged:(NSNotification*) aNotification
{
	if(m_songCallback)
	{
		m_songCallback();
	}	
}

-(void) handle_libraryChanged:(NSNotification*) aNotification
{
#if VOX_IPOD_QUERY_ASYNC
	if(m_libraryCallback)
	{
		m_libraryCallback();
	}	
#else
	MPMusicPlayerController* iPod = [MPMusicPlayerController iPodMusicPlayer];
	if(iPod)
	{
		[iPod stop];
	}
	
	[self reset];
	
	if(m_libraryCallback)
	{
		m_libraryCallback();
	}
#endif
}

@end
