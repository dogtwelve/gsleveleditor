#include "StdAfx.h"
#include "stdio.h"

#include "vox_default_config.h"
#include "vox_iphone.h"
#include "vox_iphone_internal.h"

#include "vox_macro.h"
#include "vox_mutex.h"

namespace vox
{
	
//static VoxIphone* s_voxEngine = 0;
//VoxEngineInternal* VoxEngine::m_internal=0;
	
VoxIphone& VoxIphone::GetVoxEngine()
{
	if ( ! s_voxEngine )
	{
			s_voxEngine = VOX_NEW VoxIphone();
	}
	
	VOX_ASSERT_MSG( s_voxEngine, "VoxEngine creation failed\n" );
	return *((VoxIphone*)s_voxEngine);
}
		
void VoxIphone::DestroyVoxEngine()
{
	VoxIphone* s_voxiPhoneEngine = (VoxIphone*)s_voxEngine;
	if ( s_voxiPhoneEngine )
	{
		VOX_DELETE (s_voxiPhoneEngine);
		s_voxEngine = 0;
	}
}
	
VoxIphone::VoxIphone():VoxEngine(0)
{
	m_mutex = VOX_NEW Mutex();
	m_internal = VoxIphoneInternal::GetVoxEngineInternal();
	VOX_ASSERT(m_internal);
}

VoxIphone::~VoxIphone()
{
#if !VOX_DRIVER_USE_IPHONE_REMOTEIO		
	if(m_internal)
	{
		((VoxIphoneInternal*)m_internal)->ForceResumeForDelete();
	}
#endif	
}	
	
//
	
void VoxIphone::SuspendEngine(void)
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->Suspend();
}

void VoxIphone::ResumeEngine(void)
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->Resume();
}

bool VoxIphone::IsEngineSuspended(void)
{
	if(m_internal)
	{
		return ((VoxIphoneInternal*)m_internal)->IsSuspended();
	}
	return false;
}
	
/*void VoxIphone::ForceEndAudioInterruption()
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->ForceEndAudioInterruption();
}	*/

void VoxIphone::iPod_Play()
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->iPod_Play();
}
	
void VoxIphone::iPod_Pause()
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->iPod_Pause();
}
	
void VoxIphone::iPod_Stop()
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->iPod_Stop();
}
	
void VoxIphone::iPod_Next()
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->iPod_Next();
}
	
void VoxIphone::iPod_Previous()
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->iPod_Previous();
}

void  VoxIphone::SetiPodPlayerStateChangedCallback(iPodPlayerStateChangedCallback callback)
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->SetiPodPlayerStateChangedCallback(callback);	
}
	
void  VoxIphone::SetiPodPlayerNowPlayingChangedCallback(iPodPlayerNowPlayingChangedCallback callback)
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->SetiPodPlayerNowPlayingChangedCallback(callback);	
}	

void  VoxIphone::SetiPodLibraryChangedCallback(iPodLibraryChangedCallback callback)	
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->SetiPodLibraryChangedCallback(callback);	
}
	
void VoxIphone::SetInterruptableGroup(u32 groupMask)
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->SetInterruptableGroup(groupMask);	
}
	
void VoxIphone::ApplicationDidBecomeActive()
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->Resume();		
}
	
void VoxIphone::ApplicationWillResignActive()
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->Suspend();		
}
	
s32  VoxIphone::iPod_GetPlaylistCount()
{
	if(m_internal)
		return ((VoxIphoneInternal*)m_internal)->iPod_GetPlaylistCount();	
	return 0;
}
	
std::string VoxIphone::iPod_GetPlaylistName(s32 playlistIndex)
{
	if(m_internal)
		return ((VoxIphoneInternal*)m_internal)->iPod_GetPlaylistName(playlistIndex);	
	return std::string("");
}
	
void VoxIphone::iPod_SetPlaylist(s32 playlistIndex)
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->iPod_SetPlaylist(playlistIndex);	
}

s32 VoxIphone::iPod_GetPlaybackState()
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->iPod_GetPlaybackState();	
	return VoxIpodState::k_nOther;
}

bool VoxIphone::iPod_IsAvailable()
{
	if(m_internal)
		return ((VoxIphoneInternal*)m_internal)->iPod_IsAvailable();	
	return false;
}
	
std::string VoxIphone::iPod_GetNowPlayingItemTitle()
{
	if(m_internal)
		return ((VoxIphoneInternal*)m_internal)->iPod_GetNowPlayingItemTitle();	
	return std::string("");	
}
	
std::string VoxIphone::iPod_GetNowPlayingItemArtist()
{
	if(m_internal)
		return ((VoxIphoneInternal*)m_internal)->iPod_GetNowPlayingItemArtist();	
	return std::string("");	
}
	
std::string VoxIphone::iPod_GetNowPlayingItemAlbumTitle()
{
	if(m_internal)
		return ((VoxIphoneInternal*)m_internal)->iPod_GetNowPlayingItemAlbumTitle();	
	return std::string("");	
}
	
f32 VoxIphone::iPod_GetNowPlayingCursorPosition()
{
	if(m_internal)
		return ((VoxIphoneInternal*)m_internal)->iPod_GetNowPlayingCursorPosition();	
	return 0.f;	
}
	
f32 VoxIphone::iPod_GetNowPlayingDuration()	
{
	if(m_internal)
		return ((VoxIphoneInternal*)m_internal)->iPod_GetNowPlayingDuration();	
	return 0.f;	
}

s32 VoxIphone::iPod_GetNowPlayingItemData(std::string* title, std::string* artist, std::string* album, f32* cursorPosition, f32* playbackDuration)
{
	if(m_internal)
		return ((VoxIphoneInternal*)m_internal)->iPod_GetNowPlayingItemData(title, artist, album, cursorPosition, playbackDuration);	
	return VoxIpodQueryState::k_nQueryError;	
}
	
s32 VoxIphone::iPod_GetPlaybackStateAsync()
{
	if(m_internal)
		return ((VoxIphoneInternal*)m_internal)->iPod_GetPlaybackStateAsync();	
	return VoxIpodQueryState::k_nQueryError;		
}
	
void VoxIphone::iPod_SetShuffle(s32 shuffleMode)
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->iPod_SetShuffle(shuffleMode);	
}

void VoxIphone::iPod_SetRepeat(s32 repeatMode)
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->iPod_SetRepeat(repeatMode);	
}
	
s32	VoxIphone::iPod_GetArtistCount()
{
	if(m_internal)
		return ((VoxIphoneInternal*)m_internal)->iPod_GetArtistCount();	
	return 0;
}
	
std::string	VoxIphone::iPod_GetArtistName(s32 artistIndex)
{
	if(m_internal)
		return ((VoxIphoneInternal*)m_internal)->iPod_GetArtistName(artistIndex);	
	return std::string("");
}	
	
void VoxIphone::iPod_SetArtist(s32 artistIndex)
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->iPod_SetArtist(artistIndex);	
}	
	
s32	VoxIphone::iPod_GetAlbumCount()
{
	if(m_internal)
		return ((VoxIphoneInternal*)m_internal)->iPod_GetAlbumCount();	
	return 0;
}
	
std::string	VoxIphone::iPod_GetAlbumName(s32 albumIndex)
{
	if(m_internal)
		return ((VoxIphoneInternal*)m_internal)->iPod_GetAlbumName(albumIndex);	
	return std::string("");
}

void VoxIphone::iPod_SetAlbum(s32 albumIndex)
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->iPod_SetAlbum(albumIndex);	
}	
	
s32	VoxIphone::iPod_GetSongCount()
{
	if(m_internal)
		return ((VoxIphoneInternal*)m_internal)->iPod_GetSongCount();	
	return 0;
}
	
std::string	VoxIphone::iPod_GetSongName(s32 songIndex)
{
	if(m_internal)
		return ((VoxIphoneInternal*)m_internal)->iPod_GetSongName(songIndex);	
	return std::string("");
}
		
void VoxIphone::iPod_SetSong(s32 songIndex)
{
	if(m_internal)
		((VoxIphoneInternal*)m_internal)->iPod_SetSong(songIndex);	
}

}