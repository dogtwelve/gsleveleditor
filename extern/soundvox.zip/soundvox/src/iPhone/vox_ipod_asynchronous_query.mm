/*
 *  vox_ipod_asynchronous_query.cpp
 *  VoxIphone
 *
 *  Created by alexandre.belanger on 10-06-14.
 *  Copyright 2010 Gameloft. All rights reserved.
 *
 */

#include "vox_ipod_asynchronous_query.h"
#include "vox_types.h"
#include "vox_macro.h"
#include <MediaPlayer/MediaPlayer.h>

namespace vox 
{
	
bool VoxiPodAsyncQuery::m_isRunning = false;	
bool VoxiPodAsyncQuery::m_dropResult = false;
	
VoxiPodAsyncQuery::~VoxiPodAsyncQuery()
{
	if(m_isRunning)
	{
		Cancel();
	}
}

bool VoxiPodAsyncQuery::GetPlaylists(VoxIpodControllerQueryData queryData)
{
	if(m_isRunning)
	{
		return false;
	}
	
	m_isRunning = true;
	
	m_queryData = queryData;
	
	s32 result = pthread_create(&m_thread, 0, &vox::VoxiPodAsyncQuery::_QueryPlaylists, &m_queryData);
	
	if(result != 0)
	{
		VOX_WARNING_LEVEL_1("Error in Creating thread\n",0);
		m_isRunning = false;
		return false;
	}	
	
	return true;
}

bool VoxiPodAsyncQuery::GetSongs(VoxIpodControllerQueryData queryData)
{
	if(m_isRunning)
	{
		return false;
	}
	
	m_isRunning = true;
	
	m_queryData = queryData;
		
	s32 result = pthread_create(&m_thread, 0, &vox::VoxiPodAsyncQuery::_QuerySongs, &m_queryData);
	if(result != 0)
	{
		VOX_WARNING_LEVEL_1("Error in Creating thread\n",0);
		m_isRunning = false;
		return false;
	}
	
	return true;
}

bool VoxiPodAsyncQuery::GetArtists(VoxIpodControllerQueryData queryData)
{
	if(m_isRunning)
	{
		return false;
	}
	
	m_isRunning = true;
	
	m_queryData = queryData;
	
	s32 result = pthread_create(&m_thread, 0, &vox::VoxiPodAsyncQuery::_QueryArtists, &m_queryData);
	if(result != 0)
	{
		VOX_WARNING_LEVEL_1("Error in Creating thread\n",0);
		m_isRunning = false;
		return false;
	}
	
	return true;
}

	bool VoxiPodAsyncQuery::GetAlbums(VoxIpodControllerQueryData queryData)
{
	if(m_isRunning)
	{
		return false;
	}
	
	m_isRunning = true;
	
	m_queryData = queryData;
	
	s32 result = pthread_create(&m_thread, 0, &vox::VoxiPodAsyncQuery::_QueryAlbums, &m_queryData);
	if(result != 0)
	{
		VOX_WARNING_LEVEL_1("Error in Creating thread\n",0);
		m_isRunning = false;
		return false;
	}
	
	return true;
}

bool VoxiPodAsyncQuery::Cancel()
{
	if(m_isRunning)
	{
		VOX_WARNING_LEVEL_5("Canceling thread %d\n", (int)m_thread);
		if(pthread_cancel(m_thread) != 0)
			return false;
		VOX_WARNING_LEVEL_5("Canceled thread %d\n", (int)m_thread);
		m_isRunning = false;
	}
	
	return true;
}

void* VoxiPodAsyncQuery::_QueryPlaylists(void* arg)
{
	NSAutoreleasePool* ap = [[NSAutoreleasePool alloc] init];
	
	NSArray* returnArray;
	MPMediaQuery *mediaQuery = [MPMediaQuery playlistsQuery];
	
	if(!m_dropResult)
	{
		returnArray = [mediaQuery collections];
		if(returnArray != nil)
		{
			[returnArray retain];
			((Mutex*)((VoxIpodControllerQueryData*)arg)->m_pQueryMutex)->Lock();
			*((NSArray**)((VoxIpodControllerQueryData*)arg)->m_array) = returnArray;
			((Mutex*)((VoxIpodControllerQueryData*)arg)->m_pQueryMutex)->Unlock();
		}
	}

	m_isRunning = false;	
	m_dropResult = false;
	
	[ap release];
	return 0;
}

void* VoxiPodAsyncQuery::_QuerySongs(void* arg)
{
	NSAutoreleasePool* ap = [[NSAutoreleasePool alloc] init];
	
	NSArray* returnArray;
	MPMediaQuery *mediaQuery = [MPMediaQuery songsQuery];
	
	if(!m_dropResult)
	{
		returnArray = [mediaQuery collections];
		if(returnArray != nil)
		{
			[returnArray retain];
			((Mutex*)((VoxIpodControllerQueryData*)arg)->m_pQueryMutex)->Lock();
			*((NSArray**)((VoxIpodControllerQueryData*)arg)->m_array) = returnArray;
			((Mutex*)((VoxIpodControllerQueryData*)arg)->m_pQueryMutex)->Unlock();
		}
	}
	
	m_isRunning = false;	
	m_dropResult = false;
	
	[ap release];
	return 0;
}

void* VoxiPodAsyncQuery::_QueryArtists(void* arg)
{
	NSAutoreleasePool* ap = [[NSAutoreleasePool alloc] init];
	
	NSArray* returnArray;
	MPMediaQuery *mediaQuery = [MPMediaQuery artistsQuery];
	
	if(!m_dropResult)
	{
		returnArray = [mediaQuery collections];
		if(returnArray != nil)
		{
			[returnArray retain];
			((Mutex*)((VoxIpodControllerQueryData*)arg)->m_pQueryMutex)->Lock();
			*((NSArray**)((VoxIpodControllerQueryData*)arg)->m_array) = returnArray;
			((Mutex*)((VoxIpodControllerQueryData*)arg)->m_pQueryMutex)->Unlock();
		}
	}
	
	m_isRunning = false;	
	m_dropResult = false;
	
	[ap release];
	return 0;
}

void* VoxiPodAsyncQuery::_QueryAlbums(void* arg)
{
	NSAutoreleasePool* ap = [[NSAutoreleasePool alloc] init];
	
	NSArray* returnArray;
	MPMediaQuery *mediaQuery = [MPMediaQuery albumsQuery];
	
	if(!m_dropResult)
	{
		returnArray = [mediaQuery collections];
		if(returnArray != nil)
		{
			[returnArray retain];
			((Mutex*)((VoxIpodControllerQueryData*)arg)->m_pQueryMutex)->Lock();
			*((NSArray**)((VoxIpodControllerQueryData*)arg)->m_array) = returnArray;
			((Mutex*)((VoxIpodControllerQueryData*)arg)->m_pQueryMutex)->Unlock();
		}
	}
	
	m_isRunning = false;	
	m_dropResult = false;
	
	[ap release];
	return 0;
}
	
}
