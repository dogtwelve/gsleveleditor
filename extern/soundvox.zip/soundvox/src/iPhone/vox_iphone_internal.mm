/*
 *  vox_iphone_internal.cpp
 *  iSimple
 *
 *  Created by alexandre.belanger@gameloft.com on 9/15/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */
//#import <sys/utsname.h>

//struct utsname u;
//uname(&u);
//u.machine //iPod1,1 ...

#include "vox_iphone_internal.h"
#include "vox_iPod_controller.h"

#include "vox_macro.h"

namespace vox
{	
VoxIphoneInternal* VoxIphoneInternal::GetVoxEngineInternal()
{
	if(s_voxEngineInternal)
		return (VoxIphoneInternal*)s_voxEngineInternal;
	else
	{
		VoxIphoneInternal* vei = VOX_NEW VoxIphoneInternal();
		s_voxEngineInternal = vei;
	}
	
	VOX_ASSERT_MSG(s_voxEngineInternal, "VoxEngineInternal creation failed\n");
	return (VoxIphoneInternal*)s_voxEngineInternal;
}

VoxIphoneInternal::VoxIphoneInternal()
{
	m_iPodController = 0;
	m_timeSinceOtherAudioCheck = 0.0f;
	m_interruptionLevel = 0;
	m_systemSound = false;
	m_isIpodPlaying = false;
	m_isVolumeDucked = false;
	m_defaultAudioSessionCategory = kAudioSessionCategory_AmbientSound;
	m_interruptableGroupMask = 0;
	m_externaliPodPlayerStateChangedCallback = 0;
	m_externaliPodPlayerNowPlayingChangedCallback = 0;
	m_externaliPodLibraryChangedCallback = 0;
	m_iPodSuspendCount = 0;
	
	for(int i = 0; i < k_nVoxGroupId_max; i++)
	{
		m_SavedGroupGainModifier[i] = 1.0f;
	}
	
	//AudioSessionInitialize(NULL, NULL, VoxIphoneInternal::interruptionListenerCallback, this);
	////AudioSessionAddPropertyListener(kAudioSessionProperty_AudioRouteChange, VoxIphoneInternal::propertyListenerCallback, this);
	
	//AudioSessionSetProperty(kAudioSessionProperty_AudioCategory, sizeof(m_defaultAudioSessionCategory), &m_defaultAudioSessionCategory);
	//AudioSessionSetActive(true);	
}

VoxIphoneInternal::~VoxIphoneInternal()
{
	if(m_iPodController)
		VOX_DELETE (m_iPodController);
}
	
void VoxIphoneInternal::Initialize()
{
	m_iPodController = VoxiPodController::GetiPodController();
	if(m_iPodController)
	{
		m_iPodController->Init(&VoxIphoneInternal::iPodStateChanged, &VoxIphoneInternal::iPodSongChanged, &VoxIphoneInternal::iPodLibraryChanged);
	}	
	
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	AudioSessionInitialize(NULL, NULL, VoxIphoneInternal::interruptionListenerCallback, this);
	//AudioSessionAddPropertyListener(kAudioSessionProperty_AudioRouteChange, VoxIphoneInternal::propertyListenerCallback, this);
	
	AudioSessionSetProperty(kAudioSessionProperty_AudioCategory, sizeof(m_defaultAudioSessionCategory), &m_defaultAudioSessionCategory);
	AudioSessionSetActive(true);	
	
	VoxEngineInternal::Initialize();
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

	
void VoxIphoneInternal::interruptionListenerCallback(void *inUserData,UInt32 interruptionState)
{
	if ( interruptionState == kAudioSessionBeginInterruption )
	{	
		((VoxIphoneInternal*)inUserData)->beginInterruption();
	}
	else if(interruptionState == kAudioSessionEndInterruption)
	{
		((VoxIphoneInternal*)inUserData)->endInterruption();
	}
}

void VoxIphoneInternal::beginInterruption()
{
	VOX_WARNING_LEVEL_2("Begin AudioSession Interruption",0);
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_interruptionLevel == 0)
	{
		//m_systemSound = false;
		m_systemSound = true;
		m_timeSinceOtherAudioCheck = 0;
		m_audioMutex.Lock();
		AudioSessionSetActive(false);
		m_hwDriver->Suspend();
	}
	m_interruptionLevel++;
	m_checkThreshold = 0;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}
	
void VoxIphoneInternal::endInterruption()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	
	if(m_systemSound)
	{
		m_systemSound = false;
		m_interruptionLevel = -1;
		VOX_WARNING_LEVEL_2("Bypass end AudioSession Interruption",0);	
	}
	else
	{
		m_interruptionLevel--;
		if(m_interruptionLevel == 0)
		{
			m_systemSound = false;
			AudioSessionSetProperty(kAudioSessionProperty_AudioCategory, sizeof(m_defaultAudioSessionCategory), &m_defaultAudioSessionCategory);
			AudioSessionSetActive(true);
			m_hwDriver->Resume();
			ForceUpdateEmitters(true);
			m_audioMutex.Unlock();
		}
		else if(m_interruptionLevel < 0)
		{
			m_interruptionLevel = 0;
		}
	}
	
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	VOX_WARNING_LEVEL_2("End AudioSession Interruption",0);	
}

void VoxIphoneInternal::ForceEndAudioInterruption()
{
	VOX_WARNING_LEVEL_2("%s\n", __FUNCTION__);
	VOX_WARNING_LEVEL_2("Interrupt level : %d\n", m_interruptionLevel);
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());

	if(m_interruptionLevel != 0)
	{
		m_systemSound = false;
		m_interruptionLevel = 0;
		AudioSessionSetProperty(kAudioSessionProperty_AudioCategory, sizeof(m_defaultAudioSessionCategory), &m_defaultAudioSessionCategory);
		AudioSessionSetActive(true);
		m_hwDriver->Resume();
//		ForceUpdateEmitters(true);
		m_audioMutex.Unlock();
		VOX_WARNING_LEVEL_1("Forced end AudioSession Interruption",0);	
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void VoxIphoneInternal::ForceResumeForDelete()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	UInt32 currentAudioCategory = kAudioSessionCategory_AmbientSound;
	AudioSessionSetProperty(kAudioSessionProperty_AudioCategory, sizeof(currentAudioCategory), &currentAudioCategory);
	AudioSessionSetActive(true);
	m_hwDriver->Resume();	
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void VoxIphoneInternal::ProcessAudioRouteChanged()	
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_interruptionLevel > 0)
		m_systemSound = !m_systemSound;
	else
		m_systemSound = false;
	
	m_timeSinceOtherAudioCheck = 0;
	m_checkThreshold = 0;
	
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void VoxIphoneInternal::propertyListenerCallback(void * inClientData, AudioSessionPropertyID inID, UInt32 inDataSize, const void * inData)
{
	VOX_WARNING_LEVEL_2("Property changed : %d", (s32)inID);
	if (inID == kAudioSessionProperty_AudioRouteChange)
	{
		CFDictionaryRef routeDictionary = (CFDictionaryRef)inData;
		CFNumberRef reason = (CFNumberRef)CFDictionaryGetValue(routeDictionary, CFSTR(kAudioSession_AudioRouteChangeKey_Reason));
		SInt32 reasonVal;
		CFNumberGetValue(reason, kCFNumberSInt32Type, &reasonVal);
		VOX_WARNING_LEVEL_2("Audio route changed reason: %d", (s32)reasonVal);
		if(reasonVal == 3 ) //System sound ... probably
		{
			((VoxIphoneInternal*)inClientData)->ProcessAudioRouteChanged();
		}
	}
}	

void VoxIphoneInternal::UpdateEmitters(f32 dt)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	
	if(m_suspendCount > 0)
	{
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return;
	}
	
	if(dt < 0.0f)
	{
		dt = 0.0f;
	}
	else if(dt > 0.1f)
	{
		dt = 0.1f;
	}

	if(!m_audioMutex.TryLock())
	{
		bool ss = m_systemSound;
		f32 time = m_timeSinceOtherAudioCheck += dt;
		
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		if(!ss && (time > 0.5f))
		{
			VOX_MUTEX_LEVEL_1(m_mutex.Lock());
			s32 threshold = ++m_checkThreshold;
			m_timeSinceOtherAudioCheck = 0.0f;
			VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
			if(threshold >= 3 && m_suspendCount == 0)
			{
				m_checkThreshold = 0;
				ForceEndAudioInterruption();
			}
		}
		
		return;		
	}

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	
	if(m_isIpodPlaying)
	{
		if(!m_isVolumeDucked)
		{
			m_isVolumeDucked = true;
			VOX_MUTEX_LEVEL_1(m_mutex.Lock());
			for(s32 i = 0; i < k_nVoxGroupId_max; i++)
			{
				m_SavedGroupGainModifier[i] = m_groupGainFader[i].GetEndValue();
			}
			VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
			VoxEngineInternal::SetGroupGain(m_interruptableGroupMask, 0.0f, 0.5f);
#if VOX_SEND_IPOD_STATE_AFTER_DUCKING	
			if(m_externaliPodPlayerStateChangedCallback)
			{
				m_externaliPodPlayerStateChangedCallback(vox::VoxIpodState::k_nPlaying);
			}
#endif			
		}
	}
	else 
	{
		if(m_isVolumeDucked)
		{
			m_isVolumeDucked = false;
			for(s32 i = 0; i < k_nVoxGroupId_max; i++)
			{
				VoxEngineInternal::SetGroupGain( 1 << i, m_SavedGroupGainModifier[i], 0.5f);
			}
#if VOX_SEND_IPOD_STATE_AFTER_DUCKING	
			if(m_externaliPodPlayerStateChangedCallback)
			{
				m_externaliPodPlayerStateChangedCallback(vox::VoxIpodState::k_nStopped);
			}
#endif			
		}
	}
	
	
	VoxEngineInternal::UpdateEmitters(dt);

	m_audioMutex.Unlock();
}

void VoxIphoneInternal::ForceUpdateEmitters(bool stopNonLooping)
{
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.GetReadAccess());
	m_masterGainFader = Fader(0.0f, 1.0f, 0.5f);
	
	HandlableContainerIterator iter = m_emitterObjects.begin();
	HandlableContainerIterator last = m_emitterObjects.end();	
	for(;iter != last; iter++)
	{
#if VOX_USE_HANDLABLE_MAP
		((EmitterObj*)iter->second)->SetGainModifier(0.0f);
		if(stopNonLooping)
		{
			if(!((EmitterObj*)iter->second)->GetLoop())
			{
				((EmitterObj*)iter->second)->Stop();
			}
		}
		((EmitterObj*)iter->second)->Update(100.0f);
		
#else
		((EmitterObj*)(*iter))->SetGainModifier(0.0f);
		if(stopNonLooping)
		{
			if(!((EmitterObj*)(*iter))->GetLoop())
			{
				((EmitterObj*)(*iter))->Stop();
			}
		}
		((EmitterObj*)(*iter))->Update(100.0f);
#endif
	}	
	VOX_MUTEX_LEVEL_1(m_emittersAccessController.ReleaseReadAccess());
}
	
void VoxIphoneInternal::UpdateSources()
{
	if(m_interruptionLevel == 0)
		VoxEngineInternal::UpdateSources();
}

void VoxIphoneInternal::KillEmitter( EmitterObj* emitter )
{	
	//VOX_MUTEX_LEVEL_1(m_mutex.Lock());
#if !VOX_DRIVER_USE_IPHONE_REMOTEIO
	if(m_interruptionLevel != 0)
	{
		VOX_MUTEX_LEVEL_1(m_mutex.Lock());
		UInt32 currentAudioCategory = kAudioSessionCategory_AmbientSound;
		AudioSessionSetProperty(kAudioSessionProperty_AudioCategory, sizeof(currentAudioCategory), &currentAudioCategory);
		AudioSessionSetActive(true);
		m_hwDriver->Resume();	
		//emitter->NeedToDie();
		VoxEngineInternal::KillEmitter(emitter);	
		AudioSessionSetActive(false);
		m_hwDriver->Suspend();	
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	}	
	else
#endif
	{
		VoxEngineInternal::KillEmitter(emitter);
	}

	//VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}
	
void  VoxIphoneInternal::SetGroupGain( u32 groupMask, f32 gain, f32 fadeTime )
{
	if((groupMask & m_interruptableGroupMask) && (gain > 0.f))
	{
		iPod_Pause(); //QA rule 
	}
	
	if(m_isVolumeDucked)
	{
		VOX_MUTEX_LEVEL_1(m_mutex.Lock());
		for(s32 i = 0; i < k_nVoxGroupId_max; i++)
		{
			if(groupMask & (1 << i))
			{
				m_SavedGroupGainModifier[i] = gain;
			}
		}
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		
		VoxEngineInternal::SetGroupGain(groupMask & (~m_interruptableGroupMask), gain, fadeTime);
	}
	else
	{
		VoxEngineInternal::SetGroupGain(groupMask, gain, fadeTime);
	}
}

void VoxIphoneInternal::iPod_Play()
{
	if(m_iPodController)
	{
		m_iPodController->Play();
	}
}

void VoxIphoneInternal::iPod_Pause()
{
	if(m_iPodController)
		m_iPodController->Pause();
}
	
void VoxIphoneInternal::iPod_Stop()
{
	if(m_iPodController)
		m_iPodController->Stop();
}
		
void VoxIphoneInternal::iPod_Next()
{
	if(m_iPodController)
		m_iPodController->Next();
}

void VoxIphoneInternal::iPod_Previous()
{
	if(m_iPodController)
		m_iPodController->Previous();
}

void VoxIphoneInternal::iPodStateChanged(s32 state)
{
	VOX_WARNING_LEVEL_5("iPod state changed to : %d", state);
	VoxIphoneInternal* pInternal = (VoxIphoneInternal*)s_voxEngineInternal;
	if(!pInternal)
		return;

	if(state == MPMusicPlaybackStatePlaying || state == MPMusicPlaybackStateSeekingForward  || state == MPMusicPlaybackStateSeekingBackward)//playing
	{
		pInternal->m_isIpodPlaying = true;

	}
	else if(state == MPMusicPlaybackStateStopped || state == MPMusicPlaybackStatePaused || state == MPMusicPlaybackStateInterrupted) //stopped/paused/interrupted
	{
		pInternal->m_isIpodPlaying = false;
	}

#if !VOX_SEND_IPOD_STATE_AFTER_DUCKING	
	if(pInternal->m_externaliPodPlayerStateChangedCallback)
	{
		pInternal->m_externaliPodPlayerStateChangedCallback(VoxIphoneInternal::ConvertiPodState(state));
	}
#endif
}
	
void VoxIphoneInternal::iPodSongChanged()
{
	VoxIphoneInternal* pInternal = (VoxIphoneInternal*)s_voxEngineInternal;
	if(!pInternal)
		return;

	VOX_WARNING_LEVEL_5("iPod song changed", 0);
	
	if(pInternal->m_externaliPodPlayerNowPlayingChangedCallback)
		pInternal->m_externaliPodPlayerNowPlayingChangedCallback();
}
	
void VoxIphoneInternal::iPodLibraryChanged()
{
	VOX_WARNING_LEVEL_5("iPod library changed", 0);
	VoxIphoneInternal* pInternal = (VoxIphoneInternal*)s_voxEngineInternal;
	if(!pInternal)
		return;
	
	if(pInternal->m_externaliPodLibraryChangedCallback)
		pInternal->m_externaliPodLibraryChangedCallback();
}
	
void VoxIphoneInternal::SetiPodPlayerStateChangedCallback(iPodPlayerStateChangedCallback callback)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_externaliPodPlayerStateChangedCallback = callback;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}
	
void VoxIphoneInternal::SetiPodPlayerNowPlayingChangedCallback(iPodPlayerNowPlayingChangedCallback callback)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_externaliPodPlayerNowPlayingChangedCallback = callback;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());	
}
	
void VoxIphoneInternal::SetiPodLibraryChangedCallback(iPodLibraryChangedCallback callback)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_externaliPodLibraryChangedCallback = callback;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());	
}	
	
void VoxIphoneInternal::SetInterruptableGroup(u32 groupMask)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_interruptableGroupMask = groupMask;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}
	
void VoxIphoneInternal::Resume()
{
	VOX_WARNING_LEVEL_2("%s", __FUNCTION__);
	VOX_ASSERT_MSG(m_suspendCount > 0, "Trying to resume a non-suspended engine");
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));

	if(m_hwDriver)
	{
		if(m_suspendCount > 1)
		{
			m_suspendCount--;
		}
		else if(m_suspendCount == 1)
		{
			m_hwDriver->RampIn();
			m_suspendCount--;
		}
	}
	if(m_iPodController)
	{
		if(m_iPodSuspendCount > 1)
		{
			m_iPodSuspendCount--;
		}
		else if(m_iPodSuspendCount == 1)
		{
#if VOX_IPOD_QUERY_ASYNC
			m_iPodController->Resume();
#endif
			m_iPodSuspendCount--;
		}
	}
	m_systemSound = false;
}	

void VoxIphoneInternal::Suspend()
{
	VOX_WARNING_LEVEL_2("%s", __FUNCTION__);
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));
	
	if(m_hwDriver)
	{
		if(m_suspendCount == 0)
		{
			m_hwDriver->RampOut();
		}
		m_suspendCount++;
	}
	
	if(m_iPodController)
	{
		if(m_iPodSuspendCount == 0)
		{
#if VOX_IPOD_QUERY_ASYNC
			m_iPodController->Suspend();
#else
			m_iPodController->DropQuery();
#endif
		}
		m_iPodSuspendCount++;
	}
}


bool VoxIphoneInternal::IsSuspended()
{	
	VOX_MUTEX_LEVEL_1(ScopeMutex sm(&m_mutex));
	return m_suspendCount > 0;
}

s32  VoxIphoneInternal::iPod_GetPlaylistCount()
{
	s32 result = 0;
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_iPodController)
		result = m_iPodController->GetPlaylistCount();
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;
}
	
std::string VoxIphoneInternal::iPod_GetPlaylistName(s32 playlistIndex)
{
	std::string result = std::string("");
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_iPodController)
		result = m_iPodController->GetPlaylistName(playlistIndex);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;	
}
	
void VoxIphoneInternal::iPod_SetPlaylist(s32 playlistIndex)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_iPodController)
		m_iPodController->SetPlaylist(playlistIndex);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());	
}	

s32 VoxIphoneInternal::iPod_GetArtistCount()
{
	s32 result = 0;
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_iPodController)
		result = m_iPodController->GetArtistCount();
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;
}
	
std::string VoxIphoneInternal::iPod_GetArtistName(s32 artistIndex)
{
	std::string result = std::string("");
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_iPodController)
		result = m_iPodController->GetArtistName(artistIndex);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;
}

void VoxIphoneInternal::iPod_SetArtist(s32 artistIndex)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_iPodController)
		m_iPodController->SetArtist(artistIndex);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}
	
s32 VoxIphoneInternal::iPod_GetAlbumCount()
{
	s32 result = 0;
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_iPodController)
		result = m_iPodController->GetAlbumCount();
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;
}
	
std::string VoxIphoneInternal::iPod_GetAlbumName(s32 albumIndex)
{
	std::string result = std::string("");
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_iPodController)
		result = m_iPodController->GetAlbumName(albumIndex);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;
}
	
void VoxIphoneInternal::iPod_SetAlbum(s32 albumIndex)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_iPodController)
		m_iPodController->SetAlbum(albumIndex);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());	
}
	
s32 VoxIphoneInternal::iPod_GetSongCount()
{
	s32 result = 0;
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_iPodController)
		result = m_iPodController->GetSongCount();
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;
}
	
std::string VoxIphoneInternal::iPod_GetSongName(s32 songIndex)
{
	std::string result = std::string("");
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_iPodController)
		result = m_iPodController->GetSongName(songIndex);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;
}
	
void VoxIphoneInternal::iPod_SetSong(s32 songIndex)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_iPodController)
		m_iPodController->SetSong(songIndex);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());	
}	
	
s32 VoxIphoneInternal::ConvertiPodState(s32 iPodNativeState)
{
	if(iPodNativeState == VoxIpodQueryState::k_nQueryRunning)
		return iPodNativeState;
		
	switch(iPodNativeState)
	{
		case MPMusicPlaybackStatePlaying:
		case MPMusicPlaybackStateSeekingForward:
		case MPMusicPlaybackStateSeekingBackward:
		{
			return VoxIpodState::k_nPlaying;
		}
		case MPMusicPlaybackStatePaused:
		case MPMusicPlaybackStateInterrupted:
		{
			return VoxIpodState::k_nPaused;
		}
		case MPMusicPlaybackStateStopped:
		{
			return VoxIpodState::k_nStopped;
		}			
	}
	
	return VoxIpodState::k_nOther;
}
	
s32 VoxIphoneInternal::iPod_GetPlaybackState()	
{
	if(m_iPodController)
		return ConvertiPodState(m_iPodController->GetPlaybackState());
	return ConvertiPodState(-1);
}
	
bool VoxIphoneInternal::iPod_IsAvailable()
{
	if(m_iPodController)
		return m_iPodController->IsAvailable();
	return false;	
}
	
std::string VoxIphoneInternal::iPod_GetNowPlayingItemTitle()
{
	if(m_iPodController)
		return m_iPodController->GetNowPlayingItemTitle();
	return std::string("");
}
	
std::string VoxIphoneInternal::iPod_GetNowPlayingItemArtist()
{
	if(m_iPodController)
		return m_iPodController->GetNowPlayingItemArtist();
	return std::string("");	
}
	
std::string VoxIphoneInternal::iPod_GetNowPlayingItemAlbumTitle()
{
	if(m_iPodController)
		return m_iPodController->GetNowPlayingItemAlbumTitle();
	return std::string("");	
}
	
f32 VoxIphoneInternal::iPod_GetNowPlayingCursorPosition()
{
	if(m_iPodController)
		return m_iPodController->GetNowPlayingCursorPosition();
	return 0.f;	
}
	
f32 VoxIphoneInternal::iPod_GetNowPlayingDuration()	
{
	if(m_iPodController)
		return m_iPodController->GetNowPlayingDuration();
	return 0.f;	
}	

s32 VoxIphoneInternal::iPod_GetNowPlayingItemData(std::string* title, std::string* artist, std::string* album, f32* cursorPosition, f32* playbackDuration)
{
	if(m_iPodController)
		return m_iPodController->GetNowPlayingItemData(title, artist, album, cursorPosition, playbackDuration);	
	return VoxIpodQueryState::k_nQueryError;	
}
	
s32 VoxIphoneInternal::iPod_GetPlaybackStateAsync()
{
	if(m_iPodController)
		return ConvertiPodState(m_iPodController->GetPlaybackStateAsync());	
	return VoxIpodQueryState::k_nQueryError;		
}	
	
void VoxIphoneInternal::iPod_SetShuffle(s32 shuffleMode)
{
	if(m_iPodController)
		m_iPodController->SetShuffleMode(shuffleMode);	
}

void VoxIphoneInternal::iPod_SetRepeat(s32 repeatMode)
{
	if(m_iPodController)
		m_iPodController->SetRepeatMode(repeatMode);		
}

}
