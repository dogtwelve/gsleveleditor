#include "StdAfx.h"
#include "vox_filesystem.h"
#include "vox_memory.h"
#if !defined(_NN_CTR)
#include "vox_zip_reader.h"
#endif
#include <stdlib.h>
#include <cstring>

namespace vox
{
IOFunc FileSystemInterface::m_IOFunc = IOFunc();
FileSystemInterface* FileSystemInterface::m_instance = 0;

FileSystemInterface* FileSystemInterface::GetInstance()
{
	if(!m_instance)
	{
		m_instance = VoxNewFileSystem();
	}
	return m_instance;
}

void FileSystemInterface::DestroyInstance()
{
	VOX_DELETE(m_instance);
	m_instance = 0;
}

FileSystemInterface::~FileSystemInterface()
{
	if(m_archive)
	{
		VOX_DELETE(m_archive);
		m_archive = 0;
	}
}

FileInterface* FileSystemInterface::OpenFile(c8* filename, VoxFileAccessMode mode)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileSystemInterface::OpenFile", vox::VoxThread::GetCurThreadId());
	void* fileptr = 0;
	FileInterface* fileinterface = 0;
	VOX_STRING fullpath("");

	if(m_directoriesStack.size() > 0)
	{
		fullpath = m_directoriesStack.back();
	}

	fullpath.append(filename);
	
#if !defined(_NN_CTR)
	if(m_archive && m_archiveFirst)
	{
		s32 baseOffset, fileSize;
		if(m_archive->getFileInfo(fullpath.c_str(), baseOffset, fileSize))
		{
			fileptr = FileSystemInterface::m_IOFunc.open(m_archive->getZipFileName(), mode);
			if(fileptr)
				fileinterface = VOX_NEW FileLimited(fileptr, fullpath.c_str(), baseOffset, fileSize);
		}
	}
#endif

	if(!fileptr)
	{
		fileptr = FileSystemInterface::m_IOFunc.open(fullpath.c_str(), mode);
		if(fileptr)
			fileinterface = VOX_NEW FileInterface(fileptr, fullpath.c_str());
	}

#if !defined(_NN_CTR)
	if(m_archive && !m_archiveFirst && !fileptr)
	{
		s32 baseOffset, fileSize;
		if(m_archive->getFileInfo(fullpath.c_str(), baseOffset, fileSize))
		{
			fileptr = FileSystemInterface::m_IOFunc.open(m_archive->getZipFileName(), mode);
			if(fileptr)
				fileinterface = VOX_NEW FileLimited(fileptr, fullpath.c_str(), baseOffset, fileSize);
		}
	}
#endif
	
	if(!fileinterface && fileptr)
	{
		FileSystemInterface::m_IOFunc.close(fileptr);
	}

	return fileinterface;
}

s32 FileSystemInterface::CloseFile(FileInterface* fileInterface)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileSystemInterface::CloseFile", vox::VoxThread::GetCurThreadId());
	if(fileInterface)
	{
		void* filePtr= fileInterface->GetFilePtr();
		if(filePtr)
			FileSystemInterface::m_IOFunc.close(filePtr);
		VOX_DELETE(fileInterface);
		return 0;
	}

	return -1;
}

s32 FileSystemInterface::SetArchive(const c8* zipFileName, bool ignoreCase, bool ignorePath, bool tryArchiveFirst)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileSystemInterface::SetArchive", vox::VoxThread::GetCurThreadId());
	
#if defined(_NN_CTR)
	return -1;
#else
	if(m_archive)
	{
		VOX_DELETE(m_archive);
	}

	m_archive = VOX_NEW CZipReader(zipFileName, ignoreCase, ignorePath);
	m_archiveFirst = tryArchiveFirst;

	if(!m_archive->isValid())
	{
		VOX_DELETE(m_archive);
		m_archive = 0;
		m_archiveFirst = false;
		return -1;
	}
	else
	{
		return 0;
	}
#endif
}

s32 FileSystemInterface::PushDirectory(c8* directory)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileSystemInterface::PushDirectory", vox::VoxThread::GetCurThreadId());
	if(directory)
	{
		m_directoriesStack.push_back(VOX_STRING(directory));
		return 0;
	}
	return -1;
}

s32 FileSystemInterface::PopDirectory()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileSystemInterface::PopDirectory", vox::VoxThread::GetCurThreadId());
	if(m_directoriesStack.size() > 0)
	{
		m_directoriesStack.pop_back();
	}

	return -1;
}

s32 FileSystemInterface::GetDirectory(c8* dest, s32 size, c8* fullPath)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileSystemInterface::GetDirectory", vox::VoxThread::GetCurThreadId());
	if(!dest || !fullPath)
	{
		return -1;
	}

	c8* marker = std::strrchr(fullPath, '/');
	
	if(marker)
	{
		s32 directorySize = marker - fullPath;
		directorySize++;
		if(directorySize + 1 > size)//doesn't fit
		{
			return -1;
		}
		
		std::memcpy(dest, fullPath, directorySize);
		dest[directorySize] = 0;
		return 0;
	}
	else
	{
		std::strcpy(dest, "");
	}

	return -1;
}

// FileInterface
s32 FileInterface::Read(void* dest, s32 size, s32 count)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileInterface::Read", vox::VoxThread::GetCurThreadId());
	if(m_filePtr && dest && FileSystemInterface::m_IOFunc.read)
	{
		return FileSystemInterface::m_IOFunc.read(dest, size, count, m_filePtr);
	}

	return 0;
}

s32 FileInterface::Seek(s32 offset, VoxFileSeekOrigin origin)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileInterface::Seek", vox::VoxThread::GetCurThreadId());
	if(m_filePtr && FileSystemInterface::m_IOFunc.seek)
	{
		return FileSystemInterface::m_IOFunc.seek(m_filePtr, offset, origin);
	}

	return -1;
}

s32 FileInterface::Tell()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileInterface::Tell", vox::VoxThread::GetCurThreadId());
	if(m_filePtr && FileSystemInterface::m_IOFunc.tell)
	{
		return FileSystemInterface::m_IOFunc.tell(m_filePtr);
	}
	return -1;
}

s32 FileInterface::Write(const void * dest, s32 size, s32 count)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileInterface::Write", vox::VoxThread::GetCurThreadId());
	if(m_filePtr && dest && FileSystemInterface::m_IOFunc.write)
	{
		return FileSystemInterface::m_IOFunc.write(dest, size, count, m_filePtr);
	}

	return 0;
}

//

FileLimited::FileLimited()
:FileInterface()
, m_baseOffset(0)
, m_fileSize(0)
, m_filePosition(0)
{
	m_type = k_nLimitedFile;
}

FileLimited::FileLimited(void* filePtr, const char* fullpath, s32 baseOffset, s32 fileSize)
:FileInterface(filePtr, fullpath)
, m_baseOffset(baseOffset)
, m_fileSize(fileSize)
, m_filePosition(0)
{
	m_type = k_nLimitedFile;
	Seek(0, k_nSeekSet);
}

s32 FileLimited::Read(void* dest, s32 size, s32 count)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileLimited::Read", vox::VoxThread::GetCurThreadId());
	if( size* count + m_filePosition <= m_fileSize)
	{
		s32 readcount = FileSystemInterface::m_IOFunc.read(dest, size, count, m_filePtr);
		m_filePosition += readcount * size;
		return readcount;
	}
	else
	{
		s32 remainingcount = (m_fileSize - m_filePosition) / size;
		if( remainingcount > 0)
		{
			s32 readcount = FileSystemInterface::m_IOFunc.read(dest, size, remainingcount, m_filePtr);
			m_filePosition += readcount * size;
			return readcount;
		}
	}

	return 0;
}

s32 FileLimited::Seek(s32 offset, VoxFileSeekOrigin origin)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_IO, "FileLimited::Seek", vox::VoxThread::GetCurThreadId());
	s32 pos;
	s32 nextPos;

	switch(origin)
	{
		case k_nSeekSet:
		{
			if( offset > m_fileSize )
			{
				m_filePosition = m_fileSize;
				return -1;
			}
			else if (offset < 0)
			{
				m_filePosition = -1;
				return -1;
			}
			else
			{
				pos = m_baseOffset + offset;
				nextPos = offset;
			}		
			break;
		}
		case k_nSeekCur:
		{
			if( m_filePosition + offset > m_fileSize )
			{
				m_filePosition = m_fileSize;
				return -1;
			}
			else if (m_filePosition + offset < 0)
			{
				m_filePosition = -1;
				return -1;
			}
			else
			{
				pos = m_baseOffset + m_filePosition + offset;
				nextPos = m_filePosition + offset;
			}	
			break;
		}
		case k_nSeekEnd:
		{
			if( (-offset) > m_fileSize )
			{
				m_filePosition = -1;
				return -1;
			}
			else if (offset > 0)
			{
				m_filePosition = m_fileSize;
				return -1;
			}
			else
			{
				pos = m_baseOffset + m_fileSize + offset;
				nextPos = m_fileSize + offset;
			}		
			break;
		}
		default:
			return -1;
	}

	s32 result = FileSystemInterface::m_IOFunc.seek(m_filePtr, pos, k_nSeekSet);
	if(result == 0)
		m_filePosition = nextPos;

	return result;
}

s32 FileLimited::Tell()
{
	return m_filePosition;
}

}
