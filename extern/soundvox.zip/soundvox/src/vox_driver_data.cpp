#include "StdAfx.h"
#include "vox_default_config.h"

#if VOX_DRIVER_USE_DATA && VOX_DATA_DRIVER_PLATFORM

#include "vox_driver_data.h"

#include "vox_macro.h"
#include "vox_memory.h"
#include "vox.h"
#include <stdio.h>
#include <math.h>
#include "MSHeaders.h"

namespace vox {

DriverInterface* CreateDriver()
{
	return DriverData::GetInstance();
}



// *** DriverDataSource *** //
	
DriverDataSource::DriverDataSource(void * trackParam, void* driverParam, u32 sourceId):
DriverCallbackSourceInterface(trackParam, driverParam, sourceId)
{
	Init();
}


DriverDataSource::~DriverDataSource() //**-**
{
}


void DriverDataSource::PrintDebug()
{
}

	
// *** DriverData *** //

	
DriverData::DriverData():
m_outputType(k_nInvalidOutput),
m_outputDestination(0),
m_outputActive(false)
{
	Init(0);
}

DriverData::~DriverData()
{
	Shutdown();
}

void DriverData::Init(void* param)
{
	m_mutex.Lock();

	DriverCallbackInterface::Init(param);
	DriverCallbackSourceInterface::SetDriverSampleRate(VOX_DATA_DRIVER_PREFERRED_RATE);

	m_callbackBuffer = 0;
	m_callbackBufferSize = 0;
	m_dtError = 0.f;

	m_audioUnitActive = true;

	m_mutex.Unlock();
}

void DriverData::Shutdown()
{
	m_mutex.Lock();

	if(m_outputActive)
		CloseOutput();
	
	// Free static buffer
	if(m_callbackBuffer)
	{
		VOX_FREE(m_callbackBuffer);
		m_callbackBuffer = 0;
	}

	m_audioUnitActive = false;

	m_mutex.Unlock();
}

void DriverData::Suspend()
{

}

void DriverData::Resume()
{
	
}

DriverSourceInterface* DriverData::CreateDriverSource(void * trackParam, void* driverParam, s32 priority)
{
	m_mutex.Lock();
	
	DriverDataSource* driverSource = 0;

	if(m_audioUnitActive)
	{
		driverSource = VOX_NEW DriverDataSource(trackParam, driverParam, m_nextSourceId);
		if(driverSource)
		{
			m_activeSources.push_back(driverSource);
			m_nextSourceId++;
		}
	}

	m_mutex.Unlock();
	return driverSource;
}


void DriverData::DestroyDriverSource(DriverSourceInterface* driverSource)
{
	m_mutex.Lock();
	if(driverSource)
	{
		VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> >::iterator it = m_activeSources.begin();
		VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> >::iterator end = m_activeSources.end();

		for(; it != end; it++)
		{
			if(*it == driverSource)
			{
				m_activeSources.erase(it);
				break;
			}
		}

		VOX_DELETE((DriverDataSource *) driverSource);
	}
	m_mutex.Unlock();
}

void DriverData::PrintDebug()
{
}

DriverData* DriverData::s_instance = 0;
DriverData* DriverData::GetInstance()
{
	if(!s_instance)
	{
		s_instance = VOX_NEW DriverData();
	}
	return s_instance;
}

s32 DriverData::UpdateOutput(f32 dt)
{
	m_mutex.Lock();

	if(m_outputActive)
	{	
		dt += m_dtError;
		s32 neededsize = (s32(dt * (f32)(VOX_DATA_DRIVER_PREFERRED_RATE << 2)));
		neededsize &= ~0x3;//make sure it is a multiple of 4
		m_dtError = dt - ((f32)neededsize  / (f32)(VOX_DATA_DRIVER_PREFERRED_RATE << 2));
		
		if(neededsize > m_callbackBufferSize || !m_callbackBuffer)
		{
			if(m_callbackBuffer)
				VOX_FREE(m_callbackBuffer);

			m_callbackBuffer = (c8*)VOX_ALLOC(neededsize);
			if(m_callbackBuffer)
			{
				m_callbackBufferSize = neededsize;
			}
			else
			{
				m_callbackBufferSize = 0;
				m_mutex.Unlock();
				return 0;
			}
		}

		_FillBuffer((s16*)m_callbackBuffer, neededsize >> 2);
		fwrite(m_callbackBuffer, 1, neededsize, (FILE*)m_outputDestination);	
	}

	m_mutex.Unlock();
	return 0;
}

bool DriverData::SetOutputDestination(DriverDataOutputType type, void* param)
{
	m_mutex.Lock();

	m_outputType = type;
	if(m_outputType == k_nFileRAW || m_outputType == k_nFileWave)
	{
		m_outputDestination = VOX_ALLOC(strlen((const char*)param) + 1);
		if(m_outputDestination)
		{
			memset(m_outputDestination, 0, strlen((const char*)param) + 1);
			memcpy(m_outputDestination, param, strlen((const char*)param));
			VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
			return true;
		}
	}
	else if(m_outputType == k_nBuffer)
	{
		m_outputDestination = param;
	}

	m_mutex.Unlock();
	return false;
}

bool DriverData::OpenOutput()
{
	m_mutex.Lock();

	if(m_outputActive)
		CloseOutput();

	if(m_outputType == k_nFileWave || m_outputType == k_nFileRAW)
	{
		FILE* fp = fopen((const char*) m_outputDestination, "wb");
		if(!fp)
		{
			VOX_WARNING_LEVEL_1("Failed to open output destination type %d", m_outputType);
			m_outputType = k_nInvalidOutput;
		}
		else
		{
			VOX_FREE(m_outputDestination);
			m_outputDestination = (void*) fp;
			m_outputActive = true;
			if(m_outputType == k_nFileWave)
			{
				//write riff block
				RiffHeader riffHeader;
				memcpy(riffHeader.chunkId, "RIFF", 4);
				memcpy(riffHeader.riffType, "WAVE", 4);
				fwrite(&riffHeader, sizeof(RiffHeader), 1, (FILE*)m_outputDestination);
				//write fmt block
				FormatHeader formatHeader;
				memcpy(formatHeader.chunkId, "fmt ", 4);
				formatHeader.chunkDataSize = 16;
				formatHeader.compressionCode = 1;
				formatHeader.numChannels = 2;
				formatHeader.sampleRate = VOX_DATA_DRIVER_PREFERRED_RATE;
				formatHeader.avgBytesPerSample = VOX_DATA_DRIVER_PREFERRED_RATE << 2;
				formatHeader.blockAlign = 4;
				formatHeader.significantBitsPerSample = 16;
				fwrite(&formatHeader, sizeof(formatHeader), 1, (FILE*)m_outputDestination);
				//write data header
				memcpy(formatHeader.chunkId, "data", 4);
				fwrite(&formatHeader, 8, 1, (FILE*)m_outputDestination);
			}
		}
	}
	else
	{
		//not supported atm
		m_outputType = k_nInvalidOutput;
	}

	m_mutex.Unlock();
	return m_outputActive;
}

bool DriverData::CloseOutput()
{
	m_mutex.Lock();

	if(m_outputType == k_nFileWave)
	{
		if(m_outputDestination)
		{
			//need to fill header with correct size
			s32 curpos = (s32)ftell((FILE*)m_outputDestination);
			s32 riffsize = curpos - 8;
			s32 datasize = curpos - sizeof(RiffHeader) - sizeof(FormatHeader) - 8;
			
			fseek((FILE*)m_outputDestination, 4, SEEK_SET);
			fwrite(&riffsize, 4, 1, (FILE*)m_outputDestination);

			fseek((FILE*)m_outputDestination, sizeof(RiffHeader) + sizeof(FormatHeader) + 4, SEEK_SET);
			fwrite(&datasize, 4, 1, (FILE*)m_outputDestination);

			fseek((FILE*)m_outputDestination, curpos, SEEK_SET);

			fclose((FILE*)m_outputDestination);
		}
	}
	else if(m_outputType == k_nFileRAW)
	{
		if(m_outputDestination)
		{
			fclose((FILE*)m_outputDestination);
		}
	}

	m_outputActive = false;

	m_mutex.Unlock();
	return true;
}

	
}//namespace vox

#endif //VOX_DRIVER_USE_DATA && VOX_DATA_DRIVER_PLATFORM
