#include "StdAfx.h"
#include "vox_default_config.h"

#if VOX_DRIVER_USE_PS3_MULTISTREAM && VOX_PS3_MULTISTREAM_DRIVER_PLATFORM 

#include "vox_driver_ps3_multistream.h"
#include "vox_filesystem.h"
#include <stdlib.h>
#include <string.h>
#include "vox_macro.h"
#include "vox.h"
#include <stdio.h>
#include <math.h>

//*** DriverPS3MultiStreamSource ***//
namespace vox {

DriverPS3MultiStreamSource::DriverPS3MultiStreamSource(void * trackParam, void* driverParam, s32 sourceId):
m_sourceId(sourceId)
,m_state(DriverSource::STATE_INITIAL)
,m_useCellState(false)
,m_isInit(false)
,m_busId(k_nBusIdInvalid)
,m_workBufferSize(0)
#if VOX_DSP_ENABLE_OCCLUSION
,m_dspFilter(0)
#endif
{
	m_trackParams = *((TrackParams*)trackParam);
	if(driverParam != 0)
	{
		m_numBuffer = ((PS3MultiStreamSourceParam*)driverParam)->numBuffer;
	}
	else
	{
		m_numBuffer = VOX_DRIVER_SOURCE_NUM_BUFFER;
	}

	Init();
}

DriverPS3MultiStreamSource::~DriverPS3MultiStreamSource()
{
	Cleanup();
}

void DriverPS3MultiStreamSource::Play()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverPS3MultiStreamSource::Play", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_sourceId >= 0)
	{
		if(GetState() == DriverSource::STATE_PAUSED)
		{
			cellMSCoreSetPause(m_sourceId, CELL_MS_NOTPAUSED);
			return;
		}

		if(m_bufferList[m_currentReadBuffer].free)
		{
			VOX_WARNING_LEVEL_3("Can't start source %d, no data available", m_sourceId);
		}
		else
		{
			if(!m_isInit)
			{
				CellMSInfo MS_Info;

				BusManager* busMgr = BusManager::GetInstance();
				if(busMgr)
				{
					if(m_busId == k_nBusIdInvalid)
					{
						MS_Info.SubBusGroup = busMgr->GetBusId("CompressorApply");
					}
					else if(m_busId == k_nBusIdPresetSFX)
					{
						MS_Info.SubBusGroup = busMgr->GetBusId("SFX1");
					}
					else
					{
						MS_Info.SubBusGroup = m_busId;
					}

					if(MS_Info.SubBusGroup == k_nBusIdInvalid)
					{
						MS_Info.SubBusGroup = CELL_MS_MASTER_BUS;
					}

					/*MS_Info.FirstBuffer         = (void *)(m_workBuffer[0]);
					MS_Info.FirstBufferSize     = FillBuffer(m_workBuffer[0], m_workBufferSize); // size in bytes
					MS_Info.SecondBuffer        = (void *)(m_workBuffer[1]);
					MS_Info.SecondBufferSize    = FillBuffer(m_workBuffer[1], m_workBufferSize);*/

					MS_Info.Pitch               = m_trackParams.samplingRate;
					MS_Info.numChannels         = m_trackParams.numChannels;
					MS_Info.flags				= CELL_MS_STREAM_NOFLAGS;

					MS_Info.initialOffset		= 0;

					if(m_trackParams.bitsPerSample == 16)
						MS_Info.inputType = CELL_MS_16BIT_BIG;
					else if(m_trackParams.bitsPerSample == 32)
						MS_Info.inputType = CELL_MS_32BIT_FLOAT;

					cellMSStreamSetInfo(m_sourceId, &MS_Info);
				
					cellMSStreamSetCallbackFunc(m_sourceId, StreamCallback);
					cellMSStreamSetCallbackData(m_sourceId, (void*)this);

					m_isInit = true;
				}
				else
				{
					m_state = DriverSource::STATE_ERROR;
				}
			}

			if(m_state != DriverSource::STATE_ERROR)
			{
				if(m_trackParams.numChannels == 1)
				{
					cellMSCoreSetVolume1(m_sourceId, CELL_MS_DRY, CELL_MS_SPEAKER_FL, CELL_MS_CHANNEL_0, 1.0f);
					cellMSCoreSetVolume1(m_sourceId, CELL_MS_WET, CELL_MS_SPEAKER_FL, CELL_MS_CHANNEL_0, 0.0f);
					cellMSCoreSetBypass(m_sourceId, CELL_MS_DRY, CELL_MS_BYPASSED);
					cellMSCoreSetBypass(m_sourceId, CELL_MS_WET, CELL_MS_NOTBYPASSED);
					if(m_busId == k_nBusIdPresetSFX)
					{
						f32 presetSFX1, presetSFX2, presetSFX3;
						DriverPS3MultiStream::s_sfxPreset.GetPresetValue(presetSFX1, presetSFX2, presetSFX3);

						s32 ret = cellMSStreamSetRoutingWet(m_sourceId, BUS_SFX1, presetSFX1);
						CELLMS_ERROR(ret);
						ret = cellMSStreamSetRoutingDry(m_sourceId, BUS_SFX1, 0.0f);
						CELLMS_ERROR(ret);

						ret = cellMSStreamSetRoutingWet(m_sourceId, BUS_SFX2, presetSFX2);
						CELLMS_ERROR(ret);
						ret = cellMSStreamSetRoutingDry(m_sourceId, BUS_SFX2, 0.0f);
						CELLMS_ERROR(ret);

						ret = cellMSStreamSetRoutingWet(m_sourceId, BUS_SFX3, presetSFX3);
						CELLMS_ERROR(ret);
						ret = cellMSStreamSetRoutingDry(m_sourceId, BUS_SFX3, 0.0f);
						CELLMS_ERROR(ret);
					}
					else if(m_busId != k_nBusIdInvalid)
					{
						s32 ret = cellMSStreamSetRoutingWet(m_sourceId, m_busId, 1.0f);
						CELLMS_ERROR(ret);
						ret = cellMSStreamSetRoutingDry(m_sourceId, m_busId, 0.0f);
						CELLMS_ERROR(ret);
					}

	#if	VOX_DSP_ENABLE_OCCLUSION
					if(!m_dspFilter && m_busId == k_nBusIdPresetSFX)
					{					
						m_dspFilter = VOX_NEW DSPOcclusion();
						if(m_dspFilter)
							m_dspFilter->Load(m_sourceId, CELL_MS_DSP_SLOT_0, VoxDSP::k_nFilter);
					}
	#endif
				}
				else if(m_trackParams.numChannels == 2)
				{
					cellMSCoreSetVolume1(m_sourceId, CELL_MS_DRY, CELL_MS_SPEAKER_FL, CELL_MS_CHANNEL_0, m_gain);
					cellMSCoreSetVolume1(m_sourceId, CELL_MS_DRY, CELL_MS_SPEAKER_FR, CELL_MS_CHANNEL_1, m_gain);
					cellMSCoreSetBypass(m_sourceId, CELL_MS_WET, CELL_MS_BYPASSED);
				}
				else if(m_trackParams.numChannels == 4)
				{
					cellMSCoreSetVolume1(m_sourceId, CELL_MS_DRY, CELL_MS_SPEAKER_FL, CELL_MS_CHANNEL_0, m_gain );
					cellMSCoreSetVolume1(m_sourceId, CELL_MS_DRY, CELL_MS_SPEAKER_FR, CELL_MS_CHANNEL_1, m_gain );
					cellMSCoreSetVolume1(m_sourceId, CELL_MS_DRY, CELL_MS_SPEAKER_RL, CELL_MS_CHANNEL_2, m_gain );
					cellMSCoreSetVolume1(m_sourceId, CELL_MS_DRY, CELL_MS_SPEAKER_RR, CELL_MS_CHANNEL_3, m_gain );
					cellMSCoreSetBypass(m_sourceId, CELL_MS_WET, CELL_MS_BYPASSED);
				}

				memset(m_workBuffer[0], 0, m_workBufferSize);
				cellMSStreamSetFirstReadSkip(m_sourceId, m_workBuffer[0], m_workBufferSize, m_workBufferSize / ((m_trackParams.bitsPerSample >> 3)*m_trackParams.numChannels), 0);
				s32 fillsize = FillBuffer(m_workBuffer[1], m_workBufferSize);
				cellMSStreamSetSecondRead(m_sourceId, m_workBuffer[1], fillsize);

				cellMSStreamPlay(m_sourceId);
				m_useCellState = true;
			}
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverPS3MultiStreamSource::Stop()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverPS3MultiStreamSource::Stop", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_sourceId >= 0)
	{
		FreeAllBuffer();
		cellMSStreamSetSecondRead(m_sourceId, 0, 0);
		m_useCellState = true;
		m_processedBytes = 0;
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverPS3MultiStreamSource::Pause()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverPS3MultiStreamSource::Pause", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_sourceId >= 0)
	{
		cellMSCoreSetPause(m_sourceId, CELL_MS_PAUSED);
		m_useCellState = true;
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverPS3MultiStreamSource::Reset()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_sourceId >= 0)
	{
		FreeAllBuffer();
	}

	m_useCellState = false;				// Force state to DriverSource::STATE_INITIAL
	m_processedBytes = 0;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

s32 DriverPS3MultiStreamSource::GetState()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverPS3MultiStreamSource::GetState", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	s32 result = DriverSource::STATE_ERROR;
	
	if(m_sourceId >= 0 && m_state != DriverSource::STATE_ERROR)
	{
		if(m_useCellState)
		{
			u32 state = (u32)cellMSStreamGetStatus(m_sourceId);
			result = ConvertSourceState(state);
		}
		else
		{
			result = DriverSource::STATE_INITIAL;
		}
		
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;
}

bool DriverPS3MultiStreamSource::NeedData()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	bool result = false;

	if(m_state != DriverSource::STATE_ERROR && m_numBuffer > 0) //Check if next buffer is free
	{
		result = m_bufferList[m_currentWriteBuffer].free;
	}

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;
}

void DriverPS3MultiStreamSource::UploadData(void* soundData, s32 bufferSize)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverPS3MultiStreamSource::UploadData", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_sourceId < 0)
	{
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return;
	}

	if(m_state == DriverSource::STATE_ERROR)
	{
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return;
	}

	//check that current writebuffer is free
	if(!m_bufferList[m_currentWriteBuffer].free)
	{
		VOX_WARNING_LEVEL_3("Trying to upload to source %d, but no buffer free", m_sourceId);
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return;
	}

	m_bufferList[m_currentWriteBuffer].m_data = (u8*)soundData;
	m_bufferList[m_currentWriteBuffer].m_usedSize = bufferSize;
	m_bufferList[m_currentWriteBuffer].m_totalSize = bufferSize;
	m_bufferList[m_currentWriteBuffer].m_cursorPos = 0;
	m_bufferList[m_currentWriteBuffer].free = false;
	m_currentWriteBuffer++;
	m_currentWriteBuffer %= m_numBuffer;

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverPS3MultiStreamSource::SetGain(f32 gain)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverPS3MultiStreamSource::SetGain", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_sourceId >= 0)
	{
		//gain must be in [0.0f .. 1.0f]
		if(gain > 1.0f)
			m_gain = 1.0f;
		else if(m_gain < 0.f)
			m_gain = 0.f;
		else
			m_gain = gain;

		if(m_trackParams.numChannels == 1)//surround
		{
			cellMSSurroundSourcef(m_sourceId, CELL_MS_SURROUND_GAIN, m_gain);
		}
		if(m_trackParams.numChannels == 2)
		{
			cellMSCoreSetVolume1(m_sourceId, CELL_MS_DRY, CELL_MS_SPEAKER_FL, CELL_MS_CHANNEL_0, m_gain);
			cellMSCoreSetVolume1(m_sourceId, CELL_MS_DRY, CELL_MS_SPEAKER_FR, CELL_MS_CHANNEL_1, m_gain);
		}
		else if(m_trackParams.numChannels == 4)
		{
			cellMSCoreSetVolume1(m_sourceId, CELL_MS_DRY, CELL_MS_SPEAKER_FL, CELL_MS_CHANNEL_0, m_gain );
			cellMSCoreSetVolume1(m_sourceId, CELL_MS_DRY, CELL_MS_SPEAKER_FR, CELL_MS_CHANNEL_1, m_gain );
			cellMSCoreSetVolume1(m_sourceId, CELL_MS_DRY, CELL_MS_SPEAKER_RL, CELL_MS_CHANNEL_2, m_gain );
			cellMSCoreSetVolume1(m_sourceId, CELL_MS_DRY, CELL_MS_SPEAKER_RR, CELL_MS_CHANNEL_3, m_gain );
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverPS3MultiStreamSource::SetPitch(f32 pitch)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverPS3MultiStreamSource::SetPitch", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_sourceId >= 0)
	{
		//pitch must be in (0.0f .. 2.0f]
		if(m_userPitch > 2.0f)
			m_userPitch = 2.0f;
		else if(m_userPitch <= 0.f)
			m_userPitch = 0.01f;
		else
			m_userPitch = pitch;

		if(m_trackParams.numChannels == 1)//surround
		{
			cellMSSurroundSourcef(m_sourceId, CELL_MS_SURROUND_PITCH, m_userPitch);
		}
		else //not surround
		{
			cellMSStreamSetPitch(m_sourceId, (const s32)(m_userPitch * m_trackParams.samplingRate));
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

f32 DriverPS3MultiStreamSource::GetGain()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	f32 result =  m_gain;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;	
}

f32 DriverPS3MultiStreamSource::GetPitch()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	f32 result =  m_userPitch;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return result;		
}
	
long DriverPS3MultiStreamSource::GetByteOffset()
{
	s32 value = 0;
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	//if(m_sourceId)
	//{
	//	ALint buffersProcessed, state;
	//	alGetSourcei(m_sourceId, AL_SOURCE_STATE, &state);
	//	LOG_OPENAL_ERROR;
	//	if(state != AL_STOPPED)
	//	{
	//		alGetSourcei(m_sourceId,AL_BYTE_OFFSET, &value);
	//		LOG_OPENAL_ERROR;
	//	}
	//	else
	//	{
	//		alGetSourcei(m_sourceId, AL_BUFFERS_PROCESSED, &buffersProcessed);
	//		LOG_OPENAL_ERROR;
	//		OpenALBuffer* buffer;
	//		ALuint bid;
	//		for(s32 i = 0; i < m_param.numBuffer && buffersProcessed > 0; i++)
	//		{
	//			alSourceUnqueueBuffers(m_sourceId, 1, &bid);
	//			LOG_OPENAL_ERROR;
	//			buffer = GetBuffer(bid);
	//			if(buffer)
	//			{
	//				m_processedBytes += buffer->size;
	//				buffer->queued = false;
	//			}

	//			alGetSourcei(m_sourceId, AL_BUFFERS_PROCESSED, &buffersProcessed);
	//			LOG_OPENAL_ERROR;
	//		}
	//	}
	//}
	value += m_processedBytes; //Need to find more precise mesure (up to 21ms too far)
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return value;
}

void DriverPS3MultiStreamSource::SetByteOffset(s32 offset)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_processedBytes = offset;
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverPS3MultiStreamSource::Init()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverPS3MultiStreamSource::Init", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	m_gain = 1.0f;
	m_userPitch = 1.0f;
	
	m_currentWriteBuffer = 0;
	m_currentReadBuffer = 0;

	m_workBufferSize = VOX_PS3_MULTISTREAM_BUFFER_SAMPLE * m_trackParams.numChannels * (m_trackParams.bitsPerSample >> 3);

	s32 buffersize = VOX_EMITTER_BUFFER_DURATION_MS * m_trackParams.samplingRate * m_trackParams.numChannels * (m_trackParams.bitsPerSample >> 3) / 1000;
	//make buffersize a multiple of sample size
	buffersize -= (buffersize % (m_trackParams.numChannels * (m_trackParams.bitsPerSample >> 3)));

	VOX_ASSERT_MSG(buffersize > m_workBufferSize * 2, "PS3 Multisource require buffer of 1024 samples per channel or more to work properly");
	
	m_currentWorkBuffer = 0;

	m_workBuffer[0] = (u8*)VOX_ALLOC(m_workBufferSize);
	m_workBuffer[1] = (u8*)VOX_ALLOC(m_workBufferSize);

	if(!m_workBuffer[0] || !m_workBuffer[1])
	{
		VOX_WARNING_LEVEL_3("Could not allocate all work buffer(%d) for emitter", m_workBufferSize);
		m_numBuffer = 0;
		m_state = DriverSource::STATE_ERROR;
		m_processedBytes = 0;

		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());

		return;
	}

	if(m_sourceId >= 0)
	{
		for(int i = 0; i < m_numBuffer; i++)
		{
			PS3MultiStreamBuffer newBuffer;
			newBuffer.free = true;
			newBuffer.m_cursorPos = 0;
			newBuffer.m_totalSize = buffersize;
			newBuffer.m_usedSize = 0;
			m_bufferList.push_back(newBuffer);
		}
		if(m_numBuffer != m_bufferList.size())
		{
			VOX_WARNING_LEVEL_3("Could not allocate all buffer for source % d : %d allocated on %d", m_sourceId, m_bufferList.size(), m_numBuffer);
		}

		m_numBuffer = m_bufferList.size();

		if(m_numBuffer <= 0)
		{
			m_state = DriverSource::STATE_ERROR; // No buffer allocated
		}
		else
		{
			//Create stream
			m_sourceId = cellMSStreamOpen();

			if(m_sourceId == -1)
			{
				VOX_WARNING_LEVEL_3("Could not get a channel for new source",0);
				m_state = DriverSource::STATE_ERROR;
			}
			else if(m_trackParams.numChannels == 1)//create surround
			{
				cellMSSurroundActive(m_sourceId,CELL_MS_SURROUND_ACTIVE_STREAM,0,CELL_MS_DRY);
			}
		}
	}

	m_processedBytes = 0;

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverPS3MultiStreamSource::Cleanup()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());

	if(m_sourceId >= 0)
	{
		cellMSStreamClose(m_sourceId);
	}

	m_bufferList.clear();

	if(m_workBuffer[0])
		VOX_FREE(m_workBuffer[0]);
	if(m_workBuffer[1])
		VOX_FREE(m_workBuffer[1]);

#if VOX_DSP_ENABLE_OCCLUSION
	if(m_dspFilter)
		VOX_DELETE(m_dspFilter);
#endif

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

s32 DriverPS3MultiStreamSource::ConvertSourceState(u32 state)
{
	if ( state == (CELL_MS_STREAM_ON))
	{
		return DriverSource::STATE_PLAYING;
	}
	else if (state == (CELL_MS_STREAM_OFF))
	{
		return DriverSource::STATE_STOPPED;
	}
	else if (state == (CELL_MS_STREAM_ON | CELL_MS_STREAM_PENDING))
	{
		return DriverSource::STATE_PLAYING;
	}
	else if(state == (CELL_MS_STREAM_ON | CELL_MS_STREAM_PAUSE))
	{
		return DriverSource::STATE_PAUSED;
	}
	else
	{
		VOX_WARNING_LEVEL_3("Unknown state : 0x%x", state);
		return DriverSource::STATE_ERROR;
	}
}

void DriverPS3MultiStreamSource::FreeAllBuffer()
{
	for(int i = 0; i < m_numBuffer; i++)
	{
		m_bufferList[i].free = true;
		m_currentReadBuffer = 0;
		m_currentWriteBuffer = 0;
	}
}


void DriverPS3MultiStreamSource::FreeDisposableData(s32 maxNbBytes, s32 &nbBuffersFreed, s32 &nbBytesFreed)
{
	ScopeMutex sm(&m_mutex);

	nbBuffersFreed = 0;
	nbBytesFreed = 0;

	if(maxNbBytes <= 0)
		return;

	s32 bufferIndex;
	s32 nbBytesInBuffer;
	s32 cursorPosition;					// In bytes
	s32 nbBytesFromCurrentPosition = 0;
	s32 nbBytesFromEnd = 0;
	s32 nbBytesInPreviousBuffers = 0;
	s32 earliestDisposableBuffer = -1;	// Buffer containing position = current cursor + safety margin.
	s32 earliestDisposablePosition = 0;	// Position of current cursor + safety margin in 'earliestBuffer'

	// Get a safety margin (in bytes) equivalent to VOX_NATIVE_LATENCY_SAFETY_MARGIN driver callbacks
	s32 safetyMargin = m_workBufferSize * VOX_NATIVE_LATENCY_SAFETY_MARGIN;
	
	// Determine the the earliest buffer (and position) where data can be overwritten
	bufferIndex = m_currentReadBuffer;
	for(s32 i = 0; i < m_numBuffer; i++)
	{
		if(!m_bufferList[bufferIndex].free)
		{
			nbBytesInBuffer = m_bufferList[bufferIndex].m_usedSize;
			cursorPosition = m_bufferList[bufferIndex].m_cursorPos;
			nbBytesFromCurrentPosition += nbBytesInBuffer - cursorPosition;

			if(nbBytesFromCurrentPosition > safetyMargin)
			{
				earliestDisposableBuffer = bufferIndex;
				earliestDisposablePosition = cursorPosition + safetyMargin - nbBytesInPreviousBuffers;
				break;
			}
		}

		bufferIndex = (bufferIndex + 1) % m_numBuffer;
		nbBytesInPreviousBuffers = nbBytesFromCurrentPosition;
	}

	// Free buffers starting with buffer following read buffer
	nbBytesInPreviousBuffers = 0;
	bufferIndex = m_currentReadBuffer == 0 ? m_numBuffer - 1 : m_currentReadBuffer - 1;

	for(s32 i = 0; i < m_numBuffer; i++)
	{
		if(!m_bufferList[bufferIndex].free)
		{
			nbBytesInBuffer = m_bufferList[bufferIndex].m_usedSize;
			cursorPosition = m_bufferList[bufferIndex].m_cursorPos;
			nbBytesFromEnd += nbBytesInBuffer - cursorPosition;

			if(bufferIndex == earliestDisposableBuffer)
			{
				if(cursorPosition + nbBytesFromEnd - maxNbBytes < earliestDisposablePosition)
				{
					m_bufferList[bufferIndex].m_usedSize = earliestDisposablePosition;
					if(earliestDisposablePosition == 0)
					{
						m_bufferList[bufferIndex].free = true;
						nbBuffersFreed++;
						m_currentWriteBuffer = bufferIndex;
					}
					else
					{
						m_currentWriteBuffer = (bufferIndex + 1) % m_numBuffer;
					}
				}
				else
				{
					m_bufferList[bufferIndex].m_usedSize = cursorPosition + nbBytesFromEnd - maxNbBytes;
					m_currentWriteBuffer = (bufferIndex + 1) % m_numBuffer;
				}

				nbBytesFreed += nbBytesInBuffer - m_bufferList[bufferIndex].m_usedSize;
				break;
			}
			else // Buffer is not the earliest disposable buffer
			{
				if(nbBytesFromEnd < maxNbBytes) // Buffer can be freed completely
				{
					m_bufferList[bufferIndex].free = true;
					nbBuffersFreed++;
					nbBytesFreed += nbBytesInBuffer;
				}
				else // Part of the buffer can be overwritten
				{
					m_bufferList[bufferIndex].m_usedSize = cursorPosition + nbBytesFromEnd - maxNbBytes;
					nbBytesFreed += nbBytesInBuffer - m_bufferList[bufferIndex].m_usedSize;
					m_currentWriteBuffer = (bufferIndex + 1) % m_numBuffer;
					break;
				}
			}
			nbBytesInPreviousBuffers = nbBytesFromEnd;
		}

		bufferIndex = bufferIndex == 0 ? m_numBuffer - 1 : bufferIndex - 1;
	}
}


void DriverPS3MultiStreamSource::ReleaseSource()
{
//#if VOX_OPENAL_ENABLE_SOURCE_POOL
//	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
//	if(m_sourceId)
//	{
//		alSourceStop(m_sourceId);
//		LOG_OPENAL_ERROR;
//		alSourcei(m_sourceId,AL_BUFFER,0);
//		LOG_OPENAL_ERROR;
//		m_sourceId = 0;
//	}
//	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
//#endif
}

void DriverPS3MultiStreamSource::Set3DParameter(s32 paramId, void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverPS3MultiStreamSource::Set3DParameter", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_sourceId >= 0)
	{
		switch(paramId)
		{
			case Vox3DEmitterParameter::k_nRelativeToListener:
			{
				u32 value = *((u32*)param);
				VOX_WARNING_LEVEL_5("Setting AL_SOURCE_RELATIVE for %d to %d", m_sourceId, value);
				cellMSSurroundSourcef(m_sourceId,CELL_MS_SURROUND_SOURCE_RELATIVE, value == 0 ? CELL_MS_SURROUND_FALSE : CELL_MS_SURROUND_TRUE);
				//LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DEmitterParameter::k_nMaxDistance:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting CELL_MS_SURROUND_MAX_DISTANCE for %d to %f", m_sourceId, value);
				cellMSSurroundSourcef(m_sourceId, CELL_MS_SURROUND_MAX_DISTANCE, value);
				//LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DEmitterParameter::k_nReferenceDistance:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting CELL_MS_SURROUND_REFERENCE_DISTANCE for %d to %f", m_sourceId, value);
				cellMSSurroundSourcef(m_sourceId, CELL_MS_SURROUND_REFERENCE_DISTANCE, value);
				//LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DEmitterParameter::k_nRolloffFactor:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting CELL_MS_SURROUND_ROLLOFF_FACTOR for %d to %f", m_sourceId, value);
				cellMSSurroundSourcef(m_sourceId, CELL_MS_SURROUND_ROLLOFF_FACTOR, value);
				//LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DEmitterParameter::k_nInnerConeAngle:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting CELL_MS_SURROUND_CONE_INNER_ANGLE for %d to %f", m_sourceId, value);
				cellMSSurroundSourcef(m_sourceId, CELL_MS_SURROUND_CONE_INNER_ANGLE, value);
				//LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DEmitterParameter::k_nOuterConeAngle:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting CELL_MS_SURROUND_CONE_OUTER_ANGLE for %d to %f", m_sourceId, value);
				cellMSSurroundSourcef(m_sourceId, CELL_MS_SURROUND_CONE_OUTER_ANGLE, value);
				//LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DEmitterParameter::k_nOuterConeGain:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting CELL_MS_SURROUND_CONE_OUTER_GAIN for %d to %f", m_sourceId, value);
				cellMSSurroundSourcef(m_sourceId, CELL_MS_SURROUND_CONE_OUTER_GAIN, value);
				//LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DEmitterParameter::k_nPosition:
			{
				VoxVector3f* value = (VoxVector3f*)param;
				cellMSSurroundSource3f(m_sourceId, CELL_MS_SURROUND_POSITION, value->x, value->y, value->z );
				m_position = *value;
				//LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DEmitterParameter::k_nVelocity:
			{
				VoxVector3f* value = (VoxVector3f*)param;
				cellMSSurroundSource3f(m_sourceId, CELL_MS_SURROUND_VELOCITY, value->x, value->y, value->z );
				//LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DEmitterParameter::k_nDirection:
			{
				VoxVector3f* value = (VoxVector3f*)param;
				cellMSSurroundSource3f(m_sourceId, CELL_MS_SURROUND_DIRECTION, value->x, value->y, value->z );
				//LOG_OPENAL_ERROR;
				break;
			}
			default:
			{
				VOX_WARNING_LEVEL_4("PS3 MultiStream source doesn't support property %d", paramId);
				break;
			}
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverPS3MultiStreamSource::SetDSPParameter(s32 paramId, void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverPS3MultiStreamSource::SetDSPParameter", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());

	BusManager* pBusMgr = BusManager::GetInstance();

	if(m_sourceId >= 0 && pBusMgr)
	{
		switch(paramId)
		{
			case VoxDSPEmitterParameter::k_nBusId:
			{
				c8* value = (c8*)param;
				VOX_WARNING_LEVEL_5("Setting Bus for %d to %s", m_sourceId, value);
				if(strcasecmp(value, "SFX") == 0)
					m_busId = k_nBusIdPresetSFX;
				else
					m_busId = pBusMgr->GetBusId(value);

				//Should change routing dynamicly, currently only change bus for next play
				break;
			}
			default:
			{
				VOX_WARNING_LEVEL_4("PS3 MultiStream source doesn't support property %d", paramId);
				break;
			}
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverPS3MultiStreamSource::Update(f32 dt)
{
#if VOX_DSP_ENABLE_OCCLUSION
	if(m_dspFilter)
	{
		m_dspFilter->Update(dt);
	}
#endif
}

void DriverPS3MultiStreamSource::PrintDebug()
{
}

void DriverPS3MultiStreamSource::StreamCallback(s32 streamNumber, void * userData, s32 callbackType, void * pWriteBuffer, s32 nBufferSize)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverPS3MultiStreamSource::StreamCallback", vox::VoxThread::GetCurThreadId());
	if(callbackType == CELL_MS_CALLBACK_MOREDATA)
		((DriverPS3MultiStreamSource*)userData)->ProcessCallback(callbackType, nBufferSize);
	else
	{
		((DriverPS3MultiStreamSource*)userData)->ProcessCallback(callbackType, nBufferSize);
	}
}

void DriverPS3MultiStreamSource::ProcessCallback(s32 callbackType, s32 nBufferSize)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverPS3MultiStreamSource::ProcessCallback", vox::VoxThread::GetCurThreadId());

	if(m_sourceId >= 0 && callbackType == CELL_MS_CALLBACK_MOREDATA)
	{
		//f32* volume = cellMSCoreGetVolume8(m_sourceId, CELL_MS_DRY, CELL_MS_CHANNEL_0);
		if(m_trackParams.numChannels == 1)
		{
			CellMSSurroundInfo info;
			cellMSStreamGetSurroundInfo(m_sourceId, &info);

			f32 vol[8];

			memcpy(vol, info.volumes, 8*sizeof(f32));

			vol[3] = 0.f; //mute LFE
			vol[6] = info.distance; //mono with distance attenuation
			vol[7] = m_gain; //full volume mono

			s32 ret = cellMSCoreSetVolume8(m_sourceId, CELL_MS_WET, CELL_MS_WET_STREAM , vol);
			CELLMS_ERROR(ret);

			if(m_busId == k_nBusIdPresetSFX)
			{
				f32 presetSFX1, presetSFX2, presetSFX3;
				DriverPS3MultiStream::s_sfxPreset.GetPresetValue(presetSFX1, presetSFX2, presetSFX3);
				ret = cellMSStreamSetRoutingWet(m_sourceId, BUS_SFX1, presetSFX1);
				CELLMS_ERROR(ret);
				ret = cellMSStreamSetRoutingWet(m_sourceId, BUS_SFX2, presetSFX2);
				CELLMS_ERROR(ret);
				ret = cellMSStreamSetRoutingWet(m_sourceId, BUS_SFX3, presetSFX3);
				CELLMS_ERROR(ret);
			}
#if	VOX_DSP_ENABLE_OCCLUSION
			if(m_dspFilter)
			{
				m_dspFilter->SetDistanceAttenuation(info.distance);
			}
#endif
		}

		// Force nBufferSize to m_workBufferSize (see NOTE 1 below)
		nBufferSize = m_workBufferSize;

		{
			ScopeMutex sm(&m_mutex);
			int size = FillBuffer(m_workBuffer[m_currentWorkBuffer], nBufferSize);
			if( size > 0)
			{
				cellMSStreamSetSecondRead(m_sourceId, m_workBuffer[m_currentWorkBuffer], size);
				m_currentWorkBuffer = m_currentWorkBuffer ? 0 : 1;
			}
			else
			{
				cellMSStreamSetSecondRead(m_sourceId, 0, 0);
			}
		}
	}
}

s32 DriverPS3MultiStreamSource::FillBuffer(u8* buffer, s32 size)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverPS3MultiStreamSource::FillBuffer", vox::VoxThread::GetCurThreadId());
	s32 neededSize = size;
	if(!m_bufferList[m_currentReadBuffer].free)
	{
		while(neededSize > 0)
		{
			s32 availableBytes = m_bufferList[m_currentReadBuffer].m_usedSize - m_bufferList[m_currentReadBuffer].m_cursorPos;
			if( neededSize <= availableBytes)
			{
				memcpy(buffer + (size - neededSize), m_bufferList[m_currentReadBuffer].m_data + m_bufferList[m_currentReadBuffer].m_cursorPos, neededSize);
				m_bufferList[m_currentReadBuffer].m_cursorPos += neededSize;
				neededSize = 0;
			}
			else if(availableBytes > 0)
			{
				memcpy(buffer + (size - neededSize), m_bufferList[m_currentReadBuffer].m_data + m_bufferList[m_currentReadBuffer].m_cursorPos, availableBytes);
				neededSize -= availableBytes;
				m_bufferList[m_currentReadBuffer].m_cursorPos += availableBytes;
			}

			if(m_bufferList[m_currentReadBuffer].m_usedSize == m_bufferList[m_currentReadBuffer].m_cursorPos)
			{
				m_bufferList[m_currentReadBuffer].free = true;
				m_currentReadBuffer = (m_currentReadBuffer + 1) % m_numBuffer;
				if(m_bufferList[m_currentReadBuffer].free)
					break;
			}
		}
	}

	return size - neededSize;
}
}
//*** DriverPS3MultiStream ***//
//extern CellSpurs spurs;
extern CellSpurs* GetSpursStruct();
#if defined(_PS3) && VOX_DRIVER_USE_PS3_MULTISTREAM && !defined(MS_THREADED_SAMPLE) && VOX_PS3_INIT_SPURS
#include <sys/spu_initialize.h>
#include <cell/spurs/control.h>
#include <cell/spurs/task.h>
#include <cell/spurs/event_flag.h>
#endif

namespace vox
{

DriverInterface* CreateDriver()
{
	return VOX_NEW DriverPS3MultiStream();
}

/**********************************************************************************/
// MultiStream thread defines
/**********************************************************************************/
#define VOX_DRIVER_PS3_MS_STACK_SIZE              (0x4000) // 16 kb
#define VOX_DRIVER_PS3_MS_EXIT_CODE               (0xbee)
#define VOX_DRIVER_PS3_MS_SERVER_PRIO             (0)
/**********************************************************************************
MultiStreamUpdateThread

	This thread updates MultiStream and libAudio:

	1) Updates MultiStream to generate more PCM data.
	2) Any MultiStream callbacks are then called
	3) Output PCM data is sent to libaudio
	4) It waits (allowing other threads to run) for lib audio to process data before repeating process
**********************************************************************************/
bool s_receivedExitGameRequest = false;
bool s_multiStreamUpdateThreadRunning = false;

#include <sys/timer.h>

static void _Multi_Stream_Update_Thread(uint64_t param)
{
	uint64_t sleepTime = 1000000 / (60 * 32);
    cellAudioPortStart(param);
	while(!s_receivedExitGameRequest)
	{
		// cellMSSystemSignalSPU does not sleep if it returns 0 (system pause is on), 
		// so sleep here to allow other threads to process
		if(!cellMSSystemSignalSPU())
			sys_timer_usleep(sleepTime);

		cellMSSystemGenerateCallbacks();
	}
	cellAudioPortStop(param);
    s_multiStreamUpdateThreadRunning = false;
    sys_ppu_thread_exit(0);
}

#if defined(_PS3) && VOX_DRIVER_USE_PS3_MULTISTREAM && !defined(MS_THREADED_SAMPLE) && VOX_PS3_INIT_SPURS
#define	SPURS_SPU_NUM	1
#define	SPU_THREAD_GROUP_PRIORITY		250
CellSpurs spurs __attribute__((aligned (128)));

CellSpurs* GetSpursStruct()
{
	return &spurs;
}

void InitSPURS(void)
{
	int ret = -1;
	sys_ppu_thread_t	thread_id;
	int					ppu_thr_prio __attribute__((aligned (128)));  // information for the reverb

	sys_ppu_thread_get_id(&thread_id);
	ret = sys_ppu_thread_get_priority(thread_id, &ppu_thr_prio);
	if(ret != CELL_OK)
	{
		VOX_WARNING_LEVEL_1( " ERROR sys_ppu_thread_get_priority = 0x%x\n", ret );
		VOX_ASSERT(0);
	}
	VOX_WARNING_LEVEL_5(" thread_id = %d, ppu_thr_prio = %d\n", (int)thread_id, ppu_thr_prio );

	// Keep the SPURS_SPU_NUM value as low as possible (MultiStream uses a maximum of 1 SPU) to reduce 
	// priority conflicts when SPURS SPU thread groups are context switched in and out by the PS3 operating system.
	ret = cellSpursInitialize(&spurs, SPURS_SPU_NUM, SPU_THREAD_GROUP_PRIORITY, ppu_thr_prio-1, false);
	if(ret != CELL_OK)
	{
		VOX_WARNING_LEVEL_1( "******** ERROR cellSpursInitialize = 0x%x\n", ret );
		VOX_ASSERT(0);
	}
}
#endif

#if VOX_PS3_USE_SULPHA
/**********************************************************************************
InitSulpha

	Initialises memory and DECI3 connection for Sulpha audio debugger PC tool
**********************************************************************************/
// Commenting this will remove all Sulpha setup/shutdown.
// Leave this uncommented to be able to connect the Sulpha PC tool audio debugger to the application


//Amount of memory to supply to Sulpha as a buffer
#define SULPHA_MEMORYBUFFER_SIZE (1024 * 1024)
static void* s_pSulphaMemory = 0;

// Number of items (PCM data, streams, busses and DPS's) to name
#define SULPHA_NUM_NAMED_OBJECTS (70)
bool InitSulpha(unsigned int _memoryBufferSize, unsigned int _numNames)
{
	s_pSulphaMemory = VOX_ALLOC(_memoryBufferSize);
	if(!s_pSulphaMemory)
		return false;

	s32 result = cellMSSulphaInit(s_pSulphaMemory, _memoryBufferSize, _numNames);
	VOX_WARNING_LEVEL_5("cellMSSulphaInit returned %d\n", result);

	// As well as using the Sulpha DECI3 connection, it is also possible to 
	// write directly to a file using cellMSSulphaFileConnect/Disconnect.
	result = cellMSSulphaDECI3Start();
	VOX_WARNING_LEVEL_5("cellMSSulphaDECI3Start returned %d\n", result);

	return true;
}

void CloseSulpha()
{
	if(!s_pSulphaMemory)
		return;

	cellMSSulphaShutdown();

	VOX_FREE(s_pSulphaMemory);
}
#endif //VOX_PS3_USE_SULPHA

#define VOX_DRIVER_PS3_MS_LISTENER_ID	(0)
#define VOX_DRIVER_PS3_MS_MAX_SUBS		(31)

PS3SFXPreset DriverPS3MultiStream::s_sfxPreset = PS3SFXPreset();

DriverPS3MultiStream::DriverPS3MultiStream():
m_multiStreamPuThread(0)
,m_pMultiStreamMemory(NULL)
,m_pMSSurroundMemory(NULL)
,m_portNum(-1)
,m_pBusMgr(0)
,m_driverActive(false)
{
	Init(0);
}

DriverPS3MultiStream::~DriverPS3MultiStream()
{
	Shutdown();
}

void DriverPS3MultiStream::Init(void* param)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());

	//Initialise all MS stuff


	// Initialise MultiStream
	if( InitialiseAudio(VOX_DRIVER_PS3_MS_MAX_STREAMS, VOX_DRIVER_PS3_MS_MAX_SUBS, m_portNum, audioParam, portConfig, CELL_MS_ROUTABLE_STREAMS_FLAG ) != 0 )
	{
		VOX_ASSERT_MSG(0, "ERROR starting PS3 multistream, exiting\n");
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return;
	}

	cellMSCoreRoutingInit(VOX_DRIVER_PS3_MS_BUS_MASK);

	FileSystemInterface* pfsps3 = FileSystemInterface::GetInstance();

	m_pBusMgr = BusManager::GetInstance();
	if(m_pBusMgr)
		m_pBusMgr->LoadFixedBuses();

	//Setting up surround
	s32 size = cellMSSurroundGetInfoSize(0, 1);		// 1 listener. 0 global sources
	m_pMSSurroundMemory = VOX_ALLOC_ALIGN(size, k_nVoxMemHint_Align16);

	if(!m_pMSSurroundMemory)
	{
		VOX_WARNING_LEVEL_1("ERROR creating Multistream surround buffer!!!\n",0);
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return;
	}

	cellMSSurroundInit(m_pMSSurroundMemory,0,1);	// Init Surround Sound with 1 listener and 0 global sources

	SetDefaultParameter();

	// create the MultiStream / libaudio update thread
	s32 nRet = sys_ppu_thread_create(&m_multiStreamPuThread, _Multi_Stream_Update_Thread, m_portNum, VOX_DRIVER_PS3_MS_SERVER_PRIO, VOX_DRIVER_PS3_MS_STACK_SIZE, SYS_PPU_THREAD_CREATE_JOINABLE, "MultiStream PU Thread");
	if(nRet)
	{
		VOX_WARNING_LEVEL_1("ERROR creating Multistream update thread!!!\n",0);
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return;
	}
	VOX_WARNING_LEVEL_5("Multistream thread (%d) created OK.\n", (int)m_multiStreamPuThread);

	m_driverActive = true;
	s_multiStreamUpdateThreadRunning = true;

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverPS3MultiStream::Shutdown()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());

#if VOX_PS3_USE_SULPHA
	CloseSulpha();
#endif

	s_receivedExitGameRequest = true;
	while(s_multiStreamUpdateThreadRunning) {sys_timer_usleep(16667);}

	if(m_pBusMgr)
		BusManager::Destroy();

	cellMSSurroundClose();

	void* pMemory = cellMSSystemClose();
	VOX_ASSERT(pMemory == m_pMultiStreamMemory);

	VoxFree( m_pMultiStreamMemory);
	VoxFree( m_pMSSurroundMemory);

	m_pMultiStreamMemory = NULL;
	m_pMSSurroundMemory = NULL; 
	pMemory = NULL;

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverPS3MultiStream::Suspend()
{
	//alcMakeContextCurrent(NULL);
	//LOG_OPENAL_ALC_ERROR;
	//alcSuspendContext(m_context);
	//LOG_OPENAL_ALC_ERROR;
}

void DriverPS3MultiStream::Resume()
{
	//alcMakeContextCurrent(m_context);
	//LOG_OPENAL_ALC_ERROR;
	//alcProcessContext(m_context);
	//LOG_OPENAL_ALC_ERROR;
}

DriverSourceInterface* DriverPS3MultiStream::CreateDriverSource(void * trackParam, void* driverParam, s32 priority)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverPS3MultiStream::CreateDriverSource", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	
	DriverPS3MultiStreamSource* driverSource = 0;

	if(m_driverActive)
	{
		driverSource = VOX_NEW DriverPS3MultiStreamSource(trackParam, driverParam);
	}

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return driverSource;
}

void DriverPS3MultiStream::Set3DParameter(s32 paramId, void* param)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	_Set3DParameter(paramId, param);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverPS3MultiStream::_Set3DParameter(s32 paramId, void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverPS3MultiStream::_Set3DParameter", vox::VoxThread::GetCurThreadId());
	if(m_driverActive)
	{
		switch(paramId)
		{
			case Vox3DGeneralParameter::k_nDopplerFactor:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting alDopplerFactor to %f", value);
				cellMSSurroundDopplerFactor(value);
				//LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DGeneralParameter::k_nSpeedOfSound:
			{
				f32 value = *((f32*)param);
				VOX_WARNING_LEVEL_5("Setting alSpeedOfSound to %f", value);
				cellMSSurroundSpeedOfSound(value);
				//LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DGeneralParameter::k_nDistanceModel: 
			{
				u32 value = GetPS3MS3DModel(*((u32*)param));
				VOX_WARNING_LEVEL_5("Setting alDistanceModel to %x", value);
				cellMSSurroundDistanceModel(value);
				//LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DGeneralParameter::k_nListenerPosition:
			{
				VoxVector3f* vector = (VoxVector3f*)param;
				cellMSSurroundListener3f(VOX_DRIVER_PS3_MS_LISTENER_ID, CELL_MS_SURROUND_POSITION, vector->x, vector->y, vector->z);
				//LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DGeneralParameter::k_nListenerVelocity:
			{
				VoxVector3f* vector = (VoxVector3f*)param;
				cellMSSurroundListener3f(VOX_DRIVER_PS3_MS_LISTENER_ID, CELL_MS_SURROUND_VELOCITY, vector->x, vector->y, vector->z);
				//LOG_OPENAL_ERROR;
				break;
			}
			case Vox3DGeneralParameter::k_nListenerOrientation:
			{
				VoxVector3f* vector = (VoxVector3f*)param;
				f32 orientation[6];
				orientation[0] = vector[0].x;
				orientation[1] = vector[0].y;
				orientation[2] = vector[0].z;
				orientation[3] = vector[1].x;
				orientation[4] = vector[1].y;
				orientation[5] = vector[1].z;
				cellMSSurroundListenerfv(VOX_DRIVER_PS3_MS_LISTENER_ID, CELL_MS_SURROUND_ORIENTATION, orientation);
				//LOG_OPENAL_ERROR;
				break;
			}
			default:
			{
				VOX_WARNING_LEVEL_4("PS3 MultiStream driver doesn't support 3d property %d", paramId);
				break;
			}
		}
	}
}

void DriverPS3MultiStream::SetDefaultParameter()
{
	VOX_WARNING_LEVEL_5("Setting default parameter to PS3 MultiStream driver", 0);
	f32 fvalue;
	u32 uivalue;

	// Doppler factor
	fvalue = VOX_DEFAULT_3D_DOPPLER_FACTOR;
	_Set3DParameter(Vox3DGeneralParameter::k_nDopplerFactor, &fvalue);

	// Speed of sound
	fvalue = VOX_DEFAULT_3D_SPEED_OF_SOUND;
	_Set3DParameter(Vox3DGeneralParameter::k_nSpeedOfSound, &fvalue);

	// 3D attenuation model
	uivalue = VOX_DEFAULT_3D_MODEL;
	_Set3DParameter(Vox3DGeneralParameter::k_nDistanceModel, &uivalue);	
	
	// Listener position
	f32 position[3] = VOX_DEFAULT_3D_LISTENER_POSITION;
	VoxVector3f positionv = VoxVector3f(position);
	_Set3DParameter(Vox3DGeneralParameter::k_nListenerPosition, &positionv);

	// Listener velocity
	f32 velocity[3] = VOX_DEFAULT_3D_LISTENER_VELOCITY;
	VoxVector3f velocityv = VoxVector3f(velocity);
	_Set3DParameter(Vox3DGeneralParameter::k_nListenerVelocity, &velocityv);

	// Listener Orientation
	f32 lookat[3] = VOX_DEFAULT_3D_LISTENER_LOOKAT;
	f32 up[3] = VOX_DEFAULT_3D_LISTENER_UP;
	VoxVector3f orientationv[2];
	orientationv[0] = VoxVector3f(lookat);
	orientationv[1] = VoxVector3f(up);
	_Set3DParameter(Vox3DGeneralParameter::k_nListenerOrientation, &orientationv);
}

void DriverPS3MultiStream::SetDSPParameter(s32 paramId, void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverPS3MultiStream::SetDSPParameter", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	switch(paramId)
	{
		case VoxDSPGeneralParameter::k_nRoutingVolume:
		{
			if(m_pBusMgr)
				m_pBusMgr->SetBusRoutingVolumeChange((BusRoutingChange*)param);
			break;
		}
		default:
		{
			VOX_WARNING_LEVEL_4("PS3 MultiStream driver doesn't support dsp property %d", paramId);
			break;
		}
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverPS3MultiStream::Update(f32 dt)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverPS3MultiStream::Update", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_pBusMgr)
	{
		m_pBusMgr->Update(dt);
	}

	s_sfxPreset.Update(dt);

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

u32 DriverPS3MultiStream::GetPS3MS3DModel(s32 vox3DModel)
{
	switch(vox3DModel)
	{
		case Vox3DDistanceModel::k_nNone:
		{
			return CELL_MS_SURROUND_NONE;
			break;
		}
		case Vox3DDistanceModel::k_nInverseDistance:
		{
			return CELL_MS_SURROUND_INVERSE_DISTANCE;
			break;
		}
		case Vox3DDistanceModel::k_nInverseDistanceClamped:
		{
			return CELL_MS_SURROUND_INVERSE_DISTANCE_CLAMPED;
			break;
		}
		case Vox3DDistanceModel::k_nLinearDistance:
		{
			return CELL_MS_SURROUND_LINEAR_DISTANCE;
			break;
		}
		case Vox3DDistanceModel::k_nLinearDistanceClamped:
		{
			return CELL_MS_SURROUND_LINEAR_DISTANCE_CLAMPED;
			break;
		}
		case Vox3DDistanceModel::k_nExponentDistance:
		{
			return CELL_MS_SURROUND_EXPONENT_DISTANCE;
			break;
		}
		case Vox3DDistanceModel::k_nExponentDistanceClamped:
		{
			return CELL_MS_SURROUND_EXPONENT_DISTANCE_CLAMPED;
			break;
		}
	}

	VOX_WARNING_LEVEL_2("Vox 3D attenuation model %x is not supported by PS3 MultiStream driver", vox3DModel);
	return CELL_MS_SURROUND_NONE;
}

void DriverPS3MultiStream::DestroyDriverSource(DriverSourceInterface* driverSource)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(driverSource)
	{
		VOX_DELETE ((DriverPS3MultiStreamSource*)driverSource);
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverPS3MultiStream::PrintDebug()
{
}

//MS specifics

int DriverPS3MultiStream::AudioInitCell()
{
	u32 returnPortNum = 0;

	//	cellMSSystemConfigureSysUtilEx returns the following data:
	//	Bits 0-3:	Number of available output channels
	//	Bit    4:	Dolby On status
	//	Bit    5:	DTS On status
	u32 retSysUtil = cellMSSystemConfigureSysUtilEx(VOX_DRIVER_PS3_MS_OUTPUT_FORMAT);
	u32 numChans = (retSysUtil & 0x0000000F);
	u32 dolbyOn = (retSysUtil & 0x00000010) >> 4;
	u32 dtsOn = (retSysUtil & 0x00000020) >> 5;
	VOX_WARNING_LEVEL_5("Number Of Channels: %u\n", numChans);
	VOX_WARNING_LEVEL_5("Dolby enabled: %u\n", dolbyOn);
	VOX_WARNING_LEVEL_5("DTS enabled: %u\n", dtsOn);

	s32 ret = cellAudioInit();
	if (ret !=CELL_OK)
	{
		VOX_WARNING_LEVEL_1("error cellAudioInit\n",0);
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return -1;
	}

	// audio port open.
	memset(&audioParam, 0, sizeof(CellAudioPortParam));
	audioParam.nChannel = VOX_DRIVER_PS3_MS_OUTPUT_CHANNEL;
	audioParam.nBlock   = CELL_AUDIO_BLOCK_8;

	ret = cellAudioPortOpen(&audioParam, &returnPortNum);
	VOX_WARNING_LEVEL_5("cellAudioPortOpen() : %d  port %d\n", ret, returnPortNum);
	if (ret != CELL_OK)
	{
		cellAudioQuit();
		VOX_WARNING_LEVEL_1("Error cellAudioPortOpen()\n",0);
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return -1;
	}
	 
	// get port config.
	ret = cellAudioGetPortConfig(returnPortNum, &portConfig);
	VOX_WARNING_LEVEL_5("cellAudioGetPortConfig() : %d\n", ret);
	if (ret != CELL_OK)
	{
		cellAudioQuit();
		VOX_WARNING_LEVEL_1("Error cellAudioGetPortConfig\n",0);
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return -1;
	}

	cellMSSystemConfigureLibAudio(&audioParam, &portConfig);

	return returnPortNum;
}

long DriverPS3MultiStream::InitialiseAudio( const s32 nStreams, const s32 nmaxSubs, s32 &_nPortNumber , CellAudioPortParam &_audioParam, CellAudioPortConfig &_portConfig, const s32 _nFlags)
{
	CellMSSystemConfig cfg;

#ifndef VOX_DRIVER_PS3_MS_THREADED
	uint8_t prios[8] = {1, 0, 0, 0, 0, 0, 0, 0};
#endif

	VOX_WARNING_LEVEL_5("Initialising PS3 MS driver\n",0);

// Setup system memory allocation

	cfg.channelCount=nStreams;
	cfg.subCount=nmaxSubs;
	cfg.dspPageCount=5;
	cfg.flags=_nFlags;	//default is CELL_MS_NOFLAGS

    _nPortNumber = AudioInitCell();
	if(_nPortNumber < 0)
	{
		VOX_WARNING_LEVEL_1("InitialiseAudio: Failed to find valid port number!\n",0);
		return -1;
	}

	_audioParam = audioParam;
	_portConfig = portConfig;

	// Initialise MultiStream
	s32 nMemoryNeeded = cellMSSystemGetNeededMemorySize(&cfg);
	m_pMultiStreamMemory = VOX_ALLOC_ALIGN(nMemoryNeeded, k_nVoxMemHint_Align128);

	if(!m_pMultiStreamMemory)
	{
		VOX_WARNING_LEVEL_1("InitialiseAudio: Failed to create multistream memory buffer!\n",0);
		return -1;
	}


#if VOX_PS3_USE_SULPHA
	//Init Sulpha
	if(!InitSulpha(SULPHA_MEMORYBUFFER_SIZE , SULPHA_NUM_NAMED_OBJECTS))
		VOX_WARNING_LEVEL_1("Sulpha initialization failed",0);
#endif

#if !VOX_DRIVER_PS3_MS_THREADED
	// Initialise SPURS MultiStream version
#if VOX_PS3_INIT_SPURS
	sys_spu_initialize(6, 0);
#	ifndef MS_THREADED_SAMPLE
	InitSPURS();
#endif
#else
	// Spurs must already be initialize by application
#endif
	CellSpurs* spurs = GetSpursStruct();
	cellMSSystemInitSPURS(m_pMultiStreamMemory, &cfg, spurs, &prios[0]);
#else
#if VOX_PS3_INIT_SPURS
	sys_spu_initialize(6, 0);
#else
	// Spu must already be initialize by application
#endif
	// Initialise Threaded MultiStream version (define MS_THREADED_SAMPLE in proprocessor flags)
	cellMSSystemInitSPUThread(m_pMultiStreamMemory, &cfg, 100);
#endif

    return 0;
}

void DriverPS3MultiStream::SetStaticBusRouting(c8* filename)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverPS3MultiStream::SetStaticBusRouting", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_pBusMgr)
		m_pBusMgr->LoadVRT(filename);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverPS3MultiStream::SetDynamicBusRouting(c8* filename)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverPS3MultiStream::SetDynamicBusRouting", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_pBusMgr)
	{
		m_pBusMgr->LoadVRF(filename);
		s_sfxPreset.Reset();
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverPS3MultiStream::SetSFXPresetActive(s32 preset, bool active, f32 fadeTime)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	s_sfxPreset.SetPresetActive(preset, active, fadeTime);
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

}//namespace vox
#endif //VOX_DRIVER_USE_PS3_MULTISTREAM && VOX_PS3_MULTISTREAM_DRIVER_PLATFORM

// NOTE 1 :
//
// When starving, FillBuffer() returns a number of bytes 'nBufferSize' smaller than 'm_workBufferSize'.
// If this happens when filling buffer 0 (for example), multistream starts to ask for buffers of size
// 'nBufferSize' when buffer 0 has to be filled. If we continue filling buffers with the asked size
// (i.e. nBufferSize for buffer 0 and m_workBufferSize for buffer 1, a serie of fade-in happen to the
// sound) To avoid such a situation, we force 'nBufferSize' to 'm_workBufferSize' but still provide the
// number of samples really gotten by FillBuffer() to cellMSStreamSetSecondRead(). Multistream copes better
// with this situation than if not forcing buffer size (even though there are still small glitches in
// certain situations (e.g. the number of samples gotten is not a multiple of some power of 2).
