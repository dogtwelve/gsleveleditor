#include "StdAfx.h"
#include "vox_filesystem_null.h"

#if defined(__native_client__)

#include "vox_memory.h"
#include <stdio.h>

namespace vox
{

/// Reads size bytes of data into buffer at ptr.
s32 readNullIO( void * ptr, s32 size, s32 count, void * stream )
{
	return -1;
}

s32 writeNullIO ( const void * ptr, s32 size, s32 count, void * stream )
{
	return -1;
}

/// Seeks to byte position offset.
s32 seekNullIO ( void * stream, s32 offset, VoxFileSeekOrigin origin )
{
	return -1;
}

/// Returns the current byte offset in the stream.
s32 tellNullIO ( void * stream )
{
	return -1;
}

void* openNullIO ( const c8 * filename, VoxFileAccessMode mode )
{
	return 0;
}

s32 closeNullIO ( void * stream )
{
	return -1;
}


FileSystemInterface* VoxNewFileSystem()
{
	return VOX_NEW FileSystemNull();
}

FileSystemNull::FileSystemNull()
{
	FileSystemInterface::m_IOFunc.open = openNullIO;
	FileSystemInterface::m_IOFunc.close = closeNullIO;
	FileSystemInterface::m_IOFunc.read = readNullIO;
	FileSystemInterface::m_IOFunc.write = writeNullIO;
	FileSystemInterface::m_IOFunc.seek = seekNullIO;
	FileSystemInterface::m_IOFunc.tell = tellNullIO;
}

FileSystemNull::~FileSystemNull()
{
}

}
#endif
