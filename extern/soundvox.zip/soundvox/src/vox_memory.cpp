#include "StdAfx.h"
#include "vox_memory.h"

#if !VOX_CUSTOM_ALLOCATOR && !_NN_CTR

#include <stdlib.h>

void* VoxAlloc(size_t size, const char* filename, const char* function, int line)
{
	return malloc(size);
}

void* VoxAlloc(size_t size)
{
	return malloc(size);
}

void* VoxAlloc(size_t size, vox::VoxMemHint memhint, const char* filename, const char* function, int line)
{
#if defined(_PS3)// &&  (VOX_DRIVER_USE_PS3_MULTISTREAM)
	return std::memalign(memhint & 0x0000FFFF, size);
#else
	return VoxAlloc(size, filename, function, line);
#endif
}

void* VoxAlloc(size_t size, vox::VoxMemHint memhint)
{
#if defined(_PS3)// &&  (VOX_DRIVER_USE_PS3_MULTISTREAM)
	return std::memalign(memhint & 0x0000FFFF, size);
#else
	return VoxAlloc(size);
#endif
}

void VoxFree(void* ptr)
{
	return free(ptr);
}
#else


void* VoxAlloc(size_t size, const char* filename, const char* function, int line);
void* VoxAlloc(size_t size);
void* VoxAlloc(size_t size, vox::VoxMemHint memhint);
void* VoxAlloc(size_t size, vox::VoxMemHint memhint, const char* filename, const char* function, int line);
void VoxFree(void* ptr);
#endif

// Allocator C wrapper for MPC decoder
#ifdef __cplusplus /* If this is a C++ compiler, use C linkage */
extern "C" {
#endif

void* VoxAlloc_c(size_t size, const char* filename, const char* function, int line)
{
	return VoxAlloc(size, filename, function, line);
}

void VoxFree_c(void* ptr)
{
	VoxFree(ptr);
}

#ifdef __cplusplus /* If this is a C++ compiler, use C linkage */
}
#endif
