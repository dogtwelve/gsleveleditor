#include "StdAfx.h"
#include "vox_soundpack_xml.h"

#if VOX_USE_SOUNDPACK_XML

#include <cstring>
#include <stdlib.h>
#include <tinyxml.h>
#include "vox_filesystem.h"
#include "vox_memory.h"
#include "vox_macro.h"

namespace vox
{

bool c8stringcomp::operator() (const c8* lhs, const c8* rhs) const
{
#if defined(_WIN32)
	if(_stricmp(lhs, rhs) < 0)
#else
	if(strcasecmp(lhs, rhs) < 0)		
#endif
		return true;
	return false;
}

VoxSoundPackXML::VoxSoundPackXML(const c8* xmlFileName)
{
	LoadXML(xmlFileName);
}

VoxSoundPackXML::~VoxSoundPackXML()
{
}

bool VoxSoundPackXML::LoadXML(const c8* xmlFileName)
{
	m_soundVector.clear();
	m_groupVector.clear();
	m_bankVector.clear();
	m_eventVector.clear();
	m_soundLabel.clear();

	FileSystemInterface* pFS = FileSystemInterface::GetInstance();
	if(!pFS)
		return false;

	FileInterface* pFile = pFS->OpenFile((c8*)xmlFileName);

	if(!pFile)
		return false;

	pFile->Seek(0, k_nSeekEnd);
	s32 filesize = pFile->Tell();
	pFile->Seek(0, k_nSeekSet);

	c8* fileBuffer = (c8*)VOX_ALLOC(filesize + 1);

	if(!fileBuffer)
	{
		pFS->CloseFile(pFile);
		return false;
	}

	fileBuffer[filesize] = 0;

	s32 readSize = pFile->Read(fileBuffer, filesize, 1);
	pFS->CloseFile(pFile);

	if(readSize != 1)
	{
		VOX_FREE(fileBuffer);
		return false;
	}

	TiXmlDocument doc;
	doc.Parse(fileBuffer);

	if ( !doc.Error() )
	{
		TiXmlHandle docHandle( &doc );
		
		// Load Sound
		TiXmlElement* element = TiXmlHandle(&doc).FirstChild("soundpack").FirstChild("sounds").Element();
		s32 soundsize;
		element->QueryIntAttribute("size", &soundsize);
		m_soundVector = VOX_VECTOR<SoundXMLDef, SAllocator<SoundXMLDef> >(soundsize);

		element = TiXmlHandle(&doc).FirstChild("soundpack").FirstChild("sounds").FirstChild("sound").Element();
		for ( ; element; element = element->NextSiblingElement() )
		{
			s32 uid;
			s32 intValue;
			f32 floatValue;
			const c8* strValue;
			if(TIXML_SUCCESS == element->QueryIntAttribute("uid", &uid))
				m_soundVector[uid].m_id = uid;
			if(TIXML_SUCCESS == element->QueryIntAttribute("bank", &intValue))
				m_soundVector[uid].m_bankId = intValue;
			if(TIXML_SUCCESS == element->QueryIntAttribute("group", &intValue))
				m_soundVector[uid].m_groupId = intValue;
			if(TIXML_SUCCESS == element->QueryIntAttribute("priority", &intValue))
				m_soundVector[uid].m_priority = intValue;
			strValue = element->Attribute("loop");
			if(strValue)
				m_soundVector[uid].m_isLoop = strValue[0] == 'y' ? true : false;			
			
			strValue = element->Attribute("label");

			if(strValue)
			{
				m_soundVector[uid].m_label = (c8*)VOX_ALLOC(strlen(strValue) + 1);
				if(m_soundVector[uid].m_label)
					strcpy(m_soundVector[uid].m_label, strValue);
			}
			else
			{
				m_soundVector[uid].m_label = (c8*)VOX_ALLOC(1);
				if(m_soundVector[uid].m_label)
					m_soundVector[uid].m_label[0] = 0; //empty string
			}

			strValue = element->Attribute("format");
			if(strValue)
			{
				if(strcmp(strValue, "pcm")==0 || strcmp(strValue, "adpcm")==0)
				{
					m_soundVector[uid].m_format = k_nDecoderTypeMSWav;
				}
				else if((strcmp(strValue, "mpc8")==0) || (strcmp(strValue, "mpc")==0))
				{
					m_soundVector[uid].m_format = k_nDecoderTypeMPC8;
				}
				else if(strcmp(strValue, "ogg")==0)
				{
					m_soundVector[uid].m_format = k_nDecoderTypeStbVorbis;
				}
				else if(strcmp(strValue, "vxn")==0)
				{
					m_soundVector[uid].m_format = k_nDecoderTypeInteractiveMusic;
				}
				else if(strcmp(strValue, "bcwav")==0)
				{
					m_soundVector[uid].m_format = k_nDecoderTypeBCWav;
				}
			}

			strValue = element->Attribute("loadingflags");
			if(strValue)
			{
				if(strcmp(strValue, "none")==0)
				{
					m_soundVector[uid].m_loadingFlags = k_nNone;
				}
				else if(strcmp(strValue, "load to ram")==0)
				{
					m_soundVector[uid].m_loadingFlags = k_nLoadToRam;
				}
				else if(strcmp(strValue, "load and decode")==0)
				{
					m_soundVector[uid].m_loadingFlags = k_nLoadToRamAndDecode;
				}
			}

			strValue = element->Attribute("filename");
			if(strValue)
			{
				m_soundVector[uid].m_filename = (c8*)VOX_ALLOC(strlen(strValue) + 1);
				if(m_soundVector[uid].m_filename)
					strcpy(m_soundVector[uid].m_filename, strValue);
			}
			else if(m_soundVector[uid].m_format != vox::k_nDecoderTypeInvalid)
			{
				m_soundVector[uid].m_filename = (c8*)VOX_ALLOC(strlen(m_soundVector[uid].m_label) + 7);
				if(m_soundVector[uid].m_filename)
				{
					strcpy(m_soundVector[uid].m_filename, m_soundVector[uid].m_label);
					if(m_soundVector[uid].m_format == k_nDecoderTypeMSWav)
					{
						strcat(m_soundVector[uid].m_filename, ".wav");
					}
					else if(m_soundVector[uid].m_format == k_nDecoderTypeMPC8)
					{
						strcat(m_soundVector[uid].m_filename, ".mpc");
					}
					else if(m_soundVector[uid].m_format == k_nDecoderTypeStbVorbis)
					{
						strcat(m_soundVector[uid].m_filename, ".ogg");
					}
					else if(m_soundVector[uid].m_format == k_nDecoderTypeInteractiveMusic)
					{
						strcat(m_soundVector[uid].m_filename, ".vxn");
					}
					else if(m_soundVector[uid].m_format == k_nDecoderTypeBCWav)
					{
						strcat(m_soundVector[uid].m_filename, ".bcwav");
					}
					//else
					//{
					//	m_soundVector[uid].m_filename = "";
					//}
				}
			}

			// Get sound 3D parameters
			if(TIXML_SUCCESS == element->QueryFloatAttribute("refdistance", &floatValue))
				m_soundVector[uid].m_referenceDistance = floatValue;

			if(TIXML_SUCCESS == element->QueryFloatAttribute("maxdistance", &floatValue))
				m_soundVector[uid].m_maxDistance = floatValue;

			if(TIXML_SUCCESS == element->QueryFloatAttribute("rolloff", &floatValue))
				m_soundVector[uid].m_rolloffFactor = floatValue;

			// Get sound gain parameters
			if(TIXML_SUCCESS == element->QueryFloatAttribute("basegain", &floatValue))
				m_soundVector[uid].m_baseGain = floatValue;
			
			if(TIXML_SUCCESS == element->QueryFloatAttribute("mingainmod", &floatValue))
			{
				m_soundVector[uid].m_minGainMod = floatValue;
				if(floatValue != 1.0f)
				{
					m_soundVector[uid].m_isGainRandom = true;
				}
			}

			if(TIXML_SUCCESS == element->QueryFloatAttribute("maxgainmod", &floatValue))
			{
				m_soundVector[uid].m_maxGainMod = floatValue;
				if(floatValue != 1.0f)
				{
					m_soundVector[uid].m_isGainRandom = true;
				}
			}
				

			// Get sound pitch parameters
			if(TIXML_SUCCESS == element->QueryFloatAttribute("basepitch", &floatValue))
				m_soundVector[uid].m_basePitch = floatValue;
			
			if(TIXML_SUCCESS == element->QueryFloatAttribute("minpitchmod", &floatValue))
			{
				m_soundVector[uid].m_minPitchMod = floatValue;
				if(floatValue != 1.0f)
				{
					m_soundVector[uid].m_isPitchRandom = true;
				}
			}

			if(TIXML_SUCCESS == element->QueryFloatAttribute("maxpitchmod", &floatValue))
			{
				m_soundVector[uid].m_maxPitchMod = floatValue;
				if(floatValue != 1.0f)
				{
					m_soundVector[uid].m_isPitchRandom = true;
				}
			}

			// Get sound custom parameters
			strValue = element->Attribute("customparam");
			if(strValue)
			{
				if(TIXML_SUCCESS == element->QueryIntAttribute("customparamqty", &intValue))
				m_soundVector[uid].m_numCustomSound = intValue;

				if(m_soundVector[uid].m_numCustomSound > 0)
				{
					m_soundVector[uid].m_customSoundStr = (c8**)VOX_ALLOC(m_soundVector[uid].m_numCustomSound * sizeof(c8*));
					if(m_soundVector[uid].m_customSoundStr)
					{
						// Allocate memory for 1st string. The 'm_customSoundStr[i > 0]' point within this string.
						m_soundVector[uid].m_customSoundStr[0] = (c8*)VOX_ALLOC(strlen(strValue) + 1);
						if(m_soundVector[uid].m_customSoundStr[0])
						{
							strcpy(m_soundVector[uid].m_customSoundStr[0], strValue);
							for(s32 i = 1; i < m_soundVector[uid].m_numCustomSound; i++)
							{
								c8* sc = strchr(m_soundVector[uid].m_customSoundStr[i - 1], ';');
								m_soundVector[uid].m_customSoundStr[i] = sc + 1;
								*sc = 0;
							}
						}
						else
						{
							m_soundVector[uid].m_numCustomSound = 0;
						}
					}
					else
					{
						m_soundVector[uid].m_numCustomSound = 0;
					}
				}
			}

			if(m_soundVector[uid].m_label)
				m_soundLabel[m_soundVector[uid].m_label] = uid;
		}

		// Load Group
		element = TiXmlHandle(&doc).FirstChild("soundpack").FirstChild("groups").Element();
		s32 groupsize;
		element->QueryIntAttribute("size", &groupsize);
		m_groupVector = VOX_VECTOR<GroupXMLDef, SAllocator<GroupXMLDef> >(groupsize + 1);

		element = TiXmlHandle(&doc).FirstChild("soundpack").FirstChild("groups").FirstChild("group").Element();
		for ( ; element; element = element->NextSiblingElement() )
		{
			s32 uid;
			const c8* strValue;
			if(TIXML_SUCCESS == element->QueryIntAttribute("uid", &uid))
				m_groupVector[uid].m_id = uid;
			strValue = element->Attribute("pos3d");
			if(strValue)
			{
				if(strValue[0] == 'y')
				{
					m_groupVector[uid].m_is3D = k_n3DSoundTypeAbsolute;
				}
				else if(strValue[0] == 'r')
				{
					m_groupVector[uid].m_is3D = k_n3DSoundTypeRelative;
				}
				else
				{
					m_groupVector[uid].m_is3D = k_n3DSoundTypeNone;
				}
			}
			strValue = element->Attribute("bus");
			m_groupVector[uid].m_busName = strValue ? strValue : "";
			strValue = element->Attribute("name");
			m_groupVector[uid].m_name = strValue ? strValue : "";
		}

		// Load Group Mask
		element = TiXmlHandle(&doc).FirstChild("soundpack").FirstChild("groupmasks").FirstChild("groupmask").Element();
		for ( ; element; element = element->NextSiblingElement() )
		{
			s32 mask;
			const c8* strValue;
			strValue = element->Attribute("label");
			if(TIXML_SUCCESS == element->QueryIntAttribute("mask", &mask) && strValue)
				m_groupMask[VOX_STRING(strValue)] = mask;
		}

		// Load Bank
		element = TiXmlHandle(&doc).FirstChild("soundpack").FirstChild("banks").Element();
		s32 banksize;
		element->QueryIntAttribute("size", &banksize);
		m_bankVector = VOX_VECTOR<BankXMLDef, SAllocator<BankXMLDef> >(banksize + 1);

		element = TiXmlHandle(&doc).FirstChild("soundpack").FirstChild("banks").FirstChild("bank").Element();
		for ( ; element; element = element->NextSiblingElement() )
		{
			s32 uid;
			s32 intValue;
			const c8* strValue;
			if(TIXML_SUCCESS == element->QueryIntAttribute("uid", &uid))
				m_bankVector[uid].m_id = uid;
			if(TIXML_SUCCESS == element->QueryIntAttribute("maxplaybacks", &intValue))
				m_bankVector[uid].m_maxPlayback = intValue;
			if(TIXML_SUCCESS == element->QueryIntAttribute("threshold", &intValue))
				m_bankVector[uid].m_threshold = intValue;
			strValue = element->Attribute("name");
			m_bankVector[uid].m_name = strValue ? strValue : "";
			strValue = element->Attribute("behaviour");
			if(strValue)
			{
				if(strcmp(strValue, "steal oldest") == 0)
				{
					m_bankVector[uid].m_behaviour = k_nStealOldest;
				}
				else if(strcmp(strValue, "steal lowest priority") == 0)
				{
					m_bankVector[uid].m_behaviour = k_nStealLowestPriority;
				}
				else if(strcmp(strValue, "steal low. prio. or old. same prio") == 0)
				{
					m_bankVector[uid].m_behaviour = k_nStealLowestPriorityOldest;
				}
			}
		}

		// Load Event
		element = TiXmlHandle(&doc).FirstChild("soundpack").FirstChild("events").Element();
		s32 eventsize;
		element->QueryIntAttribute("size", &eventsize);
		m_eventVector = VOX_VECTOR<EventXMLDef, SAllocator<EventXMLDef> >(eventsize);

		element = TiXmlHandle(&doc).FirstChild("soundpack").FirstChild("events").FirstChild("event").Element();
		for ( ; element; element = element->NextSiblingElement() )
		{
			s32 uid;
			const c8* strValue;
			if(TIXML_SUCCESS == element->QueryIntAttribute("uid", &uid))
				m_eventVector[uid].m_id = uid;		

			strValue = element->Attribute("label");
			//m_eventVector[uid].m_label = strValue ? strValue : "";
			
			if(strValue)
			{
				m_eventVector[uid].m_label = (c8*)VOX_ALLOC(strlen(strValue) + 1);
				if(m_eventVector[uid].m_label)
					strcpy(m_eventVector[uid].m_label, strValue);
			}
			else
			{
				m_eventVector[uid].m_label = (c8*)VOX_ALLOC(1);
				if(m_eventVector[uid].m_label)
					m_eventVector[uid].m_label[0] = 0; //empty string
			}
			
			strValue = element->Attribute("type");
			if(strValue)
			{
				if(strcmp(strValue, "random") == 0)
				{
					m_eventVector[uid].m_eventType = k_nEventTypeRandom;
				}
				else if(strcmp(strValue, "playlist") == 0)
				{
					m_eventVector[uid].m_eventType = k_nEventTypePlaylist;
				}
				else if(strcmp(strValue, "pl_random") == 0)
				{
					m_eventVector[uid].m_eventType = k_nEventTypePlRandom;
				}
			}
			strValue = element->Attribute("value");
			if(strValue)
			{
				c8* pch = strtok((c8 *)strValue, " ,");
				while(pch)
				{
					m_eventVector[uid].m_soundIds.push_back(atoi(pch));
					pch = strtok( NULL, " ,");
				}
			}

			strValue = element->Attribute("params");
			if(strValue)
			{
				c8* pch = strtok((c8 *)strValue, " ;");
				if(pch)
				{
					s32 randomParam = atoi(pch);
					m_eventVector[uid].m_eventParam = randomParam < (s32)m_eventVector[uid].m_soundIds.size() ? randomParam : m_eventVector[uid].m_soundIds.size();
					pch = strtok( NULL, " ;");
					if(pch)
					{
						s32 playbackProb = atoi(pch);
						if(playbackProb == 0)
							VOX_WARNING_LEVEL_3("Playback probability of %s is 0", m_eventVector[uid].m_label);
						m_eventVector[uid].m_playbackProbability = playbackProb <= 100 ? playbackProb : 100;
					}
				}
			}

			strValue = element->Attribute("customparam");
			if(strValue)
			{
				element->QueryIntAttribute("customparamqty", &m_eventVector[uid].m_numCustomEvent);
				m_eventVector[uid].m_customEventStr = (c8**)VOX_ALLOC(m_eventVector[uid].m_numCustomEvent * sizeof(c8*));
				if(m_eventVector[uid].m_customEventStr)
				{
					// Allocate memory for 1st string. The 'm_customEventStr[i > 0]' point within this string.
					m_eventVector[uid].m_customEventStr[0] = (c8*)VOX_ALLOC(strlen(strValue) + 1);
					if(m_eventVector[uid].m_customEventStr[0])
					{
						strcpy(m_eventVector[uid].m_customEventStr[0], strValue);
						for(s32 i = 1; i < m_eventVector[uid].m_numCustomEvent; i++)
						{
							c8* sc = strchr(m_eventVector[uid].m_customEventStr[i - 1], ';');
							m_eventVector[uid].m_customEventStr[i] = sc + 1;
							*sc = 0;
						}
					}
					else
					{
						m_eventVector[uid].m_numCustomEvent = 0;
					}
				}
				else
				{
					m_eventVector[uid].m_numCustomEvent = 0;
				}
			}

			if(m_eventVector[uid].m_eventType != k_nEventTypePlRandom)
			{
				m_eventVector[uid].m_currentEvent = (s32)m_eventVector[uid].m_soundIds.size();
			}
			else
			{
				m_eventVector[uid].m_currentEvent = rand() % (s32)m_eventVector[uid].m_soundIds.size();
			}
		}
	}

	VOX_FREE(fileBuffer);

	return true;
}

s32	 VoxSoundPackXML::GetBankUid(const c8* name) const
{
	for(u32 i = 0; i < m_bankVector.size(); i++)
	{
		if(m_bankVector[i].m_name == name)
		{
			return m_bankVector[i].m_id;
		}
	}

	return -1;
}

bool VoxSoundPackXML::GetBankInfo(const c8* name, s32 &bankId, s32 &threshold, s32 &maxplayback, PriorityBankBehavior &behaviour) const
{
	bankId = GetBankUid(name);
	return GetBankInfo(bankId, threshold, maxplayback, behaviour);
}

bool VoxSoundPackXML::GetBankInfo(s32 bankId, s32 &threshold, s32 &maxplayback, PriorityBankBehavior &behaviour) const
{
	if(bankId < 0 || bankId >= (s32)m_bankVector.size())
		return false;

	if(m_bankVector[bankId].m_id != bankId)
		return false; //id or vector is messed up

	threshold = m_bankVector[bankId].m_threshold;
	maxplayback = m_bankVector[bankId].m_maxPlayback;
	behaviour = m_bankVector[bankId].m_behaviour;

	return true;
}

bool VoxSoundPackXML::GetBankInfo(const c8* name, BankInfoXML &bankInfo) const 
{
	s32 bankId = GetBankUid(name);
	return GetBankInfo(bankId, bankInfo);
}

bool VoxSoundPackXML::GetBankInfo(s32 bankId, BankInfoXML &bankInfo) const
{
	if(bankId < 0 || bankId >= (s32)m_bankVector.size())
		return false;

	if(m_bankVector[bankId].m_id != bankId)
		return false; //id or vector is messed up

	bankInfo.m_id = m_bankVector[bankId].m_id;
	bankInfo.m_threshold = m_bankVector[bankId].m_threshold;
	bankInfo.m_maxPlayback = m_bankVector[bankId].m_maxPlayback;
	bankInfo.m_behaviour = m_bankVector[bankId].m_behaviour;
	bankInfo.m_name = m_bankVector[bankId].m_name.c_str();

	return true;
}

s32	 VoxSoundPackXML::GetGroupUid(const c8* name) const
{
	for(u32 i = 0; i < m_groupVector.size(); i++)
	{
		if(m_groupVector[i].m_name == name)
		{
			return m_groupVector[i].m_id;
		}
	}

	return -1;
}

bool VoxSoundPackXML::GetGroupInfo(const c8* name, s32 &groupId, const c8* &busName, Vox3DSoundType &is3D) const 
{
	groupId = GetGroupUid(name);
	return GetGroupInfo(groupId, busName, is3D);
}

bool VoxSoundPackXML::GetGroupInfo(s32 groupId, const c8* &busName, Vox3DSoundType &is3D) const
{
	if(groupId < 0 || groupId >= (s32)m_groupVector.size())
		return false;

	if(m_groupVector[groupId].m_id != groupId)
		return false; //id or vector is messed up

	busName = m_groupVector[groupId].m_busName.c_str();
	is3D = m_groupVector[groupId].m_is3D;

	return true;
}

bool VoxSoundPackXML::GetGroupInfo(const c8* name, GroupInfoXML &groupInfo) const 
{
	s32 groupId = GetGroupUid(name);
	return GetGroupInfo(groupId, groupInfo);
}

bool VoxSoundPackXML::GetGroupInfo(s32 groupId, GroupInfoXML &groupInfo) const 
{
	if(groupId < 0 || groupId >= (s32)m_groupVector.size())
		return false;

	if(m_groupVector[groupId].m_id != groupId)
		return false; //id or vector is messed up

	groupInfo.m_id = m_groupVector[groupId].m_id;
	groupInfo.m_busName = m_groupVector[groupId].m_busName.c_str();
	groupInfo.m_name = m_groupVector[groupId].m_name.c_str();
	groupInfo.m_is3D = m_groupVector[groupId].m_is3D;

	return true;
}

bool VoxSoundPackXML::GetGroupMask(const c8* groupMaskLabel, s32 &groupMask) const
{
#if defined(_NN_CTR)
	VOX_MAP<VOX_STRING, s32, stringcomp/*, SAllocator<std::pair<VOX_STRING,s32> >*/ >::const_iterator it = m_groupMask.find(VOX_STRING(groupMaskLabel));
#else
	VOX_MAP<VOX_STRING, s32, stringcomp, SAllocator<std::pair<const VOX_STRING,s32> > >::const_iterator it = m_groupMask.find(VOX_STRING(groupMaskLabel));
#endif
	if(it != m_groupMask.end())
	{
		groupMask = it->second;
		return  true;
	}

	groupMask = 0;
	return false;	
}

s32	 VoxSoundPackXML::GetSoundUid(const c8* label) const
{
#if defined(_NN_CTR)
	VOX_MAP<c8*, s32, c8stringcomp/*, SAllocator<std::pair<const c8*,s32> >*/ >::const_iterator it = m_soundLabel.find((c8*)label);
#else
	VOX_MAP<c8*, s32, c8stringcomp, SAllocator<std::pair<const c8*,s32> > >::const_iterator it = m_soundLabel.find((c8*)label);
#endif
	if(it != m_soundLabel.end())
		return  it->second;

	return -1;
}

bool VoxSoundPackXML::GetDataSourceInfo(const c8* label, s32 &soundUid, const c8* &filename, FormatTypes &decoderType, s32 &groupId, s32 &bankId, VoxSourceLoadingFlags &loadingFlags) const
{
	soundUid = GetSoundUid(label);
	return GetDataSourceInfo(soundUid, filename, decoderType, groupId, bankId, loadingFlags);
}

bool VoxSoundPackXML::GetDataSourceInfo(s32 soundUid, const c8* &filename, FormatTypes &decoderType, s32 &groupId, s32 &bankId, VoxSourceLoadingFlags &loadingFlags) const
{
	if(soundUid < 0 || soundUid >= (s32)m_soundVector.size())
		return false;

	if(m_soundVector[soundUid].m_id != soundUid)
		return false; //id or vector is messed up

	filename = m_soundVector[soundUid].m_filename;
	decoderType = (FormatTypes)m_soundVector[soundUid].m_format;
	groupId = m_soundVector[soundUid].m_groupId;
	bankId = m_soundVector[soundUid].m_bankId;
	loadingFlags = m_soundVector[soundUid].m_loadingFlags;

	return true;
}

bool VoxSoundPackXML::GetDataSourceInfo(const c8* label, DataSourceInfoXML &dataSourceInfo) const
{
	s32 soundUid = GetSoundUid(label);
	return GetDataSourceInfo(soundUid, dataSourceInfo);
}

bool VoxSoundPackXML::GetDataSourceInfo(s32 soundUid, DataSourceInfoXML &dataSourceInfo) const
{
	if(soundUid < 0 || soundUid >= (s32)m_soundVector.size())
		return false;

	if(m_soundVector[soundUid].m_id != soundUid)
		return false; //id or vector is messed up

	dataSourceInfo.m_id = m_soundVector[soundUid].m_id;
	dataSourceInfo.m_label = m_soundVector[soundUid].m_label;
	dataSourceInfo.m_filename = m_soundVector[soundUid].m_filename;
	dataSourceInfo.m_formatType = static_cast<FormatTypes>(m_soundVector[soundUid].m_format);
	dataSourceInfo.m_groupId = m_soundVector[soundUid].m_groupId;
	dataSourceInfo.m_bankId = m_soundVector[soundUid].m_bankId;
	dataSourceInfo.m_loadingFlags = m_soundVector[soundUid].m_loadingFlags;

	// Get custom parameters
	dataSourceInfo.m_numCustomSound = m_soundVector[soundUid].m_numCustomSound;
	dataSourceInfo.m_customSoundStr = m_soundVector[soundUid].m_customSoundStr;	

	return true;
}

bool VoxSoundPackXML::GetEmitterInfo(const c8* label, s32 &soundUid, s32 &priority, s32 &groupId, bool &isLoop, Vox3DSoundType &is3d, const c8* &busName) const
{
	soundUid = GetSoundUid(label);
	return GetEmitterInfo(soundUid, priority, groupId, isLoop, is3d, busName);
}

bool VoxSoundPackXML::GetEmitterInfo(s32 soundUid, s32 &priority, s32 &groupId, bool &isLoop, Vox3DSoundType &is3d, const c8* &busName) const
{
	if(soundUid < 0 || soundUid >= (s32)m_soundVector.size())
		return false;

	if(m_soundVector[soundUid].m_id != soundUid)
		return false; //id or vector is messed up

	groupId = m_soundVector[soundUid].m_groupId;
	bool groupInfo = GetGroupInfo(groupId, busName, is3d);
	if(!groupInfo)
		return false;

	priority = m_soundVector[soundUid].m_priority;
	isLoop = m_soundVector[soundUid].m_isLoop;

	return true;
}

bool VoxSoundPackXML::GetEmitterInfo(const c8* label, EmitterInfoXML &emitterInfo) const
{
	s32 soundUid = GetSoundUid(label);
	return GetEmitterInfo(soundUid, emitterInfo);
}

bool VoxSoundPackXML::GetEmitterInfo(s32 soundUid, EmitterInfoXML &emitterInfo) const
{
	if(soundUid < 0 || soundUid >= (s32)m_soundVector.size())
		return false;

	if(m_soundVector[soundUid].m_id != soundUid)
		return false; //id or vector is messed up

	s32 groupId = m_soundVector[soundUid].m_groupId;
	const c8* busName;
	Vox3DSoundType is3d;
	bool groupInfo = GetGroupInfo(groupId, busName, is3d);
	if(!groupInfo)
		return false;

	emitterInfo.m_id = m_soundVector[soundUid].m_id;
	emitterInfo.m_label = m_soundVector[soundUid].m_label;
	emitterInfo.m_priority = m_soundVector[soundUid].m_priority;
	emitterInfo.m_groupId = m_soundVector[soundUid].m_groupId;
	emitterInfo.m_isLoop = m_soundVector[soundUid].m_isLoop;
	emitterInfo.m_is3d = is3d;
	emitterInfo.m_busName = busName;

	// Get 3D parameters
	emitterInfo.m_referenceDistance = m_soundVector[soundUid].m_referenceDistance;
	emitterInfo.m_maxDistance = m_soundVector[soundUid].m_maxDistance;
	emitterInfo.m_rolloffFactor = m_soundVector[soundUid].m_rolloffFactor;

	// Get gain parameters
	emitterInfo.m_baseGain = m_soundVector[soundUid].m_baseGain;
	emitterInfo.m_minGainMod = m_soundVector[soundUid].m_minGainMod;
	emitterInfo.m_maxGainMod = m_soundVector[soundUid].m_maxGainMod;
	emitterInfo.m_isGainRandom = m_soundVector[soundUid].m_isGainRandom;

	// Get pitch parameters
	emitterInfo.m_basePitch = m_soundVector[soundUid].m_basePitch;
	emitterInfo.m_minPitchMod = m_soundVector[soundUid].m_minPitchMod;
	emitterInfo.m_maxPitchMod = m_soundVector[soundUid].m_maxPitchMod;
	emitterInfo.m_isPitchRandom = m_soundVector[soundUid].m_isPitchRandom;

	// Get custom parameters
	emitterInfo.m_numCustomSound = m_soundVector[soundUid].m_numCustomSound;
	emitterInfo.m_customSoundStr = m_soundVector[soundUid].m_customSoundStr;

	return true;
}


bool VoxSoundPackXML::GetEmitterInfoFromSoundOrEvent(const c8* label, EmitterInfoXML &emitterInfo)
{
	// If there is no sound with the specified label, search for an event.
	if(!GetEmitterInfo(label, emitterInfo))
	{
		s32 soundUid;

		if(GetEventSoundUid(label, soundUid))
		{
			return GetEmitterInfo(soundUid, emitterInfo);
		}
		
		return false;
	}
	return true;
}


bool VoxSoundPackXML::GetSoundCustomParam(const c8* soundLabel, s32 index, const c8* &param)
{
	s32 uid = GetSoundUid(soundLabel);
	return GetSoundCustomParam(uid, index, param);	
}

bool VoxSoundPackXML::GetSoundCustomParam(s32 soundUid, s32 index, const c8* &param)
{
	if(soundUid >= 0 && soundUid < (s32)m_soundVector.size())
	{
		if(index < m_soundVector[soundUid].m_numCustomSound)
		{
			param = m_soundVector[soundUid].m_customSoundStr[index];
			return true;
		}
		else
		{
			param = 0;
			return false;
		}		
	}
	return false;
}

s32 VoxSoundPackXML::GetEventUid(const c8* eventLabel) const
{
	for(u32 i = 0; i < m_eventVector.size(); i++)
	{
#if defined(_WIN32)
		if(_stricmp(m_eventVector[i].m_label, eventLabel) == 0)
#else
		if(strcasecmp(m_eventVector[i].m_label, eventLabel) == 0)
#endif
		{
			return m_eventVector[i].m_id;
		}
	}

	return -1;
}

bool VoxSoundPackXML::GetEventInfo(const c8* label, EventInfoXML &eventInfo) const
{
	s32 uid = GetEventUid(label);
	return GetEventInfo(uid, eventInfo);
}

bool VoxSoundPackXML::GetEventInfo(s32 eventUid, EventInfoXML &eventInfo) const 
{
	if(eventUid < 0 || eventUid >= (s32)m_eventVector.size())
		return false;

	if(m_eventVector[eventUid].m_id != eventUid)
		return false; //id or vector is messed up

	eventInfo.m_id = m_eventVector[eventUid].m_id;
	eventInfo.m_label = m_eventVector[eventUid].m_label;

	eventInfo.m_pSoundIds = &m_eventVector[eventUid].m_soundIds;

	eventInfo.m_eventType = static_cast<VoxSoundPackEventType>(m_eventVector[eventUid].m_eventType);
	eventInfo.m_eventParam = m_eventVector[eventUid].m_eventParam;
	eventInfo.m_playbackProbability = m_eventVector[eventUid].m_playbackProbability;		

	eventInfo.m_numCustomEvent = m_eventVector[eventUid].m_numCustomEvent;
	eventInfo.m_customEventStr = m_eventVector[eventUid].m_customEventStr;

	return true;
}

bool VoxSoundPackXML::GetEventSoundUid(const c8* eventLabel, s32 &soundUid) 
{
	s32 uid = GetEventUid(eventLabel);
	return GetEventSoundUid(uid, soundUid);
}

bool VoxSoundPackXML::GetEventSoundUid(s32 eventUid, s32 &soundUid) 
{
	if(eventUid >=0 && eventUid < (s32)m_eventVector.size())
	{
		s32 _size = m_eventVector[eventUid].m_soundIds.size();
		if( _size <= 0)
			return false;


		// First check if we should play a sound
		if(rand() % 100 >= m_eventVector[eventUid].m_playbackProbability)
		{
			soundUid = -1;
			return true;
		}

		switch((VoxSoundPackEventType)m_eventVector[eventUid].m_eventType)
		{
			case k_nEventTypeRandom:
			{
				//choose randomly in current available sound
				_size = m_eventVector[eventUid].m_soundIds.size();
				s32 _id = rand() % _size;
				soundUid = m_eventVector[eventUid].m_soundIds[_id];

				//send the sound in "penalty" for m_eventParam event
				m_eventVector[eventUid].m_usedSoundIds.push_back(soundUid);
				m_eventVector[eventUid].m_soundIds[_id] = m_eventVector[eventUid].m_soundIds[_size - 1];
				m_eventVector[eventUid].m_soundIds.pop_back();

				//if penalty box full or active list empty, sent the oldest back to available soundids
				if((s32)m_eventVector[eventUid].m_usedSoundIds.size() > m_eventVector[eventUid].m_eventParam || m_eventVector[eventUid].m_soundIds.size() == 0)
				{
					m_eventVector[eventUid].m_soundIds.push_back(m_eventVector[eventUid].m_usedSoundIds.front());
					m_eventVector[eventUid].m_usedSoundIds.pop_front();
				}
				break;
			}
			case k_nEventTypePlaylist:
			case k_nEventTypePlRandom:
			{
				if(m_eventVector[eventUid].m_currentEvent >= _size)
				{
					m_eventVector[eventUid].m_currentEvent = 0;
				}

				soundUid = m_eventVector[eventUid].m_soundIds[m_eventVector[eventUid].m_currentEvent++];
				break;
			}
			default:
			{
				break;
			}
		}

		return true;
	}

	return false;
}

bool VoxSoundPackXML::ResetEvent(const c8* eventLabel)
{
	s32 uid = GetEventUid(eventLabel);
	return ResetEvent(uid);
}

bool VoxSoundPackXML::ResetEvent(s32 eventUid)
{
	if(eventUid >=0 && eventUid < (s32)m_eventVector.size())
	{
		if(m_eventVector[eventUid].m_eventType != k_nEventTypePlRandom)
		{
			m_eventVector[eventUid].m_currentEvent = (s32)m_eventVector[eventUid].m_soundIds.size();
		}
		else
		{
			m_eventVector[eventUid].m_currentEvent = rand() % (s32)m_eventVector[eventUid].m_soundIds.size();
		}

		while(m_eventVector[eventUid].m_usedSoundIds.size() > 0)
		{
			m_eventVector[eventUid].m_soundIds.push_back(m_eventVector[eventUid].m_usedSoundIds.front());
			m_eventVector[eventUid].m_usedSoundIds.pop_front();
		}

		return true;
	}

	return false;
}

s32 VoxSoundPackXML::GetEventSize(const c8* eventLabel)
{
	s32 uid = GetEventUid(eventLabel);
	return GetEventSize(uid);
}

s32 VoxSoundPackXML::GetEventSize(s32 eventUid)
{
	if(eventUid >= 0 && eventUid < (s32)m_eventVector.size())
	{
		return m_eventVector[eventUid].m_soundIds.size();
	}

	return -1;
}

bool VoxSoundPackXML::GetEventEditableParam(const vox::c8* eventLabel, vox::EventXmlEditable& eventEditableParam)
{
	s32 uid = GetEventUid(eventLabel);
	return GetEventEditableParam(uid, eventEditableParam);
}

bool VoxSoundPackXML::GetEventEditableParam(vox::s32 eventUid, vox::EventXmlEditable& eventEditableParam)
{
	if(eventUid >= 0 && eventUid < (s32)m_eventVector.size())
	{
		this->ResetEvent(eventUid);
		eventEditableParam.m_soundIds = &m_eventVector[eventUid].m_soundIds;
		eventEditableParam.m_eventType = &m_eventVector[eventUid].m_eventType;
		eventEditableParam.m_eventParam = &m_eventVector[eventUid].m_eventParam;
		eventEditableParam.m_playbackProbability = &m_eventVector[eventUid].m_playbackProbability;
		return true;
	}

	return false;
}

bool VoxSoundPackXML::GetEventCustomParam(const c8* eventLabel, s32 index, const c8* &param)
{
	s32 uid = GetEventUid(eventLabel);
	return GetEventCustomParam(uid, index, param);	
}

bool VoxSoundPackXML::GetEventCustomParam(s32 eventUid, s32 index, const c8* &param)
{
	if(eventUid >= 0 && eventUid < (s32)m_eventVector.size())
	{
		if(index < m_eventVector[eventUid].m_numCustomEvent)
		{
			param = m_eventVector[eventUid].m_customEventStr[index];
			return true;
		}
		else
		{
			param = 0;
			return false;
		}		
	}
	return false;
}

} // namespace vox
#endif //VOX_USE_SOUNDPACK_XML
