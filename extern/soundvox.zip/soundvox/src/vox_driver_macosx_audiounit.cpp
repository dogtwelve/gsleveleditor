#include "vox_default_config.h"

#if VOX_DRIVER_USE_MACOSX_AUDIOUNIT && VOX_MACOSX_AUDIOUNIT_DRIVER_PLATFORM

#include "vox_driver_macosx_audiounit.h"
#include "vox_macro.h"
#include "vox_memory.h"
#include "vox.h"
#import "AudioToolBox/AudioToolBox.h"


namespace vox {

DriverInterface* CreateDriver()
{
	return VOX_NEW DriverMacOSXAudioUnit();
}
	
	
DriverMacOSXAudioUnitSource::DriverMacOSXAudioUnitSource(void * trackParam, void* driverParam, u32 sourceId):
DriverCallbackSourceInterface(trackParam, driverParam, sourceId)
{
	Init();
}
	
DriverMacOSXAudioUnitSource::~DriverMacOSXAudioUnitSource()//**-**
{
}

void DriverMacOSXAudioUnitSource::PrintDebug()
{
}
	
		
//*** DriverMacOSXAudioUnit ***//
	
#define AU_OUTPUT_BUS			0
#define AU_REACTIVATION_LIMIT	5
	
DriverMacOSXAudioUnit::DriverMacOSXAudioUnit()
:m_resampleBuffer(0)
,m_resampleBufferSize(0)
,m_resamplePos(0)
,m_prevLeft(0)
,m_prevRight(0)
{
	m_audioCallbackActive = false;
	m_audioUnitInitialized = false;
	m_driverSuspended = false;
	m_nbAudioUnitReactivationTrials = 0;
	m_reactivationTrialInterval = 0.0f;
	m_needRampOut = false;
	m_needRampIn = false;
	Init(0);
}
	
DriverMacOSXAudioUnit::~DriverMacOSXAudioUnit()
{
	Shutdown();
		
	m_mutex.Lock(); //Relock in case callback was called during shutdown
	if(m_resampleBuffer)
		VOX_FREE(m_resampleBuffer);
	m_mutex.Unlock();
}
	
void DriverMacOSXAudioUnit::Init(void* param)
{
	m_mutex.Lock();
		
	DriverCallbackInterface::Init(param);
	DriverCallbackSourceInterface::SetDriverSampleRate(VOX_MACOSX_AUDIOUNIT_DRIVER_PREFERRED_RATE);
		
	SetDefaultParameter();
		
	_InitializeAudioUnit();

	// Get actual buffer length and set driver callback period (in seconds).
	UInt32 bufferDuration;
	UInt32 dataSize = sizeof(UInt32);
	
	AudioUnitGetProperty (m_audioUnit, kAudioUnitProperty_MaximumFramesPerSlice, kAudioUnitScope_Global,
						  AU_OUTPUT_BUS, &bufferDuration, &dataSize);

	DriverCallbackSourceInterface::SetDriverCallbackPeriod((f32) bufferDuration / VOX_MACOSX_AUDIOUNIT_DRIVER_PREFERRED_RATE);	
		
	m_mutex.Unlock();
}
	
void DriverMacOSXAudioUnit::Update(f32 dt)
{
	m_mutex.Lock();
	m_reactivationTrialInterval += dt;
		
	if(m_nbAudioUnitReactivationTrials < AU_REACTIVATION_LIMIT && m_reactivationTrialInterval > 1.0f)
	{
		if(!m_audioUnitInitialized && !m_driverSuspended)
		{
			_InitializeAudioUnit();
			if(!m_audioUnitInitialized)
			{
				m_nbAudioUnitReactivationTrials++;
				VOX_WARNING_LEVEL_2("Audio unit reactivation attempt no %d failed", m_nbAudioUnitReactivationTrials);
				if(m_nbAudioUnitReactivationTrials == AU_REACTIVATION_LIMIT)
				{
					VOX_WARNING_LEVEL_1("Audio unit reactivation failed, no further attemp will be done", 0);
				}
			}
			m_reactivationTrialInterval = 0.0f;
		}
		else if(m_audioUnitActive && !m_driverSuspended && !m_audioCallbackActive)
		{
			OSStatus status = AudioOutputUnitStart(m_audioUnit);
			AU_CHECKSTATUS(status);
			if(status == 0)
			{
				m_audioCallbackActive = true;
			}
			else
			{
				m_nbAudioUnitReactivationTrials++;
				VOX_WARNING_LEVEL_2("Audio unit reactivation attempt no %d failed", m_nbAudioUnitReactivationTrials);
				if(m_nbAudioUnitReactivationTrials == AU_REACTIVATION_LIMIT)
				{
					VOX_WARNING_LEVEL_1("Audio unit reactivation failed, no further attemp will be done", 0);
				}
			}
			m_reactivationTrialInterval = 0.0f;
		}
	}
	m_mutex.Unlock();
}
	
void DriverMacOSXAudioUnit::_InitializeAudioUnit()
{
	if(m_audioUnitInitialized)
		return;
		
	OSStatus status = 0;
	bool error = 0;
	
	// Describe audio component
	AudioComponentDescription desc;
	desc.componentType = kAudioUnitType_Output;
	desc.componentSubType = kAudioUnitSubType_DefaultOutput;
	desc.componentFlags = 0;
	desc.componentFlagsMask = 0;
	desc.componentManufacturer = kAudioUnitManufacturer_Apple;
		
	// Get component
	AudioComponent outputComponent = AudioComponentFindNext(NULL, &desc);
		
	// Get audio units
	status = AudioComponentInstanceNew(outputComponent, &m_audioUnit);
	AU_CHECKSTATUS(status);
	error = error | (status != 0);
		
	if(error) //Could not get audio component
	{
		m_mutex.Unlock();
		return;
	}
		
	if(!error)
	{
		// Describe format
		AudioStreamBasicDescription audioFormat;
			
		audioFormat.mSampleRate			= VOX_MACOSX_AUDIOUNIT_DRIVER_PREFERRED_RATE;
		audioFormat.mFormatID			= kAudioFormatLinearPCM;
		audioFormat.mFormatFlags		= kAudioFormatFlagIsSignedInteger | kAudioFormatFlagIsPacked;
		audioFormat.mFramesPerPacket	= 1;
		audioFormat.mChannelsPerFrame	= 2; //Final mix is always stereo
		audioFormat.mBitsPerChannel		= 16; //16 bit per sample per channel
		audioFormat.mBytesPerPacket		= 4; // 2 bytes per channel
		audioFormat.mBytesPerFrame		= 4; // 1 packet per frame
			
		// Apply format
			
		status = AudioUnitSetProperty(m_audioUnit, 
									  kAudioUnitProperty_StreamFormat, 
									  kAudioUnitScope_Input, 
									  AU_OUTPUT_BUS, 
									  &audioFormat, 
									  sizeof(audioFormat));
		AU_CHECKSTATUS(status);
		error = error | (status != 0);
	}
		
	if(!error)
	{
		// Set output callback
		AURenderCallbackStruct callbackStruct;
		callbackStruct.inputProc = playbackCallback;
		callbackStruct.inputProcRefCon = this;
		status = AudioUnitSetProperty(m_audioUnit, 
									  kAudioUnitProperty_SetRenderCallback, 
									  kAudioUnitScope_Global, 
									  AU_OUTPUT_BUS,
									  &callbackStruct, 
									  sizeof(callbackStruct));
		AU_CHECKSTATUS(status);
		error = error | (status != 0);
	}
		
	// Initialise
	if(!error)
	{
		status = AudioUnitInitialize(m_audioUnit);
		AU_CHECKSTATUS(status);
		error = error | (status != 0);
	}
		
	if(error) //Could not initialize audio unit
	{
		status = AudioComponentInstanceDispose(m_audioUnit);
		AU_CHECKSTATUS(status);
		m_mutex.Unlock();
		return;
	}
		
	if(!error)
	{
		status = AudioOutputUnitStart(m_audioUnit);
		AU_CHECKSTATUS(status);
		error = error | (status != 0);
	}
		
	if(error) //Could not start audio unit
	{
		status = AudioUnitUninitialize(m_audioUnit);
		AU_CHECKSTATUS(status);
		status = AudioComponentInstanceDispose(m_audioUnit);
		AU_CHECKSTATUS(status);
		m_mutex.Unlock();
		return;
	}
	else
	{
		m_audioUnitActive = true;
		m_audioUnitInitialized = true;
		m_audioCallbackActive = true;
	}
}
	
void DriverMacOSXAudioUnit::Shutdown()
{
	m_audioCallbackActive = false;
	m_mutex.Lock();
	
	if(m_audioUnitActive)
	{
		m_audioUnitActive =	false;			
		OSStatus status = AudioOutputUnitStop(m_audioUnit);
		AU_CHECKSTATUS(status);
		status = AudioUnitUninitialize(m_audioUnit);
		AU_CHECKSTATUS(status);
		status = AudioComponentInstanceDispose(m_audioUnit);
		AU_CHECKSTATUS(status);
	}
		
	m_mutex.Unlock();
}
	
void DriverMacOSXAudioUnit::Suspend()
{
	m_driverSuspended = true;
	m_mutex.Lock();
	if(m_audioUnitActive)
	{
		if(m_audioCallbackActive)
		{
			OSStatus status = AudioOutputUnitStop(m_audioUnit);
			m_audioCallbackActive = false;
			AU_CHECKSTATUS(status);
		}
	}
	m_mutex.Unlock();
}
	
void DriverMacOSXAudioUnit::Resume()
{
	m_mutex.Lock();
	if(m_audioUnitActive)
	{
		if(m_nbAudioUnitReactivationTrials < AU_REACTIVATION_LIMIT)
		{
			OSStatus status = AudioOutputUnitStart(m_audioUnit);
			AU_CHECKSTATUS(status);
			if(status == 0)
			{
				m_needRampIn = true;
				m_audioCallbackActive = true;
			}
			else
			{
				m_nbAudioUnitReactivationTrials++;
				VOX_WARNING_LEVEL_2("Audio unit reactivation attempt no %d failed", m_nbAudioUnitReactivationTrials);
				if(m_nbAudioUnitReactivationTrials == AU_REACTIVATION_LIMIT)
				{
					VOX_WARNING_LEVEL_1("Audio unit reactivation failed, no further attemp will be done", 0);
				}
			}
			m_reactivationTrialInterval = 0.0f;
		}
	}
	m_mutex.Unlock();	
	m_driverSuspended = false;
}
	
DriverSourceInterface* DriverMacOSXAudioUnit::CreateDriverSource(void * trackParam, void* driverParam, s32 priority)
{
	m_mutex.Lock();

	DriverMacOSXAudioUnitSource* driverSource = 0;
		
	if(m_audioUnitActive)
	{
		driverSource = VOX_NEW DriverMacOSXAudioUnitSource(trackParam, driverParam, m_nextSourceId);
		if(driverSource)
		{
			m_activeSources.push_back(driverSource);
			m_nextSourceId++;
		}
	}
		
	m_mutex.Unlock();
	return driverSource;
}
	
	
void DriverMacOSXAudioUnit::DestroyDriverSource(DriverSourceInterface* driverSource)
{
	m_mutex.Lock();
	if(driverSource)
	{
		VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> >::iterator it = m_activeSources.begin();
		VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> >::iterator end = m_activeSources.end();
			
		for(; it != end; it++)
		{
			if(*it == driverSource)
			{
				m_activeSources.erase(it);
				break;
			}
		}
			
		VOX_DELETE( (DriverMacOSXAudioUnitSource*)driverSource);
	}
	m_mutex.Unlock();
}
	
void DriverMacOSXAudioUnit::PrintDebug()
{
}
	
void DriverMacOSXAudioUnit::FillBuffer(s16* outBuffer, s32 nbSample)
{
	if(!m_audioCallbackActive)
	{
		memset(outBuffer, 0, (nbSample << 1) * sizeof(s16));
		return;
	}
	
	DriverCallbackInterface::FillBuffer(outBuffer, nbSample);
		
	if(m_needRampIn)
	{
		m_needRampIn = false;
		m_needRampOut = false;
		
		for(s32 i = 0 ; i < (nbSample<<1) ; i+=2)
		{
			outBuffer[i] = (s32)outBuffer[i] * (i>>1) / nbSample;
			outBuffer[i+1] = (s32)outBuffer[i+1] * (i>>1) / nbSample;
		}	
	}
	else if(m_needRampOut)
	{
		m_needRampOut = false;
		
		for(s32 i = 0 ; i < (nbSample<<1) ; i+=2)
		{
			outBuffer[i] = (s32)outBuffer[i] * (nbSample - (i>>1)) / nbSample;
			outBuffer[i+1] = (s32)outBuffer[i+1] * (nbSample - (i>>1)) / nbSample;
		}
	}
}
	
OSStatus DriverMacOSXAudioUnit::playbackCallback(void *inRefCon, AudioUnitRenderActionFlags *ioActionFlags, const AudioTimeStamp *inTimeStamp, UInt32 inBusNumber, UInt32 inNumberFrames, AudioBufferList *ioData)
{	
	if(inRefCon)
	{
		for(u32 i = 0; i < ioData->mNumberBuffers; i++)
		{
			s16* data = (s16*)ioData->mBuffers[i].mData;			
			((DriverMacOSXAudioUnit*)inRefCon)->FillBuffer(data, ioData->mBuffers[i].mDataByteSize >> 2/*inNumberFrames*/);
		}
	}
	
	return 0;
}
	
}//namespace vox

#endif //VOX_DRIVER_USE_MACOSX_AUDIOUNIT && VOX_MACOSX_AUDIOUNIT_DRIVER_PLATFORM