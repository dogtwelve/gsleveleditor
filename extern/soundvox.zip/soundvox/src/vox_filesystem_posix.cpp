#include "StdAfx.h"
#include "vox_filesystem_posix.h"

#if ((defined(_IPHONE_OS)) && VOX_USE_POSIX_FILESYSTEM) && !VOX_USE_GLF

#include "vox_memory.h"
#include <stdio.h>
#include <fcntl.h>

#include <sys/mman.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

namespace vox
{

/// Reads size bytes of data into buffer at ptr.
s32 readPosix( void * ptr, s32 size, s32 count, void * stream )
{
	FilePosixInfo* fileInfo = (FilePosixInfo*)stream;
	if(fileInfo)
	{
		if(fileInfo->m_mmapptr)
		{
			s32 readsize = size * count;
			if(readsize + fileInfo->m_position > fileInfo->m_size)
			{
				readsize = fileInfo->m_size - fileInfo->m_position - 1;
			}

			c8* buf = (c8*) fileInfo->m_mmapptr;
			memcpy(ptr, &(buf[fileInfo->m_position]), readsize);
			fileInfo->m_position += readsize;
			return readsize / size;
		}
		else // "normal" mode
		{
			s32 readsize = read(fileInfo->m_fildes, ptr, size * count);
			return readsize > 0 ? readsize / size : readsize;
		}
	}
	return -1;
}

s32 writePosix ( const void * ptr, s32 size, s32 count, void * stream )
{
	//Not supported
	return -1;
}

/// Seeks to byte position offset.
s32 seekPosix ( void * stream, s32 offset, VoxFileSeekOrigin origin )
{
	FilePosixInfo* fileInfo = (FilePosixInfo*)stream;
	if(fileInfo)
	{
		switch(origin)
		{
			case k_nSeekSet:
			{
				if(offset <= fileInfo->m_size && offset >= 0)
				{
					fileInfo->m_position = offset;
				}
				else
				{
					return -1;
				}
				break;
			}
			case k_nSeekEnd:
			{
				if((-offset) <= fileInfo->m_size && offset <= 0)
				{
					fileInfo->m_position = fileInfo->m_size - offset;
				}
				else
				{
					return -1;
				}
				break;
			}
			case k_nSeekCur:
			{
				if((fileInfo->m_position + offset) <= fileInfo->m_size && (fileInfo->m_position + offset) >= 0)
				{
					fileInfo->m_position += offset;
				}
				else
				{
					return -1;
				}
				break;
			}
			default:
			{
				break;
			}
		}

		if(!fileInfo->m_mmapptr)
		{
			fileInfo->m_position = lseek(fileInfo->m_fildes, fileInfo->m_position, SEEK_SET);
			return fileInfo->m_position < 0 ? fileInfo->m_position : 0;
		}

		return 0;
	}
	return -1;
}

/// Returns the current byte offset in the stream.
s32 tellPosix ( void * stream )
{
	FilePosixInfo* fileInfo = (FilePosixInfo*)stream;
	if(fileInfo)
	{
		return fileInfo->m_position;
	}
	
	return -1;
}

void* openPosix ( const c8 * filename, VoxFileAccessMode mode )
{
	FilePosixInfo* fileInfo = 0;

	switch(mode)
	{
		case k_nRead: //Only read supported
		case k_nReadBinary:
		{
			int fildes = open(filename, O_RDONLY);
			if(fildes >= 0)
			{
				struct stat sb;
				if (fstat (fildes, &sb) != -1) 
				{
					fileInfo = VOX_NEW FilePosixInfo();
					if(fileInfo)
					{
						fileInfo->m_fildes = fildes;
						fileInfo->m_size = sb.st_size;
						fileInfo->m_position = 0;
						fileInfo->m_mmapptr = mmap(0, fileInfo->m_size, PROT_READ, MAP_SHARED, fileInfo->m_fildes, 0); 
						if(fileInfo->m_mmapptr == MAP_FAILED)
						{
							fileInfo->m_mmapptr = 0; //keep file open for "normal" mode
						}
						else
						{
							madvise(fileInfo->m_mmapptr, fileInfo->m_size, POSIX_MADV_SEQUENTIAL);
						}
					}
					else
					{
						close(fildes);
					}
				}
				else
				{
					fileInfo = VOX_NEW FilePosixInfo();
					if(fileInfo)
					{
						fileInfo->m_fildes = fildes;						
						fileInfo->m_size = lseek(fileInfo->m_fildes, 0, SEEK_END);
						lseek(fileInfo->m_fildes, 0, SEEK_SET);
						fileInfo->m_position = 0;
						fileInfo->m_mmapptr = 0; 
					}
					else
					{
						close(fildes);
					}
				}
			}

			break;
		}
		default:
			fileInfo = 0;
	}

	return fileInfo;
}

s32 closePosix ( void * stream )
{
	FilePosixInfo* fileInfo = (FilePosixInfo*)stream;
	if(fileInfo)
	{
		if(fileInfo->m_mmapptr)
		{
			munmap(fileInfo->m_mmapptr, fileInfo->m_size);
		}

		s32 retcode = close(fileInfo->m_fildes);
		
		VOX_DELETE(fileInfo);
		
		return retcode;
	}
	return -1;
}


FileSystemInterface* VoxNewFileSystem()
{
	return VOX_NEW FileSystemPosix();
}

FileSystemPosix::FileSystemPosix()
{
	FileSystemInterface::m_IOFunc.open = openPosix;
	FileSystemInterface::m_IOFunc.close = closePosix;
	FileSystemInterface::m_IOFunc.read = readPosix;
	FileSystemInterface::m_IOFunc.write = writePosix;
	FileSystemInterface::m_IOFunc.seek = seekPosix;
	FileSystemInterface::m_IOFunc.tell = tellPosix;
}

FileSystemPosix::~FileSystemPosix()
{
}

}
#endif
