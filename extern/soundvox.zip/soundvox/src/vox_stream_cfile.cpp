#include "StdAfx.h"
#include "vox_stream_cfile.h"
#include "vox_default_config.h"
#include "vox.h"
#include "vox_macro.h"

namespace vox {

StreamInterface* StreamCFileFactory(void* params)
{
	return VOX_NEW StreamCFile( (const c8*)params );
}

///

StreamCFile::StreamCFile( const c8* filename )
{
	if ( filename )
	{
		m_filename = filename;
		Init();
	}
}

void StreamCFile::Init()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "StreamCFile::Init", vox::VoxThread::GetCurThreadId());
	m_streamSize = 0;
	m_pFS = FileSystemInterface::GetInstance();
	if ( m_filename.size() && m_pFS)
	{
		FileInterface* fp = m_pFS->OpenFile((c8*)m_filename.c_str());
		if ( fp )
		{
			fp->Seek(0, vox::k_nSeekEnd);
			m_streamSize = fp->Tell();
			m_pFS->CloseFile(fp);
		}
		else
		{
			VOX_WARNING_LEVEL_1("%s could not access %s", __FUNCTION__, m_filename.c_str());
		}
	}
}

StreamCursorInterface* 
StreamCFile::CreateNewCursor()
{
	if(m_streamSize > 0)
		return VOX_NEW StreamCFileCursor(this);
	return 0;
}

void 
StreamCFile::DestroyCursor(StreamCursorInterface* pStreamCursor)
{
	VOX_DELETE(pStreamCursor);
}
///

void StreamCFileCursor::Init()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "StreamCFileCursor::Init", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT( m_pStream );
	VOX_ASSERT( !m_fp );

	if ( m_pStream && ( ! m_fp ) )
	{
		const c8* filename = ((StreamCFile*)m_pStream)->GetFileName();
		FileSystemInterface* pFS = ((StreamCFile*)m_pStream)->GetFileSystem();
		if ( filename )
		{
			m_fp = pFS->OpenFile( (c8*)filename );
		}
	}

	if(!m_fp)
		VOX_WARNING_LEVEL_2( "Could not load file %s\n", ((StreamCFile*)m_pStream)->GetFileName());
}

void StreamCFileCursor::Shutdown()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "StreamCFileCursor::Shutdown", vox::VoxThread::GetCurThreadId());
	if ( m_pStream && m_fp )
	{
		FileSystemInterface* pFS = ((StreamCFile*)m_pStream)->GetFileSystem();
		if ( pFS )
		{
			pFS->CloseFile(m_fp);
		}
	}
	else if( m_fp ) //fail-safe, should not happen
	{
		FileSystemInterface* pFS = FileSystemInterface::GetInstance();
		if ( pFS )
		{
			pFS->CloseFile(m_fp);
		}
	}
}

s32 StreamCFileCursor::Seek( s32 pos, s32 origin )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "StreamCFileCursor::Seek", vox::VoxThread::GetCurThreadId());
	if ( m_fp )
	{
		switch(origin)
		{
			case ORIGIN_START:
			{
				m_position = pos;
				break;
			}
			case ORIGIN_CURRENT:
			{
				if(m_position < 0)
					m_position = m_fp->Tell();
				m_position += pos;
				break;
			}
			case ORIGIN_END:
			{
				m_position = Size() - pos - 1;
				break;
			}
		}
	
		if(m_position < 0 || m_position > Size())
		{
			m_position = -1;
			return -1;
		}
		else
		{
#if VOX_BUFFERED_FILE_STREAM
			if(m_position >= m_bufferOffset &&  m_position < (m_bufferOffset + m_bufferAvailableBytes))
			{
				m_bufferCursorPos = m_position - m_bufferOffset;
				return 0;
			}
			else
			{
				m_bufferAvailableBytes = 0;
				m_bufferCursorPos = 0;
				m_bufferOffset = 0;
				s32 ret = m_fp->Seek( m_position, vox::k_nSeekSet );
				if(ret == 0)
				{
					m_bufferOffset = m_position;
					return 0;
				}
				else
				{
					m_position = -1;
					m_bufferOffset = -1;
					return ret;
				}
			}
#else
			return m_fp->Seek( m_position, vox::k_nSeekSet );
#endif
		}
	}
	return -1;
}

s32 StreamCFileCursor::Tell()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "StreamCFileCursor::Tell", vox::VoxThread::GetCurThreadId());
	
	if ( m_fp )
	{
		if(m_position < 0)
			m_position = m_fp->Tell();
		return m_position;
	}

	return -1;
}

s32 StreamCFileCursor::Read( u8* buff, s32 len )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "StreamCFileCursor::Read", vox::VoxThread::GetCurThreadId());
	
	if ( m_fp && (len > 0))
	{
		if(m_position < 0)
			m_position = m_fp->Tell();

#if VOX_BUFFERED_FILE_STREAM
		s32 bytesLeft = m_bufferAvailableBytes - m_bufferCursorPos;
		s32 outBytes = 0;

		while(len > 0)
		{
			while((len > 0) && (bytesLeft > 0))
			{
				if(bytesLeft >= len)
				{
					memcpy(&buff[outBytes], &(m_buffer[m_bufferCursorPos]), len);
					outBytes += len;
					m_bufferCursorPos += len;
					len = 0;
				}
				else
				{
					memcpy(&buff[outBytes], &(m_buffer[m_bufferCursorPos]), bytesLeft);
					outBytes += bytesLeft;
					m_bufferCursorPos += bytesLeft;
					len -= bytesLeft;
				}

				bytesLeft = m_bufferAvailableBytes - m_bufferCursorPos;
			}

			if(bytesLeft == 0)
			{
				m_bufferOffset += m_bufferAvailableBytes;
				m_bufferAvailableBytes = m_fp->Read(m_buffer, 1, VOX_FILE_STREAM_BUFFER_SIZE);
				m_bufferCursorPos = 0;
				if(m_bufferAvailableBytes == 0)
				{
					m_position += outBytes;
					return outBytes;
				}

				bytesLeft = m_bufferAvailableBytes;
			}
		}

		m_position += outBytes;
		return outBytes;
#else
		s32 readSize = m_fp->Read(buff, 1, len);
		m_position += readSize;
		return readSize;
#endif
	}
	return 0;
}

bool StreamCFileCursor::EndOfStream()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_STREAM, "StreamCFileCursor::EndOfStream", vox::VoxThread::GetCurThreadId());
	if ( m_fp )
	{
		if(m_position < 0)
			m_position = Tell();
		s32 pos = m_position;
		return pos >= (Size() -1);
	}
	return true;
}

} //namespace vox
