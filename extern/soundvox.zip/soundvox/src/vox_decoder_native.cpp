#include "StdAfx.h"
#include "vox_decoder_native.h"
#include "vox_native_subdecoder_pcm.h"
#include "vox_native_subdecoder_imaadpcm.h"
#if !defined(_NN_CTR) && !defined(_PS3)
#include "vox_native_subdecoder_msadpcm.h"
#endif
#include "vox_macro.h"

namespace vox {


DecoderInterface* DecoderNativeFactory(void* params)
{
	return VOX_NEW DecoderNative();
}

///

DecoderNative::DecoderNative()
:m_needParsing(true)
{
#if !defined(_NN_CTR) && !defined(_PS3)
	m_pFmtExtentedInfos = 0;
#endif
}

DecoderNative::~DecoderNative()
{
	if(m_audioSegments.m_pBuffer)
	{
		VOX_FREE(m_audioSegments.m_pBuffer);
		m_audioSegments.m_pBuffer = 0;
		m_audioSegments.m_nbSegments = 0;
	}
	if(m_transitionRules.m_pBuffer)
	{
		VOX_FREE(m_transitionRules.m_pBuffer);
		m_transitionRules.m_pBuffer = 0;
		m_transitionRules.m_nbRules = 0;
	}

	if(m_states.m_pPlaylistIndexes)
	{
		VOX_FREE(m_states.m_pPlaylistIndexes);
		m_states.m_pPlaylistIndexes = 0;
		m_states.m_nbStates = 0;
	}

#if !defined(_NN_CTR) && !defined(_PS3)
	if(m_pFmtExtentedInfos)
	{
		VOX_DELETE(m_pFmtExtentedInfos);
		m_pFmtExtentedInfos = 0;
	}
#endif
}


#if !defined(_NN_CTR) && !defined(_PS3)
void DecoderNative::CreateFmtExtendedInfosContainer(void)
{
	m_pFmtExtentedInfos = VOX_NEW FmtExtendedInfos();
}
#endif


void DecoderNative::CreatePlaylistsContainer(s32 nbPlaylists)
{
	m_playlists.Init(nbPlaylists);
}


// NOTE : If (on file) memory size of the AudioSegment structure is larger than the memory occupied
// by the structure in the array 'm_pSegments', allocate extra bytes so that the object written
// doesn't overflow the array (even if it's only padding).

void DecoderNative::CreateSegmentsInfoContainers(s32 nbSegments, s32 segmentSize)
{
	s32 nbExtraBytes = segmentSize - sizeof(AudioSegment);

	// Create array of segments
	m_audioSegments.m_pBuffer = (AudioSegment *) VOX_ALLOC(nbSegments * sizeof(AudioSegment) + nbExtraBytes);

	if(m_audioSegments.m_pBuffer)
	{
		m_audioSegments.m_nbSegments = nbSegments;
	}
	else
	{
		return;
	}

	// Create vector of vectors to contain cue information
	m_segmentsCues.reserve(nbSegments);
	m_segmentsCues = DOUBLE_VECTOR(s32)(nbSegments);
}


void DecoderNative::CreateStatesContainer(s32 nbStates)
{
	// Create array of states
	m_states.m_pPlaylistIndexes = (s32 *) VOX_ALLOC(nbStates * sizeof(s32));

	if(m_states.m_pPlaylistIndexes)
	{
		m_states.m_nbStates = nbStates;
	}
}


// NOTE : If (on file) memory size of the TransitionRule structure is larger than the memory
// occupied by the structure in the array 'm_pBuffer', allocate extra bytes so that the object
// written doesn't overflow the array (even if it's only padding).

void DecoderNative::CreateTransitionRulesContainer(s32 nbRules, s32 ruleSize)
{
	s32 nbExtraBytes = ruleSize - sizeof(TransitionRule);

	// Create array of rules
	m_transitionRules.m_pBuffer = (TransitionRule *) VOX_ALLOC(nbRules * sizeof(TransitionRule) + nbExtraBytes);

	if(m_transitionRules.m_pBuffer)
	{
		m_transitionRules.m_nbRules = nbRules;
	}
}


void DecoderNative::CreateTransitionsContainer(s32 nbStates)
{
	// Create vector of vectors to contain transitions information
	m_transitions.reserve(nbStates);
	m_transitions = DOUBLE_VECTOR(TransitionParams)(nbStates);
}


DecoderCursorInterface* DecoderNative::CreateNewCursor( StreamCursorInterface* pStreamCursor )
{
	return VOX_NEW DecoderNativeCursor(this,pStreamCursor);
}

void DecoderNative::DestroyCursor(DecoderCursorInterface* pDecoderCursor)
{
	VOX_DELETE( (DecoderNativeCursor*)pDecoderCursor);
}


///

DecoderNativeCursor::DecoderNativeCursor(DecoderInterface* pDecoder, StreamCursorInterface* pStreamCursor)
: DecoderCursorInterface( pDecoder, pStreamCursor )
, m_pNativeChunks(0)
, m_pAudioSegments(0)
, m_pStates(0)
, m_pTransitionRules(0)
, m_pTransitions(0)
, m_pSegmentsCues(0)
, m_pStateLabels(0)
, m_pPlaylists(0)
#if !defined(_NN_CTR) && !defined(_PS3)
, m_pFmtExtentedInfos(0)
#endif
, m_pSubDecoder(0)
, m_decodeCount(0)
#if VOX_NATIVE_REDUCE_LATENCY
, m_pSubDecoderOldState(0)
, m_pSubDecoderRecentState(0)
, m_nbBytesSinceOldSnapshot(0)
, m_nbBytesSinceRecentSnapshot(0)
, m_maxRewindBytes(0)
, m_nbBytesSinceLastTransition(0)
#endif
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderNativeCursor::DecoderNativeCursor", vox::VoxThread::GetCurThreadId());

	m_pNativeChunks = ((DecoderNative*)m_pDecoder)->GetNativeChunks();
	if(((DecoderNative*)m_pDecoder)->NeedParsing())
	{	
		if(ParseFile())
		{
			((DecoderNative*)m_pDecoder)->SetParsed();
		}
		else
		{
			m_trackParams.Reset();
			return;
		}
	}
	
	// Get segments and cues (are constructed in ParseFile() when first cursor is created).
	m_pAudioSegments = ((DecoderNative*)m_pDecoder)->GetAudioSegments();
	m_pSegmentsCues = ((DecoderNative*)m_pDecoder)->GetSegmentsCues();
	m_pTransitionRules = ((DecoderNative*)m_pDecoder)->GetTransitionRules();
	m_pTransitions = ((DecoderNative*)m_pDecoder)->GetTransitions();
	m_pStateLabels = ((DecoderNative*)m_pDecoder)->GetStateLabels();
	m_pStates = ((DecoderNative*)m_pDecoder)->GetStates();

#if !defined(_NN_CTR) && !defined(_PS3)
	m_pFmtExtentedInfos = ((DecoderNative*)m_pDecoder)->GetFmtExtendedInfos();
#endif

	// Create a copy of the playlist manager owned by decoder
	NativePlaylistsManager	*pPlaylists;
	pPlaylists = ((DecoderNative*)m_pDecoder)->GetPlaylistsManager();
	m_pPlaylists = (NativePlaylistsManager *) VOX_NEW NativePlaylistsManager(*pPlaylists);

	if(!m_pPlaylists)
	{
		m_trackParams.Reset();
		return;
	}

	if(!m_pPlaylists->IsValid())
	{
		m_trackParams.Reset();
		return;
	}

	if(m_pNativeChunks->m_formatChunk.m_format.m_compressionCode == k_ccPCM)
	{
		m_pSubDecoder = VOX_NEW VoxNativeSubDecoderPCM(pStreamCursor, m_pNativeChunks, m_pStates, m_pAudioSegments,
													   m_pSegmentsCues, m_pTransitionRules, m_pTransitions,
													   m_pStateLabels, m_pPlaylists);

#if VOX_NATIVE_REDUCE_LATENCY
		m_pSubDecoderOldState = VOX_NEW NativeSubDecoderPCMState(m_pPlaylists);
		m_pSubDecoderRecentState = VOX_NEW NativeSubDecoderPCMState(m_pPlaylists);
#endif
	}
	else if(m_pNativeChunks->m_formatChunk.m_format.m_compressionCode == k_ccIMAADPCM)
	{
		m_pSubDecoder = VOX_NEW VoxNativeSubDecoderIMAADPCM(pStreamCursor, m_pNativeChunks, m_pStates, m_pAudioSegments,
															m_pSegmentsCues, m_pTransitionRules, m_pTransitions,
															m_pStateLabels, m_pPlaylists);

#if VOX_NATIVE_REDUCE_LATENCY
		m_pSubDecoderOldState = VOX_NEW NativeSubDecoderIMAADPCMState(m_pPlaylists);
		m_pSubDecoderRecentState = VOX_NEW NativeSubDecoderIMAADPCMState(m_pPlaylists);
#endif
	}
#if !defined(_NN_CTR) && !defined(_PS3)
	else if(m_pNativeChunks->m_formatChunk.m_format.m_compressionCode == k_ccMSADPCM)
	{
		m_pSubDecoder = VOX_NEW VoxNativeSubDecoderMSADPCM(pStreamCursor, m_pNativeChunks, m_pStates, m_pAudioSegments,
														   m_pSegmentsCues, m_pTransitionRules, m_pTransitions,
														   m_pStateLabels, m_pPlaylists, m_pFmtExtentedInfos);

#if VOX_NATIVE_REDUCE_LATENCY
		m_pSubDecoderOldState = VOX_NEW NativeSubDecoderMSADPCMState(m_pPlaylists);
		m_pSubDecoderRecentState = VOX_NEW NativeSubDecoderMSADPCMState(m_pPlaylists);
#endif
	}
#endif // !defined(_NN_CTR) ...

	VOX_ASSERT_MSG(m_pSubDecoder, "Could not initialize Vox native subdecoder");
	if(m_pSubDecoder)
	{
		m_trackParams = m_pSubDecoder->GetTrackParams();
	}
	else
	{
		m_trackParams.Reset();
		return;
	}

#if VOX_NATIVE_REDUCE_LATENCY
	if(m_pSubDecoderOldState != 0 && m_pSubDecoderRecentState != 0)
	{
		if(m_pSubDecoderOldState->m_pPlaylists != 0 && m_pSubDecoderRecentState->m_pPlaylists != 0)
		{
			m_maxRewindBytes = (s32) ((f32) (VOX_NATIVE_MAX_DATA_OVERWRITE_TIME * m_trackParams.samplingRate * m_trackParams.numChannels) / 500.0f );
		}
		else
		{
			m_trackParams.Reset();
			return;
		}
	}
	else
	{
		m_trackParams.Reset();
		return;
	}
#endif
}
	

DecoderNativeCursor::~DecoderNativeCursor()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderNativeCursor::~DecoderNativeCursor", vox::VoxThread::GetCurThreadId());

	if(m_pSubDecoder)
	{
		VOX_DELETE(m_pSubDecoder);
		m_pSubDecoder = 0;
	}

#if VOX_NATIVE_REDUCE_LATENCY
	if(m_pSubDecoderOldState)
	{
		VOX_DELETE(m_pSubDecoderOldState);
		m_pSubDecoderOldState = 0;
	}

	if(m_pSubDecoderRecentState)
	{
		VOX_DELETE(m_pSubDecoderRecentState);
		m_pSubDecoderRecentState = 0;
	}
#endif

	if(m_pPlaylists)
	{
		VOX_DELETE(m_pPlaylists);
		m_pPlaylists = 0;
	}
}


s32 DecoderNativeCursor::Decode(void* outputBuffer, s32 nbBytes)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderNativeCursor::Decode", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_pSubDecoder, "Not Vox native subdecoder, cannot decode\n");

	if(m_pSubDecoder)
	{
#if VOX_NATIVE_REDUCE_LATENCY
		// Get snapshot of subDecoder state before second decode or if the current snapshot is too old
		if(m_decodeCount == 1 || m_nbBytesSinceRecentSnapshot + nbBytes > m_maxRewindBytes)
		{
			NativeSubDecoderState *pTempState;

			pTempState = m_pSubDecoderOldState;
			m_pSubDecoderOldState = m_pSubDecoderRecentState;
			m_pSubDecoderRecentState = pTempState;

			if(m_pNativeChunks->m_formatChunk.m_format.m_compressionCode == k_ccIMAADPCM)
			{	
				((VoxNativeSubDecoderIMAADPCM *) m_pSubDecoder)->GetState((NativeSubDecoderIMAADPCMState *) m_pSubDecoderRecentState);
			}
			else if(m_pNativeChunks->m_formatChunk.m_format.m_compressionCode == k_ccPCM)
			{
				((VoxNativeSubDecoderPCM *) m_pSubDecoder)->GetState((NativeSubDecoderPCMState *) m_pSubDecoderRecentState);
			}
#if !defined(_NN_CTR) && !defined(_PS3)
			else if(m_pNativeChunks->m_formatChunk.m_format.m_compressionCode == k_ccMSADPCM)
			{	
				((VoxNativeSubDecoderMSADPCM *) m_pSubDecoder)->GetState((NativeSubDecoderMSADPCMState *) m_pSubDecoderRecentState);
			}
#endif

			m_nbBytesSinceOldSnapshot = m_nbBytesSinceRecentSnapshot;
			m_nbBytesSinceRecentSnapshot = 0;
		}
#endif

		// Get native user state
		s32 stateIndex = GetStateIndex();
		
		// If a new user state is requested, transmit it to subdecoder.
		if(stateIndex >= 0)
		{
			m_pSubDecoder->SetState(stateIndex);
			#if VOX_NATIVE_REDUCE_LATENCY
				m_nbBytesSinceLastTransition = 0;
			#endif
		}
		else if(m_decodeCount == 0)
		{
			m_pSubDecoder->SetState(0);
		}

		s32 nbBytesDecoded = m_pSubDecoder->Decode(outputBuffer, nbBytes);

		#if VOX_NATIVE_REDUCE_LATENCY
			if(m_decodeCount > 0)
			{
				m_nbBytesSinceOldSnapshot += nbBytesDecoded;
				m_nbBytesSinceRecentSnapshot += nbBytesDecoded;
				m_nbBytesSinceLastTransition += nbBytesDecoded;
			}
		#endif

		m_decodeCount++;
		return nbBytesDecoded;
	}

	return 0;
}


s32	DecoderNativeCursor::GetStateIndex(void)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());

	if(m_statesList.size() > 0)
	{
		s32 stateIndex = m_statesList.back();
		m_statesList.pop_back();
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return stateIndex;
	}

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return -1;
}


bool DecoderNativeCursor::HasData()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderNativeCursor::HasData", vox::VoxThread::GetCurThreadId());

	if(m_pSubDecoder)
		return m_pSubDecoder->HasData();
	return false;
}


bool DecoderNativeCursor::ParseFile()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderNativeCursor::ParseFile", vox::VoxThread::GetCurThreadId());

	s32 nbSegments;
	s32 nbCues;
	s32 nbGroups;
	s32 nbPlaylistElements;
	s32 nbRules;
	s32 nbTransitions;
	s32 nbStates;						// TODO : All nbXXX variables can be put into one (except for nbStates)
	s32 nbPlaylists;
	s32 cueLocation;
	u8 *pGroup = 0;								// Temporary buffer to contain one group object.
	u8 *pPlaylistElement = 0;					// Temporary buffer to contain one playlist element object.
	NativeChunkHeader		chunkHeader;
	NativePlaylistsManager	*pPlaylists = 0;

	if(!m_pStreamCursor)
		return false;

	// Go to start of file if not already there
	if(m_pStreamCursor->Tell() != 0)
	{
		m_pStreamCursor->Seek(0, ORIGIN_START);
	}

	// Read the Id chunk header
	s32 readsize = m_pStreamCursor->Read((u8*)&chunkHeader, NATIVE_CHUNK_HEADER_SIZE);
	#if VOX_BIG_ENDIAN
		ConvertNativeChunkHeaderToBE(chunkHeader);
	#endif

	// If Id chunk is present, read its its content
	if(readsize == NATIVE_CHUNK_HEADER_SIZE && chunkHeader.m_id == k_idChunkName)
	{
		m_pNativeChunks->m_idChunk.m_header.m_id = k_idChunkName;
		m_pNativeChunks->m_idChunk.m_header.m_size = chunkHeader.m_size;
		m_pStreamCursor->Read((u8*)&m_pNativeChunks->m_idChunk.m_fileInfos, chunkHeader.m_size);
		#if VOX_BIG_ENDIAN
			ConvertFileInfosToBE(m_pNativeChunks->m_idChunk.m_fileInfos);
		#endif
	}
	else
	{
		return false;
	}

	// Get the size of all chunks located between the 'id' and 'data' chunk
	s32 infoChunksSize = m_pNativeChunks->m_idChunk.m_fileInfos.m_dataStart - 2 * NATIVE_CHUNK_HEADER_SIZE -
						 m_pNativeChunks->m_idChunk.m_header.m_size;

	// Create a buffer and read all chunks located between the 'id' and 'data' chunk into it.
	u8 *pInfoChunksBuffer = (u8 *) VOX_ALLOC(infoChunksSize);

	if(!pInfoChunksBuffer)
		return false;

	m_pStreamCursor->Read(pInfoChunksBuffer, infoChunksSize);

	s32 nbBytesRead = 0;

	while(nbBytesRead < infoChunksSize)
	{
		memcpy(&chunkHeader, pInfoChunksBuffer + nbBytesRead, NATIVE_CHUNK_HEADER_SIZE);
		#if VOX_BIG_ENDIAN
			ConvertNativeChunkHeaderToBE(chunkHeader);
		#endif
		nbBytesRead += NATIVE_CHUNK_HEADER_SIZE;

		if(chunkHeader.m_id == k_formatChunkName)
		{
			m_pNativeChunks->m_formatChunk.m_header.m_id = k_formatChunkName;
			m_pNativeChunks->m_formatChunk.m_header.m_size = chunkHeader.m_size;

			memcpy(&m_pNativeChunks->m_formatChunk.m_format, pInfoChunksBuffer + nbBytesRead, chunkHeader.m_size);
			#if VOX_BIG_ENDIAN
				ConvertAudioFormatToBE(m_pNativeChunks->m_formatChunk.m_format);
			#endif
			nbBytesRead += chunkHeader.m_size;

			// TODO : See if this value should not be overriden directly in the xml->vxn file transformation.
			m_pNativeChunks->m_formatChunk.m_format.m_bitsPerSample = 16; // Intended to be nb of bits per decoded sample
		}
		else if(chunkHeader.m_id == k_segmentsChunkName)
		{
			nbSegments = *((s32 *) (pInfoChunksBuffer + nbBytesRead));
			#if VOX_BIG_ENDIAN
				ConvertSignedIntToBE(nbSegments);
			#endif
			nbBytesRead += sizeof(s32);

			s32 segmentSize = (chunkHeader.m_size - sizeof(s32)) / nbSegments;
			((DecoderNative*)m_pDecoder)->CreateSegmentsInfoContainers(nbSegments, segmentSize);

			// Get pointers to segments and cues containers
			m_pAudioSegments = ((DecoderNative*)m_pDecoder)->GetAudioSegments();
			m_pSegmentsCues = ((DecoderNative*)m_pDecoder)->GetSegmentsCues();
				
			AudioSegment *segmentsCursor = m_pAudioSegments->m_pBuffer;

			if(segmentsCursor)
			{
				for(int i = 0; i < nbSegments; i++)
				{
					memcpy(segmentsCursor, pInfoChunksBuffer + nbBytesRead, segmentSize);
					#if VOX_BIG_ENDIAN
						ConvertIntBlockToBE((u32 *) segmentsCursor, segmentSize);
					#endif
				
					nbBytesRead += segmentSize;
					segmentsCursor++;

					// Put first queue as start of segment
					cueLocation = 0;
					(*m_pSegmentsCues)[i].push_back(cueLocation);
				}
			}
			else // Decoder's audio segments buffer has not been allocated.
			{
				return false;
			}
		}
		else if(chunkHeader.m_id == k_cuesChunkName)
		{
			SegmentCue segmentCue;

			// Read cues from file
			nbCues = *((s32 *) (pInfoChunksBuffer + nbBytesRead));
			#if VOX_BIG_ENDIAN
				ConvertSignedIntToBE(nbCues);
			#endif
			nbBytesRead += sizeof(s32);
			s32 cueSize = (chunkHeader.m_size - sizeof(s32)) / nbCues;

			// Add cues gotten 
			for(int i = 0; i < nbCues; i++)
			{
				memcpy(&segmentCue, pInfoChunksBuffer + nbBytesRead, cueSize);
				#if VOX_BIG_ENDIAN
					ConvertIntBlockToBE((u32 *) &segmentCue, cueSize);
				#endif
				nbBytesRead += cueSize;
					
				// Create a CueLocation object from the file infos
				cueLocation = segmentCue.m_sampleOffset;

				// Add cue location to vector of associate segment
				(*m_pSegmentsCues)[segmentCue.m_segmentIndex].push_back(cueLocation);
			}
		}
		else if(chunkHeader.m_id == k_groupsChunkName)
		{
			nbGroups = *((s32 *) (pInfoChunksBuffer + nbBytesRead));
			#if VOX_BIG_ENDIAN
				ConvertSignedIntToBE(nbGroups);
			#endif
			nbBytesRead += sizeof(s32);

			s32 groupSize = (chunkHeader.m_size - sizeof(s32)) / nbGroups;
			pGroup = (u8 *) VOX_ALLOC(groupSize);

			if(pGroup)
			{
				for(int i = 0; i < nbGroups; i++)
				{
					memcpy(pGroup, pInfoChunksBuffer + nbBytesRead, groupSize);
					#if VOX_BIG_ENDIAN
						ConvertIntBlockToBE((u32 *) pGroup, groupSize);
					#endif
					nbBytesRead += groupSize;
					pPlaylists->AddGroup((GroupInfos *) pGroup);
					if(!pPlaylists->IsValid())
						return false;
				}
			}
			else
			{
				return false;
			}
		}
		else if(chunkHeader.m_id == k_playlistElementsChunkName)
		{
			nbPlaylistElements = *((s32 *) (pInfoChunksBuffer + nbBytesRead));
			#if VOX_BIG_ENDIAN
				ConvertSignedIntToBE(nbPlaylistElements);
			#endif
			nbBytesRead += sizeof(s32);

			s32 playlistElementSize = (chunkHeader.m_size - sizeof(s32)) / nbPlaylistElements;
			pPlaylistElement = (u8 *) VOX_ALLOC(playlistElementSize);

			if(pPlaylistElement)
			{
				for(int i = 0; i < nbPlaylistElements; i++)
				{
					memcpy(pPlaylistElement, pInfoChunksBuffer + nbBytesRead, playlistElementSize);
					#if VOX_BIG_ENDIAN
						ConvertIntBlockToBE((u32 *) pPlaylistElement, playlistElementSize);
					#endif
					nbBytesRead += playlistElementSize;
					pPlaylists->AddPlaylistElement((PlaylistElementInfos *) pPlaylistElement);
					if(!pPlaylists->IsValid())
						return false;
				}
			}
			else
			{
				return false;
			}
		}
		else if(chunkHeader.m_id == k_rulesChunkName)
		{
			nbRules = *((s32 *) (pInfoChunksBuffer + nbBytesRead));
			#if VOX_BIG_ENDIAN
				ConvertSignedIntToBE(nbRules);
			#endif
			nbBytesRead += sizeof(s32);

			s32 ruleSize = (chunkHeader.m_size - sizeof(s32)) / nbRules;
			((DecoderNative*)m_pDecoder)->CreateTransitionRulesContainer(nbRules, ruleSize);

			// Get pointers to rules container
			m_pTransitionRules = ((DecoderNative*)m_pDecoder)->GetTransitionRules();
				
			TransitionRule *pRulesCursor = m_pTransitionRules->m_pBuffer;

			if(pRulesCursor)
			{
				for(int i = 0; i < nbRules; i++)
				{
					memcpy(pRulesCursor, pInfoChunksBuffer + nbBytesRead, ruleSize);
					#if VOX_BIG_ENDIAN
						ConvertIntBlockToBE((u32 *) pRulesCursor, ruleSize);
					#endif
					nbBytesRead += ruleSize;
					pRulesCursor++;
				}
			}
			else // Decoder's transition rules buffer has not been allocated.
			{
				return false;
			}
		}
		else if(chunkHeader.m_id == k_playlistsChunkName)
		{
			nbPlaylists = *((s32 *) (pInfoChunksBuffer + nbBytesRead));
			#if VOX_BIG_ENDIAN
				ConvertSignedIntToBE(nbPlaylists);
			#endif
			nbBytesRead += sizeof(s32);

			s32 playlistSize = (chunkHeader.m_size - 1 * sizeof(s32)) / nbPlaylists;

			// Create the playlists container and get a pointer to it.
			((DecoderNative*)m_pDecoder)->CreatePlaylistsContainer(nbPlaylists);
			pPlaylists = ((DecoderNative*)m_pDecoder)->GetPlaylistsManager();
				
			if(pPlaylists->IsValid())
			{
				PlaylistInfos playlistInfos;
				for(int i = 0; i < nbPlaylists; i++)
				{
					memcpy(&playlistInfos, pInfoChunksBuffer + nbBytesRead, playlistSize);
					#if VOX_BIG_ENDIAN
						ConvertIntBlockToBE((u32 *) &playlistInfos, playlistSize);
					#endif
					nbBytesRead += playlistSize;
					pPlaylists->AddPlaylist(i, &playlistInfos);
					if(!pPlaylists->IsValid()) // Playlist manager not valid because playlist insertion failed.
						return false;
				}
			}
		}
		else if(chunkHeader.m_id == k_statesChunkName)
		{
			nbStates = *((s32 *) (pInfoChunksBuffer + nbBytesRead));

			#if VOX_BIG_ENDIAN
				ConvertSignedIntToBE(nbStates);
			#endif
			nbBytesRead += sizeof(s32);
			s32 stateSize = (chunkHeader.m_size - sizeof(s32)) / nbStates;

			// Create the states container and get a pointer to it.
			((DecoderNative*)m_pDecoder)->CreateStatesContainer(nbStates);
			m_pStates = ((DecoderNative*)m_pDecoder)->GetStates();
			
			if(m_pStates->m_pPlaylistIndexes)
			{
				// Get pointer to state labels container
				m_pStateLabels = ((DecoderNative*)m_pDecoder)->GetStateLabels();
				
				StateInfos state;
				VOX_STRING label;
				for(int i = 0; i < nbStates; i++)
				{
					memcpy(&state, pInfoChunksBuffer + nbBytesRead, stateSize);
					#if VOX_BIG_ENDIAN
						ConvertStateInfosToBE(state);
					#endif
					nbBytesRead += stateSize;

					m_pStates->m_pPlaylistIndexes[i] = state.m_playlistIndex;
					label.append(state.m_label);
					(*m_pStateLabels)[label] = i;
					label.clear();
				}
			}
			else // Decoder's state buffer has not been allocated.
			{
				return false;
			}
		}
		else if(chunkHeader.m_id == k_transitionsChunkName)
		{
			nbTransitions = *((s32 *) (pInfoChunksBuffer + nbBytesRead));
			#if VOX_BIG_ENDIAN
				ConvertSignedIntToBE(nbTransitions);
			#endif
			nbBytesRead += sizeof(s32);
			s32 transitionSize = (chunkHeader.m_size - sizeof(s32)) / nbTransitions;

			((DecoderNative*)m_pDecoder)->CreateTransitionsContainer(nbStates);

			// Get pointers to transitions container
			m_pTransitions = ((DecoderNative*)m_pDecoder)->GetTransitions();
				
			Transition transition;

			for(int i = 0; i < nbTransitions; i++)
			{
				memcpy(&transition, pInfoChunksBuffer + nbBytesRead, transitionSize);
				#if VOX_BIG_ENDIAN
					ConvertIntBlockToBE((u32 *) &transition, transitionSize);
				#endif
				nbBytesRead += transitionSize;
				(*m_pTransitions)[transition.m_fromState].push_back(transition.m_parameters);
			}
		}
#if !defined(_NN_CTR) && !defined(_PS3)
		else if(chunkHeader.m_id == k_msAdpcmExtensionChunkName)
		{
			((DecoderNative*)m_pDecoder)->CreateFmtExtendedInfosContainer();
			m_pFmtExtentedInfos = ((DecoderNative*)m_pDecoder)->GetFmtExtendedInfos();
			if(m_pFmtExtentedInfos)
			{
				m_pFmtExtentedInfos->m_cbSize = chunkHeader.m_size;
				m_pFmtExtentedInfos->m_samplesPerBlock = *((s16*) (pInfoChunksBuffer + nbBytesRead));
				nbBytesRead += 2;
				m_pFmtExtentedInfos->m_nbCoefficients = *((s16*) (pInfoChunksBuffer + nbBytesRead));
				nbBytesRead += 2;

				for(s32 i = 0; i < m_pFmtExtentedInfos->m_nbCoefficients; i++)
				{
					m_pFmtExtentedInfos->m_coefficients[i][0] = *((s16*) (pInfoChunksBuffer + nbBytesRead));
					nbBytesRead += 2;
					m_pFmtExtentedInfos->m_coefficients[i][1] = *((s16*) (pInfoChunksBuffer + nbBytesRead));
					nbBytesRead += 2;
				}
			}
		}
#endif
		else // skip other chunk
		{
			nbBytesRead += chunkHeader.m_size;
		}
	}	// End of while

	// Set cues associated to pre-entry, post-exit and end of segment.
	SetImplicitSegmentCues();

	VOX_FREE(pGroup);
	VOX_FREE(pPlaylistElement);
	VOX_FREE(pInfoChunksBuffer);
	return true;
}



void DecoderNativeCursor::Reset(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderNativeCursor::Reset", vox::VoxThread::GetCurThreadId());

	if(m_pSubDecoder)
	{
		m_pSubDecoder->Reset();
		m_decodeCount = 0;

		#if VOX_NATIVE_REDUCE_LATENCY
			m_nbBytesSinceOldSnapshot = 0;
			m_nbBytesSinceRecentSnapshot = 0;
			m_nbBytesSinceLastTransition = 0;
		#endif

		// Empty states list
		VOX_MUTEX_LEVEL_1(m_mutex.Lock());
		m_statesList.clear();
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	}
}



#if VOX_NATIVE_REDUCE_LATENCY
s32 DecoderNativeCursor::GetRewindLimit(void)
{
	if(m_nbBytesSinceRecentSnapshot > m_nbBytesSinceLastTransition)
	{
		return 0;
	}
	else if(m_nbBytesSinceOldSnapshot > m_nbBytesSinceLastTransition)
	{
		return m_nbBytesSinceRecentSnapshot;
	}

	return m_nbBytesSinceOldSnapshot;
}


void DecoderNativeCursor::Rewind(s32 nbBytes)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderNativeCursor::Rewind", vox::VoxThread::GetCurThreadId());

	if(m_pSubDecoder)
	{
		s32 nbBytesToSkip;

		if(nbBytes <= m_nbBytesSinceRecentSnapshot) // Get the subdecoder's recent snapshot
		{
			if(m_pNativeChunks->m_formatChunk.m_format.m_compressionCode == k_ccIMAADPCM)
			{
				((VoxNativeSubDecoderIMAADPCM *) m_pSubDecoder)->SetState((NativeSubDecoderIMAADPCMState *) m_pSubDecoderRecentState);
			}
			else if(m_pNativeChunks->m_formatChunk.m_format.m_compressionCode == k_ccPCM)
			{
				((VoxNativeSubDecoderPCM *) m_pSubDecoder)->SetState((NativeSubDecoderPCMState *) m_pSubDecoderRecentState);
			}
#if !defined(_NN_CTR) && !defined(_PS3)
			else if(m_pNativeChunks->m_formatChunk.m_format.m_compressionCode == k_ccMSADPCM)
			{
				((VoxNativeSubDecoderMSADPCM *) m_pSubDecoder)->SetState((NativeSubDecoderMSADPCMState *) m_pSubDecoderRecentState);
			}
#endif
			// Determine by how many bytes we should advance in time to build the pre-decode state
			nbBytesToSkip = m_nbBytesSinceRecentSnapshot - nbBytes;
		}
		else if(nbBytes <= m_nbBytesSinceOldSnapshot) // Get the subdecoder's old snapshot
		{
			if(m_pNativeChunks->m_formatChunk.m_format.m_compressionCode == k_ccIMAADPCM)
			{
				((VoxNativeSubDecoderIMAADPCM *) m_pSubDecoder)->SetState((NativeSubDecoderIMAADPCMState *) m_pSubDecoderOldState);
			}
			else if(m_pNativeChunks->m_formatChunk.m_format.m_compressionCode == k_ccPCM)
			{
				((VoxNativeSubDecoderPCM *) m_pSubDecoder)->SetState((NativeSubDecoderPCMState *) m_pSubDecoderOldState);
			}
#if !defined(_NN_CTR) && !defined(_PS3)
			else if(m_pNativeChunks->m_formatChunk.m_format.m_compressionCode == k_ccMSADPCM)
			{
				((VoxNativeSubDecoderMSADPCM *) m_pSubDecoder)->SetState((NativeSubDecoderMSADPCMState *) m_pSubDecoderOldState);
			}
#endif

			// Determine by how many bytes we should advance in time to build the pre-decode state
			nbBytesToSkip = m_nbBytesSinceOldSnapshot - nbBytes;
		}
		else // Trying to rewind before the old snapshot
		{
			VOX_WARNING_LEVEL_4("%s", "Trying to rewind native decoder before oldest snapshot");
			return;
		}

		// Build the subdecoder's pre-decode state by emulating a decode until the required position.
		if(nbBytesToSkip > 0)
		{
			m_pSubDecoder->EmulateDecode(nbBytesToSkip);
		}
	}
}
#endif // VOX_NATIVE_REDUCE_LATENCY


s32 DecoderNativeCursor::Seek( u32 sampleNum )
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderNativeCursor::Seek", vox::VoxThread::GetCurThreadId());
	VOX_ASSERT_MSG(m_pSubDecoder, "Not Vox native subdecoder, cannot Seek\n");

	if(m_pSubDecoder)
		return m_pSubDecoder->Seek(sampleNum);

	return -1;
}


void DecoderNativeCursor::SetImplicitSegmentCues(void)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderNativeCursor::SetImplicitSegmentCues", vox::VoxThread::GetCurThreadId());

	s32 cueLocation;
	s32 nbCues;
	s32 nbSegments = m_pAudioSegments->m_nbSegments;

	// For all segments, set last cue as end of segment
	for(int i = 0; i < nbSegments; i++)
	{
		nbCues = (*m_pSegmentsCues)[i].size();
		// If pre-entry cue hasn't been provided, set it as segment start.
		if(nbCues == 1)
		{
			cueLocation = 0;
			(*m_pSegmentsCues)[i].push_back(cueLocation);
		}
		// If post-exit cue hasn't been provided, set it as segment end.
		if(nbCues < 3)
		{
			cueLocation = m_pAudioSegments->m_pBuffer[i].m_nbSamples - 1;
			(*m_pSegmentsCues)[i].push_back(cueLocation);
		}

		// Set last cue as segment end
		cueLocation = m_pAudioSegments->m_pBuffer[i].m_nbSamples - 1;
		(*m_pSegmentsCues)[i].push_back(cueLocation);
	}
}


void DecoderNativeCursor::SetInteractiveMusicState(const char *stateLabel)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DECODER, "DecoderNativeCursor::SetInteractiveMusicState", vox::VoxThread::GetCurThreadId());

	VOX_MUTEX_LEVEL_1(m_mutex.Lock());

	// Get the state index from map and put it into the states list.
	VOX_STRING label(stateLabel);
	STRING_MAP(s32,StringCompare)::const_iterator iterator = m_pStateLabels->find(label);
	if(iterator != m_pStateLabels->end())
	{
		m_statesList.push_front(iterator->second);
	}

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}


void DecoderNativeCursor::SetLoop( bool loop )
{
	VOX_ASSERT_MSG(m_pSubDecoder, "Not Vox native subdecoder, cannot SetLoop\n");

	if(m_pSubDecoder)
		m_pSubDecoder->SetLoop(loop);
}


} //namespace vox
