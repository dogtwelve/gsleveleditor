#include "StdAfx.h"
#include "vox_default_config.h"

#if VOX_DRIVER_USE_ALSA && VOX_ALSA_DRIVER_PLATFORM

#include "vox_driver_alsa.h"
#include "vox_macro.h"
#include "vox_memory.h"
#include "vox.h"


namespace vox {

DriverInterface* CreateDriver()
{
	return VOX_NEW DriverAlsa();
}
	
	
DriverAlsaSource::DriverAlsaSource(void * trackParam, void* driverParam, u32 sourceId):
DriverCallbackSourceInterface(trackParam, driverParam, sourceId)
{
	Init();
}

DriverAlsaSource::~DriverAlsaSource()//**-**
{
}

void DriverAlsaSource::PrintDebug()
{
}


	
//*** DriverAlsa ***//

#define AU_OUTPUT_BUS 0
	
DriverAlsa::DriverAlsa()
{
	m_pcm_handle = 0;
	m_pcm_callback = 0;
	m_buffer_size = 0;
	m_period_size = 0;
	m_updateThread = 0;

	Init(0);
}

DriverAlsa::~DriverAlsa()
{
	Shutdown();
}

#define ALSA_CHECKSTATUS(X) if(X < 0){VOX_WARNING_LEVEL_1("%s:%d : Error in driver : %d : %s", __FUNCTION__, __LINE__, X, snd_strerror(X));}
#define ALSA_RETURN_ON_ERROR(X) { \
									AU_CHECKSTATUS((X)); \
									if((X) != 0) \
									{ \
										if(hw_params) \
											snd_pcm_hw_params_free (hw_params); \
										if(sw_params) \
											snd_pcm_sw_params_free (sw_params); \
										VOX_MUTEX_LEVEL_1(m_mutex.Unlock()); \
										return; \
									} \
								} \


void DriverAlsa::Init(void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverAlsa::Init", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	
	VOX_WARNING_LEVEL_5("Starting Alsa init",0);

	DriverCallbackInterface::Init(param);
	
	s32 status = 0;
	s32 error = 0;
	snd_pcm_hw_params_t *hw_params = 0;
	snd_pcm_sw_params_t *sw_params = 0;

	VOX_ASSERT(m_period_size <= m_buffer_size);

	//HW init

	error = snd_pcm_open (&m_pcm_handle, "default", SND_PCM_STREAM_PLAYBACK, 0);
	ALSA_RETURN_ON_ERROR(error);

	error = snd_pcm_hw_params_malloc (&hw_params);
	ALSA_RETURN_ON_ERROR(error);
	   
	error = snd_pcm_hw_params_any (m_pcm_handle, hw_params);
	ALSA_RETURN_ON_ERROR(error);

	error = snd_pcm_hw_params_set_access (m_pcm_handle, hw_params, SND_PCM_ACCESS_RW_INTERLEAVED);
	ALSA_RETURN_ON_ERROR(error);
			 
	error = snd_pcm_hw_params_set_format (m_pcm_handle, hw_params, SND_PCM_FORMAT_S16_LE);
	ALSA_RETURN_ON_ERROR(error);

	u32 sampleRate = VOX_ALSA_DRIVER_PREFERRED_RATE;
	error = snd_pcm_hw_params_set_rate_near (m_pcm_handle, hw_params, &sampleRate, 0);
	ALSA_RETURN_ON_ERROR(error);

	error = snd_pcm_hw_params_set_channels (m_pcm_handle, hw_params, 2);
	ALSA_RETURN_ON_ERROR(error);

	// Calculate the number of desired periods
	u32 nbPeriods = VOX_ALSA_API_DRIVER_BUFFER_LENGTH / VOX_ALSA_DRIVER_BUFFER_LENGTH;

	// Calculate desired period and buffer sizes
	#if VOX_ALSA_DRIVER_STREAM_MODE == VOX_ALSA_DRIVER_STREAM_MODE_THREAD
		m_buffer_size = (VOX_ALSA_DRIVER_PREFERRED_RATE) * VOX_THREAD_UPDATE_DT * nbPeriods / 1000;
		m_period_size = (VOX_ALSA_DRIVER_PREFERRED_RATE) * VOX_THREAD_UPDATE_DT / 1000;
	#else
		m_buffer_size = (VOX_ALSA_DRIVER_PREFERRED_RATE) * VOX_ALSA_API_DRIVER_BUFFER_LENGTH;
		m_period_size = (VOX_ALSA_DRIVER_PREFERRED_RATE) * VOX_ALSA_DRIVER_BUFFER_LENGTH;
	#endif

	// Set period size (note that value returned is not necessarily desired value)
	error = snd_pcm_hw_params_set_period_size_near (m_pcm_handle, hw_params, &m_period_size, NULL);
	ALSA_RETURN_ON_ERROR(error);

	// Reevaluate the number of periods so that "nbPeriods * m_period_size >= m_buffer_size)
	nbPeriods = (m_buffer_size / m_period_size) + (m_buffer_size % m_period_size != 0);
	error = snd_pcm_hw_params_set_periods_near(m_pcm_handle, hw_params, &nbPeriods, 0);
	ALSA_RETURN_ON_ERROR(error);

	// Set hardware parameters (note that this method automatically calls snd_pcm_prepare() when it succeeds)
	error = snd_pcm_hw_params (m_pcm_handle, hw_params);
	ALSA_RETURN_ON_ERROR(error);

	// Get effective buffer size (in frames)
	error = snd_pcm_hw_params_get_buffer_size(hw_params, &m_buffer_size);
    ALSA_RETURN_ON_ERROR(error);

	m_outBuffer = (c8*)VOX_ALLOC(m_buffer_size * 4); // * 4 => 2 channels, 2 bytes per sample
	if(!m_outBuffer)
		ALSA_RETURN_ON_ERROR(-1);

	snd_pcm_hw_params_free (hw_params);
	hw_params = 0;

	// Inform parent class about driver's callback period (used for pitch ramping)
	DriverCallbackSourceInterface::SetDriverCallbackPeriod((f32) m_period_size / (f32) sampleRate);

	// Inform parent class about driver's sample rate
	DriverCallbackSourceInterface::SetDriverSampleRate((s32) sampleRate);

	// SW init

	error = snd_pcm_sw_params_malloc (&sw_params);
	ALSA_RETURN_ON_ERROR(error);

	error = snd_pcm_sw_params_current (m_pcm_handle, sw_params);
	ALSA_RETURN_ON_ERROR(error);

	error = snd_pcm_sw_params_set_avail_min (m_pcm_handle, sw_params, m_buffer_size);
	ALSA_RETURN_ON_ERROR(error);

	// Avoid stream start before snd_pcm_start() call (to enable full buffer fill before actual start)
	error = snd_pcm_sw_params_set_start_threshold (m_pcm_handle, sw_params, m_buffer_size + 1);
	ALSA_RETURN_ON_ERROR(error);

	error = snd_pcm_sw_params (m_pcm_handle, sw_params);
	ALSA_RETURN_ON_ERROR(error);

	snd_pcm_sw_params_free (sw_params);
	ALSA_RETURN_ON_ERROR(error);

	// Get the number of samples that can be filled in buffer (at this point, this is m_buffer_size).
	snd_pcm_sframes_t avail = snd_pcm_avail_update(m_pcm_handle);
	if(avail > m_buffer_size)
	{
		avail = m_buffer_size;
	}

	// Fill buffer completely before starting stream
	_FillBuffer((s16*)m_outBuffer, (s32)avail);
	s32 err = snd_pcm_writei(m_pcm_handle, m_outBuffer, avail);
	ALSA_CHECKSTATUS(err);

	SetDefaultParameter();

	// Start thread or register callback
#if VOX_ALSA_DRIVER_STREAM_MODE == VOX_ALSA_DRIVER_STREAM_MODE_THREAD
	m_updateThread = VOX_NEW VoxThread(&vox::DriverAlsa::UpdateThreaded, this, 0, "DriverAlsa::Update");
	if(!m_updateThread)
	{
		VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
		return;
	}
#else
	error = snd_async_add_pcm_handler(&m_pcm_callback, m_pcm_handle, DriverAlsa::playbackCallback, this);
	ALSA_RETURN_ON_ERROR(error);
#endif
	
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());

	// Start the pcm stream
	error = snd_pcm_start(m_pcm_handle);

	ALSA_CHECKSTATUS(error);

	if(error == 0)
		m_audioUnitActive = true;

	VOX_WARNING_LEVEL_5("End of alsa init",0);
}

void DriverAlsa::Shutdown()
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_DRIVER, "DriverAlsa::Shutdown", vox::VoxThread::GetCurThreadId());
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());

	if(m_pcm_handle)
	{
#if VOX_ALSA_DRIVER_STREAM_MODE == VOX_ALSA_DRIVER_STREAM_MODE_THREAD
		if(m_updateThread)
		{
			VOX_DELETE(m_updateThread);
			m_updateThread = 0;
		}
#endif

		m_audioUnitActive =	false;
		s32 status = snd_pcm_drop(m_pcm_handle);
		AU_CHECKSTATUS(status);
		status = snd_pcm_close(m_pcm_handle);
		AU_CHECKSTATUS(status);
		m_pcm_handle = 0;
		m_pcm_callback = 0;

		if(m_outBuffer)
		{
			VOX_FREE(m_outBuffer);
			m_outBuffer = 0;
		}
	}

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverAlsa::Suspend()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_audioUnitActive)
	{
		s32 status = snd_pcm_pause(m_pcm_handle, 0);
		AU_CHECKSTATUS(status);
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverAlsa::Resume()
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(m_audioUnitActive)
	{
		s32 status = snd_pcm_pause(m_pcm_handle, 1);
		AU_CHECKSTATUS(status);
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());	
}

DriverSourceInterface* DriverAlsa::CreateDriverSource(void * trackParam, void* driverParam, s32 priority)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());

	DriverAlsaSource* driverSource = 0;

	if(m_audioUnitActive)
	{
		driverSource = VOX_NEW DriverAlsaSource(trackParam, driverParam, m_nextSourceId);
		if(driverSource)
		{
			m_activeSources.push_back(driverSource);
			m_nextSourceId++;
		}
	}

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
	return driverSource;
}


void DriverAlsa::DestroyDriverSource(DriverSourceInterface* driverSource)
{
	VOX_MUTEX_LEVEL_1(m_mutex.Lock());
	if(driverSource)
	{
		VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> >::iterator it = m_activeSources.begin();
		VOX_LIST<DriverCallbackSourceInterface*, SAllocator<DriverCallbackSourceInterface*> >::iterator end = m_activeSources.end();

		for(; it != end; it++)
		{
			if(*it == driverSource)
			{
				m_activeSources.erase(it);
				break;
			}
		}

		VOX_DELETE( (DriverAlsaSource*)driverSource);
	}
	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}

void DriverAlsa::PrintDebug()
{
}


void DriverAlsa::DoCallback()
{	
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverAlsa::DoCallback", vox::VoxThread::GetCurThreadId());

	VOX_MUTEX_LEVEL_1(m_mutex.Lock());

	if(!m_outBuffer)
		return;

	// Get number of samples that can be overwritten in buffer
	snd_pcm_sframes_t avail = snd_pcm_avail_update(m_pcm_handle);

	// Fill samples in buffer only when there is a minimum amount (period size / 2).
	if(avail >= (m_period_size >> 1))
	{
		// Don't put more than m_buffer_size samples
		if(avail > m_buffer_size)
		{
			avail = m_buffer_size; 
		}
		_FillBuffer((s16*)m_outBuffer, (s32)avail);
		s32 err = snd_pcm_writei(m_pcm_handle, m_outBuffer, avail);
		ALSA_CHECKSTATUS(err);
		if(err < 0) 
		{
			Recover(err);
		}
	}

	VOX_MUTEX_LEVEL_1(m_mutex.Unlock());
}


void DriverAlsa::Recover(s32 errorType)
{
	// If stream is supsended, try resuming it.
	if(errorType == -ESTRPIPE)
    {
        errorType = snd_pcm_resume(m_pcm_handle);
		if(errorType != -ENOSYS)
			return;
	}

	VOX_WARNING_LEVEL_1("Trying to repair pipe", 0);

	errorType = snd_pcm_prepare(m_pcm_handle);
	ALSA_CHECKSTATUS(errorType);
	if(errorType < 0)
	{
		snd_pcm_drop(m_pcm_handle);
		return;
	}

	// Get number of samples that can be overwritten in buffer
	snd_pcm_sframes_t avail = snd_pcm_avail_update(m_pcm_handle);
	if(avail > m_buffer_size)
	{
		avail = m_buffer_size; //don't put more than m_buffer_size
	}
		
	// Write samples to buffer
	errorType = snd_pcm_writei(m_pcm_handle, m_outBuffer, avail);
	ALSA_CHECKSTATUS(errorType);
	if(errorType < 0)
	{
		snd_pcm_drop(m_pcm_handle);
		return;
	}

	// Restart pcm stream
	errorType = snd_pcm_start(m_pcm_handle);
	ALSA_CHECKSTATUS(errorType);
	if(errorType < 0)
	{
		snd_pcm_drop(m_pcm_handle);
	}
}


void DriverAlsa::playbackCallback(snd_async_handler_t *pcm_callback_handler)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverAlsa::playbackCallback", vox::VoxThread::GetCurThreadId());
	if(!pcm_callback_handler)
		return;

	void *private_data = snd_async_handler_get_callback_private(pcm_callback_handler);

	if(private_data)
	{
		((DriverAlsa*)private_data)->DoCallback();
	}
}


void DriverAlsa::UpdateThreaded(void* caller, void* param)
{
	VOX_PROFILING_SCOPED_EVENT(__PSE, VOX_PROFILER_EVENT_TYPE_CALLBACK, "DriverAlsa::UpdateThreaded", vox::VoxThread::GetCurThreadId());
	((DriverAlsa*)caller)->DoCallback();
}

}//namespace vox

#endif //VOX_DRIVER_USE_IPHONE_REMOTEIO && VOX_IPHONE_REMOTEIO_DRIVER_PLATFORM
