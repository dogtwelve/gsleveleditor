#include "StdAfx.h"
#include "vox_zip_reader.h"
#include "vox_filesystem.h"
#include "MSHeaders.h"
#include "vox_macro.h"
#include <string.h>

namespace vox
{

CZipReader::CZipReader(const c8* filename, bool ignoreCase, bool ignorePaths)
: IgnoreCase(ignoreCase)
, IgnorePaths(ignorePaths)
{
	File = 0;
	FileSystemInterface* fs = vox::FileSystemInterface::GetInstance();

	if(fs)
		File = fs->OpenFile((c8*)filename);

	if (File)
	{
		// scan local headers
		m_archiveName = File->GetFilePath();
		while (scanLocalHeader());
	}
}


CZipReader::~CZipReader()
{
	if (File)
	{
		FileSystemInterface* fs = vox::FileSystemInterface::GetInstance();
		fs->CloseFile(File);
	}
}

//! splits filename from zip file into useful filenames and paths
void
CZipReader::extractFilename(SZipFileEntry* entry)
{
	s32 lorfn = entry->header.FilenameLength; // length of real file name

	if (!lorfn)
		return;

	if (IgnoreCase)
	{
		for (u32 i=0; i<entry->zipFileName.length(); ++i)
		{
			char x = entry->zipFileName[i];
			entry->zipFileName[i] = x >= 'A' && x <= 'Z' ? (char) x + 0x20 : (char) x;
		}
	}
	const c8* p = entry->zipFileName.c_str() + lorfn;
	
	// suche ein slash oder den anfang.

	while (*p!='/' && p!=entry->zipFileName.c_str())
	{
		--p;
		--lorfn;
	}

	bool thereIsAPath = p != entry->zipFileName.c_str();

	if (thereIsAPath)
	{
		// there is a path
		++p;
		++lorfn;
	}

	entry->simpleFileName = p;
	entry->path = "";

	// pfad auch kopieren
	if (thereIsAPath)
	{
		lorfn = (s32)(p - entry->zipFileName.c_str());
		
		entry->path = entry->zipFileName.substr( 0, lorfn );

		//entry->path.append(entry->zipFileName, lorfn);
		//entry->path.append ( "" );
	}

	if (!IgnorePaths)
		entry->simpleFileName = entry->zipFileName; // thanks to Pr3t3nd3r for this fix
}

//! scans for a local header, returns false if there is no more local file header.
bool
CZipReader::scanLocalHeader()
{
	c8 tmp[1024];

	SZipFileEntry entry;
	entry.fileDataPosition = 0;
	memset(&entry.header, 0, sizeof(SZIPFileHeader));

	File->Read(&entry.header, sizeof(SZIPFileHeader), 1);

#if VOX_BIG_ENDIAN
	entry.header.Sig = os::byteswap(entry.header.Sig);
	entry.header.VersionToExtract = os::byteswap(entry.header.VersionToExtract);
	entry.header.GeneralBitFlag = os::byteswap(entry.header.GeneralBitFlag);
	entry.header.CompressionMethod = os::byteswap(entry.header.CompressionMethod);
	entry.header.LastModFileTime = os::byteswap(entry.header.LastModFileTime);
	entry.header.LastModFileDate = os::byteswap(entry.header.LastModFileDate);
	entry.header.DataDescriptor.CRC32 = os::byteswap(entry.header.DataDescriptor.CRC32);
	entry.header.DataDescriptor.CompressedSize = os::byteswap(entry.header.DataDescriptor.CompressedSize);
	entry.header.DataDescriptor.UncompressedSize = os::byteswap(entry.header.DataDescriptor.UncompressedSize);
	entry.header.FilenameLength = os::byteswap(entry.header.FilenameLength);
	entry.header.ExtraFieldLength = os::byteswap(entry.header.ExtraFieldLength);
#endif

	if (entry.header.Sig != 0x04034b50 && entry.header.Sig != VOX_ZIP_MAGIC_NUMBER)
		return false; // local file headers end here.

	// read filename
	entry.zipFileName.reserve(entry.header.FilenameLength+2);
	File->Read(tmp, entry.header.FilenameLength, 1);
	tmp[entry.header.FilenameLength] = 0x0;
	entry.zipFileName = tmp;

	extractFilename(&entry);

	// move forward length of extra field.

	if (entry.header.ExtraFieldLength)
		File->Seek(entry.header.ExtraFieldLength, k_nSeekCur);

	// if bit 3 was set, read DataDescriptor, following after the compressed data
	if (entry.header.GeneralBitFlag & ZIP_INFO_IN_DATA_DESCRITOR)
	{
		// read data descriptor
		File->Read(&entry.header.DataDescriptor, sizeof(entry.header.DataDescriptor), 1);
#if VOX_BIG_ENDIAN
		entry.header.DataDescriptor.CRC32 = os::byteswap(entry.header.DataDescriptor.CRC32);
		entry.header.DataDescriptor.CompressedSize = os::byteswap(entry.header.DataDescriptor.CompressedSize);
		entry.header.DataDescriptor.UncompressedSize = os::byteswap(entry.header.DataDescriptor.UncompressedSize);
#endif
	}

	// store position in file
	entry.fileDataPosition = File->Tell();//File->getPos();

	// move forward length of data
	File->Seek(entry.header.DataDescriptor.CompressedSize, k_nSeekCur);

	//#ifdef _DEBUG
	////os::Debuginfo::print("added file from archive", entry.simpleFileName.c_str());
	//#endif

	FileList[entry.simpleFileName] = entry;
	//FileList.push_back(entry);

	return true;
}

bool CZipReader::getFileInfo(const c8* filename, s32 &baseOffset, s32 &fileSize)
{
	VOX_STRING fname(filename);

	if(IgnorePaths)
		deletePathFromFilename(fname);

	if (IgnoreCase)
	{
		for (u32 i = 0; i < fname.length(); ++i)
		{
			char x = fname[i];
			fname[i] = x >= 'A' && x <= 'Z' ? (char) x + 0x20 : (char) x;
		}
	}

	VOX_MAP<VOX_STRING, SZipFileEntry, StringComp, SAllocator<std::pair<const VOX_STRING,SZipFileEntry> > >::const_iterator it = FileList.find(fname);
	if(it == FileList.end())
		return false;
	
	switch(it->second.header.CompressionMethod)
	{
		case 0: // no compression
		{
			baseOffset = it->second.fileDataPosition;
			fileSize = it->second.header.DataDescriptor.UncompressedSize;
			VOX_WARNING_LEVEL_5("Found file %s", filename);
			return true;
		}
		default:
		{
			//os::Printer::log("file has unsupported compression method.", FileList[index].simpleFileName.c_str(), ELL_ERROR);
			return false;
		}
	};
}

// returns count of files in archive
s32
CZipReader::getFileCount()
{
	return FileList.size();
}

// deletes the path from a filename
void
CZipReader::deletePathFromFilename(VOX_STRING& filename)
{
	// delete path from filename
	const c8* p = filename.c_str() + filename.size();

	// search for path separator or beginning

	while (*p!='/' && *p!='\\' && p!=filename.c_str())
		--p;

	if (p != filename.c_str())
	{
		++p;
		filename = p;
	}
}

}
